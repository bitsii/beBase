namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 5));
private static byte[] bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_23 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_25 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_26 = {0x74,0x72,0x75,0x65};
private static byte[] bels_27 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_55 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_56 = {0x67,0x63,0x63};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_59, 9));
private static byte[] bels_60 = {};
private static byte[] bels_61 = {0x63};
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_62, 8));
private static byte[] bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_63, 7));
private static byte[] bels_64 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_66 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 13));
private static byte[] bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_71, 18));
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 30));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 31));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 41));
private static byte[] bels_78 = {0x2F};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 31));
private static byte[] bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 41));
private static byte[] bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 51));
private static byte[] bels_82 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 14));
private static byte[] bels_83 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 19));
private static byte[] bels_84 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 9));
private static byte[] bels_85 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 13));
private static byte[] bels_86 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 2));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 22));
private static byte[] bels_88 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 5));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 6));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 7));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 8));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 9));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 10));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 15));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 11));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_106, 12));
private static byte[] bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_107, 16));
private static byte[] bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_108, 13));
private static byte[] bels_109 = {0x20};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_109, 1));
private static byte[] bels_110 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_50 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_110, 16));
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 100 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 118 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 118 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 118 */
 else  /* Line: 118 */ {
break;
} /* Line: 118 */
} /* Line: 118 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 128 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 131 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 136 */
if (bevp_printSteps.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 139 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 145 */ {
} /* Line: 145 */
return beva_addTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_119_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_122_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_125_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_127_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_128_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpvar_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_11));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 155 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 156 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 156 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 157 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 159 */
} /* Line: 157 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
} /* Line: 156 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_3;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 165 */
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_13));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_14));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_15));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_exeName = bevp_libName;
} /* Line: 171 */
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_16));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_21));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_22));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_23));
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_24));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_25));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_26));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_51_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_27));
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_28));
bevt_50_tmpvar_phold = bevp_params.bem_get_2(bevt_51_tmpvar_phold, bevt_52_tmpvar_phold);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpvar_phold);
bevt_56_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_31));
bevt_55_tmpvar_phold = bevp_params.bem_get_1(bevt_56_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpvar_phold.bem_firstGet_0();
bevt_58_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_32));
bevt_57_tmpvar_phold = bevp_params.bem_get_1(bevt_58_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_72_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 225 */
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_80_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_44));
bevt_82_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpvar_phold, bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_45));
bevt_84_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpvar_phold, bevt_84_tmpvar_phold);
bevt_85_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpvar_phold);
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpvar_phold);
if (bevl_pacm == null) {
bevt_88_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_90_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpvar_phold.bevi_bool) {
bevt_89_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_91_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_91_tmpvar_phold != null && bevt_91_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_91_tmpvar_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpvar_phold);
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_52));
bevt_96_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_95_tmpvar_phold, bevt_96_tmpvar_phold);
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_54));
bevp_emitFlags = bevp_params.bem_get_1(bevt_98_tmpvar_phold);
bevt_100_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_55));
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_56));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_101_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevt_103_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_57));
bevt_104_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_58));
bevt_102_tmpvar_phold = bevp_params.bem_get_2(bevt_103_tmpvar_phold, bevt_104_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_102_tmpvar_phold.bem_firstGet_0();
bevt_107_tmpvar_phold = bevo_4;
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_108_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_60));
bevt_105_tmpvar_phold = bevp_params.bem_get_2(bevt_106_tmpvar_phold, bevt_108_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_105_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_109_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_109_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_61));
} /* Line: 263 */
bevt_112_tmpvar_phold = bevo_5;
bevt_111_tmpvar_phold = bevl_outLang.bem_add_1(bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bem_add_1(bevt_113_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_114_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_115_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_115_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_117_tmpvar_phold = bevo_6;
bevt_116_tmpvar_phold = bevl_outLang.bem_add_1(bevt_117_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_116_tmpvar_phold);
if (bevl_langSources == null) {
bevt_118_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_118_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_119_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_119_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_120_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_120_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_121_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_121_tmpvar_phold != null && bevt_121_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_121_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_122_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_122_tmpvar_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_125_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_existsGet_0();
if (bevt_124_tmpvar_phold.bevi_bool) {
bevt_123_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_126_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_126_tmpvar_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_127_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_127_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_128_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_128_tmpvar_phold.bem_readerGet_0();
bevt_129_tmpvar_phold = bevl_emr.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_129_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 295 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_64));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_65));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpvar_phold = bevo_8;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpvar_phold = bevo_9;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_69));
bevt_8_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 355 */
} /* Line: 348 */
} /* Line: 348 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 358 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpvar_phold = bevo_10;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_lsp);
bevt_0_tmpvar_phold.bem_print_0();
bevt_2_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpvar_phold.bem_now_0();
bevt_4_tmpvar_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_5_tmpvar_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpvar_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpvar_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpvar_phold.bem_now_0();
bevl_sse = bevt_7_tmpvar_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpvar_phold = bevo_11;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevl_sse);
bevt_9_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_19_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_22_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_24_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_25_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_40_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_79_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
bevt_5_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpvar_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 381 */ {
bevt_0_tmpvar_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 382 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
this.bem_loadSyns_1(bevl_lsp);
} /* Line: 383 */
 else  /* Line: 382 */ {
break;
} /* Line: 382 */
} /* Line: 382 */
} /* Line: 382 */
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 390 */ {
bevt_10_tmpvar_phold = bevo_12;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevp_libName);
bevt_9_tmpvar_phold.bem_print_0();
} /* Line: 391 */
} /* Line: 390 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 396 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 397 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 400 */
} /* Line: 397 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
bevt_2_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 403 */ {
bevt_14_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 403 */ {
bevl_ups = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_16_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpvar_phold.bevi_bool) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 404 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpvar_phold = bevl_pack.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_17_tmpvar_phold);
} /* Line: 408 */
} /* Line: 404 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
if (bevp_parse.bevi_bool) /* Line: 411 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 413 */ {
bevt_18_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 416 */
 else  /* Line: 413 */ {
break;
} /* Line: 413 */
} /* Line: 413 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 418 */
bevt_20_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_19_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_20_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_19_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_22_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_22_tmpvar_phold == null) {
bevt_21_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_23_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_23_tmpvar_phold.bem_now_0();
bevt_24_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_24_tmpvar_phold.bem_doEmit_0();
bevt_26_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_25_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_26_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_25_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_28_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_27_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_28_tmpvar_phold.bem_now_0();
bevl_emitTime = bevt_27_tmpvar_phold.bem_subtract_1(bevl_emitStart);
bevt_30_tmpvar_phold = bevo_13;
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_29_tmpvar_phold.bem_print_0();
bevt_32_tmpvar_phold = bevo_14;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevl_emitTime);
bevt_31_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = bevo_15;
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_33_tmpvar_phold.bem_print_0();
bevt_35_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_35_tmpvar_phold;
} /* Line: 433 */
if (bevp_doEmit.bevi_bool) /* Line: 435 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_36_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_36_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 439 */ {
bevt_37_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 439 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 441 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
bevl_em.bemd_0(-1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_38_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_38_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 445 */ {
bevt_39_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 445 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 447 */
 else  /* Line: 445 */ {
break;
} /* Line: 445 */
} /* Line: 445 */
} /* Line: 445 */
bevt_41_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_40_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_41_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_40_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_42_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_42_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 452 */ {
bevt_44_tmpvar_phold = bevo_16;
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_43_tmpvar_phold.bem_print_0();
} /* Line: 453 */
bevt_46_tmpvar_phold = bevo_17;
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_45_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 456 */ {
bevl_em.bemd_1(-1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 458 */
if (bevp_make.bevi_bool) /* Line: 461 */ {
if (bevp_genOnly.bevi_bool) {
bevt_47_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 462 */ {
bevl_em.bemd_1(-1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 465 */ {
bevt_3_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 466 */ {
bevt_48_tmpvar_phold = bevt_3_tmpvar_loop.bem_hasNextGet_0();
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 466 */ {
bevl_bp = bevt_3_tmpvar_loop.bem_nextGet_0();
bevt_49_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_49_tmpvar_phold.bemd_0(-159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_50_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_50_tmpvar_phold.bem_copy_0();
bevt_52_tmpvar_phold = bevl_cpFrom.bemd_0(-723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 470 */ {
bevt_55_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_55_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 471 */
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 473 */ {
bevt_59_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_59_tmpvar_phold, bevt_60_tmpvar_phold);
} /* Line: 474 */
} /* Line: 473 */
 else  /* Line: 466 */ {
break;
} /* Line: 466 */
} /* Line: 466 */
} /* Line: 466 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 481 */ {
bevt_61_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 481 */ {
bevt_62_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 481 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 481 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 481 */
 else  /* Line: 481 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 481 */ {
bevt_63_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_63_tmpvar_phold);
bevt_68_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_67_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_68_tmpvar_phold.bem_copy_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_toString_0();
bevt_69_tmpvar_phold = bevo_18;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_64_tmpvar_phold);
bevt_72_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 485 */ {
bevt_73_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_73_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 486 */
bevt_76_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 488 */ {
bevt_77_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_78_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
} /* Line: 489 */
} /* Line: 488 */
 else  /* Line: 481 */ {
break;
} /* Line: 481 */
} /* Line: 481 */
} /* Line: 481 */
} /* Line: 462 */
bevt_80_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_79_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_80_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_79_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_81_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_83_tmpvar_phold = bevo_19;
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_82_tmpvar_phold.bem_print_0();
} /* Line: 497 */
if (bevp_parseEmitTime == null) {
bevt_84_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 499 */ {
bevt_86_tmpvar_phold = bevo_20;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_85_tmpvar_phold.bem_print_0();
} /* Line: 500 */
if (bevp_parseEmitCompileTime == null) {
bevt_87_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 502 */ {
bevt_89_tmpvar_phold = bevo_21;
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_88_tmpvar_phold.bem_print_0();
} /* Line: 503 */
if (bevp_run.bevi_bool) /* Line: 506 */ {
bevt_90_tmpvar_phold = bevo_22;
bevt_90_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_93_tmpvar_phold = bevo_23;
bevt_92_tmpvar_phold = bevt_93_tmpvar_phold.bem_add_1(bevl_result);
bevt_94_tmpvar_phold = bevo_24;
bevt_91_tmpvar_phold = bevt_92_tmpvar_phold.bem_add_1(bevt_94_tmpvar_phold);
bevt_91_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 510 */
bevt_95_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_95_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 516 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 520 */
 else  /* Line: 516 */ {
break;
} /* Line: 516 */
} /* Line: 516 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 522 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 522 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 526 */
 else  /* Line: 522 */ {
break;
} /* Line: 522 */
} /* Line: 522 */
bevt_6_tmpvar_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 532 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 533 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 536 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 537 */
 else  /* Line: 538 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 541 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 543 */
 else  /* Line: 544 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = this.bem_getSynNp_1(bevt_15_tmpvar_phold);
} /* Line: 547 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 549 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 559 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 560 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 575 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 576 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 589 */ {
if (bevp_printSteps.bevi_bool) /* Line: 590 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 590 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 590 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 590 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 590 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 590 */ {
bevt_4_tmpvar_phold = bevo_25;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 591 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 600 */ {
bevt_11_tmpvar_phold = bevo_26;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 601 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(-1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 604 */ {
bevt_13_tmpvar_phold = bevo_27;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 606 */
if (bevp_printSteps.bevi_bool) /* Line: 609 */ {
bevt_15_tmpvar_phold = bevo_28;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 610 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 613 */ {
bevt_17_tmpvar_phold = bevo_29;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 615 */
if (bevp_printSteps.bevi_bool) /* Line: 617 */ {
bevt_19_tmpvar_phold = bevo_30;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 618 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(-410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 623 */ {
bevt_21_tmpvar_phold = bevo_31;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 625 */
if (bevp_printSteps.bevi_bool) /* Line: 628 */ {
bevt_23_tmpvar_phold = bevo_32;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 629 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 632 */ {
bevt_25_tmpvar_phold = bevo_33;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 634 */
if (bevp_printSteps.bevi_bool) /* Line: 637 */ {
bevt_27_tmpvar_phold = bevo_34;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 638 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 641 */ {
bevt_29_tmpvar_phold = bevo_35;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 643 */
if (bevp_printSteps.bevi_bool) /* Line: 646 */ {
bevt_31_tmpvar_phold = bevo_36;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 647 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 650 */ {
bevt_33_tmpvar_phold = bevo_37;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 652 */
if (bevp_printSteps.bevi_bool) /* Line: 655 */ {
bevt_35_tmpvar_phold = bevo_38;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 656 */
bevt_36_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 659 */ {
bevt_37_tmpvar_phold = bevo_39;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 661 */
if (bevp_printSteps.bevi_bool) /* Line: 664 */ {
bevt_39_tmpvar_phold = bevo_40;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 665 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 668 */ {
bevt_41_tmpvar_phold = bevo_41;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 670 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_43_tmpvar_phold = bevo_42;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 674 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 677 */ {
bevt_45_tmpvar_phold = bevo_43;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 679 */
if (bevp_printSteps.bevi_bool) /* Line: 682 */ {
bevt_47_tmpvar_phold = bevo_44;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 683 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 686 */ {
bevt_49_tmpvar_phold = bevo_45;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 688 */
if (bevp_printSteps.bevi_bool) /* Line: 690 */ {
bevt_51_tmpvar_phold = bevo_46;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 691 */
bevt_52_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 694 */ {
bevt_53_tmpvar_phold = bevo_47;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 696 */
if (bevp_printSteps.bevi_bool) /* Line: 699 */ {
bevt_55_tmpvar_phold = bevo_48;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_49;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 701 */
bevt_57_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 704 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 704 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 704 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 704 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 704 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 704 */ {
bevt_58_tmpvar_phold = bevo_50;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 706 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 708 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 708 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(-568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 719 */
 else  /* Line: 708 */ {
break;
} /* Line: 708 */
} /* Line: 708 */
} /* Line: 708 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 729 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 729 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 733 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 734 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 736 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 738 */
} /* Line: 736 */
 else  /* Line: 729 */ {
break;
} /* Line: 729 */
} /* Line: 729 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_6_6_SystemObject bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_6_6_SystemObject bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 92, 92, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 111, 115, 116, 117, 117, 117, 117, 117, 118, 118, 118, 119, 118, 121, 125, 126, 127, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 147, 152, 154, 155, 155, 155, 156, 156, 0, 156, 156, 157, 157, 157, 158, 159, 159, 164, 164, 164, 164, 165, 167, 167, 167, 168, 168, 169, 169, 169, 171, 173, 173, 173, 173, 173, 173, 174, 175, 175, 176, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 355, 355, 355, 357, 358, 360, 364, 366, 366, 366, 367, 367, 368, 368, 368, 369, 369, 370, 371, 371, 372, 372, 372, 373, 373, 373, 379, 379, 380, 381, 381, 382, 0, 382, 382, 383, 386, 387, 387, 388, 389, 391, 391, 391, 394, 396, 0, 396, 396, 397, 397, 397, 398, 399, 400, 403, 0, 403, 403, 404, 404, 404, 405, 406, 407, 408, 408, 413, 413, 414, 416, 418, 421, 421, 421, 424, 424, 424, 426, 426, 427, 427, 428, 428, 428, 429, 429, 429, 430, 430, 430, 431, 431, 431, 432, 432, 432, 433, 433, 436, 437, 439, 439, 439, 440, 441, 443, 444, 445, 445, 445, 446, 447, 451, 451, 451, 452, 452, 453, 453, 453, 455, 455, 455, 458, 462, 462, 463, 464, 466, 0, 466, 466, 467, 467, 468, 468, 469, 469, 469, 470, 470, 471, 471, 473, 473, 473, 474, 474, 474, 478, 479, 481, 481, 0, 0, 0, 482, 482, 483, 483, 483, 483, 483, 483, 483, 483, 485, 485, 486, 486, 488, 488, 488, 489, 489, 489, 494, 494, 494, 496, 496, 497, 497, 497, 499, 499, 500, 500, 500, 502, 502, 503, 503, 503, 507, 507, 508, 509, 509, 509, 509, 509, 510, 512, 512, 516, 516, 516, 517, 518, 518, 519, 520, 522, 522, 522, 523, 524, 524, 525, 526, 528, 528, 532, 532, 532, 532, 533, 533, 533, 535, 535, 536, 536, 536, 536, 537, 539, 539, 539, 539, 539, 541, 541, 542, 542, 543, 547, 547, 547, 549, 551, 551, 552, 552, 552, 552, 553, 557, 558, 558, 559, 559, 560, 566, 566, 567, 568, 575, 575, 576, 578, 583, 584, 585, 586, 587, 588, 588, 0, 0, 0, 591, 591, 591, 591, 593, 595, 595, 595, 595, 596, 596, 596, 597, 601, 601, 603, 603, 605, 605, 606, 606, 610, 610, 612, 612, 614, 614, 615, 615, 618, 618, 621, 621, 622, 624, 624, 625, 625, 629, 629, 631, 631, 633, 633, 634, 634, 638, 638, 640, 640, 642, 642, 643, 643, 647, 647, 649, 649, 651, 651, 652, 652, 656, 656, 658, 658, 660, 660, 661, 661, 665, 665, 667, 667, 669, 669, 670, 670, 674, 674, 676, 676, 678, 678, 679, 679, 683, 683, 685, 685, 687, 687, 688, 688, 691, 691, 693, 693, 695, 695, 696, 696, 700, 700, 701, 701, 703, 703, 0, 0, 0, 705, 705, 706, 706, 708, 708, 708, 709, 711, 712, 713, 713, 714, 715, 715, 715, 716, 717, 718, 719, 725, 726, 727, 728, 728, 729, 729, 730, 731, 731, 732, 733, 733, 734, 736, 736, 737, 738, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 284, 289, 290, 291, 293, 296, 297, 299, 302, 306, 309, 313, 316, 317, 319, 320, 326, 327, 328, 329, 336, 337, 338, 339, 340, 352, 353, 354, 355, 356, 357, 358, 359, 362, 367, 368, 369, 375, 383, 384, 385, 387, 388, 389, 393, 394, 395, 396, 397, 400, 404, 407, 411, 413, 419, 420, 421, 424, 566, 567, 568, 569, 574, 575, 576, 576, 579, 581, 582, 583, 588, 589, 590, 591, 599, 600, 601, 602, 604, 606, 607, 608, 609, 610, 612, 613, 614, 617, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 677, 678, 680, 681, 682, 687, 688, 690, 691, 692, 697, 698, 700, 701, 702, 707, 708, 710, 711, 712, 717, 718, 720, 721, 722, 727, 728, 730, 731, 732, 737, 738, 740, 741, 742, 747, 748, 750, 751, 752, 757, 758, 760, 761, 762, 767, 768, 770, 771, 772, 777, 778, 781, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 801, 802, 803, 808, 809, 812, 816, 819, 819, 822, 824, 825, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 868, 869, 872, 874, 875, 876, 877, 878, 879, 884, 885, 886, 888, 889, 890, 891, 896, 897, 898, 900, 901, 902, 902, 905, 907, 908, 909, 915, 916, 917, 918, 919, 920, 921, 926, 927, 928, 930, 935, 936, 937, 938, 939, 940, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 1005, 1006, 1007, 1010, 1012, 1013, 1014, 1015, 1016, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1032, 1033, 1033, 1036, 1038, 1039, 1046, 1047, 1048, 1049, 1050, 1051, 1056, 1057, 1057, 1060, 1062, 1063, 1076, 1077, 1080, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1098, 1099, 1113, 1118, 1119, 1121, 1126, 1127, 1128, 1129, 1131, 1134, 1135, 1137, 1140, 1141, 1143, 1146, 1147, 1148, 1152, 1153, 1155, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1310, 1311, 1312, 1313, 1318, 1319, 1319, 1322, 1324, 1325, 1332, 1333, 1338, 1339, 1340, 1342, 1343, 1344, 1347, 1348, 1348, 1351, 1353, 1354, 1355, 1360, 1361, 1362, 1363, 1370, 1370, 1373, 1375, 1376, 1377, 1382, 1383, 1384, 1385, 1386, 1387, 1395, 1398, 1400, 1401, 1407, 1409, 1410, 1411, 1412, 1413, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1442, 1443, 1444, 1445, 1448, 1450, 1451, 1457, 1458, 1459, 1460, 1463, 1465, 1466, 1473, 1474, 1475, 1476, 1481, 1482, 1483, 1484, 1486, 1487, 1488, 1490, 1493, 1498, 1499, 1500, 1502, 1502, 1505, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1518, 1519, 1521, 1522, 1523, 1525, 1526, 1527, 1535, 1536, 1539, 1541, 1543, 1546, 1550, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1566, 1567, 1569, 1570, 1571, 1573, 1574, 1575, 1584, 1585, 1586, 1587, 1592, 1593, 1594, 1595, 1597, 1602, 1603, 1604, 1605, 1607, 1612, 1613, 1614, 1615, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1628, 1629, 1642, 1643, 1646, 1648, 1649, 1650, 1651, 1652, 1658, 1659, 1662, 1664, 1665, 1666, 1667, 1668, 1674, 1675, 1703, 1704, 1705, 1710, 1711, 1712, 1713, 1715, 1716, 1717, 1718, 1719, 1724, 1725, 1728, 1729, 1730, 1731, 1732, 1733, 1738, 1739, 1740, 1741, 1744, 1745, 1746, 1748, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1764, 1765, 1766, 1767, 1772, 1773, 1775, 1776, 1777, 1778, 1782, 1787, 1788, 1790, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1878, 1882, 1885, 1889, 1890, 1891, 1892, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1904, 1905, 1907, 1908, 1910, 1911, 1912, 1913, 1916, 1917, 1919, 1920, 1922, 1923, 1924, 1925, 1928, 1929, 1931, 1932, 1933, 1935, 1936, 1937, 1938, 1941, 1942, 1944, 1945, 1947, 1948, 1949, 1950, 1953, 1954, 1956, 1957, 1959, 1960, 1961, 1962, 1965, 1966, 1968, 1969, 1971, 1972, 1973, 1974, 1977, 1978, 1980, 1981, 1983, 1984, 1985, 1986, 1989, 1990, 1992, 1993, 1995, 1996, 1997, 1998, 2001, 2002, 2004, 2005, 2007, 2008, 2009, 2010, 2013, 2014, 2016, 2017, 2019, 2020, 2021, 2022, 2025, 2026, 2028, 2029, 2031, 2032, 2033, 2034, 2037, 2038, 2039, 2040, 2042, 2043, 2045, 2049, 2052, 2056, 2057, 2058, 2059, 2061, 2062, 2065, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2101, 2102, 2103, 2104, 2105, 2106, 2109, 2111, 2112, 2113, 2114, 2115, 2116, 2118, 2120, 2121, 2123, 2124, 2134, 2137, 2141, 2144, 2148, 2151, 2155, 2158, 2162, 2165, 2169, 2172, 2176, 2179, 2183, 2186, 2190, 2193, 2197, 2200, 2204, 2207, 2211, 2214, 2218, 2221, 2225, 2228, 2232, 2235, 2239, 2242, 2246, 2249, 2253, 2256, 2260, 2263, 2267, 2270, 2274, 2277, 2281, 2284, 2288, 2291, 2295, 2298, 2302, 2305, 2309, 2312, 2316, 2319, 2323, 2326, 2330, 2333, 2337, 2340, 2344, 2347, 2351, 2354, 2358, 2361, 2365, 2368, 2372, 2375, 2379, 2382, 2386, 2389, 2393, 2396, 2400, 2403, 2407, 2410, 2414, 2417, 2421, 2424, 2428, 2431, 2435, 2438, 2442, 2445, 2449, 2452, 2456, 2459, 2463, 2466, 2470, 2473, 2477, 2480, 2484, 2487, 2491, 2494, 2498, 2501, 2505, 2508, 2512, 2515, 2519, 2522, 2526, 2529, 2533, 2536, 2540, 2543, 2547, 2550, 2554, 2557, 2561, 2564, 2568, 2571, 2575, 2578, 2582, 2585, 2589, 2592, 2596, 2599, 2603, 2606, 2610, 2613, 2617, 2620, 2624, 2627, 2631};
/* BEGIN LINEINFO 
assign 1 53 246
new 0 53 246
assign 1 55 247
new 0 55 247
assign 1 56 248
new 0 56 248
assign 1 57 249
new 0 57 249
assign 1 58 250
new 0 58 250
assign 1 60 251
new 0 60 251
assign 1 61 252
new 0 61 252
assign 1 62 253
new 0 62 253
assign 1 63 254
new 0 63 254
assign 1 64 255
new 0 64 255
assign 1 65 256
new 0 65 256
assign 1 66 257
new 0 66 257
assign 1 70 258
new 0 70 258
assign 1 72 259
new 1 72 259
assign 1 73 260
ntypesGet 0 73 260
assign 1 74 261
twtokGet 0 74 261
assign 1 75 262
new 0 75 262
assign 1 75 263
new 1 75 263
assign 1 78 264
new 0 78 264
assign 1 81 265
new 0 81 265
assign 1 82 266
new 0 82 266
assign 1 88 267
new 0 88 267
assign 1 89 268
new 0 89 268
assign 1 90 269
new 0 90 269
assign 1 91 270
new 0 91 270
assign 1 92 271
new 0 92 271
assign 1 92 272
new 1 92 272
assign 1 99 284
def 1 99 289
assign 1 99 290
new 0 99 290
assign 1 99 291
equals 1 99 291
assign 1 0 293
assign 1 99 296
new 0 99 296
assign 1 99 297
ends 1 99 297
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 100 316
new 0 100 316
return 1 100 317
assign 1 102 319
new 0 102 319
return 1 102 320
assign 1 106 326
new 0 106 326
assign 1 106 327
new 0 106 327
assign 1 106 328
swap 2 106 328
return 1 106 329
assign 1 110 336
new 0 110 336
assign 1 110 337
argsGet 0 110 337
assign 1 111 338
new 0 111 338
assign 1 111 339
main 1 111 339
exit 1 111 340
assign 1 115 352
assign 1 116 353
new 1 116 353
assign 1 117 354
new 0 117 354
assign 1 117 355
new 0 117 355
assign 1 117 356
get 2 117 356
assign 1 117 357
firstGet 0 117 357
assign 1 117 358
new 1 117 358
assign 1 118 359
new 0 118 359
assign 1 118 362
lesser 1 118 367
assign 1 119 368
go 0 119 368
incrementValue 0 118 369
return 1 121 375
assign 1 125 383
new 0 125 383
config 0 126 384
assign 1 127 385
new 0 127 385
assign 1 129 387
new 0 129 387
assign 1 130 388
doWhat 0 130 388
assign 1 131 389
new 0 131 389
assign 1 133 393
toString 0 133 393
assign 1 134 394
new 0 134 394
assign 1 135 395
new 0 135 395
assign 1 135 396
add 1 135 396
assign 1 136 397
new 0 136 397
assign 1 0 400
assign 1 0 404
assign 1 0 407
print 0 139 411
return 1 141 413
assign 1 145 419
nameGet 0 145 419
assign 1 145 420
new 0 145 420
assign 1 145 421
equals 1 145 421
return 1 147 424
assign 1 152 566
new 0 152 566
assign 1 154 567
new 0 154 567
assign 1 155 568
get 1 155 568
assign 1 155 569
def 1 155 574
assign 1 156 575
get 1 156 575
assign 1 156 576
iteratorGet 0 0 576
assign 1 156 579
hasNextGet 0 156 579
assign 1 156 581
nextGet 0 156 581
assign 1 157 582
has 1 157 582
assign 1 157 583
not 0 157 588
put 1 158 589
assign 1 159 590
new 1 159 590
addFile 1 159 591
assign 1 164 599
new 0 164 599
assign 1 164 600
nameGet 0 164 600
assign 1 164 601
new 0 164 601
assign 1 164 602
equals 1 164 602
preProcessorSet 1 165 604
assign 1 167 606
new 0 167 606
assign 1 167 607
get 1 167 607
assign 1 167 608
firstGet 0 167 608
assign 1 168 609
new 0 168 609
assign 1 168 610
has 1 168 610
assign 1 169 612
new 0 169 612
assign 1 169 613
get 1 169 613
assign 1 169 614
firstGet 0 169 614
assign 1 171 617
assign 1 173 619
new 0 173 619
assign 1 173 620
new 0 173 620
assign 1 173 621
get 2 173 621
assign 1 173 622
firstGet 0 173 622
assign 1 173 623
new 1 173 623
assign 1 173 624
pathGet 0 173 624
addStep 1 174 625
assign 1 175 626
new 0 175 626
addStep 1 175 627
assign 1 176 628
new 0 176 628
assign 1 176 629
new 0 176 629
assign 1 176 630
get 2 176 630
assign 1 176 631
firstGet 0 176 631
assign 1 176 632
new 1 176 632
assign 1 176 633
pathGet 0 176 633
assign 1 177 634
new 0 177 634
assign 1 177 635
new 0 177 635
assign 1 177 636
nameGet 0 177 636
assign 1 177 637
get 2 177 637
assign 1 177 638
firstGet 0 177 638
assign 1 177 639
new 1 177 639
assign 1 178 640
new 0 178 640
assign 1 178 641
nameGet 0 178 641
assign 1 178 642
get 2 178 642
assign 1 178 643
firstGet 0 178 643
assign 1 178 644
new 1 178 644
assign 1 179 645
new 0 179 645
assign 1 179 646
new 0 179 646
assign 1 179 647
get 2 179 647
assign 1 179 648
firstGet 0 179 648
assign 1 179 649
new 1 179 649
assign 1 180 650
new 0 180 650
assign 1 180 651
new 0 180 651
assign 1 180 652
get 2 180 652
assign 1 180 653
firstGet 0 180 653
assign 1 180 654
new 1 180 654
assign 1 181 655
new 0 181 655
assign 1 181 656
new 0 181 656
assign 1 181 657
get 2 181 657
assign 1 181 658
firstGet 0 181 658
assign 1 181 659
new 1 181 659
assign 1 182 660
new 0 182 660
assign 1 182 661
get 1 182 661
assign 1 183 662
new 0 183 662
assign 1 183 663
get 1 183 663
assign 1 185 664
new 0 185 664
assign 1 185 665
get 1 185 665
assign 1 185 666
firstGet 0 185 666
assign 1 186 667
new 0 186 667
assign 1 186 668
get 1 186 668
assign 1 186 669
firstGet 0 186 669
assign 1 187 670
new 0 187 670
assign 1 187 671
get 1 187 671
assign 1 188 672
undef 1 188 677
assign 1 189 678
new 0 189 678
assign 1 191 680
new 0 191 680
assign 1 191 681
get 1 191 681
assign 1 192 682
undef 1 192 687
assign 1 193 688
new 0 193 688
assign 1 195 690
new 0 195 690
assign 1 195 691
get 1 195 691
assign 1 196 692
undef 1 196 697
assign 1 197 698
new 0 197 698
assign 1 199 700
new 0 199 700
assign 1 199 701
get 1 199 701
assign 1 200 702
undef 1 200 707
assign 1 201 708
new 0 201 708
assign 1 203 710
new 0 203 710
assign 1 203 711
get 1 203 711
assign 1 204 712
undef 1 204 717
assign 1 205 718
new 0 205 718
assign 1 207 720
new 0 207 720
assign 1 207 721
get 1 207 721
assign 1 208 722
undef 1 208 727
assign 1 209 728
new 0 209 728
assign 1 211 730
new 0 211 730
assign 1 211 731
get 1 211 731
assign 1 212 732
undef 1 212 737
assign 1 213 738
new 0 213 738
assign 1 215 740
new 0 215 740
assign 1 215 741
get 1 215 741
assign 1 216 742
undef 1 216 747
assign 1 217 748
new 0 217 748
assign 1 219 750
new 0 219 750
assign 1 219 751
get 1 219 751
assign 1 220 752
undef 1 220 757
assign 1 221 758
new 0 221 758
assign 1 223 760
new 0 223 760
assign 1 223 761
get 1 223 761
assign 1 224 762
def 1 224 767
assign 1 225 768
firstGet 0 225 768
assign 1 227 770
new 0 227 770
assign 1 227 771
get 1 227 771
assign 1 228 772
def 1 228 777
assign 1 229 778
firstGet 0 229 778
assign 1 231 781
new 0 231 781
assign 1 233 783
new 0 233 783
assign 1 233 784
new 0 233 784
assign 1 233 785
isTrue 2 233 785
assign 1 234 786
new 0 234 786
assign 1 234 787
new 0 234 787
assign 1 234 788
isTrue 2 234 788
assign 1 235 789
new 0 235 789
assign 1 235 790
isTrue 1 235 790
assign 1 236 791
new 0 236 791
assign 1 236 792
isTrue 1 236 792
assign 1 237 793
new 0 237 793
assign 1 238 794
new 0 238 794
assign 1 238 795
get 1 238 795
assign 1 239 796
def 1 239 801
assign 1 239 802
isEmptyGet 0 239 802
assign 1 239 803
not 0 239 808
assign 1 0 809
assign 1 0 812
assign 1 0 816
assign 1 240 819
linkedListIteratorGet 0 0 819
assign 1 240 822
hasNextGet 0 240 822
assign 1 240 824
nextGet 0 240 824
put 1 241 825
assign 1 244 832
new 0 244 832
assign 1 244 833
isTrue 1 244 833
assign 1 245 834
new 0 245 834
assign 1 245 835
isTrue 1 245 835
assign 1 246 836
new 0 246 836
assign 1 246 837
isTrue 1 246 837
assign 1 247 838
new 0 247 838
assign 1 247 839
new 0 247 839
assign 1 247 840
isTrue 2 247 840
assign 1 248 841
new 0 248 841
assign 1 248 842
get 1 248 842
assign 1 249 843
new 0 249 843
assign 1 249 844
get 1 249 844
assign 1 250 845
new 0 250 845
assign 1 250 846
new 0 250 846
assign 1 250 847
get 2 250 847
assign 1 250 848
firstGet 0 250 848
assign 1 251 849
new 0 251 849
assign 1 251 850
new 0 251 850
assign 1 251 851
get 2 251 851
assign 1 251 852
firstGet 0 251 852
assign 1 252 853
new 0 252 853
assign 1 252 854
add 1 252 854
assign 1 252 855
new 0 252 855
assign 1 252 856
get 2 252 856
assign 1 252 857
firstGet 0 252 857
assign 1 253 858
new 0 253 858
assign 1 254 859
new 0 254 859
assign 1 255 860
new 0 255 860
assign 1 256 861
new 0 256 861
assign 1 257 862
new 0 257 862
assign 1 260 863
def 1 260 868
assign 1 261 869
firstGet 0 261 869
assign 1 263 872
new 0 263 872
assign 1 270 874
new 0 270 874
assign 1 270 875
add 1 270 875
assign 1 270 876
nameGet 0 270 876
assign 1 270 877
add 1 270 877
assign 1 270 878
get 1 270 878
assign 1 271 879
def 1 271 884
assign 1 272 885
orderedGet 0 272 885
addAll 1 272 886
assign 1 275 888
new 0 275 888
assign 1 275 889
add 1 275 889
assign 1 275 890
get 1 275 890
assign 1 276 891
def 1 276 896
assign 1 277 897
orderedGet 0 277 897
addAll 1 277 898
assign 1 280 900
new 0 280 900
assign 1 281 901
orderedGet 0 281 901
assign 1 281 902
iteratorGet 0 0 902
assign 1 281 905
hasNextGet 0 281 905
assign 1 281 907
nextGet 0 281 907
assign 1 282 908
new 1 282 908
addValue 1 282 909
assign 1 284 915
newlineGet 0 284 915
assign 1 285 916
assign 1 286 917
new 1 286 917
assign 1 288 918
copy 0 288 918
assign 1 289 919
fileGet 0 289 919
assign 1 289 920
existsGet 0 289 920
assign 1 289 921
not 0 289 926
assign 1 290 927
fileGet 0 290 927
makeDirs 0 290 928
assign 1 292 930
def 1 292 935
assign 1 293 936
new 1 293 936
assign 1 293 937
readerGet 0 293 937
assign 1 294 938
open 0 294 938
assign 1 294 939
readString 0 294 939
close 0 295 940
assign 1 301 954
classNameGet 0 301 954
assign 1 302 955
add 1 302 955
assign 1 302 956
new 0 302 956
assign 1 302 957
add 1 302 957
assign 1 302 958
toString 0 302 958
assign 1 302 959
add 1 302 959
assign 1 303 960
add 1 303 960
assign 1 303 961
new 0 303 961
assign 1 303 962
add 1 303 962
assign 1 303 963
toString 0 303 963
assign 1 303 964
add 1 303 964
return 1 304 965
assign 1 308 1005
new 0 308 1005
assign 1 309 1006
classesGet 0 309 1006
assign 1 309 1007
valueIteratorGet 0 309 1007
assign 1 309 1010
hasNextGet 0 309 1010
assign 1 310 1012
nextGet 0 310 1012
assign 1 311 1013
shouldEmitGet 0 311 1013
assign 1 311 1014
heldGet 0 311 1014
assign 1 311 1015
fromFileGet 0 311 1015
assign 1 311 1016
has 1 311 1016
assign 1 312 1018
heldGet 0 312 1018
assign 1 312 1019
namepathGet 0 312 1019
assign 1 312 1020
toString 0 312 1020
put 1 312 1021
assign 1 313 1022
usedByGet 0 313 1022
assign 1 313 1023
heldGet 0 313 1023
assign 1 313 1024
namepathGet 0 313 1024
assign 1 313 1025
toString 0 313 1025
assign 1 313 1026
get 1 313 1026
assign 1 314 1027
def 1 314 1032
assign 1 315 1033
setIteratorGet 0 0 1033
assign 1 315 1036
hasNextGet 0 315 1036
assign 1 315 1038
nextGet 0 315 1038
put 1 316 1039
assign 1 319 1046
subClassesGet 0 319 1046
assign 1 319 1047
heldGet 0 319 1047
assign 1 319 1048
namepathGet 0 319 1048
assign 1 319 1049
toString 0 319 1049
assign 1 319 1050
get 1 319 1050
assign 1 320 1051
def 1 320 1056
assign 1 321 1057
setIteratorGet 0 0 1057
assign 1 321 1060
hasNextGet 0 321 1060
assign 1 321 1062
nextGet 0 321 1062
put 1 322 1063
assign 1 327 1076
classesGet 0 327 1076
assign 1 327 1077
valueIteratorGet 0 327 1077
assign 1 327 1080
hasNextGet 0 327 1080
assign 1 328 1082
nextGet 0 328 1082
assign 1 329 1083
heldGet 0 329 1083
assign 1 329 1084
heldGet 0 329 1084
assign 1 329 1085
namepathGet 0 329 1085
assign 1 329 1086
toString 0 329 1086
assign 1 329 1087
has 1 329 1087
shouldWriteSet 1 329 1088
assign 1 336 1098
new 0 336 1098
return 1 336 1099
assign 1 340 1113
def 1 340 1118
return 1 341 1119
assign 1 346 1121
def 1 346 1126
assign 1 347 1127
firstGet 0 347 1127
assign 1 348 1128
new 0 348 1128
assign 1 348 1129
equals 1 348 1129
assign 1 349 1131
new 1 349 1131
assign 1 350 1134
new 0 350 1134
assign 1 350 1135
equals 1 350 1135
assign 1 351 1137
new 1 351 1137
assign 1 352 1140
new 0 352 1140
assign 1 352 1141
equals 1 352 1141
assign 1 353 1143
new 1 353 1143
assign 1 355 1146
new 0 355 1146
assign 1 355 1147
new 1 355 1147
throw 1 355 1148
dynConditionsAllSet 1 357 1152
return 1 358 1153
return 1 360 1155
assign 1 364 1174
apNew 1 364 1174
assign 1 366 1175
new 0 366 1175
assign 1 366 1176
add 1 366 1176
print 0 366 1177
assign 1 367 1178
new 0 367 1178
assign 1 367 1179
now 0 367 1179
assign 1 368 1180
fileGet 0 368 1180
assign 1 368 1181
readerGet 0 368 1181
assign 1 368 1182
open 0 368 1182
assign 1 369 1183
new 0 369 1183
assign 1 369 1184
deserialize 1 369 1184
close 0 370 1185
assign 1 371 1186
synClassesGet 0 371 1186
addValue 1 371 1187
assign 1 372 1188
new 0 372 1188
assign 1 372 1189
now 0 372 1189
assign 1 372 1190
subtract 1 372 1190
assign 1 373 1191
new 0 373 1191
assign 1 373 1192
add 1 373 1192
print 0 373 1193
assign 1 379 1310
new 0 379 1310
assign 1 379 1311
now 0 379 1311
assign 1 380 1312
new 0 380 1312
assign 1 381 1313
def 1 381 1318
assign 1 382 1319
linkedListIteratorGet 0 0 1319
assign 1 382 1322
hasNextGet 0 382 1322
assign 1 382 1324
nextGet 0 382 1324
loadSyns 1 383 1325
assign 1 386 1332
emitterGet 0 386 1332
assign 1 387 1333
def 1 387 1338
assign 1 388 1339
new 4 388 1339
put 1 389 1340
assign 1 391 1342
new 0 391 1342
assign 1 391 1343
add 1 391 1343
print 0 391 1344
assign 1 394 1347
new 0 394 1347
assign 1 396 1348
iteratorGet 0 0 1348
assign 1 396 1351
hasNextGet 0 396 1351
assign 1 396 1353
nextGet 0 396 1353
assign 1 397 1354
has 1 397 1354
assign 1 397 1355
not 0 397 1360
put 1 398 1361
assign 1 399 1362
new 2 399 1362
addValue 1 400 1363
assign 1 403 1370
iteratorGet 0 0 1370
assign 1 403 1373
hasNextGet 0 403 1373
assign 1 403 1375
nextGet 0 403 1375
assign 1 404 1376
has 1 404 1376
assign 1 404 1377
not 0 404 1382
put 1 405 1383
assign 1 406 1384
new 2 406 1384
addValue 1 407 1385
assign 1 408 1386
libNameGet 0 408 1386
put 1 408 1387
assign 1 413 1395
iteratorGet 0 413 1395
assign 1 413 1398
hasNextGet 0 413 1398
assign 1 414 1400
nextGet 0 414 1400
doParse 1 416 1401
buildSyns 1 418 1407
assign 1 421 1409
new 0 421 1409
assign 1 421 1410
now 0 421 1410
assign 1 421 1411
subtract 1 421 1411
assign 1 424 1412
emitCommonGet 0 424 1412
assign 1 424 1413
def 1 424 1418
assign 1 426 1419
new 0 426 1419
assign 1 426 1420
now 0 426 1420
assign 1 427 1421
emitCommonGet 0 427 1421
doEmit 0 427 1422
assign 1 428 1423
new 0 428 1423
assign 1 428 1424
now 0 428 1424
assign 1 428 1425
subtract 1 428 1425
assign 1 429 1426
new 0 429 1426
assign 1 429 1427
now 0 429 1427
assign 1 429 1428
subtract 1 429 1428
assign 1 430 1429
new 0 430 1429
assign 1 430 1430
add 1 430 1430
print 0 430 1431
assign 1 431 1432
new 0 431 1432
assign 1 431 1433
add 1 431 1433
print 0 431 1434
assign 1 432 1435
new 0 432 1435
assign 1 432 1436
add 1 432 1436
print 0 432 1437
assign 1 433 1438
new 0 433 1438
return 1 433 1439
setClassesToWrite 0 436 1442
libnameInfoGet 0 437 1443
assign 1 439 1444
classesGet 0 439 1444
assign 1 439 1445
valueIteratorGet 0 439 1445
assign 1 439 1448
hasNextGet 0 439 1448
assign 1 440 1450
nextGet 0 440 1450
doEmit 1 441 1451
emitMain 0 443 1457
emitCUInit 0 444 1458
assign 1 445 1459
classesGet 0 445 1459
assign 1 445 1460
valueIteratorGet 0 445 1460
assign 1 445 1463
hasNextGet 0 445 1463
assign 1 446 1465
nextGet 0 446 1465
emitSyn 1 447 1466
assign 1 451 1473
new 0 451 1473
assign 1 451 1474
now 0 451 1474
assign 1 451 1475
subtract 1 451 1475
assign 1 452 1476
def 1 452 1481
assign 1 453 1482
new 0 453 1482
assign 1 453 1483
add 1 453 1483
print 0 453 1484
assign 1 455 1486
new 0 455 1486
assign 1 455 1487
add 1 455 1487
print 0 455 1488
prepMake 1 458 1490
assign 1 462 1493
not 0 462 1498
make 1 463 1499
deployLibrary 1 464 1500
assign 1 466 1502
linkedListIteratorGet 0 0 1502
assign 1 466 1505
hasNextGet 0 466 1505
assign 1 466 1507
nextGet 0 466 1507
assign 1 467 1508
libnameInfoGet 0 467 1508
assign 1 467 1509
unitShlibGet 0 467 1509
assign 1 468 1510
emitPathGet 0 468 1510
assign 1 468 1511
copy 0 468 1511
assign 1 469 1512
stepsGet 0 469 1512
assign 1 469 1513
lastGet 0 469 1513
addStep 1 469 1514
assign 1 470 1515
fileGet 0 470 1515
assign 1 470 1516
existsGet 0 470 1516
assign 1 471 1518
fileGet 0 471 1518
delete 0 471 1519
assign 1 473 1521
fileGet 0 473 1521
assign 1 473 1522
existsGet 0 473 1522
assign 1 473 1523
not 0 473 1523
assign 1 474 1525
fileGet 0 474 1525
assign 1 474 1526
fileGet 0 474 1526
deployFile 2 474 1527
assign 1 478 1535
iteratorGet 0 478 1535
assign 1 479 1536
iteratorGet 0 479 1536
assign 1 481 1539
hasNextGet 0 481 1539
assign 1 481 1541
hasNextGet 0 481 1541
assign 1 0 1543
assign 1 0 1546
assign 1 0 1550
assign 1 482 1553
nextGet 0 482 1553
assign 1 482 1554
apNew 1 482 1554
assign 1 483 1555
emitPathGet 0 483 1555
assign 1 483 1556
copy 0 483 1556
assign 1 483 1557
toString 0 483 1557
assign 1 483 1558
new 0 483 1558
assign 1 483 1559
add 1 483 1559
assign 1 483 1560
nextGet 0 483 1560
assign 1 483 1561
add 1 483 1561
assign 1 483 1562
apNew 1 483 1562
assign 1 485 1563
fileGet 0 485 1563
assign 1 485 1564
existsGet 0 485 1564
assign 1 486 1566
fileGet 0 486 1566
delete 0 486 1567
assign 1 488 1569
fileGet 0 488 1569
assign 1 488 1570
existsGet 0 488 1570
assign 1 488 1571
not 0 488 1571
assign 1 489 1573
fileGet 0 489 1573
assign 1 489 1574
fileGet 0 489 1574
deployFile 2 489 1575
assign 1 494 1584
new 0 494 1584
assign 1 494 1585
now 0 494 1585
assign 1 494 1586
subtract 1 494 1586
assign 1 496 1587
def 1 496 1592
assign 1 497 1593
new 0 497 1593
assign 1 497 1594
add 1 497 1594
print 0 497 1595
assign 1 499 1597
def 1 499 1602
assign 1 500 1603
new 0 500 1603
assign 1 500 1604
add 1 500 1604
print 0 500 1605
assign 1 502 1607
def 1 502 1612
assign 1 503 1613
new 0 503 1613
assign 1 503 1614
add 1 503 1614
print 0 503 1615
assign 1 507 1618
new 0 507 1618
print 0 507 1619
assign 1 508 1620
run 2 508 1620
assign 1 509 1621
new 0 509 1621
assign 1 509 1622
add 1 509 1622
assign 1 509 1623
new 0 509 1623
assign 1 509 1624
add 1 509 1624
print 0 509 1625
return 1 510 1626
assign 1 512 1628
new 0 512 1628
return 1 512 1629
assign 1 516 1642
justParsedGet 0 516 1642
assign 1 516 1643
valueIteratorGet 0 516 1643
assign 1 516 1646
hasNextGet 0 516 1646
assign 1 517 1648
nextGet 0 517 1648
assign 1 518 1649
heldGet 0 518 1649
libNameSet 1 518 1650
assign 1 519 1651
getSyn 2 519 1651
libNameSet 1 520 1652
assign 1 522 1658
justParsedGet 0 522 1658
assign 1 522 1659
valueIteratorGet 0 522 1659
assign 1 522 1662
hasNextGet 0 522 1662
assign 1 523 1664
nextGet 0 523 1664
assign 1 524 1665
heldGet 0 524 1665
assign 1 524 1666
synGet 0 524 1666
checkInheritance 2 525 1667
integrate 1 526 1668
assign 1 528 1674
new 0 528 1674
justParsedSet 1 528 1675
assign 1 532 1703
heldGet 0 532 1703
assign 1 532 1704
synGet 0 532 1704
assign 1 532 1705
def 1 532 1710
assign 1 533 1711
heldGet 0 533 1711
assign 1 533 1712
synGet 0 533 1712
return 1 533 1713
assign 1 535 1715
heldGet 0 535 1715
libNameSet 1 535 1716
assign 1 536 1717
heldGet 0 536 1717
assign 1 536 1718
extendsGet 0 536 1718
assign 1 536 1719
undef 1 536 1724
assign 1 537 1725
new 1 537 1725
assign 1 539 1728
classesGet 0 539 1728
assign 1 539 1729
heldGet 0 539 1729
assign 1 539 1730
extendsGet 0 539 1730
assign 1 539 1731
toString 0 539 1731
assign 1 539 1732
get 1 539 1732
assign 1 541 1733
def 1 541 1738
assign 1 542 1739
heldGet 0 542 1739
libNameSet 1 542 1740
assign 1 543 1741
getSyn 2 543 1741
assign 1 547 1744
heldGet 0 547 1744
assign 1 547 1745
extendsGet 0 547 1745
assign 1 547 1746
getSynNp 1 547 1746
assign 1 549 1748
new 2 549 1748
assign 1 551 1750
heldGet 0 551 1750
synSet 1 551 1751
assign 1 552 1752
heldGet 0 552 1752
assign 1 552 1753
namepathGet 0 552 1753
assign 1 552 1754
toString 0 552 1754
addSynClass 2 552 1755
return 1 553 1756
assign 1 557 1764
toString 0 557 1764
assign 1 558 1765
synClassesGet 0 558 1765
assign 1 558 1766
get 1 558 1766
assign 1 559 1767
def 1 559 1772
return 1 560 1773
assign 1 566 1775
emitterGet 0 566 1775
assign 1 566 1776
loadSyn 1 566 1776
addSynClass 2 567 1777
return 1 568 1778
assign 1 575 1782
undef 1 575 1787
assign 1 576 1788
new 1 576 1788
return 1 578 1790
assign 1 583 1869
new 1 583 1869
assign 1 584 1870
new 0 584 1870
assign 1 585 1871
emitterGet 0 585 1871
assign 1 586 1872
assign 1 587 1873
new 0 587 1873
assign 1 588 1874
shouldEmitGet 0 588 1874
put 1 588 1875
assign 1 0 1878
assign 1 0 1882
assign 1 0 1885
assign 1 591 1889
new 0 591 1889
assign 1 591 1890
toString 0 591 1890
assign 1 591 1891
add 1 591 1891
print 0 591 1892
assign 1 593 1894
assign 1 595 1895
fileGet 0 595 1895
assign 1 595 1896
readerGet 0 595 1896
assign 1 595 1897
open 0 595 1897
assign 1 595 1898
readBuffer 1 595 1898
assign 1 596 1899
fileGet 0 596 1899
assign 1 596 1900
readerGet 0 596 1900
close 0 596 1901
assign 1 597 1902
tokenize 1 597 1902
assign 1 601 1904
new 0 601 1904
echo 0 601 1905
assign 1 603 1907
outermostGet 0 603 1907
nodify 2 603 1908
assign 1 605 1910
new 0 605 1910
print 0 605 1911
assign 1 606 1912
new 2 606 1912
traverse 1 606 1913
assign 1 610 1916
new 0 610 1916
echo 0 610 1917
assign 1 612 1919
new 0 612 1919
traverse 1 612 1920
assign 1 614 1922
new 0 614 1922
print 0 614 1923
assign 1 615 1924
new 2 615 1924
traverse 1 615 1925
assign 1 618 1928
new 0 618 1928
echo 0 618 1929
assign 1 621 1931
new 0 621 1931
traverse 1 621 1932
contain 0 622 1933
assign 1 624 1935
new 0 624 1935
print 0 624 1936
assign 1 625 1937
new 2 625 1937
traverse 1 625 1938
assign 1 629 1941
new 0 629 1941
echo 0 629 1942
assign 1 631 1944
new 0 631 1944
traverse 1 631 1945
assign 1 633 1947
new 0 633 1947
print 0 633 1948
assign 1 634 1949
new 2 634 1949
traverse 1 634 1950
assign 1 638 1953
new 0 638 1953
echo 0 638 1954
assign 1 640 1956
new 0 640 1956
traverse 1 640 1957
assign 1 642 1959
new 0 642 1959
print 0 642 1960
assign 1 643 1961
new 2 643 1961
traverse 1 643 1962
assign 1 647 1965
new 0 647 1965
echo 0 647 1966
assign 1 649 1968
new 0 649 1968
traverse 1 649 1969
assign 1 651 1971
new 0 651 1971
print 0 651 1972
assign 1 652 1973
new 2 652 1973
traverse 1 652 1974
assign 1 656 1977
new 0 656 1977
echo 0 656 1978
assign 1 658 1980
new 0 658 1980
traverse 1 658 1981
assign 1 660 1983
new 0 660 1983
print 0 660 1984
assign 1 661 1985
new 2 661 1985
traverse 1 661 1986
assign 1 665 1989
new 0 665 1989
echo 0 665 1990
assign 1 667 1992
new 0 667 1992
traverse 1 667 1993
assign 1 669 1995
new 0 669 1995
print 0 669 1996
assign 1 670 1997
new 2 670 1997
traverse 1 670 1998
assign 1 674 2001
new 0 674 2001
echo 0 674 2002
assign 1 676 2004
new 0 676 2004
traverse 1 676 2005
assign 1 678 2007
new 0 678 2007
print 0 678 2008
assign 1 679 2009
new 2 679 2009
traverse 1 679 2010
assign 1 683 2013
new 0 683 2013
echo 0 683 2014
assign 1 685 2016
new 0 685 2016
traverse 1 685 2017
assign 1 687 2019
new 0 687 2019
print 0 687 2020
assign 1 688 2021
new 2 688 2021
traverse 1 688 2022
assign 1 691 2025
new 0 691 2025
echo 0 691 2026
assign 1 693 2028
new 0 693 2028
traverse 1 693 2029
assign 1 695 2031
new 0 695 2031
print 0 695 2032
assign 1 696 2033
new 2 696 2033
traverse 1 696 2034
assign 1 700 2037
new 0 700 2037
echo 0 700 2038
assign 1 701 2039
new 0 701 2039
print 0 701 2040
assign 1 703 2042
new 0 703 2042
traverse 1 703 2043
assign 1 0 2045
assign 1 0 2049
assign 1 0 2052
assign 1 705 2056
new 0 705 2056
print 0 705 2057
assign 1 706 2058
new 2 706 2058
traverse 1 706 2059
assign 1 708 2061
classesGet 0 708 2061
assign 1 708 2062
valueIteratorGet 0 708 2062
assign 1 708 2065
hasNextGet 0 708 2065
assign 1 709 2067
nextGet 0 709 2067
assign 1 711 2068
transUnitGet 0 711 2068
assign 1 712 2069
new 1 712 2069
assign 1 713 2070
TRANSUNITGet 0 713 2070
typenameSet 1 713 2071
assign 1 714 2072
new 0 714 2072
assign 1 715 2073
heldGet 0 715 2073
assign 1 715 2074
emitsGet 0 715 2074
emitsSet 1 715 2075
heldSet 1 716 2076
delete 0 717 2077
addValue 1 718 2078
copyLoc 1 719 2079
reInitContained 0 725 2101
assign 1 726 2102
containedGet 0 726 2102
assign 1 727 2103
new 0 727 2103
assign 1 728 2104
new 0 728 2104
assign 1 728 2105
crGet 0 728 2105
assign 1 729 2106
linkedListIteratorGet 0 729 2106
assign 1 729 2109
hasNextGet 0 729 2109
assign 1 730 2111
new 1 730 2111
assign 1 731 2112
nextGet 0 731 2112
heldSet 1 731 2113
nlcSet 1 732 2114
assign 1 733 2115
heldGet 0 733 2115
assign 1 733 2116
equals 1 733 2116
assign 1 734 2118
increment 0 734 2118
assign 1 736 2120
heldGet 0 736 2120
assign 1 736 2121
notEquals 1 736 2121
addValue 1 737 2123
containerSet 1 738 2124
return 1 0 2134
assign 1 0 2137
return 1 0 2141
assign 1 0 2144
return 1 0 2148
assign 1 0 2151
return 1 0 2155
assign 1 0 2158
return 1 0 2162
assign 1 0 2165
return 1 0 2169
assign 1 0 2172
return 1 0 2176
assign 1 0 2179
return 1 0 2183
assign 1 0 2186
return 1 0 2190
assign 1 0 2193
return 1 0 2197
assign 1 0 2200
return 1 0 2204
assign 1 0 2207
return 1 0 2211
assign 1 0 2214
return 1 0 2218
assign 1 0 2221
return 1 0 2225
assign 1 0 2228
return 1 0 2232
assign 1 0 2235
return 1 0 2239
assign 1 0 2242
return 1 0 2246
assign 1 0 2249
return 1 0 2253
assign 1 0 2256
return 1 0 2260
assign 1 0 2263
return 1 0 2267
assign 1 0 2270
return 1 0 2274
assign 1 0 2277
return 1 0 2281
assign 1 0 2284
return 1 0 2288
assign 1 0 2291
return 1 0 2295
assign 1 0 2298
return 1 0 2302
assign 1 0 2305
return 1 0 2309
assign 1 0 2312
return 1 0 2316
assign 1 0 2319
return 1 0 2323
assign 1 0 2326
return 1 0 2330
assign 1 0 2333
return 1 0 2337
assign 1 0 2340
return 1 0 2344
assign 1 0 2347
return 1 0 2351
assign 1 0 2354
return 1 0 2358
assign 1 0 2361
return 1 0 2365
assign 1 0 2368
return 1 0 2372
assign 1 0 2375
return 1 0 2379
assign 1 0 2382
return 1 0 2386
assign 1 0 2389
return 1 0 2393
assign 1 0 2396
return 1 0 2400
assign 1 0 2403
return 1 0 2407
assign 1 0 2410
return 1 0 2414
assign 1 0 2417
return 1 0 2421
assign 1 0 2424
return 1 0 2428
assign 1 0 2431
return 1 0 2435
assign 1 0 2438
return 1 0 2442
assign 1 0 2445
return 1 0 2449
assign 1 0 2452
return 1 0 2456
assign 1 0 2459
return 1 0 2463
assign 1 0 2466
return 1 0 2470
assign 1 0 2473
return 1 0 2477
assign 1 0 2480
return 1 0 2484
assign 1 0 2487
return 1 0 2491
assign 1 0 2494
return 1 0 2498
assign 1 0 2501
return 1 0 2505
assign 1 0 2508
return 1 0 2512
assign 1 0 2515
return 1 0 2519
assign 1 0 2522
return 1 0 2526
assign 1 0 2529
return 1 0 2533
assign 1 0 2536
return 1 0 2540
assign 1 0 2543
return 1 0 2547
assign 1 0 2550
return 1 0 2554
assign 1 0 2557
return 1 0 2561
assign 1 0 2564
return 1 0 2568
assign 1 0 2571
return 1 0 2575
assign 1 0 2578
return 1 0 2582
assign 1 0 2585
return 1 0 2589
assign 1 0 2592
return 1 0 2596
assign 1 0 2599
return 1 0 2603
assign 1 0 2606
return 1 0 2610
assign 1 0 2613
return 1 0 2617
assign 1 0 2620
return 1 0 2624
assign 1 0 2627
assign 1 0 2631
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -1924410263: return bem_initLibsGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 2072413014: return bem_loadSynsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -1066352481: return bem_saveSynsGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case -505952126: return bem_copyTo_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case -211282909: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -1913328010: return bem_initLibsSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -1055270228: return bem_saveSynsSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 2083495267: return bem_loadSynsSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
