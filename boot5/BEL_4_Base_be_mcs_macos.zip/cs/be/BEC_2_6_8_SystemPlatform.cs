namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemPlatform : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
static BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_6, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_11, 60));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_12, 5));
public static new BEC_2_6_8_SystemPlatform bevs_inst;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
this.bem_buildProfile_0();
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_0;
bevt_2_tmpany_phold = bevp_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 624 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_5_tmpany_phold = bevo_1;
bevt_4_tmpany_phold = bevp_name.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 624 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 624 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 624 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_7_tmpany_phold = bevo_2;
bevt_6_tmpany_phold = bevp_name.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 624 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 624 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 624 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 624 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
} /* Line: 629 */
 else  /* Line: 624 */ {
bevt_9_tmpany_phold = bevo_3;
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 630 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_7));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_8));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 635 */
 else  /* Line: 636 */ {
bevt_13_tmpany_phold = bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_name);
bevt_14_tmpany_phold = bevo_5;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 637 */
} /* Line: 624 */
bevl_strings = BEC_2_4_7_TextStrings.bevs_inst;
bevt_16_tmpany_phold = bevo_6;
bevt_15_tmpany_phold = bevp_name.bem_equals_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 640 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(1567400443, BEL_4_Base.bevn_unixNewlineGet_0);
} /* Line: 642 */
 else  /* Line: 643 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(1567400443, BEL_4_Base.bevn_unixNewlineGet_0);
} /* Line: 644 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNixGet_0() {
return bevp_isNix;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isWinGet_0() {
return bevp_isWin;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_otherSeparatorGet_0() {
return bevp_otherSeparator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nullFileGet_0() {
return bevp_nullFile;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {618, 619, 624, 624, 0, 624, 624, 0, 0, 0, 624, 624, 0, 0, 625, 626, 627, 628, 629, 630, 630, 631, 632, 633, 634, 635, 637, 637, 637, 637, 637, 637, 639, 640, 640, 642, 644, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {45, 46, 68, 69, 71, 74, 75, 77, 80, 84, 87, 88, 90, 93, 97, 98, 99, 100, 101, 104, 105, 107, 108, 109, 110, 111, 114, 115, 116, 117, 118, 119, 122, 123, 124, 126, 129, 134, 137, 141, 144, 148, 151, 155, 158, 162, 165, 169, 172, 176, 179};
/* BEGIN LINEINFO 
assign 1 618 45
buildProfile 0 619 46
assign 1 624 68
new 0 624 68
assign 1 624 69
equals 1 624 69
assign 1 0 71
assign 1 624 74
new 0 624 74
assign 1 624 75
equals 1 624 75
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 624 87
new 0 624 87
assign 1 624 88
equals 1 624 88
assign 1 0 90
assign 1 0 93
assign 1 625 97
new 0 625 97
assign 1 626 98
new 0 626 98
assign 1 627 99
new 0 627 99
assign 1 628 100
new 0 628 100
assign 1 629 101
new 0 629 101
assign 1 630 104
new 0 630 104
assign 1 630 105
equals 1 630 105
assign 1 631 107
new 0 631 107
assign 1 632 108
new 0 632 108
assign 1 633 109
new 0 633 109
assign 1 634 110
new 0 634 110
assign 1 635 111
new 0 635 111
assign 1 637 114
new 0 637 114
assign 1 637 115
add 1 637 115
assign 1 637 116
new 0 637 116
assign 1 637 117
add 1 637 117
assign 1 637 118
new 1 637 118
throw 1 637 119
assign 1 639 122
new 0 639 122
assign 1 640 123
new 0 640 123
assign 1 640 124
equals 1 640 124
assign 1 642 126
unixNewlineGet 0 642 126
assign 1 644 129
unixNewlineGet 0 644 129
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -497549102: return bem_otherSeparatorGet_0();
case 1820417453: return bem_create_0();
case 399659426: return bem_separatorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1211273660: return bem_nameGet_0();
case -1012494862: return bem_once_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case -1935732139: return bem_isWinGet_0();
case 287040793: return bem_hashGet_0();
case -1081412016: return bem_many_0();
case 1102720804: return bem_classNameGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -845792839: return bem_iteratorGet_0();
case -154864460: return bem_isNixGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 127461284: return bem_nullFileGet_0();
case -729571811: return bem_serializeToString_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case -314718434: return bem_print_0();
case 425100364: return bem_buildProfile_0();
case 776765523: return bem_newlineGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -486466849: return bem_otherSeparatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1924649886: return bem_isWinSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -143782207: return bem_isNixSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 138543537: return bem_nullFileSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemPlatform.bevs_inst = (BEC_2_6_8_SystemPlatform)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemPlatform.bevs_inst;
}
}
}
