namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_2_4_IOFile : BEC_2_6_6_SystemObject {
public BEC_2_2_4_IOFile() { }
static BEC_2_2_4_IOFile() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_2_4_IOFile bevs_inst;
public BEC_3_2_4_4_IOFilePath bevp_path;
public BEC_2_6_6_SystemObject bevp_reader;
public BEC_2_6_6_SystemObject bevp_writer;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_apNew_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__path) {
this.bem_pathSet_1(beva__path);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_3_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 60 */
return bevp_reader;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writerGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_writer == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevt_1_tmpany_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_3_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpany_phold);
} /* Line: 67 */
return bevp_writer;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_delete_0() {
BEC_2_6_6_SystemObject bevl_llpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          File.Delete(bevls_path);
          } /* Line: 96 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_copyFile_1(BEC_2_6_6_SystemObject beva_other) {
BEC_3_2_4_6_IOFileWriter bevl_outw = null;
BEC_3_2_4_6_IOFileReader bevl_inr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bemd_0(-400189342, BEL_4_Base.bevn_pathGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(992607997, BEL_4_Base.bevn_parentGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_0_tmpany_phold.bemd_0(-181594299, BEL_4_Base.bevn_makeDirs_0);
bevt_3_tmpany_phold = beva_other.bemd_0(-2037163820, BEL_4_Base.bevn_writerGet_0);
bevl_outw = (BEC_3_2_4_6_IOFileWriter) bevt_3_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_4_tmpany_phold = this.bem_readerGet_0();
bevl_inr = (BEC_3_2_4_6_IOFileReader) bevt_4_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inr.bem_copyData_1(bevl_outw);
bevl_inr.bem_close_0();
bevl_outw.bem_close_0();
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdirs_0() {
this.bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_mkdir_0() {
this.bem_makeDirs_0();
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeDirs_0() {
BEC_2_4_6_TextString bevl_frs = null;
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_5_4_LogicBool bevl_t = null;
BEC_2_6_6_SystemObject bevl_strn = null;
BEC_2_6_6_SystemObject bevl_parentpath = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_t = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_strn = BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevl_strn.bemd_0(-1081741254, BEL_4_Base.bevn_emptyGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_5_tmpany_phold = this.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpany_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 137 */ {
return this;
} /* Line: 139 */
bevt_7_tmpany_phold = bevl_parentpath.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpany_phold.bemd_0(-181594299, BEL_4_Base.bevn_makeDirs_0);

         Directory.CreateDirectory(
         System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int)
         );
         } /* Line: 164 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirectoryGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_isDirGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isDirGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = this.bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (Directory.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 216 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isFileGet_0() {
BEC_2_6_6_SystemObject bevl_spa = null;
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpany_phold = this.bem_existsGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 239 */ {

          string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
          if (File.Exists(bevls_path)) {
            bevl_result = be.BECS_Runtime.boolTrue;
          }
          } /* Line: 264 */
return bevl_result;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_makeFile_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_writerGet_0();
bevt_0_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_1_tmpany_phold = this.bem_writerGet_0();
bevt_1_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 282 */ {
return null;
} /* Line: 283 */
bevt_2_tmpany_phold = this.bem_contentsNoCheckGet_0();
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_contentsNoCheckGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_4_6_TextString bevl_res = null;
bevl_r = this.bem_readerGet_0();
bevl_r.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_res = (BEC_2_4_6_TextString) bevl_r.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_r.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_res;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
bevt_4_tmpany_phold = this.bem_pathGet_0();
bevt_3_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_4_tmpany_phold.bem_parentGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 297 */ {
bevt_7_tmpany_phold = this.bem_pathGet_0();
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_5_tmpany_phold.bem_makeDirs_0();
} /* Line: 298 */
this.bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_contentsNoCheckSet_1(BEC_2_4_6_TextString beva_contents) {
BEC_2_6_6_SystemObject bevl_w = null;
bevl_w = this.bem_writerGet_0();
bevl_w.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_contents);
bevl_w.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_sz = null;
bevl_sz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_sz;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_existsGet_0() {
BEC_2_5_4_LogicBool bevl_tvala = null;
BEC_2_6_6_SystemObject bevl_mpath = null;
bevl_tvala = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      string bevls_path = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
      if (File.Exists(bevls_path) || Directory.Exists(bevls_path)) {
        bevl_tvala = be.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_absPathGet_0() {
BEC_3_2_4_4_IOFilePath bevl_absp = null;
BEC_2_4_6_TextString bevl_abstr = null;
 /* Line: 374 */ {
} /* Line: 375 */
bevl_absp = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_close_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_reader == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevp_reader.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 389 */
if (bevp_writer == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 391 */ {
bevp_writer.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 392 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_2_4_17_IOFileDirectoryIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_17_IOFileDirectoryIterator) (new BEC_3_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_reader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_writerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_writer = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {47, 47, 51, 51, 55, 59, 59, 60, 60, 62, 66, 66, 67, 67, 69, 83, 106, 106, 106, 106, 107, 107, 108, 108, 109, 110, 111, 112, 112, 117, 120, 131, 132, 133, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 136, 137, 139, 141, 141, 177, 177, 189, 190, 191, 225, 237, 238, 239, 273, 277, 277, 278, 278, 282, 282, 282, 283, 285, 285, 289, 290, 291, 292, 293, 297, 297, 297, 297, 297, 297, 298, 298, 298, 298, 300, 304, 305, 306, 307, 312, 319, 331, 332, 366, 383, 384, 388, 388, 389, 391, 391, 392, 397, 397, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 31, 32, 36, 42, 47, 48, 49, 51, 56, 61, 62, 63, 65, 70, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 102, 106, 123, 124, 125, 126, 127, 128, 129, 131, 132, 137, 138, 141, 145, 148, 149, 151, 153, 154, 164, 165, 171, 172, 173, 181, 187, 188, 189, 197, 202, 203, 204, 205, 212, 213, 218, 219, 221, 222, 227, 228, 229, 230, 231, 242, 243, 244, 245, 246, 251, 252, 253, 254, 255, 257, 262, 263, 264, 265, 270, 271, 276, 277, 283, 290, 291, 296, 301, 302, 304, 309, 310, 316, 317, 320, 323, 327, 331};
/* BEGIN LINEINFO 
assign 1 47 25
new 1 47 25
pathSet 1 47 26
assign 1 51 31
apNew 1 51 31
pathSet 1 51 32
pathSet 1 55 36
assign 1 59 42
undef 1 59 47
assign 1 60 48
toString 0 60 48
assign 1 60 49
new 1 60 49
return 1 62 51
assign 1 66 56
undef 1 66 61
assign 1 67 62
toString 0 67 62
assign 1 67 63
new 1 67 63
return 1 69 65
assign 1 83 70
existsGet 0 83 70
assign 1 106 87
pathGet 0 106 87
assign 1 106 88
parentGet 0 106 88
assign 1 106 89
fileGet 0 106 89
makeDirs 0 106 90
assign 1 107 91
writerGet 0 107 91
assign 1 107 92
open 0 107 92
assign 1 108 93
readerGet 0 108 93
assign 1 108 94
open 0 108 94
copyData 1 109 95
close 0 110 96
close 0 111 97
assign 1 112 98
new 0 112 98
return 1 112 99
makeDirs 0 117 102
makeDirs 0 120 106
assign 1 131 123
toString 0 131 123
assign 1 132 124
new 0 132 124
assign 1 133 125
new 0 133 125
assign 1 134 126
new 0 134 126
assign 1 135 127
toString 0 135 127
assign 1 135 128
emptyGet 0 135 128
assign 1 135 129
notEquals 1 135 129
assign 1 135 131
existsGet 0 135 131
assign 1 135 132
not 0 135 137
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 136 148
parentGet 0 136 148
assign 1 137 149
equals 1 137 149
return 1 139 151
assign 1 141 153
fileGet 0 141 153
makeDirs 0 141 154
assign 1 177 164
isDirGet 0 177 164
return 1 177 165
assign 1 189 171
new 0 189 171
assign 1 190 172
toString 0 190 172
assign 1 191 173
existsGet 0 191 173
return 1 225 181
assign 1 237 187
new 0 237 187
assign 1 238 188
toString 0 238 188
assign 1 239 189
existsGet 0 239 189
return 1 273 197
assign 1 277 202
writerGet 0 277 202
open 0 277 203
assign 1 278 204
writerGet 0 278 204
close 0 278 205
assign 1 282 212
existsGet 0 282 212
assign 1 282 213
not 0 282 218
return 1 283 219
assign 1 285 221
contentsNoCheckGet 0 285 221
return 1 285 222
assign 1 289 227
readerGet 0 289 227
open 0 290 228
assign 1 291 229
readString 0 291 229
close 0 292 230
return 1 293 231
assign 1 297 242
pathGet 0 297 242
assign 1 297 243
parentGet 0 297 243
assign 1 297 244
fileGet 0 297 244
assign 1 297 245
existsGet 0 297 245
assign 1 297 246
not 0 297 251
assign 1 298 252
pathGet 0 298 252
assign 1 298 253
parentGet 0 298 253
assign 1 298 254
fileGet 0 298 254
makeDirs 0 298 255
contentsNoCheckSet 1 300 257
assign 1 304 262
writerGet 0 304 262
open 0 305 263
write 1 306 264
close 0 307 265
assign 1 312 270
new 0 312 270
return 1 319 271
assign 1 331 276
new 0 331 276
assign 1 332 277
toString 0 332 277
return 1 366 283
assign 1 383 290
apNew 1 383 290
return 1 384 291
assign 1 388 296
def 1 388 301
close 0 389 302
assign 1 391 304
def 1 391 309
close 0 392 310
assign 1 397 316
new 1 397 316
return 1 397 317
return 1 0 320
assign 1 0 323
assign 1 0 327
assign 1 0 331
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 371906180: return bem_readerGet_0();
case -209284380: return bem_isDirectoryGet_0();
case -1081412016: return bem_many_0();
case -181594299: return bem_makeDirs_0();
case 129806037: return bem_mkdirs_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -574873532: return bem_isDirGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case -160463007: return bem_isFileGet_0();
case 2072547979: return bem_existsGet_0();
case 108109840: return bem_absPathGet_0();
case 866536361: return bem_close_0();
case 547861133: return bem_contentsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -124528197: return bem_makeFile_0();
case -729571811: return bem_serializeToString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 439054906: return bem_contentsNoCheckGet_0();
case -1354714650: return bem_copy_0();
case 819712668: return bem_delete_0();
case -400189342: return bem_pathGet_0();
case 1112565280: return bem_mkdir_0();
case -2037163820: return bem_writerGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1294597629: return bem_copyFile_1(bevd_0);
case -393721811: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 382988433: return bem_readerSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -824830365: return bem_apNew_1(bevd_0);
case 558943386: return bem_contentsSet_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 450137159: return bem_contentsNoCheckSet_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2026081567: return bem_writerSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_4_IOFile();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_4_IOFile.bevs_inst = (BEC_2_2_4_IOFile)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_4_IOFile.bevs_inst;
}
}
}
