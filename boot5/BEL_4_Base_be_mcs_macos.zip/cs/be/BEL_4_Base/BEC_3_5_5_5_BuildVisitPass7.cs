namespace be.BEL_4_Base {
/* IO:File: source/build/Pass7.be */
public class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpvar_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpvar_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpvar_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_1));
bevt_13_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_2));
bevt_15_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_19_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_22_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_26_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_29_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_32_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_35_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_38_tmpvar_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpvar_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpvar_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 62 */
} /* Line: 55 */
} /* Line: 53 */
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_123_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_129_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_139_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_143_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_163_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 93 */
if (bevp_inClassNp == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 95 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 97 */
bevt_16_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_equals_1(bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpvar_phold);
} /* Line: 111 */
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpvar_phold);
} /* Line: 115 */
bevt_38_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_equals_1(bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_40_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpvar_phold);
} /* Line: 123 */
 else  /* Line: 121 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_equals_1(bevt_44_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 125 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpvar_phold == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 126 */ {
if (bevl_nnode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_53_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_59_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_55_tmpvar_phold);
} /* Line: 127 */
 else  /* Line: 128 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpvar_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpvar_phold;
} /* Line: 135 */
} /* Line: 126 */
 else  /* Line: 121 */ {
bevt_64_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_equals_1(bevt_65_tmpvar_phold);
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 137 */ {
if (bevl_nnode == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_68_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpvar_phold == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 141 */ {
bevt_73_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 143 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 147 */ {
bevt_77_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 149 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
} /* Line: 147 */
bevl_pc = bevl_nnode;
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpvar_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_82_tmpvar_phold = bevl_dnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 160 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 160 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bels_12));
bevt_85_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 163 */
 else  /* Line: 162 */ {
bevt_88_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bem_equals_1(bevt_89_tmpvar_phold);
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevt_91_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_92_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 169 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 170 */
} /* Line: 165 */
 else  /* Line: 162 */ {
bevt_96_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_equals_1(bevt_97_tmpvar_phold);
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_101_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpvar_phold);
if (bevt_98_tmpvar_phold != null && bevt_98_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpvar_phold).bevi_bool) /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_103_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_103_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_104_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_104_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
bevt_106_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_105_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_106_tmpvar_phold);
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_107_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_107_tmpvar_phold);
bevt_108_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_108_tmpvar_phold);
bevt_109_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_109_tmpvar_phold);
} /* Line: 181 */
 else  /* Line: 182 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 183 */
} /* Line: 178 */
 else  /* Line: 162 */ {
bevt_111_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_112_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_13));
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_112_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_114_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bels_14));
bevt_113_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_114_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_113_tmpvar_phold);
} /* Line: 186 */
 else  /* Line: 162 */ {
bevt_116_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_117_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_15));
bevt_115_tmpvar_phold = bevt_116_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_117_tmpvar_phold);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 187 */ {
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bels_16));
bevt_118_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_119_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_118_tmpvar_phold);
} /* Line: 188 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 193 */
 else  /* Line: 194 */ {
bevt_120_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_120_tmpvar_phold);
bevt_121_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_121_tmpvar_phold);
} /* Line: 196 */
} /* Line: 160 */
} /* Line: 138 */
 else  /* Line: 121 */ {
bevt_123_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_124_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_equals_1(bevt_124_tmpvar_phold);
if (bevt_122_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_125_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_17));
bevt_126_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 205 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_129_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_130_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_equals_1(bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bels_18));
bevt_131_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 210 */
bevt_133_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_133_tmpvar_phold);
} /* Line: 212 */
 else  /* Line: 121 */ {
bevt_135_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_136_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bem_equals_1(bevt_136_tmpvar_phold);
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
if (bevl_onode == null) {
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_140_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bels_19));
bevt_139_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_139_tmpvar_phold);
} /* Line: 219 */
bevt_142_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_143_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_141_tmpvar_phold = bevt_142_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_143_tmpvar_phold);
if (bevt_141_tmpvar_phold != null && bevt_141_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_141_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevl_pnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_144_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_146_tmpvar_phold = bevl_pnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 223 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_148_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_148_tmpvar_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_149_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_149_tmpvar_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_151_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bem_equals_1(bevt_152_tmpvar_phold);
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 232 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 233 */
 else  /* Line: 232 */ {
bevt_154_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_155_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bem_equals_1(bevt_155_tmpvar_phold);
if (bevt_153_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_159_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_157_tmpvar_phold = bevt_158_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_160_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_160_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_161_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_161_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_162_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_162_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 240 */
} /* Line: 232 */
} /* Line: 232 */
} /* Line: 223 */
} /* Line: 221 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
bevt_163_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_163_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpvar_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpvar_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {28, 29, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42, 44, 46, 47, 49, 51, 0, 51, 0, 52, 53, 0, 53, 0, 54, 55, 0, 55, 0, 55, 0, 55, 0, 61, 62, 88, 91, 92, 93, 95, 96, 97, 99, 100, 102, 103, 105, 106, 108, 110, 111, 113, 114, 115, 121, 122, 123, 125, 0, 126, 0, 126, 0, 127, 129, 130, 131, 135, 137, 138, 0, 139, 140, 141, 142, 143, 144, 147, 148, 149, 152, 153, 154, 155, 156, 157, 158, 159, 160, 0, 161, 162, 163, 164, 165, 166, 167, 168, 170, 172, 0, 173, 174, 175, 176, 177, 178, 179, 180, 181, 183, 185, 186, 187, 188, 191, 192, 193, 195, 196, 200, 203, 204, 205, 207, 208, 209, 210, 212, 213, 215, 218, 0, 218, 0, 219, 221, 222, 223, 0, 223, 0, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 0, 235, 236, 237, 238, 239, 240, 245, 249, 250, 251, 252, 253, 255, 256, 257, 258, 259, 260, 261, 262, 0};
public static new int[] bevs_smnlec
 = new int[] {34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34};
/* BEGIN LINEINFO 
assign 1 28 34
new 0 28 34
fromString 1 29 34
assign 1 31 34
new 1 31 34
assign 1 32 34
NAMEPATHGet 0 32 34
typenameSet 1 32 34
heldSet 1 33 34
copyLoc 1 34 34
assign 1 36 34
new 0 36 34
assign 1 37 34
new 0 37 34
nameSet 1 37 34
assign 1 38 34
new 0 38 34
wasBoundSet 1 38 34
assign 1 39 34
new 0 39 34
boundSet 1 39 34
assign 1 40 34
new 0 40 34
isConstructSet 1 40 34
assign 1 41 34
new 0 41 34
isLiteralSet 1 41 34
assign 1 42 34
heldGet 0 42 34
literalValueSet 1 42 34
addValue 1 44 34
assign 1 46 34
CALLGet 0 46 34
typenameSet 1 46 34
heldSet 1 47 34
resolveNp 0 49 34
assign 1 51 34
new 0 51 34
assign 1 51 34
equals 1 51 34
assign 1 0 34
assign 1 51 34
new 0 51 34
assign 1 51 34
equals 1 51 34
assign 1 0 34
assign 1 0 34
assign 1 52 34
priorPeerGet 0 52 34
assign 1 53 34
def 1 53 34
assign 1 53 34
typenameGet 0 53 34
assign 1 53 34
SUBTRACTGet 0 53 34
assign 1 53 34
equals 1 53 34
assign 1 0 34
assign 1 53 34
typenameGet 0 53 34
assign 1 53 34
ADDGet 0 53 34
assign 1 53 34
equals 1 53 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 54 34
priorPeerGet 0 54 34
assign 1 55 34
undef 1 55 34
assign 1 0 34
assign 1 55 34
typenameGet 0 55 34
assign 1 55 34
CALLGet 0 55 34
assign 1 55 34
notEquals 1 55 34
assign 1 55 34
typenameGet 0 55 34
assign 1 55 34
IDGet 0 55 34
assign 1 55 34
notEquals 1 55 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 55 34
typenameGet 0 55 34
assign 1 55 34
VARGet 0 55 34
assign 1 55 34
notEquals 1 55 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 55 34
typenameGet 0 55 34
assign 1 55 34
ACCESSORGet 0 55 34
assign 1 55 34
notEquals 1 55 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 61 34
heldGet 0 61 34
assign 1 61 34
literalValueGet 0 61 34
assign 1 61 34
add 1 61 34
literalValueSet 1 61 34
delete 0 62 34
assign 1 88 34
nextPeerGet 0 88 34
assign 1 91 34
typenameGet 0 91 34
assign 1 91 34
CLASSGet 0 91 34
assign 1 91 34
equals 1 91 34
assign 1 92 34
heldGet 0 92 34
assign 1 92 34
namepathGet 0 92 34
assign 1 93 34
heldGet 0 93 34
assign 1 93 34
fromFileGet 0 93 34
assign 1 93 34
toString 0 93 34
assign 1 95 34
def 1 95 34
inClassNpSet 1 96 34
inFileSet 1 97 34
assign 1 99 34
typenameGet 0 99 34
assign 1 99 34
INTLGet 0 99 34
assign 1 99 34
equals 1 99 34
assign 1 100 34
new 0 100 34
buildLiteral 2 100 34
assign 1 102 34
typenameGet 0 102 34
assign 1 102 34
FLOATLGet 0 102 34
assign 1 102 34
equals 1 102 34
assign 1 103 34
new 0 103 34
buildLiteral 2 103 34
assign 1 105 34
typenameGet 0 105 34
assign 1 105 34
STRINGLGet 0 105 34
assign 1 105 34
equals 1 105 34
assign 1 106 34
new 0 106 34
buildLiteral 2 106 34
assign 1 108 34
typenameGet 0 108 34
assign 1 108 34
WSTRINGLGet 0 108 34
assign 1 108 34
equals 1 108 34
assign 1 110 34
new 0 110 34
buildLiteral 2 110 34
assign 1 111 34
new 0 111 34
wideStringSet 1 111 34
assign 1 113 34
typenameGet 0 113 34
assign 1 113 34
TRUEGet 0 113 34
assign 1 113 34
equals 1 113 34
assign 1 114 34
new 0 114 34
heldSet 1 114 34
assign 1 115 34
new 0 115 34
buildLiteral 2 115 34
assign 1 121 34
typenameGet 0 121 34
assign 1 121 34
FALSEGet 0 121 34
assign 1 121 34
equals 1 121 34
assign 1 122 34
new 0 122 34
heldSet 1 122 34
assign 1 123 34
new 0 123 34
buildLiteral 2 123 34
assign 1 125 34
typenameGet 0 125 34
assign 1 125 34
VARGet 0 125 34
assign 1 125 34
equals 1 125 34
assign 1 125 34
heldGet 0 125 34
assign 1 125 34
isArgGet 0 125 34
assign 1 125 34
not 0 125 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 126 34
heldGet 0 126 34
assign 1 126 34
nameGet 0 126 34
assign 1 126 34
undef 1 126 34
assign 1 126 34
undef 1 126 34
assign 1 0 34
assign 1 126 34
typenameGet 0 126 34
assign 1 126 34
IDGet 0 126 34
assign 1 126 34
notEquals 1 126 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 127 34
new 0 127 34
assign 1 127 34
heldGet 0 127 34
assign 1 127 34
nameGet 0 127 34
assign 1 127 34
add 1 127 34
assign 1 127 34
new 2 127 34
throw 1 127 34
assign 1 129 34
heldGet 0 129 34
assign 1 129 34
heldGet 0 129 34
nameSet 1 129 34
addVariable 0 130 34
delete 0 131 34
assign 1 135 34
nextDescendGet 0 135 34
return 1 135 34
assign 1 137 34
typenameGet 0 137 34
assign 1 137 34
IDGet 0 137 34
assign 1 137 34
equals 1 137 34
assign 1 138 34
def 1 138 34
assign 1 138 34
typenameGet 0 138 34
assign 1 138 34
PARENSGet 0 138 34
assign 1 138 34
equals 1 138 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 139 34
containedGet 0 139 34
assign 1 139 34
def 1 139 34
assign 1 140 34
new 0 140 34
assign 1 141 34
containedGet 0 141 34
assign 1 141 34
iteratorGet 0 141 34
assign 1 141 34
hasNextGet 0 141 34
assign 1 142 34
nextGet 0 142 34
assign 1 143 34
typenameGet 0 143 34
assign 1 143 34
COMMAGet 0 143 34
assign 1 143 34
equals 1 143 34
addValue 1 144 34
assign 1 147 34
iteratorGet 0 147 34
assign 1 147 34
hasNextGet 0 147 34
assign 1 148 34
nextGet 0 148 34
delete 0 149 34
assign 1 152 34
assign 1 153 34
CALLGet 0 153 34
typenameSet 1 153 34
assign 1 154 34
new 0 154 34
assign 1 155 34
heldGet 0 155 34
nameSet 1 155 34
heldSet 1 156 34
delete 0 157 34
assign 1 158 34
assign 1 159 34
priorPeerGet 0 159 34
assign 1 160 34
def 1 160 34
assign 1 160 34
typenameGet 0 160 34
assign 1 160 34
DOTGet 0 160 34
assign 1 160 34
equals 1 160 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 161 34
priorPeerGet 0 161 34
assign 1 162 34
undef 1 162 34
assign 1 163 34
new 0 163 34
assign 1 163 34
new 2 163 34
throw 1 163 34
assign 1 164 34
typenameGet 0 164 34
assign 1 164 34
NAMEPATHGet 0 164 34
assign 1 164 34
equals 1 164 34
assign 1 165 34
nameGet 0 165 34
assign 1 165 34
isNewish 1 165 34
assign 1 166 34
new 0 166 34
wasBoundSet 1 166 34
assign 1 167 34
new 0 167 34
boundSet 1 167 34
assign 1 168 34
new 0 168 34
isConstructSet 1 168 34
createImpliedConstruct 2 170 34
assign 1 172 34
typenameGet 0 172 34
assign 1 172 34
IDGet 0 172 34
assign 1 172 34
equals 1 172 34
assign 1 172 34
transUnitGet 0 172 34
assign 1 172 34
heldGet 0 172 34
assign 1 172 34
aliasedGet 0 172 34
assign 1 172 34
heldGet 0 172 34
assign 1 172 34
has 1 172 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 173 34
new 0 173 34
assign 1 174 34
heldGet 0 174 34
addStep 1 174 34
heldSet 1 175 34
assign 1 176 34
NAMEPATHGet 0 176 34
typenameSet 1 176 34
resolveNp 0 177 34
assign 1 178 34
nameGet 0 178 34
assign 1 178 34
isNewish 1 178 34
assign 1 179 34
new 0 179 34
wasBoundSet 1 179 34
assign 1 180 34
new 0 180 34
boundSet 1 180 34
assign 1 181 34
new 0 181 34
isConstructSet 1 181 34
createImpliedConstruct 2 183 34
assign 1 185 34
nameGet 0 185 34
assign 1 185 34
new 0 185 34
assign 1 185 34
equals 1 185 34
assign 1 186 34
new 0 186 34
assign 1 186 34
new 2 186 34
throw 1 186 34
assign 1 187 34
nameGet 0 187 34
assign 1 187 34
new 0 187 34
assign 1 187 34
equals 1 187 34
assign 1 188 34
new 0 188 34
assign 1 188 34
new 2 188 34
throw 1 188 34
delete 0 191 34
prepend 1 192 34
delete 0 193 34
assign 1 195 34
new 0 195 34
boundSet 1 195 34
assign 1 196 34
new 0 196 34
wasBoundSet 1 196 34
assign 1 200 34
typenameGet 0 200 34
assign 1 200 34
IDXGet 0 200 34
assign 1 200 34
equals 1 200 34
assign 1 203 34
priorPeerGet 0 203 34
assign 1 204 34
undef 1 204 34
assign 1 205 34
new 0 205 34
assign 1 205 34
new 2 205 34
throw 1 205 34
delete 0 207 34
prepend 1 208 34
assign 1 209 34
typenameGet 0 209 34
assign 1 209 34
NAMEPATHGet 0 209 34
assign 1 209 34
equals 1 209 34
assign 1 210 34
new 0 210 34
assign 1 210 34
new 2 210 34
throw 1 210 34
assign 1 212 34
IDXACCGet 0 212 34
typenameSet 1 212 34
assign 1 213 34
typenameGet 0 213 34
assign 1 213 34
DOTGet 0 213 34
assign 1 213 34
equals 1 213 34
assign 1 215 34
priorPeerGet 0 215 34
assign 1 218 34
undef 1 218 34
assign 1 0 34
assign 1 218 34
undef 1 218 34
assign 1 0 34
assign 1 0 34
assign 1 219 34
new 0 219 34
assign 1 219 34
new 2 219 34
throw 1 219 34
assign 1 221 34
typenameGet 0 221 34
assign 1 221 34
IDGet 0 221 34
assign 1 221 34
equals 1 221 34
assign 1 222 34
nextPeerGet 0 222 34
assign 1 223 34
undef 1 223 34
assign 1 0 34
assign 1 223 34
typenameGet 0 223 34
assign 1 223 34
PARENSGet 0 223 34
assign 1 223 34
notEquals 1 223 34
assign 1 0 34
assign 1 0 34
assign 1 224 34
priorPeerGet 0 224 34
assign 1 225 34
ACCESSORGet 0 225 34
typenameSet 1 225 34
assign 1 226 34
new 0 226 34
assign 1 227 34
heldGet 0 227 34
nameSet 1 227 34
delete 0 228 34
delete 0 229 34
heldSet 1 230 34
addValue 1 231 34
assign 1 232 34
typenameGet 0 232 34
assign 1 232 34
NAMEPATHGet 0 232 34
assign 1 232 34
equals 1 232 34
createImpliedConstruct 2 233 34
assign 1 234 34
typenameGet 0 234 34
assign 1 234 34
IDGet 0 234 34
assign 1 234 34
equals 1 234 34
assign 1 234 34
transUnitGet 0 234 34
assign 1 234 34
heldGet 0 234 34
assign 1 234 34
aliasedGet 0 234 34
assign 1 234 34
heldGet 0 234 34
assign 1 234 34
has 1 234 34
assign 1 0 34
assign 1 0 34
assign 1 0 34
assign 1 235 34
new 0 235 34
assign 1 236 34
heldGet 0 236 34
addStep 1 236 34
heldSet 1 237 34
assign 1 238 34
NAMEPATHGet 0 238 34
typenameSet 1 238 34
resolveNp 0 239 34
createImpliedConstruct 2 240 34
assign 1 245 34
nextDescendGet 0 245 34
return 1 245 34
assign 1 249 34
new 0 249 34
heldSet 1 250 34
assign 1 251 34
NAMEPATHGet 0 251 34
typenameSet 1 251 34
assign 1 252 34
heldGet 0 252 34
heldSet 1 252 34
prepend 1 253 34
assign 1 255 34
new 0 255 34
assign 1 256 34
new 0 256 34
nameSet 1 256 34
assign 1 257 34
new 0 257 34
wasBoundSet 1 257 34
assign 1 258 34
new 0 258 34
boundSet 1 258 34
assign 1 259 34
new 0 259 34
isConstructSet 1 259 34
assign 1 260 34
new 0 260 34
wasImpliedConstructSet 1 260 34
heldSet 1 261 34
assign 1 262 34
CALLGet 0 262 34
typenameSet 1 262 34
return 1 0 34
assign 1 0 34
return 1 0 34
assign 1 0 34
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
}
