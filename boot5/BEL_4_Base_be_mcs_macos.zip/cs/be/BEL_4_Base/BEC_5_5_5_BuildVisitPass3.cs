namespace be.BEL_4_Base {
/* File: source/build/Pass3.be */
public class BEC_5_5_5_BuildVisitPass3 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass3() { }
static BEC_5_5_5_BuildVisitPass3() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x33};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x33,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_0 = {0x2D};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 1));
public static new BEC_5_5_5_BuildVisitPass3 bevs_inst;
public BEC_5_4_BuildNode bevp_container;
public BEC_4_3_MathInt bevp_nestComment;
public BEC_4_3_MathInt bevp_strqCnt;
public BEC_5_4_BuildNode bevp_goingStr;
public BEC_4_3_MathInt bevp_quoteType;
public BEC_5_4_LogicBool bevp_inLc;
public BEC_5_4_LogicBool bevp_inSpace;
public BEC_5_4_LogicBool bevp_inNl;
public BEC_5_4_LogicBool bevp_inStr;
public override BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bevp_nestComment = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_strqCnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_inLc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inSpace = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inNl = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inStr = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_BuildNode bevl_toRet = null;
BEC_5_4_BuildNode bevl_xn = null;
BEC_4_3_MathInt bevl_fsc = null;
BEC_6_6_SystemObject bevl_csc = null;
BEC_6_6_SystemObject bevl_ia = null;
BEC_5_4_BuildNode bevl_vback = null;
BEC_5_4_BuildNode bevl_pre = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_21_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_22_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_23_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_24_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_25_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_26_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_27_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_28_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_29_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_30_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_31_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_32_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_33_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_34_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_35_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_36_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_37_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_38_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_39_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_40_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_41_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_42_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_43_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_44_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_45_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_46_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_47_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_48_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_49_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_50_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_51_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_52_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_53_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_54_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_55_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_56_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_67_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_4_3_MathInt bevt_107_tmpvar_phold = null;
BEC_4_3_MathInt bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_4_3_MathInt bevt_123_tmpvar_phold = null;
BEC_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_4_3_MathInt bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_4_3_MathInt bevt_131_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_132_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_138_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_143_tmpvar_phold = null;
BEC_4_3_MathInt bevt_144_tmpvar_phold = null;
BEC_4_3_MathInt bevt_145_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_146_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_147_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_148_tmpvar_phold = null;
BEC_4_3_MathInt bevt_149_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_150_tmpvar_phold = null;
BEC_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_153_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_154_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_155_tmpvar_phold = null;
BEC_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_4_3_MathInt bevt_157_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_158_tmpvar_phold = null;
BEC_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_162_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_163_tmpvar_phold = null;
BEC_4_3_MathInt bevt_164_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_165_tmpvar_phold = null;
BEC_4_3_MathInt bevt_166_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_167_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_168_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_170_tmpvar_phold = null;
BEC_4_3_MathInt bevt_171_tmpvar_phold = null;
BEC_4_3_MathInt bevt_172_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_173_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_174_tmpvar_phold = null;
BEC_4_3_MathInt bevt_175_tmpvar_phold = null;
BEC_4_3_MathInt bevt_176_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_4_3_MathInt bevt_179_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_181_tmpvar_phold = null;
BEC_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_183_tmpvar_phold = null;
BEC_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_187_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_188_tmpvar_phold = null;
BEC_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_4_3_MathInt bevt_190_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_192_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_193_tmpvar_phold = null;
BEC_4_3_MathInt bevt_194_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_195_tmpvar_phold = null;
BEC_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_198_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_200_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_201_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_202_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_203_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_4_3_MathInt bevt_205_tmpvar_phold = null;
BEC_4_3_MathInt bevt_206_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_208_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_209_tmpvar_phold = null;
BEC_4_3_MathInt bevt_210_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_211_tmpvar_phold = null;
BEC_4_3_MathInt bevt_212_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_213_tmpvar_phold = null;
BEC_4_3_MathInt bevt_214_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_215_tmpvar_phold = null;
BEC_4_3_MathInt bevt_216_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_220_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_221_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_222_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_223_tmpvar_phold = null;
BEC_4_3_MathInt bevt_224_tmpvar_phold = null;
BEC_4_3_MathInt bevt_225_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_226_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_227_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_228_tmpvar_phold = null;
BEC_4_3_MathInt bevt_229_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_230_tmpvar_phold = null;
BEC_4_3_MathInt bevt_231_tmpvar_phold = null;
BEC_4_3_MathInt bevt_232_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_236_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_237_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_238_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_239_tmpvar_phold = null;
BEC_4_3_MathInt bevt_240_tmpvar_phold = null;
BEC_4_3_MathInt bevt_241_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_242_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_243_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_4_3_MathInt bevt_245_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_246_tmpvar_phold = null;
BEC_4_3_MathInt bevt_247_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_248_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_249_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_250_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_251_tmpvar_phold = null;
BEC_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_253_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_254_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_255_tmpvar_phold = null;
BEC_4_3_MathInt bevt_256_tmpvar_phold = null;
BEC_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_259_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_260_tmpvar_phold = null;
BEC_4_3_MathInt bevt_261_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_262_tmpvar_phold = null;
BEC_4_3_MathInt bevt_263_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_264_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_269_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_270_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_271_tmpvar_phold = null;
BEC_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_4_3_MathInt bevt_273_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_274_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_275_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_276_tmpvar_phold = null;
BEC_4_3_MathInt bevt_277_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_278_tmpvar_phold = null;
BEC_4_3_MathInt bevt_279_tmpvar_phold = null;
BEC_4_3_MathInt bevt_280_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_281_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_282_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_283_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_284_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_285_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_286_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_287_tmpvar_phold = null;
BEC_4_3_MathInt bevt_288_tmpvar_phold = null;
BEC_4_3_MathInt bevt_289_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_290_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_291_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_292_tmpvar_phold = null;
BEC_4_3_MathInt bevt_293_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_294_tmpvar_phold = null;
BEC_4_3_MathInt bevt_295_tmpvar_phold = null;
BEC_4_3_MathInt bevt_296_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_297_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_298_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_299_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_300_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_301_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_302_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_303_tmpvar_phold = null;
BEC_4_3_MathInt bevt_304_tmpvar_phold = null;
BEC_4_3_MathInt bevt_305_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_306_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_307_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_308_tmpvar_phold = null;
BEC_4_3_MathInt bevt_309_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_310_tmpvar_phold = null;
BEC_4_3_MathInt bevt_311_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_312_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_313_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_314_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_315_tmpvar_phold = null;
BEC_4_3_MathInt bevt_316_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_317_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_318_tmpvar_phold = null;
BEC_4_3_MathInt bevt_319_tmpvar_phold = null;
BEC_4_3_MathInt bevt_320_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_321_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_322_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_323_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_324_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_325_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_326_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_327_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_328_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_329_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_330_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_331_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_332_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_333_tmpvar_phold = null;
BEC_4_3_MathInt bevt_334_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_335_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_336_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_337_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_338_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_339_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_340_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_341_tmpvar_phold = null;
BEC_4_3_MathInt bevt_342_tmpvar_phold = null;
BEC_4_3_MathInt bevt_343_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_344_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_345_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_346_tmpvar_phold = null;
BEC_4_3_MathInt bevt_347_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_348_tmpvar_phold = null;
BEC_4_3_MathInt bevt_349_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_350_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_351_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_352_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_353_tmpvar_phold = null;
BEC_4_3_MathInt bevt_354_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_355_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_356_tmpvar_phold = null;
BEC_4_3_MathInt bevt_357_tmpvar_phold = null;
BEC_4_3_MathInt bevt_358_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_359_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_360_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_361_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_362_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_363_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_364_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_365_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_366_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_367_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_368_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_369_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_370_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_371_tmpvar_phold = null;
BEC_4_3_MathInt bevt_372_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_373_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_374_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_375_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_376_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_377_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_378_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_379_tmpvar_phold = null;
BEC_4_3_MathInt bevt_380_tmpvar_phold = null;
BEC_4_3_MathInt bevt_381_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_382_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_383_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_384_tmpvar_phold = null;
BEC_4_3_MathInt bevt_385_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_386_tmpvar_phold = null;
BEC_4_3_MathInt bevt_387_tmpvar_phold = null;
BEC_4_3_MathInt bevt_388_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_389_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_390_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_391_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_392_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_393_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_394_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_395_tmpvar_phold = null;
BEC_4_3_MathInt bevt_396_tmpvar_phold = null;
BEC_4_3_MathInt bevt_397_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_398_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_399_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_400_tmpvar_phold = null;
BEC_4_3_MathInt bevt_401_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_402_tmpvar_phold = null;
BEC_4_3_MathInt bevt_403_tmpvar_phold = null;
BEC_4_3_MathInt bevt_404_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_405_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_406_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_407_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_408_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_409_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_410_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_411_tmpvar_phold = null;
BEC_4_3_MathInt bevt_412_tmpvar_phold = null;
BEC_4_3_MathInt bevt_413_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_414_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_415_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_416_tmpvar_phold = null;
BEC_4_3_MathInt bevt_417_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_418_tmpvar_phold = null;
BEC_4_3_MathInt bevt_419_tmpvar_phold = null;
BEC_4_3_MathInt bevt_420_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_421_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_422_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_423_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_424_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_425_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_426_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_427_tmpvar_phold = null;
BEC_4_3_MathInt bevt_428_tmpvar_phold = null;
BEC_4_3_MathInt bevt_429_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_430_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_431_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_432_tmpvar_phold = null;
BEC_4_3_MathInt bevt_433_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_434_tmpvar_phold = null;
BEC_4_3_MathInt bevt_435_tmpvar_phold = null;
BEC_4_3_MathInt bevt_436_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_437_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_438_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_439_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_440_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_441_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_442_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_443_tmpvar_phold = null;
BEC_4_3_MathInt bevt_444_tmpvar_phold = null;
BEC_4_3_MathInt bevt_445_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_446_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_447_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_448_tmpvar_phold = null;
BEC_4_3_MathInt bevt_449_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_450_tmpvar_phold = null;
BEC_4_3_MathInt bevt_451_tmpvar_phold = null;
BEC_4_3_MathInt bevt_452_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_453_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_454_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_455_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_456_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_457_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_458_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_459_tmpvar_phold = null;
BEC_4_3_MathInt bevt_460_tmpvar_phold = null;
BEC_4_3_MathInt bevt_461_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_462_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_463_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_464_tmpvar_phold = null;
BEC_4_3_MathInt bevt_465_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_466_tmpvar_phold = null;
BEC_4_3_MathInt bevt_467_tmpvar_phold = null;
BEC_4_3_MathInt bevt_468_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_469_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_470_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_471_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_472_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_473_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_474_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_475_tmpvar_phold = null;
BEC_4_3_MathInt bevt_476_tmpvar_phold = null;
BEC_4_3_MathInt bevt_477_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_478_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_479_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_480_tmpvar_phold = null;
BEC_4_3_MathInt bevt_481_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_482_tmpvar_phold = null;
BEC_4_3_MathInt bevt_483_tmpvar_phold = null;
BEC_4_3_MathInt bevt_484_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_485_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_486_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_487_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_488_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_489_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_490_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_491_tmpvar_phold = null;
BEC_4_3_MathInt bevt_492_tmpvar_phold = null;
BEC_4_3_MathInt bevt_493_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_494_tmpvar_phold = null;
BEC_4_3_MathInt bevt_495_tmpvar_phold = null;
BEC_4_3_MathInt bevt_496_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_497_tmpvar_phold = null;
bevt_58_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_61_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_61_tmpvar_phold == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_64_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_equals_1(bevt_65_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_66_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevp_nestComment = bevp_nestComment.bem_increment_0();
bevt_67_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_67_tmpvar_phold.bem_nextDescendGet_0();
bevt_68_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_68_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 58 */
bevt_70_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_equals_1(bevt_71_tmpvar_phold);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_73_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_73_tmpvar_phold == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_76_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_typenameGet_0();
bevt_77_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_equals_1(bevt_77_tmpvar_phold);
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_78_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevp_nestComment = bevp_nestComment.bem_decrement_0();
bevt_79_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_79_tmpvar_phold.bem_nextDescendGet_0();
bevt_80_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_80_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 66 */
bevt_82_tmpvar_phold = bevo_0;
bevt_81_tmpvar_phold = bevp_nestComment.bem_greater_1(bevt_82_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 71 */
bevt_83_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_84_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 73 */ {
bevt_86_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_87_tmpvar_phold = bevp_ntypes.bem_STRQGet_0();
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_equals_1(bevt_87_tmpvar_phold);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_89_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_90_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_equals_1(bevt_90_tmpvar_phold);
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 73 */ {
bevl_xn = beva_node.bem_nextPeerGet_0();
bevp_strqCnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevp_quoteType = beva_node.bem_typenameGet_0();
while (true)
 /* Line: 77 */ {
if (bevl_xn == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_93_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_92_tmpvar_phold = bevt_93_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 77 */ {
bevp_strqCnt = bevp_strqCnt.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 80 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
bevt_95_tmpvar_phold = bevo_1;
bevt_94_tmpvar_phold = bevp_strqCnt.bem_equals_1(bevt_95_tmpvar_phold);
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevp_strqCnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_96_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_96_tmpvar_phold);
bevt_97_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
beva_node.bem_typenameSet_1(bevt_97_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
beva_node.bem_typeDetailSet_1(bevt_98_tmpvar_phold);
} /* Line: 86 */
 else  /* Line: 87 */ {
bevp_inStr = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_goingStr = beva_node;
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_102_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_equals_1(bevt_102_tmpvar_phold);
if (bevt_100_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_103_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_103_tmpvar_phold);
} /* Line: 93 */
 else  /* Line: 94 */ {
bevt_104_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_104_tmpvar_phold);
} /* Line: 95 */
} /* Line: 91 */
return bevl_xn;
} /* Line: 98 */
if (bevp_inStr.bevi_bool) /* Line: 100 */ {
bevt_105_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 100 */ {
bevt_107_tmpvar_phold = bevp_goingStr.bem_typenameGet_0();
bevt_108_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_equals_1(bevt_108_tmpvar_phold);
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_110_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_111_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_equals_1(bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 101 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 101 */
 else  /* Line: 101 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 101 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_fsc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 105 */ {
if (bevl_xn == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_114_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_115_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bem_equals_1(bevt_115_tmpvar_phold);
if (bevt_113_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 105 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 105 */
 else  /* Line: 105 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 105 */ {
bevl_fsc = bevl_fsc.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 108 */
 else  /* Line: 105 */ {
break;
} /* Line: 105 */
} /* Line: 105 */
bevl_ia = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 110 */ {
bevt_116_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fsc);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 110 */ {
bevt_118_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_119_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_119_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_117_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 110 */
 else  /* Line: 110 */ {
break;
} /* Line: 110 */
} /* Line: 110 */
if (bevl_xn == null) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_123_tmpvar_phold = bevo_2;
bevt_122_tmpvar_phold = bevl_fsc.bem_modulus_1(bevt_123_tmpvar_phold);
bevt_124_tmpvar_phold = bevo_3;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_equals_1(bevt_124_tmpvar_phold);
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 113 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 113 */
 else  /* Line: 113 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 113 */ {
bevt_126_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_125_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 113 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 113 */
 else  /* Line: 113 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 113 */ {
bevl_xn.bem_delayDelete_0();
bevt_128_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_129_tmpvar_phold = bevl_xn.bem_heldGet_0();
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_129_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_127_tmpvar_phold);
bevl_xn = bevl_xn.bem_nextDescendGet_0();
} /* Line: 116 */
return bevl_xn;
} /* Line: 118 */
 else  /* Line: 101 */ {
bevt_131_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_130_tmpvar_phold = bevt_131_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 119 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_csc = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 123 */ {
if (bevl_xn == null) {
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_132_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_134_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_133_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
 else  /* Line: 123 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevl_csc = bevl_csc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 126 */
 else  /* Line: 123 */ {
break;
} /* Line: 123 */
} /* Line: 123 */
bevt_135_tmpvar_phold = bevl_csc.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_strqCnt);
if (bevt_135_tmpvar_phold != null && bevt_135_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_135_tmpvar_phold).bevi_bool) /* Line: 128 */ {
bevp_goingStr.bem_typeDetailSet_1(bevp_strqCnt);
bevp_strqCnt = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_goingStr = null;
bevp_inStr = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 132 */
 else  /* Line: 133 */ {
bevl_ia = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 134 */ {
bevt_136_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_csc);
if (bevt_136_tmpvar_phold != null && bevt_136_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_136_tmpvar_phold).bevi_bool) /* Line: 134 */ {
bevt_138_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_139_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_139_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_137_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 134 */
 else  /* Line: 134 */ {
break;
} /* Line: 134 */
} /* Line: 134 */
} /* Line: 134 */
return bevl_xn;
} /* Line: 138 */
 else  /* Line: 139 */ {
bevt_141_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_142_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_142_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_140_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 143 */
} /* Line: 101 */
} /* Line: 101 */
bevt_144_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_145_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_143_tmpvar_phold = bevt_144_tmpvar_phold.bem_equals_1(bevt_145_tmpvar_phold);
if (bevt_143_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevt_147_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_147_tmpvar_phold == null) {
bevt_146_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_146_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_146_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 146 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 146 */
 else  /* Line: 146 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 146 */ {
bevt_150_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bem_typenameGet_0();
bevt_151_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bem_equals_1(bevt_151_tmpvar_phold);
if (bevt_148_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 146 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 146 */
 else  /* Line: 146 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 146 */ {
bevt_152_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 146 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 146 */
 else  /* Line: 146 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 146 */ {
bevt_153_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_153_tmpvar_phold.bem_nextDescendGet_0();
bevp_inLc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_154_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_154_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 151 */
if (bevp_inLc.bevi_bool) /* Line: 153 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
bevt_156_tmpvar_phold = bevl_toRet.bem_typenameGet_0();
bevt_157_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bem_equals_1(bevt_157_tmpvar_phold);
if (bevt_155_tmpvar_phold.bevi_bool) /* Line: 156 */ {
bevp_inLc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_toRet.bem_delayDelete_0();
bevl_toRet = bevl_toRet.bem_nextDescendGet_0();
} /* Line: 159 */
return bevl_toRet;
} /* Line: 161 */
bevt_159_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_160_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bem_equals_1(bevt_160_tmpvar_phold);
if (bevt_158_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_162_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_162_tmpvar_phold == null) {
bevt_161_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_161_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_161_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 163 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 163 */
 else  /* Line: 163 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 163 */ {
bevt_165_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bem_typenameGet_0();
bevt_166_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bem_equals_1(bevt_166_tmpvar_phold);
if (bevt_163_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 163 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 163 */
 else  /* Line: 163 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 163 */ {
bevt_168_tmpvar_phold = beva_node.bem_priorPeerGet_0();
if (bevt_168_tmpvar_phold == null) {
bevt_167_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_167_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_167_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevl_vback = beva_node.bem_priorPeerGet_0();
while (true)
 /* Line: 166 */ {
if (bevl_vback == null) {
bevt_169_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_169_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_169_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_171_tmpvar_phold = bevl_vback.bem_typenameGet_0();
bevt_172_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_170_tmpvar_phold = bevt_171_tmpvar_phold.bem_equals_1(bevt_172_tmpvar_phold);
if (bevt_170_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 166 */ {
bevl_vback = bevl_vback.bem_priorPeerGet_0();
} /* Line: 167 */
 else  /* Line: 166 */ {
break;
} /* Line: 166 */
} /* Line: 166 */
bevl_pre = bevl_vback;
} /* Line: 169 */
if (bevl_pre == null) {
bevt_173_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_173_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_173_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_175_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_176_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_174_tmpvar_phold = bevt_175_tmpvar_phold.bem_equals_1(bevt_176_tmpvar_phold);
if (bevt_174_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
if (bevt_23_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_178_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_179_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bem_equals_1(bevt_179_tmpvar_phold);
if (bevt_177_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
if (bevt_22_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_181_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_182_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_has_1(bevt_182_tmpvar_phold);
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
if (bevt_21_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevt_183_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_185_tmpvar_phold = bevo_4;
bevt_187_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_186_tmpvar_phold = bevt_187_tmpvar_phold.bem_heldGet_0();
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_add_1(bevt_186_tmpvar_phold);
bevt_183_tmpvar_phold.bem_heldSet_1(bevt_184_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 178 */
} /* Line: 172 */
bevt_189_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_190_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bem_equals_1(bevt_190_tmpvar_phold);
if (bevt_188_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevt_192_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_192_tmpvar_phold == null) {
bevt_191_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_191_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_191_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 181 */
 else  /* Line: 181 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_25_tmpvar_anchor.bevi_bool) /* Line: 181 */ {
bevt_195_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bem_typenameGet_0();
bevt_196_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bem_equals_1(bevt_196_tmpvar_phold);
if (bevt_193_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 181 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 181 */
 else  /* Line: 181 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_24_tmpvar_anchor.bevi_bool) /* Line: 181 */ {
bevt_197_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_197_tmpvar_phold);
bevt_199_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_201_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_200_tmpvar_phold = bevt_201_tmpvar_phold.bem_heldGet_0();
bevt_198_tmpvar_phold = bevt_199_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_200_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_198_tmpvar_phold);
bevt_202_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_202_tmpvar_phold.bem_nextDescendGet_0();
bevt_203_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_203_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 186 */
bevt_205_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_206_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_204_tmpvar_phold = bevt_205_tmpvar_phold.bem_equals_1(bevt_206_tmpvar_phold);
if (bevt_204_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevt_208_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_208_tmpvar_phold == null) {
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 188 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 188 */
 else  /* Line: 188 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_27_tmpvar_anchor.bevi_bool) /* Line: 188 */ {
bevt_211_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bem_typenameGet_0();
bevt_212_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bem_equals_1(bevt_212_tmpvar_phold);
if (bevt_209_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 188 */ {
bevt_215_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bem_typenameGet_0();
bevt_216_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bem_equals_1(bevt_216_tmpvar_phold);
if (bevt_213_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 188 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 188 */
 else  /* Line: 188 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 188 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_220_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_219_tmpvar_phold = bevt_220_tmpvar_phold.bem_heldGet_0();
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_219_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_217_tmpvar_phold);
bevt_221_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_221_tmpvar_phold.bem_nextDescendGet_0();
bevt_222_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_222_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 193 */
bevt_224_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_225_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bem_equals_1(bevt_225_tmpvar_phold);
if (bevt_223_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_227_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_227_tmpvar_phold == null) {
bevt_226_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_226_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_226_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_29_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_230_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bem_typenameGet_0();
bevt_231_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_228_tmpvar_phold = bevt_229_tmpvar_phold.bem_equals_1(bevt_231_tmpvar_phold);
if (bevt_228_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_28_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_232_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_232_tmpvar_phold);
bevt_234_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_235_tmpvar_phold = bevt_236_tmpvar_phold.bem_heldGet_0();
bevt_233_tmpvar_phold = bevt_234_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_235_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_233_tmpvar_phold);
bevt_237_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_237_tmpvar_phold.bem_nextDescendGet_0();
bevt_238_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_238_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 200 */
bevt_240_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_241_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_239_tmpvar_phold = bevt_240_tmpvar_phold.bem_equals_1(bevt_241_tmpvar_phold);
if (bevt_239_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_243_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_243_tmpvar_phold == null) {
bevt_242_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_242_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_242_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_246_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_245_tmpvar_phold = bevt_246_tmpvar_phold.bem_typenameGet_0();
bevt_247_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_244_tmpvar_phold = bevt_245_tmpvar_phold.bem_equals_1(bevt_247_tmpvar_phold);
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_30_tmpvar_anchor.bevi_bool) /* Line: 203 */ {
bevt_249_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_251_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_250_tmpvar_phold = bevt_251_tmpvar_phold.bem_heldGet_0();
bevt_248_tmpvar_phold = bevt_249_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_250_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_248_tmpvar_phold);
bevt_252_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
beva_node.bem_typenameSet_1(bevt_252_tmpvar_phold);
bevt_253_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_253_tmpvar_phold.bem_nextDescendGet_0();
bevt_254_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_254_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 208 */
} /* Line: 203 */
bevt_256_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_257_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bem_equals_1(bevt_257_tmpvar_phold);
if (bevt_255_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_259_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_259_tmpvar_phold == null) {
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_262_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_261_tmpvar_phold = bevt_262_tmpvar_phold.bem_typenameGet_0();
bevt_263_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_260_tmpvar_phold = bevt_261_tmpvar_phold.bem_equals_1(bevt_263_tmpvar_phold);
if (bevt_260_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 212 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 212 */
 else  /* Line: 212 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_31_tmpvar_anchor.bevi_bool) /* Line: 212 */ {
bevt_265_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_267_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bem_heldGet_0();
bevt_264_tmpvar_phold = bevt_265_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_266_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_264_tmpvar_phold);
bevt_268_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
beva_node.bem_typenameSet_1(bevt_268_tmpvar_phold);
bevt_269_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_269_tmpvar_phold.bem_nextDescendGet_0();
bevt_270_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_270_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 217 */
} /* Line: 212 */
bevt_272_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_273_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_271_tmpvar_phold = bevt_272_tmpvar_phold.bem_equals_1(bevt_273_tmpvar_phold);
if (bevt_271_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_275_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_275_tmpvar_phold == null) {
bevt_274_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_274_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_274_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_33_tmpvar_anchor.bevi_bool) /* Line: 220 */ {
bevt_278_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_typenameGet_0();
bevt_279_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_276_tmpvar_phold = bevt_277_tmpvar_phold.bem_equals_1(bevt_279_tmpvar_phold);
if (bevt_276_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_32_tmpvar_anchor.bevi_bool) /* Line: 220 */ {
bevt_280_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_280_tmpvar_phold);
bevt_282_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_284_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_283_tmpvar_phold = bevt_284_tmpvar_phold.bem_heldGet_0();
bevt_281_tmpvar_phold = bevt_282_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_283_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_281_tmpvar_phold);
bevt_285_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_285_tmpvar_phold.bem_nextDescendGet_0();
bevt_286_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_286_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 225 */
bevt_288_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_289_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_287_tmpvar_phold = bevt_288_tmpvar_phold.bem_equals_1(bevt_289_tmpvar_phold);
if (bevt_287_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_291_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_291_tmpvar_phold == null) {
bevt_290_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_290_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_290_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_35_tmpvar_anchor.bevi_bool) /* Line: 227 */ {
bevt_294_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_293_tmpvar_phold = bevt_294_tmpvar_phold.bem_typenameGet_0();
bevt_295_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_292_tmpvar_phold = bevt_293_tmpvar_phold.bem_equals_1(bevt_295_tmpvar_phold);
if (bevt_292_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_34_tmpvar_anchor.bevi_bool) /* Line: 227 */ {
bevt_296_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_296_tmpvar_phold);
bevt_298_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_300_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_299_tmpvar_phold = bevt_300_tmpvar_phold.bem_heldGet_0();
bevt_297_tmpvar_phold = bevt_298_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_299_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_297_tmpvar_phold);
bevt_301_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_301_tmpvar_phold.bem_nextDescendGet_0();
bevt_302_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_302_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 232 */
bevt_304_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_305_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bem_equals_1(bevt_305_tmpvar_phold);
if (bevt_303_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_307_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_307_tmpvar_phold == null) {
bevt_306_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_306_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_306_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_37_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevt_310_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_309_tmpvar_phold = bevt_310_tmpvar_phold.bem_typenameGet_0();
bevt_311_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bem_equals_1(bevt_311_tmpvar_phold);
if (bevt_308_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_36_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevt_314_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_313_tmpvar_phold = bevt_314_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_313_tmpvar_phold == null) {
bevt_312_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_312_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_312_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_318_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_317_tmpvar_phold = bevt_318_tmpvar_phold.bem_nextPeerGet_0();
bevt_316_tmpvar_phold = bevt_317_tmpvar_phold.bem_typenameGet_0();
bevt_319_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_315_tmpvar_phold = bevt_316_tmpvar_phold.bem_equals_1(bevt_319_tmpvar_phold);
if (bevt_315_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_38_tmpvar_anchor.bevi_bool) /* Line: 235 */ {
bevt_320_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_320_tmpvar_phold);
bevt_323_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_325_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_324_tmpvar_phold = bevt_325_tmpvar_phold.bem_heldGet_0();
bevt_322_tmpvar_phold = bevt_323_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_324_tmpvar_phold);
bevt_328_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_327_tmpvar_phold = bevt_328_tmpvar_phold.bem_nextPeerGet_0();
bevt_326_tmpvar_phold = bevt_327_tmpvar_phold.bem_heldGet_0();
bevt_321_tmpvar_phold = bevt_322_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_326_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_321_tmpvar_phold);
bevt_330_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_329_tmpvar_phold = bevt_330_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_329_tmpvar_phold.bem_nextDescendGet_0();
bevt_331_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_331_tmpvar_phold.bem_delayDelete_0();
bevt_333_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_332_tmpvar_phold = bevt_333_tmpvar_phold.bem_nextPeerGet_0();
bevt_332_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 241 */
bevt_334_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_334_tmpvar_phold);
bevt_336_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_338_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_337_tmpvar_phold = bevt_338_tmpvar_phold.bem_heldGet_0();
bevt_335_tmpvar_phold = bevt_336_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_337_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_335_tmpvar_phold);
bevt_339_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_339_tmpvar_phold.bem_nextDescendGet_0();
bevt_340_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_340_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 247 */
bevt_342_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_343_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_341_tmpvar_phold = bevt_342_tmpvar_phold.bem_equals_1(bevt_343_tmpvar_phold);
if (bevt_341_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_345_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_345_tmpvar_phold == null) {
bevt_344_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_344_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_344_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_40_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_348_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_347_tmpvar_phold = bevt_348_tmpvar_phold.bem_typenameGet_0();
bevt_349_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_346_tmpvar_phold = bevt_347_tmpvar_phold.bem_equals_1(bevt_349_tmpvar_phold);
if (bevt_346_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 249 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 249 */
 else  /* Line: 249 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_39_tmpvar_anchor.bevi_bool) /* Line: 249 */ {
bevt_352_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_351_tmpvar_phold = bevt_352_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_351_tmpvar_phold == null) {
bevt_350_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_350_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_350_tmpvar_phold.bevi_bool) /* Line: 250 */ {
bevt_356_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_355_tmpvar_phold = bevt_356_tmpvar_phold.bem_nextPeerGet_0();
bevt_354_tmpvar_phold = bevt_355_tmpvar_phold.bem_typenameGet_0();
bevt_357_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_353_tmpvar_phold = bevt_354_tmpvar_phold.bem_equals_1(bevt_357_tmpvar_phold);
if (bevt_353_tmpvar_phold.bevi_bool) /* Line: 250 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 250 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 250 */
 else  /* Line: 250 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_41_tmpvar_anchor.bevi_bool) /* Line: 250 */ {
bevt_358_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_358_tmpvar_phold);
bevt_361_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_363_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_362_tmpvar_phold = bevt_363_tmpvar_phold.bem_heldGet_0();
bevt_360_tmpvar_phold = bevt_361_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_362_tmpvar_phold);
bevt_366_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_365_tmpvar_phold = bevt_366_tmpvar_phold.bem_nextPeerGet_0();
bevt_364_tmpvar_phold = bevt_365_tmpvar_phold.bem_heldGet_0();
bevt_359_tmpvar_phold = bevt_360_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_364_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_359_tmpvar_phold);
bevt_368_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_367_tmpvar_phold = bevt_368_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_367_tmpvar_phold.bem_nextDescendGet_0();
bevt_369_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_369_tmpvar_phold.bem_delayDelete_0();
bevt_371_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_370_tmpvar_phold = bevt_371_tmpvar_phold.bem_nextPeerGet_0();
bevt_370_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 256 */
bevt_372_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_372_tmpvar_phold);
bevt_374_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_376_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_375_tmpvar_phold = bevt_376_tmpvar_phold.bem_heldGet_0();
bevt_373_tmpvar_phold = bevt_374_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_375_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_373_tmpvar_phold);
bevt_377_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_377_tmpvar_phold.bem_nextDescendGet_0();
bevt_378_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_378_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 262 */
bevt_380_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_381_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_379_tmpvar_phold = bevt_380_tmpvar_phold.bem_equals_1(bevt_381_tmpvar_phold);
if (bevt_379_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_383_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_383_tmpvar_phold == null) {
bevt_382_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_382_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_382_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_43_tmpvar_anchor.bevi_bool) /* Line: 264 */ {
bevt_386_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_385_tmpvar_phold = bevt_386_tmpvar_phold.bem_typenameGet_0();
bevt_387_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_384_tmpvar_phold = bevt_385_tmpvar_phold.bem_equals_1(bevt_387_tmpvar_phold);
if (bevt_384_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
 else  /* Line: 264 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_42_tmpvar_anchor.bevi_bool) /* Line: 264 */ {
bevt_388_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_388_tmpvar_phold);
bevt_390_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_392_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_391_tmpvar_phold = bevt_392_tmpvar_phold.bem_heldGet_0();
bevt_389_tmpvar_phold = bevt_390_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_391_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_389_tmpvar_phold);
bevt_393_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_393_tmpvar_phold.bem_nextDescendGet_0();
bevt_394_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_394_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 269 */
bevt_396_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_397_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_395_tmpvar_phold = bevt_396_tmpvar_phold.bem_equals_1(bevt_397_tmpvar_phold);
if (bevt_395_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_399_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_399_tmpvar_phold == null) {
bevt_398_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_398_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_398_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_45_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_402_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_401_tmpvar_phold = bevt_402_tmpvar_phold.bem_typenameGet_0();
bevt_403_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_400_tmpvar_phold = bevt_401_tmpvar_phold.bem_equals_1(bevt_403_tmpvar_phold);
if (bevt_400_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_44_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_404_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_404_tmpvar_phold);
bevt_406_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_408_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_407_tmpvar_phold = bevt_408_tmpvar_phold.bem_heldGet_0();
bevt_405_tmpvar_phold = bevt_406_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_407_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_405_tmpvar_phold);
bevt_409_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_409_tmpvar_phold.bem_nextDescendGet_0();
bevt_410_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_410_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 276 */
bevt_412_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_413_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_411_tmpvar_phold = bevt_412_tmpvar_phold.bem_equals_1(bevt_413_tmpvar_phold);
if (bevt_411_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_415_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_415_tmpvar_phold == null) {
bevt_414_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_414_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_414_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_47_tmpvar_anchor.bevi_bool) /* Line: 278 */ {
bevt_418_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_417_tmpvar_phold = bevt_418_tmpvar_phold.bem_typenameGet_0();
bevt_419_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_416_tmpvar_phold = bevt_417_tmpvar_phold.bem_equals_1(bevt_419_tmpvar_phold);
if (bevt_416_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_46_tmpvar_anchor.bevi_bool) /* Line: 278 */ {
bevt_420_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_420_tmpvar_phold);
bevt_422_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_424_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_423_tmpvar_phold = bevt_424_tmpvar_phold.bem_heldGet_0();
bevt_421_tmpvar_phold = bevt_422_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_423_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_421_tmpvar_phold);
bevt_425_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_425_tmpvar_phold.bem_nextDescendGet_0();
bevt_426_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_426_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 283 */
bevt_428_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_429_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_427_tmpvar_phold = bevt_428_tmpvar_phold.bem_equals_1(bevt_429_tmpvar_phold);
if (bevt_427_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_431_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_431_tmpvar_phold == null) {
bevt_430_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_430_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_430_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 285 */
 else  /* Line: 285 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_49_tmpvar_anchor.bevi_bool) /* Line: 285 */ {
bevt_434_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_433_tmpvar_phold = bevt_434_tmpvar_phold.bem_typenameGet_0();
bevt_435_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_432_tmpvar_phold = bevt_433_tmpvar_phold.bem_equals_1(bevt_435_tmpvar_phold);
if (bevt_432_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 285 */
 else  /* Line: 285 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_48_tmpvar_anchor.bevi_bool) /* Line: 285 */ {
bevt_436_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_436_tmpvar_phold);
bevt_438_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_440_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_439_tmpvar_phold = bevt_440_tmpvar_phold.bem_heldGet_0();
bevt_437_tmpvar_phold = bevt_438_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_439_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_437_tmpvar_phold);
bevt_441_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_441_tmpvar_phold.bem_nextDescendGet_0();
bevt_442_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_442_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 290 */
bevt_444_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_445_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_443_tmpvar_phold = bevt_444_tmpvar_phold.bem_equals_1(bevt_445_tmpvar_phold);
if (bevt_443_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_447_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_447_tmpvar_phold == null) {
bevt_446_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_446_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_446_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 292 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 292 */
 else  /* Line: 292 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_51_tmpvar_anchor.bevi_bool) /* Line: 292 */ {
bevt_450_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_449_tmpvar_phold = bevt_450_tmpvar_phold.bem_typenameGet_0();
bevt_451_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_448_tmpvar_phold = bevt_449_tmpvar_phold.bem_equals_1(bevt_451_tmpvar_phold);
if (bevt_448_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 292 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 292 */
 else  /* Line: 292 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_50_tmpvar_anchor.bevi_bool) /* Line: 292 */ {
bevt_452_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_452_tmpvar_phold);
bevt_454_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_456_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_455_tmpvar_phold = bevt_456_tmpvar_phold.bem_heldGet_0();
bevt_453_tmpvar_phold = bevt_454_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_455_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_453_tmpvar_phold);
bevt_457_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_457_tmpvar_phold.bem_nextDescendGet_0();
bevt_458_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_458_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 297 */
bevt_460_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_461_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_459_tmpvar_phold = bevt_460_tmpvar_phold.bem_equals_1(bevt_461_tmpvar_phold);
if (bevt_459_tmpvar_phold.bevi_bool) /* Line: 299 */ {
bevt_463_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_463_tmpvar_phold == null) {
bevt_462_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_462_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_462_tmpvar_phold.bevi_bool) /* Line: 299 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 299 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 299 */
 else  /* Line: 299 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_53_tmpvar_anchor.bevi_bool) /* Line: 299 */ {
bevt_466_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_465_tmpvar_phold = bevt_466_tmpvar_phold.bem_typenameGet_0();
bevt_467_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_464_tmpvar_phold = bevt_465_tmpvar_phold.bem_equals_1(bevt_467_tmpvar_phold);
if (bevt_464_tmpvar_phold.bevi_bool) /* Line: 299 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 299 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 299 */
 else  /* Line: 299 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_52_tmpvar_anchor.bevi_bool) /* Line: 299 */ {
bevt_468_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_468_tmpvar_phold);
bevt_470_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_472_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_471_tmpvar_phold = bevt_472_tmpvar_phold.bem_heldGet_0();
bevt_469_tmpvar_phold = bevt_470_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_471_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_469_tmpvar_phold);
bevt_473_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_473_tmpvar_phold.bem_nextDescendGet_0();
bevt_474_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_474_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 304 */
bevt_476_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_477_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_475_tmpvar_phold = bevt_476_tmpvar_phold.bem_equals_1(bevt_477_tmpvar_phold);
if (bevt_475_tmpvar_phold.bevi_bool) /* Line: 306 */ {
bevt_479_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_479_tmpvar_phold == null) {
bevt_478_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_478_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_478_tmpvar_phold.bevi_bool) /* Line: 306 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 306 */
 else  /* Line: 306 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_55_tmpvar_anchor.bevi_bool) /* Line: 306 */ {
bevt_482_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_481_tmpvar_phold = bevt_482_tmpvar_phold.bem_typenameGet_0();
bevt_483_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_480_tmpvar_phold = bevt_481_tmpvar_phold.bem_equals_1(bevt_483_tmpvar_phold);
if (bevt_480_tmpvar_phold.bevi_bool) /* Line: 306 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 306 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 306 */
 else  /* Line: 306 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_54_tmpvar_anchor.bevi_bool) /* Line: 306 */ {
bevt_484_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_484_tmpvar_phold);
bevt_486_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_488_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_487_tmpvar_phold = bevt_488_tmpvar_phold.bem_heldGet_0();
bevt_485_tmpvar_phold = bevt_486_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_487_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_485_tmpvar_phold);
bevt_489_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_489_tmpvar_phold.bem_nextDescendGet_0();
bevt_490_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_490_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 311 */
bevt_492_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_493_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_491_tmpvar_phold = bevt_492_tmpvar_phold.bem_equals_1(bevt_493_tmpvar_phold);
if (bevt_491_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 313 */ {
bevt_495_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_496_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevt_494_tmpvar_phold = bevt_495_tmpvar_phold.bem_equals_1(bevt_496_tmpvar_phold);
if (bevt_494_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 313 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 313 */
if (bevt_56_tmpvar_anchor.bevi_bool) /* Line: 313 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 316 */
bevt_497_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_497_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nestCommentGet_0() {
return bevp_nestComment;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nestCommentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nestComment = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_strqCntGet_0() {
return bevp_strqCnt;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_strqCntSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_strqCnt = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_goingStrGet_0() {
return bevp_goingStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_goingStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_goingStr = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_quoteTypeGet_0() {
return bevp_quoteType;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_quoteTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_quoteType = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inLcGet_0() {
return bevp_inLc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inLcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inLc = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inSpaceGet_0() {
return bevp_inSpace;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inSpaceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inSpace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inNlGet_0() {
return bevp_inNl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inNlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inNl = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inStrGet_0() {
return bevp_inStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inStr = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {24, 30, 32, 41, 42, 43, 44, 52, 52, 52, 52, 52, 52, 0, 0, 0, 52, 52, 52, 52, 0, 0, 0, 52, 0, 0, 0, 54, 55, 55, 56, 56, 57, 58, 60, 60, 60, 60, 60, 60, 0, 0, 0, 60, 60, 60, 60, 0, 0, 0, 60, 0, 0, 0, 62, 63, 63, 64, 64, 65, 66, 68, 68, 69, 70, 71, 73, 73, 0, 0, 0, 73, 73, 73, 0, 73, 73, 73, 0, 0, 0, 0, 0, 74, 75, 76, 77, 77, 77, 77, 0, 0, 0, 78, 79, 80, 82, 82, 83, 84, 84, 85, 85, 86, 86, 88, 89, 90, 90, 91, 91, 91, 93, 93, 95, 95, 98, 100, 0, 0, 0, 101, 101, 101, 101, 101, 101, 0, 0, 0, 102, 103, 104, 105, 105, 105, 105, 105, 0, 0, 0, 106, 107, 108, 110, 110, 111, 111, 111, 111, 110, 113, 113, 113, 113, 113, 113, 0, 0, 0, 113, 113, 0, 0, 0, 114, 115, 115, 115, 115, 116, 118, 119, 119, 120, 121, 122, 123, 123, 123, 123, 0, 0, 0, 124, 125, 126, 128, 129, 130, 131, 132, 134, 134, 135, 135, 135, 135, 134, 138, 140, 140, 140, 140, 141, 142, 143, 146, 146, 146, 146, 146, 146, 0, 0, 0, 146, 146, 146, 146, 0, 0, 0, 146, 0, 0, 0, 147, 147, 148, 149, 149, 150, 151, 154, 155, 156, 156, 156, 157, 158, 159, 161, 163, 163, 163, 163, 163, 163, 0, 0, 0, 163, 163, 163, 163, 0, 0, 0, 164, 164, 164, 165, 166, 166, 166, 166, 166, 0, 0, 0, 167, 169, 172, 172, 0, 172, 172, 172, 0, 0, 0, 172, 172, 172, 0, 0, 0, 172, 172, 172, 0, 0, 175, 175, 175, 175, 175, 175, 176, 177, 178, 181, 181, 181, 181, 181, 181, 0, 0, 0, 181, 181, 181, 181, 0, 0, 0, 182, 182, 183, 183, 183, 183, 183, 184, 184, 185, 185, 186, 188, 188, 188, 188, 188, 188, 0, 0, 0, 188, 188, 188, 188, 0, 188, 188, 188, 188, 0, 0, 0, 0, 0, 190, 190, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 195, 195, 195, 195, 0, 0, 0, 195, 195, 195, 195, 0, 0, 0, 196, 196, 197, 197, 197, 197, 197, 198, 198, 199, 199, 200, 202, 202, 202, 203, 203, 203, 203, 203, 203, 203, 0, 0, 0, 204, 204, 204, 204, 204, 205, 205, 206, 206, 207, 207, 208, 211, 211, 211, 212, 212, 212, 212, 212, 212, 212, 0, 0, 0, 213, 213, 213, 213, 213, 214, 214, 215, 215, 216, 216, 217, 220, 220, 220, 220, 220, 220, 0, 0, 0, 220, 220, 220, 220, 0, 0, 0, 221, 221, 222, 222, 222, 222, 222, 223, 223, 224, 224, 225, 227, 227, 227, 227, 227, 227, 0, 0, 0, 227, 227, 227, 227, 0, 0, 0, 228, 228, 229, 229, 229, 229, 229, 230, 230, 231, 231, 232, 234, 234, 234, 234, 234, 234, 0, 0, 0, 234, 234, 234, 234, 0, 0, 0, 235, 235, 235, 235, 235, 235, 235, 235, 235, 0, 0, 0, 236, 236, 237, 237, 237, 237, 237, 237, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 240, 241, 243, 243, 244, 244, 244, 244, 244, 245, 245, 246, 246, 247, 249, 249, 249, 249, 249, 249, 0, 0, 0, 249, 249, 249, 249, 0, 0, 0, 250, 250, 250, 250, 250, 250, 250, 250, 250, 0, 0, 0, 251, 251, 252, 252, 252, 252, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 255, 255, 255, 256, 258, 258, 259, 259, 259, 259, 259, 260, 260, 261, 261, 262, 264, 264, 264, 264, 264, 264, 0, 0, 0, 264, 264, 264, 264, 0, 0, 0, 265, 265, 266, 266, 266, 266, 266, 267, 267, 268, 268, 269, 271, 271, 271, 271, 271, 271, 0, 0, 0, 271, 271, 271, 271, 0, 0, 0, 272, 272, 273, 273, 273, 273, 273, 274, 274, 275, 275, 276, 278, 278, 278, 278, 278, 278, 0, 0, 0, 278, 278, 278, 278, 0, 0, 0, 279, 279, 280, 280, 280, 280, 280, 281, 281, 282, 282, 283, 285, 285, 285, 285, 285, 285, 0, 0, 0, 285, 285, 285, 285, 0, 0, 0, 286, 286, 287, 287, 287, 287, 287, 288, 288, 289, 289, 290, 292, 292, 292, 292, 292, 292, 0, 0, 0, 292, 292, 292, 292, 0, 0, 0, 293, 293, 294, 294, 294, 294, 294, 295, 295, 296, 296, 297, 299, 299, 299, 299, 299, 299, 0, 0, 0, 299, 299, 299, 299, 0, 0, 0, 300, 300, 301, 301, 301, 301, 301, 302, 302, 303, 303, 304, 306, 306, 306, 306, 306, 306, 0, 0, 0, 306, 306, 306, 306, 0, 0, 0, 307, 307, 308, 308, 308, 308, 308, 309, 309, 310, 310, 311, 313, 313, 313, 0, 313, 313, 313, 0, 0, 314, 315, 316, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {25, 26, 27, 28, 29, 30, 31, 540, 541, 542, 544, 545, 550, 551, 554, 558, 561, 562, 563, 564, 566, 569, 573, 576, 578, 581, 585, 588, 589, 590, 591, 592, 593, 594, 596, 597, 598, 600, 601, 606, 607, 610, 614, 617, 618, 619, 620, 622, 625, 629, 632, 634, 637, 641, 644, 645, 646, 647, 648, 649, 650, 652, 653, 655, 656, 657, 659, 661, 663, 666, 670, 673, 674, 675, 677, 680, 681, 682, 684, 687, 691, 694, 698, 701, 702, 703, 706, 711, 712, 713, 715, 718, 722, 725, 726, 727, 733, 734, 736, 737, 738, 739, 740, 741, 742, 745, 746, 747, 748, 749, 750, 751, 753, 754, 757, 758, 761, 764, 766, 769, 773, 776, 777, 778, 780, 781, 782, 784, 787, 791, 794, 795, 796, 799, 804, 805, 806, 807, 809, 812, 816, 819, 820, 821, 827, 830, 832, 833, 834, 835, 836, 842, 847, 848, 849, 850, 851, 853, 856, 860, 863, 864, 866, 869, 873, 876, 877, 878, 879, 880, 881, 883, 886, 887, 889, 890, 891, 894, 899, 900, 901, 903, 906, 910, 913, 914, 915, 921, 923, 924, 925, 926, 929, 932, 934, 935, 936, 937, 938, 945, 948, 949, 950, 951, 952, 953, 954, 958, 959, 960, 962, 963, 968, 969, 972, 976, 979, 980, 981, 982, 984, 987, 991, 994, 996, 999, 1003, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1015, 1016, 1017, 1018, 1019, 1021, 1022, 1023, 1025, 1027, 1028, 1029, 1031, 1032, 1037, 1038, 1041, 1045, 1048, 1049, 1050, 1051, 1053, 1056, 1060, 1063, 1064, 1069, 1070, 1073, 1078, 1079, 1080, 1081, 1083, 1086, 1090, 1093, 1099, 1101, 1106, 1107, 1110, 1111, 1112, 1114, 1117, 1121, 1124, 1125, 1126, 1128, 1131, 1135, 1138, 1139, 1140, 1142, 1145, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1160, 1161, 1162, 1164, 1165, 1170, 1171, 1174, 1178, 1181, 1182, 1183, 1184, 1186, 1189, 1193, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1207, 1209, 1210, 1211, 1213, 1214, 1219, 1220, 1223, 1227, 1230, 1231, 1232, 1233, 1235, 1238, 1239, 1240, 1241, 1243, 1246, 1250, 1253, 1257, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1271, 1272, 1273, 1275, 1276, 1281, 1282, 1285, 1289, 1292, 1293, 1294, 1295, 1297, 1300, 1304, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1320, 1321, 1322, 1324, 1325, 1330, 1331, 1332, 1333, 1334, 1336, 1339, 1343, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1360, 1361, 1362, 1364, 1365, 1370, 1371, 1372, 1373, 1374, 1376, 1379, 1383, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1400, 1401, 1402, 1404, 1405, 1410, 1411, 1414, 1418, 1421, 1422, 1423, 1424, 1426, 1429, 1433, 1436, 1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1449, 1450, 1451, 1453, 1454, 1459, 1460, 1463, 1467, 1470, 1471, 1472, 1473, 1475, 1478, 1482, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1498, 1499, 1500, 1502, 1503, 1508, 1509, 1512, 1516, 1519, 1520, 1521, 1522, 1524, 1527, 1531, 1534, 1535, 1536, 1541, 1542, 1543, 1544, 1545, 1546, 1548, 1551, 1555, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1592, 1593, 1594, 1596, 1597, 1602, 1603, 1606, 1610, 1613, 1614, 1615, 1616, 1618, 1621, 1625, 1628, 1629, 1630, 1635, 1636, 1637, 1638, 1639, 1640, 1642, 1645, 1649, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1686, 1687, 1688, 1690, 1691, 1696, 1697, 1700, 1704, 1707, 1708, 1709, 1710, 1712, 1715, 1719, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1735, 1736, 1737, 1739, 1740, 1745, 1746, 1749, 1753, 1756, 1757, 1758, 1759, 1761, 1764, 1768, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1784, 1785, 1786, 1788, 1789, 1794, 1795, 1798, 1802, 1805, 1806, 1807, 1808, 1810, 1813, 1817, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1833, 1834, 1835, 1837, 1838, 1843, 1844, 1847, 1851, 1854, 1855, 1856, 1857, 1859, 1862, 1866, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1882, 1883, 1884, 1886, 1887, 1892, 1893, 1896, 1900, 1903, 1904, 1905, 1906, 1908, 1911, 1915, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1931, 1932, 1933, 1935, 1936, 1941, 1942, 1945, 1949, 1952, 1953, 1954, 1955, 1957, 1960, 1964, 1967, 1968, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1980, 1981, 1982, 1984, 1985, 1990, 1991, 1994, 1998, 2001, 2002, 2003, 2004, 2006, 2009, 2013, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2029, 2030, 2031, 2033, 2036, 2037, 2038, 2040, 2043, 2047, 2048, 2049, 2051, 2052, 2055, 2058, 2062, 2065, 2069, 2072, 2076, 2079, 2083, 2086, 2090, 2093, 2097, 2100, 2104, 2107, 2111, 2114};
/* BEGIN LINEINFO 
begin 1 24 25
assign 1 30 26
new 0 30 26
assign 1 32 27
new 0 32 27
assign 1 41 28
new 0 41 28
assign 1 42 29
new 0 42 29
assign 1 43 30
new 0 43 30
assign 1 44 31
new 0 44 31
assign 1 52 540
typenameGet 0 52 540
assign 1 52 541
DIVIDEGet 0 52 541
assign 1 52 542
equals 1 52 542
assign 1 52 544
nextPeerGet 0 52 544
assign 1 52 545
def 1 52 550
assign 1 0 551
assign 1 0 554
assign 1 0 558
assign 1 52 561
nextPeerGet 0 52 561
assign 1 52 562
typenameGet 0 52 562
assign 1 52 563
MULTIPLYGet 0 52 563
assign 1 52 564
equals 1 52 564
assign 1 0 566
assign 1 0 569
assign 1 0 573
assign 1 52 576
not 0 52 576
assign 1 0 578
assign 1 0 581
assign 1 0 585
assign 1 54 588
increment 0 54 588
assign 1 55 589
nextPeerGet 0 55 589
assign 1 55 590
nextDescendGet 0 55 590
assign 1 56 591
nextPeerGet 0 56 591
delayDelete 0 56 592
delayDelete 0 57 593
return 1 58 594
assign 1 60 596
typenameGet 0 60 596
assign 1 60 597
MULTIPLYGet 0 60 597
assign 1 60 598
equals 1 60 598
assign 1 60 600
nextPeerGet 0 60 600
assign 1 60 601
def 1 60 606
assign 1 0 607
assign 1 0 610
assign 1 0 614
assign 1 60 617
nextPeerGet 0 60 617
assign 1 60 618
typenameGet 0 60 618
assign 1 60 619
DIVIDEGet 0 60 619
assign 1 60 620
equals 1 60 620
assign 1 0 622
assign 1 0 625
assign 1 0 629
assign 1 60 632
not 0 60 632
assign 1 0 634
assign 1 0 637
assign 1 0 641
assign 1 62 644
decrement 0 62 644
assign 1 63 645
nextPeerGet 0 63 645
assign 1 63 646
nextDescendGet 0 63 646
assign 1 64 647
nextPeerGet 0 64 647
delayDelete 0 64 648
delayDelete 0 65 649
return 1 66 650
assign 1 68 652
new 0 68 652
assign 1 68 653
greater 1 68 653
assign 1 69 655
nextDescendGet 0 69 655
delayDelete 0 70 656
return 1 71 657
assign 1 73 659
not 0 73 659
assign 1 73 661
not 0 73 661
assign 1 0 663
assign 1 0 666
assign 1 0 670
assign 1 73 673
typenameGet 0 73 673
assign 1 73 674
STRQGet 0 73 674
assign 1 73 675
equals 1 73 675
assign 1 0 677
assign 1 73 680
typenameGet 0 73 680
assign 1 73 681
WSTRQGet 0 73 681
assign 1 73 682
equals 1 73 682
assign 1 0 684
assign 1 0 687
assign 1 0 691
assign 1 0 694
assign 1 0 698
assign 1 74 701
nextPeerGet 0 74 701
assign 1 75 702
new 0 75 702
assign 1 76 703
typenameGet 0 76 703
assign 1 77 706
def 1 77 711
assign 1 77 712
typenameGet 0 77 712
assign 1 77 713
equals 1 77 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
assign 1 78 725
increment 0 78 725
delayDelete 0 79 726
assign 1 80 727
nextPeerGet 0 80 727
assign 1 82 733
new 0 82 733
assign 1 82 734
equals 1 82 734
assign 1 83 736
new 0 83 736
assign 1 84 737
new 0 84 737
heldSet 1 84 738
assign 1 85 739
STRINGLGet 0 85 739
typenameSet 1 85 740
assign 1 86 741
new 0 86 741
typeDetailSet 1 86 742
assign 1 88 745
new 0 88 745
assign 1 89 746
assign 1 90 747
new 0 90 747
heldSet 1 90 748
assign 1 91 749
typenameGet 0 91 749
assign 1 91 750
WSTRQGet 0 91 750
assign 1 91 751
equals 1 91 751
assign 1 93 753
WSTRINGLGet 0 93 753
typenameSet 1 93 754
assign 1 95 757
STRINGLGet 0 95 757
typenameSet 1 95 758
return 1 98 761
assign 1 100 764
not 0 100 764
assign 1 0 766
assign 1 0 769
assign 1 0 773
assign 1 101 776
typenameGet 0 101 776
assign 1 101 777
STRINGLGet 0 101 777
assign 1 101 778
equals 1 101 778
assign 1 101 780
typenameGet 0 101 780
assign 1 101 781
FSLASHGet 0 101 781
assign 1 101 782
equals 1 101 782
assign 1 0 784
assign 1 0 787
assign 1 0 791
delayDelete 0 102 794
assign 1 103 795
nextPeerGet 0 103 795
assign 1 104 796
new 0 104 796
assign 1 105 799
def 1 105 804
assign 1 105 805
typenameGet 0 105 805
assign 1 105 806
FSLASHGet 0 105 806
assign 1 105 807
equals 1 105 807
assign 1 0 809
assign 1 0 812
assign 1 0 816
assign 1 106 819
increment 0 106 819
delayDelete 0 107 820
assign 1 108 821
nextPeerGet 0 108 821
assign 1 110 827
new 0 110 827
assign 1 110 830
lesser 1 110 830
assign 1 111 832
heldGet 0 111 832
assign 1 111 833
heldGet 0 111 833
assign 1 111 834
add 1 111 834
heldSet 1 111 835
assign 1 110 836
increment 0 110 836
assign 1 113 842
def 1 113 847
assign 1 113 848
new 0 113 848
assign 1 113 849
modulus 1 113 849
assign 1 113 850
new 0 113 850
assign 1 113 851
equals 1 113 851
assign 1 0 853
assign 1 0 856
assign 1 0 860
assign 1 113 863
typenameGet 0 113 863
assign 1 113 864
equals 1 113 864
assign 1 0 866
assign 1 0 869
assign 1 0 873
delayDelete 0 114 876
assign 1 115 877
heldGet 0 115 877
assign 1 115 878
heldGet 0 115 878
assign 1 115 879
add 1 115 879
heldSet 1 115 880
assign 1 116 881
nextDescendGet 0 116 881
return 1 118 883
assign 1 119 886
typenameGet 0 119 886
assign 1 119 887
equals 1 119 887
delayDelete 0 120 889
assign 1 121 890
nextPeerGet 0 121 890
assign 1 122 891
new 0 122 891
assign 1 123 894
def 1 123 899
assign 1 123 900
typenameGet 0 123 900
assign 1 123 901
equals 1 123 901
assign 1 0 903
assign 1 0 906
assign 1 0 910
assign 1 124 913
increment 0 124 913
delayDelete 0 125 914
assign 1 126 915
nextPeerGet 0 126 915
assign 1 128 921
equals 1 128 921
typeDetailSet 1 129 923
assign 1 130 924
new 0 130 924
assign 1 131 925
assign 1 132 926
new 0 132 926
assign 1 134 929
new 0 134 929
assign 1 134 932
lesser 1 134 932
assign 1 135 934
heldGet 0 135 934
assign 1 135 935
heldGet 0 135 935
assign 1 135 936
add 1 135 936
heldSet 1 135 937
assign 1 134 938
increment 0 134 938
return 1 138 945
assign 1 140 948
heldGet 0 140 948
assign 1 140 949
heldGet 0 140 949
assign 1 140 950
add 1 140 950
heldSet 1 140 951
assign 1 141 952
nextDescendGet 0 141 952
delayDelete 0 142 953
return 1 143 954
assign 1 146 958
typenameGet 0 146 958
assign 1 146 959
DIVIDEGet 0 146 959
assign 1 146 960
equals 1 146 960
assign 1 146 962
nextPeerGet 0 146 962
assign 1 146 963
def 1 146 968
assign 1 0 969
assign 1 0 972
assign 1 0 976
assign 1 146 979
nextPeerGet 0 146 979
assign 1 146 980
typenameGet 0 146 980
assign 1 146 981
DIVIDEGet 0 146 981
assign 1 146 982
equals 1 146 982
assign 1 0 984
assign 1 0 987
assign 1 0 991
assign 1 146 994
not 0 146 994
assign 1 0 996
assign 1 0 999
assign 1 0 1003
assign 1 147 1006
nextPeerGet 0 147 1006
assign 1 147 1007
nextDescendGet 0 147 1007
assign 1 148 1008
new 0 148 1008
assign 1 149 1009
nextPeerGet 0 149 1009
delayDelete 0 149 1010
delayDelete 0 150 1011
return 1 151 1012
assign 1 154 1015
nextDescendGet 0 154 1015
delayDelete 0 155 1016
assign 1 156 1017
typenameGet 0 156 1017
assign 1 156 1018
NEWLINEGet 0 156 1018
assign 1 156 1019
equals 1 156 1019
assign 1 157 1021
new 0 157 1021
delayDelete 0 158 1022
assign 1 159 1023
nextDescendGet 0 159 1023
return 1 161 1025
assign 1 163 1027
typenameGet 0 163 1027
assign 1 163 1028
SUBTRACTGet 0 163 1028
assign 1 163 1029
equals 1 163 1029
assign 1 163 1031
nextPeerGet 0 163 1031
assign 1 163 1032
def 1 163 1037
assign 1 0 1038
assign 1 0 1041
assign 1 0 1045
assign 1 163 1048
nextPeerGet 0 163 1048
assign 1 163 1049
typenameGet 0 163 1049
assign 1 163 1050
INTLGet 0 163 1050
assign 1 163 1051
equals 1 163 1051
assign 1 0 1053
assign 1 0 1056
assign 1 0 1060
assign 1 164 1063
priorPeerGet 0 164 1063
assign 1 164 1064
def 1 164 1069
assign 1 165 1070
priorPeerGet 0 165 1070
assign 1 166 1073
def 1 166 1078
assign 1 166 1079
typenameGet 0 166 1079
assign 1 166 1080
SPACEGet 0 166 1080
assign 1 166 1081
equals 1 166 1081
assign 1 0 1083
assign 1 0 1086
assign 1 0 1090
assign 1 167 1093
priorPeerGet 0 167 1093
assign 1 169 1099
assign 1 172 1101
undef 1 172 1106
assign 1 0 1107
assign 1 172 1110
typenameGet 0 172 1110
assign 1 172 1111
COMMAGet 0 172 1111
assign 1 172 1112
equals 1 172 1112
assign 1 0 1114
assign 1 0 1117
assign 1 0 1121
assign 1 172 1124
typenameGet 0 172 1124
assign 1 172 1125
PARENSGet 0 172 1125
assign 1 172 1126
equals 1 172 1126
assign 1 0 1128
assign 1 0 1131
assign 1 0 1135
assign 1 172 1138
operGet 0 172 1138
assign 1 172 1139
typenameGet 0 172 1139
assign 1 172 1140
has 1 172 1140
assign 1 0 1142
assign 1 0 1145
assign 1 175 1149
nextPeerGet 0 175 1149
assign 1 175 1150
new 0 175 1150
assign 1 175 1151
nextPeerGet 0 175 1151
assign 1 175 1152
heldGet 0 175 1152
assign 1 175 1153
add 1 175 1153
heldSet 1 175 1154
assign 1 176 1155
nextDescendGet 0 176 1155
delayDelete 0 177 1156
return 1 178 1157
assign 1 181 1160
typenameGet 0 181 1160
assign 1 181 1161
ASSIGNGet 0 181 1161
assign 1 181 1162
equals 1 181 1162
assign 1 181 1164
nextPeerGet 0 181 1164
assign 1 181 1165
def 1 181 1170
assign 1 0 1171
assign 1 0 1174
assign 1 0 1178
assign 1 181 1181
nextPeerGet 0 181 1181
assign 1 181 1182
typenameGet 0 181 1182
assign 1 181 1183
ASSIGNGet 0 181 1183
assign 1 181 1184
equals 1 181 1184
assign 1 0 1186
assign 1 0 1189
assign 1 0 1193
assign 1 182 1196
EQUALSGet 0 182 1196
typenameSet 1 182 1197
assign 1 183 1198
heldGet 0 183 1198
assign 1 183 1199
nextPeerGet 0 183 1199
assign 1 183 1200
heldGet 0 183 1200
assign 1 183 1201
add 1 183 1201
heldSet 1 183 1202
assign 1 184 1203
nextPeerGet 0 184 1203
assign 1 184 1204
nextDescendGet 0 184 1204
assign 1 185 1205
nextPeerGet 0 185 1205
delayDelete 0 185 1206
return 1 186 1207
assign 1 188 1209
typenameGet 0 188 1209
assign 1 188 1210
ASSIGNGet 0 188 1210
assign 1 188 1211
equals 1 188 1211
assign 1 188 1213
nextPeerGet 0 188 1213
assign 1 188 1214
def 1 188 1219
assign 1 0 1220
assign 1 0 1223
assign 1 0 1227
assign 1 188 1230
nextPeerGet 0 188 1230
assign 1 188 1231
typenameGet 0 188 1231
assign 1 188 1232
ONCEGet 0 188 1232
assign 1 188 1233
equals 1 188 1233
assign 1 0 1235
assign 1 188 1238
nextPeerGet 0 188 1238
assign 1 188 1239
typenameGet 0 188 1239
assign 1 188 1240
MANYGet 0 188 1240
assign 1 188 1241
equals 1 188 1241
assign 1 0 1243
assign 1 0 1246
assign 1 0 1250
assign 1 0 1253
assign 1 0 1257
assign 1 190 1260
heldGet 0 190 1260
assign 1 190 1261
nextPeerGet 0 190 1261
assign 1 190 1262
heldGet 0 190 1262
assign 1 190 1263
add 1 190 1263
heldSet 1 190 1264
assign 1 191 1265
nextPeerGet 0 191 1265
assign 1 191 1266
nextDescendGet 0 191 1266
assign 1 192 1267
nextPeerGet 0 192 1267
delayDelete 0 192 1268
return 1 193 1269
assign 1 195 1271
typenameGet 0 195 1271
assign 1 195 1272
NOTGet 0 195 1272
assign 1 195 1273
equals 1 195 1273
assign 1 195 1275
nextPeerGet 0 195 1275
assign 1 195 1276
def 1 195 1281
assign 1 0 1282
assign 1 0 1285
assign 1 0 1289
assign 1 195 1292
nextPeerGet 0 195 1292
assign 1 195 1293
typenameGet 0 195 1293
assign 1 195 1294
ASSIGNGet 0 195 1294
assign 1 195 1295
equals 1 195 1295
assign 1 0 1297
assign 1 0 1300
assign 1 0 1304
assign 1 196 1307
NOT_EQUALSGet 0 196 1307
typenameSet 1 196 1308
assign 1 197 1309
heldGet 0 197 1309
assign 1 197 1310
nextPeerGet 0 197 1310
assign 1 197 1311
heldGet 0 197 1311
assign 1 197 1312
add 1 197 1312
heldSet 1 197 1313
assign 1 198 1314
nextPeerGet 0 198 1314
assign 1 198 1315
nextDescendGet 0 198 1315
assign 1 199 1316
nextPeerGet 0 199 1316
delayDelete 0 199 1317
return 1 200 1318
assign 1 202 1320
typenameGet 0 202 1320
assign 1 202 1321
ORGet 0 202 1321
assign 1 202 1322
equals 1 202 1322
assign 1 203 1324
nextPeerGet 0 203 1324
assign 1 203 1325
def 1 203 1330
assign 1 203 1331
nextPeerGet 0 203 1331
assign 1 203 1332
typenameGet 0 203 1332
assign 1 203 1333
ORGet 0 203 1333
assign 1 203 1334
equals 1 203 1334
assign 1 0 1336
assign 1 0 1339
assign 1 0 1343
assign 1 204 1346
heldGet 0 204 1346
assign 1 204 1347
nextPeerGet 0 204 1347
assign 1 204 1348
heldGet 0 204 1348
assign 1 204 1349
add 1 204 1349
heldSet 1 204 1350
assign 1 205 1351
LOGICAL_ORGet 0 205 1351
typenameSet 1 205 1352
assign 1 206 1353
nextPeerGet 0 206 1353
assign 1 206 1354
nextDescendGet 0 206 1354
assign 1 207 1355
nextPeerGet 0 207 1355
delayDelete 0 207 1356
return 1 208 1357
assign 1 211 1360
typenameGet 0 211 1360
assign 1 211 1361
ANDGet 0 211 1361
assign 1 211 1362
equals 1 211 1362
assign 1 212 1364
nextPeerGet 0 212 1364
assign 1 212 1365
def 1 212 1370
assign 1 212 1371
nextPeerGet 0 212 1371
assign 1 212 1372
typenameGet 0 212 1372
assign 1 212 1373
ANDGet 0 212 1373
assign 1 212 1374
equals 1 212 1374
assign 1 0 1376
assign 1 0 1379
assign 1 0 1383
assign 1 213 1386
heldGet 0 213 1386
assign 1 213 1387
nextPeerGet 0 213 1387
assign 1 213 1388
heldGet 0 213 1388
assign 1 213 1389
add 1 213 1389
heldSet 1 213 1390
assign 1 214 1391
LOGICAL_ANDGet 0 214 1391
typenameSet 1 214 1392
assign 1 215 1393
nextPeerGet 0 215 1393
assign 1 215 1394
nextDescendGet 0 215 1394
assign 1 216 1395
nextPeerGet 0 216 1395
delayDelete 0 216 1396
return 1 217 1397
assign 1 220 1400
typenameGet 0 220 1400
assign 1 220 1401
GREATERGet 0 220 1401
assign 1 220 1402
equals 1 220 1402
assign 1 220 1404
nextPeerGet 0 220 1404
assign 1 220 1405
def 1 220 1410
assign 1 0 1411
assign 1 0 1414
assign 1 0 1418
assign 1 220 1421
nextPeerGet 0 220 1421
assign 1 220 1422
typenameGet 0 220 1422
assign 1 220 1423
ASSIGNGet 0 220 1423
assign 1 220 1424
equals 1 220 1424
assign 1 0 1426
assign 1 0 1429
assign 1 0 1433
assign 1 221 1436
GREATER_EQUALSGet 0 221 1436
typenameSet 1 221 1437
assign 1 222 1438
heldGet 0 222 1438
assign 1 222 1439
nextPeerGet 0 222 1439
assign 1 222 1440
heldGet 0 222 1440
assign 1 222 1441
add 1 222 1441
heldSet 1 222 1442
assign 1 223 1443
nextPeerGet 0 223 1443
assign 1 223 1444
nextDescendGet 0 223 1444
assign 1 224 1445
nextPeerGet 0 224 1445
delayDelete 0 224 1446
return 1 225 1447
assign 1 227 1449
typenameGet 0 227 1449
assign 1 227 1450
LESSERGet 0 227 1450
assign 1 227 1451
equals 1 227 1451
assign 1 227 1453
nextPeerGet 0 227 1453
assign 1 227 1454
def 1 227 1459
assign 1 0 1460
assign 1 0 1463
assign 1 0 1467
assign 1 227 1470
nextPeerGet 0 227 1470
assign 1 227 1471
typenameGet 0 227 1471
assign 1 227 1472
ASSIGNGet 0 227 1472
assign 1 227 1473
equals 1 227 1473
assign 1 0 1475
assign 1 0 1478
assign 1 0 1482
assign 1 228 1485
LESSER_EQUALSGet 0 228 1485
typenameSet 1 228 1486
assign 1 229 1487
heldGet 0 229 1487
assign 1 229 1488
nextPeerGet 0 229 1488
assign 1 229 1489
heldGet 0 229 1489
assign 1 229 1490
add 1 229 1490
heldSet 1 229 1491
assign 1 230 1492
nextPeerGet 0 230 1492
assign 1 230 1493
nextDescendGet 0 230 1493
assign 1 231 1494
nextPeerGet 0 231 1494
delayDelete 0 231 1495
return 1 232 1496
assign 1 234 1498
typenameGet 0 234 1498
assign 1 234 1499
ADDGet 0 234 1499
assign 1 234 1500
equals 1 234 1500
assign 1 234 1502
nextPeerGet 0 234 1502
assign 1 234 1503
def 1 234 1508
assign 1 0 1509
assign 1 0 1512
assign 1 0 1516
assign 1 234 1519
nextPeerGet 0 234 1519
assign 1 234 1520
typenameGet 0 234 1520
assign 1 234 1521
ADDGet 0 234 1521
assign 1 234 1522
equals 1 234 1522
assign 1 0 1524
assign 1 0 1527
assign 1 0 1531
assign 1 235 1534
nextPeerGet 0 235 1534
assign 1 235 1535
nextPeerGet 0 235 1535
assign 1 235 1536
def 1 235 1541
assign 1 235 1542
nextPeerGet 0 235 1542
assign 1 235 1543
nextPeerGet 0 235 1543
assign 1 235 1544
typenameGet 0 235 1544
assign 1 235 1545
ASSIGNGet 0 235 1545
assign 1 235 1546
equals 1 235 1546
assign 1 0 1548
assign 1 0 1551
assign 1 0 1555
assign 1 236 1558
INCREMENT_ASSIGNGet 0 236 1558
typenameSet 1 236 1559
assign 1 237 1560
heldGet 0 237 1560
assign 1 237 1561
nextPeerGet 0 237 1561
assign 1 237 1562
heldGet 0 237 1562
assign 1 237 1563
add 1 237 1563
assign 1 237 1564
nextPeerGet 0 237 1564
assign 1 237 1565
nextPeerGet 0 237 1565
assign 1 237 1566
heldGet 0 237 1566
assign 1 237 1567
add 1 237 1567
heldSet 1 237 1568
assign 1 238 1569
nextPeerGet 0 238 1569
assign 1 238 1570
nextPeerGet 0 238 1570
assign 1 238 1571
nextDescendGet 0 238 1571
assign 1 239 1572
nextPeerGet 0 239 1572
delayDelete 0 239 1573
assign 1 240 1574
nextPeerGet 0 240 1574
assign 1 240 1575
nextPeerGet 0 240 1575
delayDelete 0 240 1576
return 1 241 1577
assign 1 243 1579
INCREMENTGet 0 243 1579
typenameSet 1 243 1580
assign 1 244 1581
heldGet 0 244 1581
assign 1 244 1582
nextPeerGet 0 244 1582
assign 1 244 1583
heldGet 0 244 1583
assign 1 244 1584
add 1 244 1584
heldSet 1 244 1585
assign 1 245 1586
nextPeerGet 0 245 1586
assign 1 245 1587
nextDescendGet 0 245 1587
assign 1 246 1588
nextPeerGet 0 246 1588
delayDelete 0 246 1589
return 1 247 1590
assign 1 249 1592
typenameGet 0 249 1592
assign 1 249 1593
SUBTRACTGet 0 249 1593
assign 1 249 1594
equals 1 249 1594
assign 1 249 1596
nextPeerGet 0 249 1596
assign 1 249 1597
def 1 249 1602
assign 1 0 1603
assign 1 0 1606
assign 1 0 1610
assign 1 249 1613
nextPeerGet 0 249 1613
assign 1 249 1614
typenameGet 0 249 1614
assign 1 249 1615
SUBTRACTGet 0 249 1615
assign 1 249 1616
equals 1 249 1616
assign 1 0 1618
assign 1 0 1621
assign 1 0 1625
assign 1 250 1628
nextPeerGet 0 250 1628
assign 1 250 1629
nextPeerGet 0 250 1629
assign 1 250 1630
def 1 250 1635
assign 1 250 1636
nextPeerGet 0 250 1636
assign 1 250 1637
nextPeerGet 0 250 1637
assign 1 250 1638
typenameGet 0 250 1638
assign 1 250 1639
ASSIGNGet 0 250 1639
assign 1 250 1640
equals 1 250 1640
assign 1 0 1642
assign 1 0 1645
assign 1 0 1649
assign 1 251 1652
DECREMENT_ASSIGNGet 0 251 1652
typenameSet 1 251 1653
assign 1 252 1654
heldGet 0 252 1654
assign 1 252 1655
nextPeerGet 0 252 1655
assign 1 252 1656
heldGet 0 252 1656
assign 1 252 1657
add 1 252 1657
assign 1 252 1658
nextPeerGet 0 252 1658
assign 1 252 1659
nextPeerGet 0 252 1659
assign 1 252 1660
heldGet 0 252 1660
assign 1 252 1661
add 1 252 1661
heldSet 1 252 1662
assign 1 253 1663
nextPeerGet 0 253 1663
assign 1 253 1664
nextPeerGet 0 253 1664
assign 1 253 1665
nextDescendGet 0 253 1665
assign 1 254 1666
nextPeerGet 0 254 1666
delayDelete 0 254 1667
assign 1 255 1668
nextPeerGet 0 255 1668
assign 1 255 1669
nextPeerGet 0 255 1669
delayDelete 0 255 1670
return 1 256 1671
assign 1 258 1673
DECREMENTGet 0 258 1673
typenameSet 1 258 1674
assign 1 259 1675
heldGet 0 259 1675
assign 1 259 1676
nextPeerGet 0 259 1676
assign 1 259 1677
heldGet 0 259 1677
assign 1 259 1678
add 1 259 1678
heldSet 1 259 1679
assign 1 260 1680
nextPeerGet 0 260 1680
assign 1 260 1681
nextDescendGet 0 260 1681
assign 1 261 1682
nextPeerGet 0 261 1682
delayDelete 0 261 1683
return 1 262 1684
assign 1 264 1686
typenameGet 0 264 1686
assign 1 264 1687
ADDGet 0 264 1687
assign 1 264 1688
equals 1 264 1688
assign 1 264 1690
nextPeerGet 0 264 1690
assign 1 264 1691
def 1 264 1696
assign 1 0 1697
assign 1 0 1700
assign 1 0 1704
assign 1 264 1707
nextPeerGet 0 264 1707
assign 1 264 1708
typenameGet 0 264 1708
assign 1 264 1709
ASSIGNGet 0 264 1709
assign 1 264 1710
equals 1 264 1710
assign 1 0 1712
assign 1 0 1715
assign 1 0 1719
assign 1 265 1722
ADD_ASSIGNGet 0 265 1722
typenameSet 1 265 1723
assign 1 266 1724
heldGet 0 266 1724
assign 1 266 1725
nextPeerGet 0 266 1725
assign 1 266 1726
heldGet 0 266 1726
assign 1 266 1727
add 1 266 1727
heldSet 1 266 1728
assign 1 267 1729
nextPeerGet 0 267 1729
assign 1 267 1730
nextDescendGet 0 267 1730
assign 1 268 1731
nextPeerGet 0 268 1731
delayDelete 0 268 1732
return 1 269 1733
assign 1 271 1735
typenameGet 0 271 1735
assign 1 271 1736
SUBTRACTGet 0 271 1736
assign 1 271 1737
equals 1 271 1737
assign 1 271 1739
nextPeerGet 0 271 1739
assign 1 271 1740
def 1 271 1745
assign 1 0 1746
assign 1 0 1749
assign 1 0 1753
assign 1 271 1756
nextPeerGet 0 271 1756
assign 1 271 1757
typenameGet 0 271 1757
assign 1 271 1758
ASSIGNGet 0 271 1758
assign 1 271 1759
equals 1 271 1759
assign 1 0 1761
assign 1 0 1764
assign 1 0 1768
assign 1 272 1771
SUBTRACT_ASSIGNGet 0 272 1771
typenameSet 1 272 1772
assign 1 273 1773
heldGet 0 273 1773
assign 1 273 1774
nextPeerGet 0 273 1774
assign 1 273 1775
heldGet 0 273 1775
assign 1 273 1776
add 1 273 1776
heldSet 1 273 1777
assign 1 274 1778
nextPeerGet 0 274 1778
assign 1 274 1779
nextDescendGet 0 274 1779
assign 1 275 1780
nextPeerGet 0 275 1780
delayDelete 0 275 1781
return 1 276 1782
assign 1 278 1784
typenameGet 0 278 1784
assign 1 278 1785
MULTIPLYGet 0 278 1785
assign 1 278 1786
equals 1 278 1786
assign 1 278 1788
nextPeerGet 0 278 1788
assign 1 278 1789
def 1 278 1794
assign 1 0 1795
assign 1 0 1798
assign 1 0 1802
assign 1 278 1805
nextPeerGet 0 278 1805
assign 1 278 1806
typenameGet 0 278 1806
assign 1 278 1807
ASSIGNGet 0 278 1807
assign 1 278 1808
equals 1 278 1808
assign 1 0 1810
assign 1 0 1813
assign 1 0 1817
assign 1 279 1820
MULTIPLY_ASSIGNGet 0 279 1820
typenameSet 1 279 1821
assign 1 280 1822
heldGet 0 280 1822
assign 1 280 1823
nextPeerGet 0 280 1823
assign 1 280 1824
heldGet 0 280 1824
assign 1 280 1825
add 1 280 1825
heldSet 1 280 1826
assign 1 281 1827
nextPeerGet 0 281 1827
assign 1 281 1828
nextDescendGet 0 281 1828
assign 1 282 1829
nextPeerGet 0 282 1829
delayDelete 0 282 1830
return 1 283 1831
assign 1 285 1833
typenameGet 0 285 1833
assign 1 285 1834
DIVIDEGet 0 285 1834
assign 1 285 1835
equals 1 285 1835
assign 1 285 1837
nextPeerGet 0 285 1837
assign 1 285 1838
def 1 285 1843
assign 1 0 1844
assign 1 0 1847
assign 1 0 1851
assign 1 285 1854
nextPeerGet 0 285 1854
assign 1 285 1855
typenameGet 0 285 1855
assign 1 285 1856
ASSIGNGet 0 285 1856
assign 1 285 1857
equals 1 285 1857
assign 1 0 1859
assign 1 0 1862
assign 1 0 1866
assign 1 286 1869
DIVIDE_ASSIGNGet 0 286 1869
typenameSet 1 286 1870
assign 1 287 1871
heldGet 0 287 1871
assign 1 287 1872
nextPeerGet 0 287 1872
assign 1 287 1873
heldGet 0 287 1873
assign 1 287 1874
add 1 287 1874
heldSet 1 287 1875
assign 1 288 1876
nextPeerGet 0 288 1876
assign 1 288 1877
nextDescendGet 0 288 1877
assign 1 289 1878
nextPeerGet 0 289 1878
delayDelete 0 289 1879
return 1 290 1880
assign 1 292 1882
typenameGet 0 292 1882
assign 1 292 1883
MODULUSGet 0 292 1883
assign 1 292 1884
equals 1 292 1884
assign 1 292 1886
nextPeerGet 0 292 1886
assign 1 292 1887
def 1 292 1892
assign 1 0 1893
assign 1 0 1896
assign 1 0 1900
assign 1 292 1903
nextPeerGet 0 292 1903
assign 1 292 1904
typenameGet 0 292 1904
assign 1 292 1905
ASSIGNGet 0 292 1905
assign 1 292 1906
equals 1 292 1906
assign 1 0 1908
assign 1 0 1911
assign 1 0 1915
assign 1 293 1918
MODULUS_ASSIGNGet 0 293 1918
typenameSet 1 293 1919
assign 1 294 1920
heldGet 0 294 1920
assign 1 294 1921
nextPeerGet 0 294 1921
assign 1 294 1922
heldGet 0 294 1922
assign 1 294 1923
add 1 294 1923
heldSet 1 294 1924
assign 1 295 1925
nextPeerGet 0 295 1925
assign 1 295 1926
nextDescendGet 0 295 1926
assign 1 296 1927
nextPeerGet 0 296 1927
delayDelete 0 296 1928
return 1 297 1929
assign 1 299 1931
typenameGet 0 299 1931
assign 1 299 1932
ANDGet 0 299 1932
assign 1 299 1933
equals 1 299 1933
assign 1 299 1935
nextPeerGet 0 299 1935
assign 1 299 1936
def 1 299 1941
assign 1 0 1942
assign 1 0 1945
assign 1 0 1949
assign 1 299 1952
nextPeerGet 0 299 1952
assign 1 299 1953
typenameGet 0 299 1953
assign 1 299 1954
ASSIGNGet 0 299 1954
assign 1 299 1955
equals 1 299 1955
assign 1 0 1957
assign 1 0 1960
assign 1 0 1964
assign 1 300 1967
AND_ASSIGNGet 0 300 1967
typenameSet 1 300 1968
assign 1 301 1969
heldGet 0 301 1969
assign 1 301 1970
nextPeerGet 0 301 1970
assign 1 301 1971
heldGet 0 301 1971
assign 1 301 1972
add 1 301 1972
heldSet 1 301 1973
assign 1 302 1974
nextPeerGet 0 302 1974
assign 1 302 1975
nextDescendGet 0 302 1975
assign 1 303 1976
nextPeerGet 0 303 1976
delayDelete 0 303 1977
return 1 304 1978
assign 1 306 1980
typenameGet 0 306 1980
assign 1 306 1981
ORGet 0 306 1981
assign 1 306 1982
equals 1 306 1982
assign 1 306 1984
nextPeerGet 0 306 1984
assign 1 306 1985
def 1 306 1990
assign 1 0 1991
assign 1 0 1994
assign 1 0 1998
assign 1 306 2001
nextPeerGet 0 306 2001
assign 1 306 2002
typenameGet 0 306 2002
assign 1 306 2003
ASSIGNGet 0 306 2003
assign 1 306 2004
equals 1 306 2004
assign 1 0 2006
assign 1 0 2009
assign 1 0 2013
assign 1 307 2016
OR_ASSIGNGet 0 307 2016
typenameSet 1 307 2017
assign 1 308 2018
heldGet 0 308 2018
assign 1 308 2019
nextPeerGet 0 308 2019
assign 1 308 2020
heldGet 0 308 2020
assign 1 308 2021
add 1 308 2021
heldSet 1 308 2022
assign 1 309 2023
nextPeerGet 0 309 2023
assign 1 309 2024
nextDescendGet 0 309 2024
assign 1 310 2025
nextPeerGet 0 310 2025
delayDelete 0 310 2026
return 1 311 2027
assign 1 313 2029
typenameGet 0 313 2029
assign 1 313 2030
SPACEGet 0 313 2030
assign 1 313 2031
equals 1 313 2031
assign 1 0 2033
assign 1 313 2036
typenameGet 0 313 2036
assign 1 313 2037
NEWLINEGet 0 313 2037
assign 1 313 2038
equals 1 313 2038
assign 1 0 2040
assign 1 0 2043
assign 1 314 2047
nextDescendGet 0 314 2047
delayDelete 0 315 2048
return 1 316 2049
assign 1 318 2051
nextDescendGet 0 318 2051
return 1 318 2052
return 1 0 2055
assign 1 0 2058
return 1 0 2062
assign 1 0 2065
return 1 0 2069
assign 1 0 2072
return 1 0 2076
assign 1 0 2079
return 1 0 2083
assign 1 0 2086
return 1 0 2090
assign 1 0 2093
return 1 0 2097
assign 1 0 2100
return 1 0 2104
assign 1 0 2107
return 1 0 2111
assign 1 0 2114
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 572357856: return bem_nestCommentGet_0();
case 599903714: return bem_strqCntGet_0();
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 734766741: return bem_inLcGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1788342768: return bem_goingStrGet_0();
case 1081412016: return bem_many_0();
case 1246859482: return bem_inSpaceGet_0();
case 1417421339: return bem_inStrGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1297902980: return bem_inNlGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 2021097297: return bem_quoteTypeGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1235777229: return bem_inSpaceSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 588821461: return bem_strqCntSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1428503592: return bem_inStrSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 723684488: return bem_inLcSet_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 583440109: return bem_nestCommentSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 2032179550: return bem_quoteTypeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1799425021: return bem_goingStrSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1308985233: return bem_inNlSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass3();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass3.bevs_inst = (BEC_5_5_5_BuildVisitPass3)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass3.bevs_inst;
}
}
}
