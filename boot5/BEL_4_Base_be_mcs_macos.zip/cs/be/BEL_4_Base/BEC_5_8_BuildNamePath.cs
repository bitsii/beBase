namespace be.BEL_4_Base {
/* File: source/build/BuildTypes.be */
public class BEC_5_8_BuildNamePath : BEC_6_8_SystemBasePath {
public BEC_5_8_BuildNamePath() { }
static BEC_5_8_BuildNamePath() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 4));
public static new BEC_5_8_BuildNamePath bevs_inst;
public BEC_4_6_TextString bevp_label;
public override BEC_6_8_SystemBasePath bem_new_1(BEC_4_6_TextString beva_spath) {
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_separator = bevt_0_tmpvar_phold.bem_colonGet_0();
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_labelGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_label == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 31 */ {
bevt_2_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
return bevt_1_tmpvar_phold;
} /* Line: 32 */
return bevp_label;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_resolve_1(BEC_6_6_SystemObject beva_node) {
BEC_4_6_TextString bevl_oldpath = null;
BEC_4_6_TextString bevl_fstep = null;
BEC_5_4_BuildNode bevl_tunode = null;
BEC_6_8_SystemBasePath bevl_par = null;
BEC_6_8_SystemBasePath bevl_np2 = null;
BEC_6_8_SystemBasePath bevl_np = null;
BEC_5_4_BuildNode bevl_clnode = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevl_oldpath = this.bem_pathGet_0();
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevl_oldpath.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 40 */ {
return this;
} /* Line: 40 */
bevl_fstep = this.bem_firstStepGet_0();
bevl_tunode = (BEC_5_4_BuildNode) beva_node.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevt_3_tmpvar_phold = bevl_tunode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_par = (BEC_6_8_SystemBasePath) bevt_2_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_fstep);
if (bevl_par == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevl_np2 = this.bem_deleteFirstStep_0();
bevl_np = bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 47 */
bevl_clnode = (BEC_5_4_BuildNode) beva_node.bemd_0(312889617, BEL_4_Base.bevn_classGet_0);
if (bevl_clnode == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_6_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_6_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, this);
} /* Line: 51 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_labelSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_label = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 26, 27, 31, 31, 32, 32, 32, 35, 39, 40, 40, 40, 41, 42, 43, 43, 43, 44, 44, 45, 46, 47, 49, 50, 50, 51, 51, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 16, 23, 28, 29, 30, 31, 33, 50, 51, 52, 54, 56, 57, 58, 59, 60, 61, 66, 67, 68, 69, 71, 72, 77, 78, 79, 84};
/* BEGIN LINEINFO 
assign 1 26 14
new 0 26 14
assign 1 26 15
colonGet 0 26 15
fromString 1 27 16
assign 1 31 23
undef 1 31 28
assign 1 32 29
split 1 32 29
assign 1 32 30
lastGet 0 32 30
return 1 32 31
return 1 35 33
assign 1 39 50
pathGet 0 39 50
assign 1 40 51
new 0 40 51
assign 1 40 52
equals 1 40 52
return 1 40 54
assign 1 41 56
firstStepGet 0 41 56
assign 1 42 57
transUnitGet 0 42 57
assign 1 43 58
heldGet 0 43 58
assign 1 43 59
aliasedGet 0 43 59
assign 1 43 60
get 1 43 60
assign 1 44 61
def 1 44 66
assign 1 45 67
deleteFirstStep 0 45 67
assign 1 46 68
add 1 46 68
assign 1 47 69
pathGet 0 47 69
assign 1 49 71
classGet 0 49 71
assign 1 50 72
def 1 50 77
assign 1 51 78
heldGet 0 51 78
addUsed 1 51 79
assign 1 0 84
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 1672091917: return bem_labelGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1661009664: return bem_labelSet_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1991261538: return bem_resolve_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_8_BuildNamePath.bevs_inst = (BEC_5_8_BuildNamePath)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_8_BuildNamePath.bevs_inst;
}
}
}
