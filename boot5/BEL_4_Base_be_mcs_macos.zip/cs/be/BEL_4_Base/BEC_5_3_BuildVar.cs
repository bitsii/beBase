namespace be.BEL_4_Base {
/* File: source/build/BuildTypes.be */
public class BEC_5_3_BuildVar : BEC_6_6_SystemObject {
public BEC_5_3_BuildVar() { }
static BEC_5_3_BuildVar() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
private static byte[] bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 7));
private static byte[] bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 6));
private static byte[] bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 12));
private static byte[] bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_4, 11));
public static new BEC_5_3_BuildVar bevs_inst;
public BEC_4_6_TextString bevp_name;
public BEC_5_8_BuildNamePath bevp_namepath;
public BEC_6_6_SystemObject bevp_refs;
public BEC_9_3_ContainerMap bevp_allCalls;
public BEC_4_6_TextString bevp_suffix;
public BEC_5_4_LogicBool bevp_isArg;
public BEC_5_4_LogicBool bevp_isAdded;
public BEC_5_4_LogicBool bevp_isTmpVar;
public BEC_5_4_LogicBool bevp_isDeclared;
public BEC_5_4_LogicBool bevp_isProperty;
public BEC_4_3_MathInt bevp_numAssigns;
public BEC_5_4_LogicBool bevp_isTyped;
public BEC_4_3_MathInt bevp_vpos;
public BEC_5_4_LogicBool bevp_isSelf;
public BEC_4_3_MathInt bevp_maxCpos;
public BEC_4_3_MathInt bevp_minCpos;
public BEC_4_6_TextString bevp_nativeName;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_4_MathInts bevt_0_tmpvar_phold = null;
bevp_isArg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isAdded = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isTmpVar = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isDeclared = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_isProperty = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_numAssigns = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_vpos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
bevp_isSelf = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_maxCpos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(-1));
bevt_0_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst.bem_new_0();
bevp_minCpos = bevt_0_tmpvar_phold.bem_maxGet_0();
return this;
} /*method end*/
public virtual BEC_5_3_BuildVar bem_synNew_1(BEC_5_3_BuildVar beva_full) {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addCall_1(BEC_5_4_BuildNode beva_call) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_allCalls == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevp_allCalls = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
} /* Line: 240 */
bevp_allCalls.bem_put_2(beva_call, beva_call);
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxCposGet_0() {
BEC_6_6_SystemObject bevl_kv = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_maxCpos.bem_greater_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 246 */ {
return bevp_maxCpos;
} /* Line: 246 */
bevt_0_tmpvar_loop = bevp_allCalls.bem_iteratorGet_0();
while (true)
 /* Line: 247 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevp_maxCpos);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_9_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_maxCpos = (BEC_4_3_MathInt) bevt_8_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 249 */
} /* Line: 248 */
 else  /* Line: 247 */ {
break;
} /* Line: 247 */
} /* Line: 247 */
return bevp_maxCpos;
} /*method end*/
public virtual BEC_4_3_MathInt bem_minCposGet_0() {
BEC_4_3_MathInt bevl_bigun = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_4_MathInts bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst.bem_new_0();
bevl_bigun = bevt_1_tmpvar_phold.bem_maxGet_0();
bevt_2_tmpvar_phold = bevp_minCpos.bem_lesser_1(bevl_bigun);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 258 */ {
return bevp_minCpos;
} /* Line: 258 */
bevt_0_tmpvar_loop = bevp_allCalls.bem_iteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 259 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevp_minCpos);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_9_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_minCpos = (BEC_4_3_MathInt) bevt_8_tmpvar_phold.bemd_0(2128364298, BEL_4_Base.bevn_cposGet_0);
} /* Line: 261 */
} /* Line: 260 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
return bevp_minCpos;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_4_6_TextString bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevl_ret.bem_add_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_name.bem_toString_0();
bevl_ret = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
} /* Line: 270 */
if (bevp_isArg.bevi_bool) /* Line: 272 */ {
bevt_4_tmpvar_phold = bevo_2;
bevl_ret = bevl_ret.bem_add_1(bevt_4_tmpvar_phold);
} /* Line: 273 */
if (bevp_isTmpVar.bevi_bool) /* Line: 275 */ {
bevt_5_tmpvar_phold = bevo_3;
bevl_ret = bevl_ret.bem_add_1(bevt_5_tmpvar_phold);
} /* Line: 276 */
bevt_6_tmpvar_phold = bevp_isDeclared.bem_not_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_7_tmpvar_phold = bevo_4;
bevl_ret = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
} /* Line: 279 */
if (bevp_isProperty.bevi_bool) /* Line: 281 */ {
bevt_8_tmpvar_phold = bevo_5;
bevl_ret = bevl_ret.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 282 */
return bevl_ret;
} /*method end*/
public virtual BEC_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_namepathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_refsGet_0() {
return bevp_refs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_refsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_refs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_allCallsGet_0() {
return bevp_allCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allCalls = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_suffixGet_0() {
return bevp_suffix;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_suffixSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_suffix = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isArgGet_0() {
return bevp_isArg;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isArgSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isArg = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isAddedGet_0() {
return bevp_isAdded;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isAddedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isAdded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isTmpVarGet_0() {
return bevp_isTmpVar;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isTmpVarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isTmpVar = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isDeclaredGet_0() {
return bevp_isDeclared;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isDeclaredSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isDeclared = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isPropertyGet_0() {
return bevp_isProperty;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isPropertySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isProperty = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_numAssignsGet_0() {
return bevp_numAssigns;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_numAssignsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_numAssigns = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isTypedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isTyped = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_vposGet_0() {
return bevp_vpos;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_vposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isSelfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isSelf = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxCposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxCpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_minCposSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_minCpos = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nativeNameGet_0() {
return bevp_nativeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nativeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nativeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 219, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 239, 239, 240, 242, 246, 246, 246, 247, 0, 247, 247, 248, 248, 248, 248, 249, 249, 249, 252, 256, 256, 258, 258, 259, 0, 259, 259, 260, 260, 260, 260, 261, 261, 261, 264, 268, 269, 269, 270, 270, 270, 270, 273, 273, 276, 276, 278, 279, 279, 282, 282, 284, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 68, 73, 74, 76, 91, 92, 94, 96, 96, 99, 101, 102, 103, 104, 105, 107, 108, 109, 116, 131, 132, 133, 135, 137, 137, 140, 142, 143, 144, 145, 146, 148, 149, 150, 157, 170, 171, 176, 177, 178, 179, 180, 183, 184, 187, 188, 190, 192, 193, 196, 197, 199, 202, 205, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240, 244, 247, 251, 254, 258, 261, 265, 268, 272, 275, 279, 282, 286, 289, 293, 296, 300, 304, 308, 311};
/* BEGIN LINEINFO 
assign 1 209 39
new 0 209 39
assign 1 210 40
new 0 210 40
assign 1 211 41
new 0 211 41
assign 1 212 42
new 0 212 42
assign 1 213 43
new 0 213 43
assign 1 214 44
new 0 214 44
assign 1 215 45
new 0 215 45
assign 1 216 46
new 0 216 46
assign 1 217 47
new 0 217 47
assign 1 218 48
new 0 218 48
assign 1 219 49
new 0 219 49
assign 1 219 50
maxGet 0 219 50
assign 1 226 54
isArgGet 0 226 54
assign 1 227 55
nameGet 0 227 55
assign 1 228 56
isAddedGet 0 228 56
assign 1 229 57
isTmpVarGet 0 229 57
assign 1 230 58
isPropertyGet 0 230 58
assign 1 231 59
new 0 231 59
assign 1 232 60
namepathGet 0 232 60
assign 1 233 61
isTypedGet 0 233 61
assign 1 234 62
vposGet 0 234 62
assign 1 235 63
isSelfGet 0 235 63
assign 1 239 68
undef 1 239 73
assign 1 240 74
new 0 240 74
put 2 242 76
assign 1 246 91
new 0 246 91
assign 1 246 92
greater 1 246 92
return 1 246 94
assign 1 247 96
iteratorGet 0 0 96
assign 1 247 99
hasNextGet 0 247 99
assign 1 247 101
nextGet 0 247 101
assign 1 248 102
keyGet 0 248 102
assign 1 248 103
heldGet 0 248 103
assign 1 248 104
cposGet 0 248 104
assign 1 248 105
greater 1 248 105
assign 1 249 107
keyGet 0 249 107
assign 1 249 108
heldGet 0 249 108
assign 1 249 109
cposGet 0 249 109
return 1 252 116
assign 1 256 131
new 0 256 131
assign 1 256 132
maxGet 0 256 132
assign 1 258 133
lesser 1 258 133
return 1 258 135
assign 1 259 137
iteratorGet 0 0 137
assign 1 259 140
hasNextGet 0 259 140
assign 1 259 142
nextGet 0 259 142
assign 1 260 143
keyGet 0 260 143
assign 1 260 144
heldGet 0 260 144
assign 1 260 145
cposGet 0 260 145
assign 1 260 146
lesser 1 260 146
assign 1 261 148
keyGet 0 261 148
assign 1 261 149
heldGet 0 261 149
assign 1 261 150
cposGet 0 261 150
return 1 264 157
assign 1 268 170
classNameGet 0 268 170
assign 1 269 171
def 1 269 176
assign 1 270 177
new 0 270 177
assign 1 270 178
add 1 270 178
assign 1 270 179
toString 0 270 179
assign 1 270 180
add 1 270 180
assign 1 273 183
new 0 273 183
assign 1 273 184
add 1 273 184
assign 1 276 187
new 0 276 187
assign 1 276 188
add 1 276 188
assign 1 278 190
not 0 278 190
assign 1 279 192
new 0 279 192
assign 1 279 193
add 1 279 193
assign 1 282 196
new 0 282 196
assign 1 282 197
add 1 282 197
return 1 284 199
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
return 1 0 244
assign 1 0 247
return 1 0 251
assign 1 0 254
return 1 0 258
assign 1 0 261
return 1 0 265
assign 1 0 268
return 1 0 272
assign 1 0 275
return 1 0 279
assign 1 0 282
return 1 0 286
assign 1 0 289
return 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 0 304
return 1 0 308
assign 1 0 311
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 781552485: return bem_nativeNameGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 495053105: return bem_isAddedGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 354142775: return bem_namepathGet_0();
case 1126433704: return bem_isPropertyGet_0();
case 1135771315: return bem_isTmpVarGet_0();
case 1308786538: return bem_echo_0();
case 1193313287: return bem_isTypedGet_0();
case 729571811: return bem_serializeToString_0();
case 389100841: return bem_numAssignsGet_0();
case 1454846051: return bem_isDeclaredGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2024716595: return bem_allCallsGet_0();
case 535212143: return bem_isSelfGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 2110260727: return bem_vposGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1211273660: return bem_nameGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 1081412016: return bem_many_0();
case 564053209: return bem_refsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 743311346: return bem_maxCposGet_0();
case 2104155978: return bem_suffixGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 1869307931: return bem_isArgGet_0();
case 845792839: return bem_iteratorGet_0();
case 314718434: return bem_print_0();
case 1217737412: return bem_minCposGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1797856106: return bem_synNew_1((BEC_5_3_BuildVar) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 792634738: return bem_nativeNameSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2099178474: return bem_vposSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 506135358: return bem_isAddedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 552970956: return bem_refsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1124689062: return bem_isTmpVarSet_1(bevd_0);
case 754393599: return bem_maxCposSet_1(bevd_0);
case 1137515957: return bem_isPropertySet_1(bevd_0);
case 2093073725: return bem_suffixSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1880390184: return bem_isArgSet_1(bevd_0);
case 1204395540: return bem_isTypedSet_1(bevd_0);
case 400183094: return bem_numAssignsSet_1(bevd_0);
case 1465928304: return bem_isDeclaredSet_1(bevd_0);
case 524129890: return bem_isSelfSet_1(bevd_0);
case 474935663: return bem_addCall_1((BEC_5_4_BuildNode) bevd_0);
case 1228819665: return bem_minCposSet_1(bevd_0);
case 2035798848: return bem_allCallsSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_3_BuildVar();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_3_BuildVar.bevs_inst = (BEC_5_3_BuildVar)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_3_BuildVar.bevs_inst;
}
}
}
