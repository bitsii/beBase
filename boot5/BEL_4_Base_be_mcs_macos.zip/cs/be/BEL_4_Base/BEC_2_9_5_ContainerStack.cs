namespace be.BEL_4_Base {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
static BEC_2_9_5_ContainerStack() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerStack bevs_inst;
public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_push_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpvar_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpvar_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 42 */ {
if (bevp_holder == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 43 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 44 */
 else  /* Line: 45 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 47 */
} /* Line: 43 */
 else  /* Line: 42 */ {
bevt_3_tmpvar_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevt_4_tmpvar_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpvar_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 52 */
 else  /* Line: 53 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 54 */
} /* Line: 42 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_pop_0() {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 61 */ {
return bevp_top;
} /* Line: 62 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 66 */ {
bevp_holder = bevl_last;
} /* Line: 67 */
if (bevl_last == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 69 */ {
return null;
} /* Line: 70 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_peek_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 79 */ {
return bevp_top;
} /* Line: 80 */
bevt_1_tmpvar_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
this.bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_pop_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_pop.bevi_bool) /* Line: 98 */ {
bevt_0_tmpvar_phold = this.bem_pop_0();
return bevt_0_tmpvar_phold;
} /* Line: 99 */
bevt_1_tmpvar_phold = this.bem_peek_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) {
this.bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() {
return bevp_holder;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 42, 42, 43, 43, 44, 46, 47, 49, 49, 49, 50, 50, 51, 51, 52, 54, 56, 57, 61, 61, 62, 64, 65, 66, 66, 67, 69, 69, 70, 72, 73, 74, 75, 79, 79, 80, 82, 82, 86, 86, 90, 94, 94, 99, 99, 101, 101, 105, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {13, 23, 28, 29, 34, 35, 38, 39, 43, 44, 49, 50, 51, 52, 53, 54, 57, 60, 61, 70, 75, 76, 78, 79, 80, 85, 86, 88, 93, 94, 96, 97, 98, 99, 104, 109, 110, 112, 113, 117, 122, 125, 130, 131, 137, 138, 140, 141, 144, 148, 151, 155, 158, 162, 165};
/* BEGIN LINEINFO 
assign 1 36 13
new 0 36 13
assign 1 42 23
undef 1 42 28
assign 1 43 29
undef 1 43 34
assign 1 44 35
new 0 44 35
assign 1 46 38
assign 1 47 39
assign 1 49 43
nextGet 0 49 43
assign 1 49 44
undef 1 49 49
assign 1 50 50
new 0 50 50
nextSet 1 50 51
assign 1 51 52
nextGet 0 51 52
priorSet 1 51 53
assign 1 52 54
nextGet 0 52 54
assign 1 54 57
nextGet 0 54 57
heldSet 1 56 60
assign 1 57 61
increment 0 57 61
assign 1 61 70
undef 1 61 75
return 1 62 76
assign 1 64 78
assign 1 65 79
priorGet 0 65 79
assign 1 66 80
undef 1 66 85
assign 1 67 86
assign 1 69 88
undef 1 69 93
return 1 70 94
assign 1 72 96
heldGet 0 72 96
heldSet 1 73 97
assign 1 74 98
decrement 0 74 98
return 1 75 99
assign 1 79 104
undef 1 79 109
return 1 80 110
assign 1 82 112
heldGet 0 82 112
return 1 82 113
assign 1 86 117
undef 1 86 122
return 1 86 122
push 1 90 125
assign 1 94 130
pop 0 94 130
return 1 94 131
assign 1 99 137
pop 0 99 137
return 1 99 138
assign 1 101 140
peek 0 101 140
return 1 101 141
push 1 105 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 98246023: return bem_get_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 106851778: return bem_pop_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 992112052: return bem_peek_0();
case 789252923: return bem_holderGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 988612302: return bem_topGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 977530049: return bem_topSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 800335176: return bem_holderSet_1(bevd_0);
case 976921524: return bem_push_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerStack();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerStack.bevs_inst = (BEC_2_9_5_ContainerStack)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerStack.bevs_inst;
}
}
}
