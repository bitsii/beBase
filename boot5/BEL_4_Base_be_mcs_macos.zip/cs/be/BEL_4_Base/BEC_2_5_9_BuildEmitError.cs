namespace be.BEL_4_Base {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bevs_inst;
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1475977273: return bem_langGet_0();
case 1307921883: return bem_methodNameGet_0();
case 287040793: return bem_hashGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1774940957: return bem_toString_0();
case -786424307: return bem_tagGet_0();
case 1353219100: return bem_klassNameGet_0();
case 1820417453: return bem_create_0();
case 556476320: return bem_fileNameGet_0();
case -764669899: return bem_getFrameText_0();
case -220901978: return bem_emitLangGet_0();
case -1141730732: return bem_framesTextGet_0();
case -1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case -1305997690: return bem_msgGet_0();
case -1012494862: return bem_once_0();
case 154290862: return bem_translateEmittedException_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -314718434: return bem_print_0();
case 443216037: return bem_nodeGet_0();
case 1102720804: return bem_classNameGet_0();
case 484558571: return bem_descriptionGet_0();
case -1611190486: return bem_lineNumberGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1354714650: return bem_copy_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1184167343: return bem_translatedGet_0();
case 734830721: return bem_framesGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 454298290: return bem_nodeSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case -813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1294915437: return bem_msgSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1173085090: return bem_translatedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1130648479: return bem_framesTextSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bevs_inst = (BEC_2_5_9_BuildEmitError)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bevs_inst;
}
}
}
