namespace be.BEL_4_Base {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
static BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(44));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
private static byte[] bels_0 = {0x2B};
private static byte[] bels_1 = {0x25};
private static byte[] bels_2 = {0x2B};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x25};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_5 = {0x2B};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 1));
private static byte[] bels_6 = {0x25};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 1));
public static new BEC_2_6_3_EncodeUrl bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeUrl bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_multiply_1(bevt_7_tmpvar_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_tmpvar_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_tmpvar_phold);
while (true)
 /* Line: 165 */ {
bevt_9_tmpvar_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_1;
if (bevl_ac.bevi_int > bevt_12_tmpvar_phold.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_14_tmpvar_phold = bevo_2;
if (bevl_ac.bevi_int < bevt_14_tmpvar_phold.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_16_tmpvar_phold = bevo_3;
if (bevl_ac.bevi_int > bevt_16_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_18_tmpvar_phold = bevo_4;
if (bevl_ac.bevi_int < bevt_18_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_20_tmpvar_phold = bevo_5;
if (bevl_ac.bevi_int > bevt_20_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_22_tmpvar_phold = bevo_6;
if (bevl_ac.bevi_int < bevt_22_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_24_tmpvar_phold = bevo_7;
if (bevl_ac.bevi_int > bevt_24_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_26_tmpvar_phold = bevo_8;
if (bevl_ac.bevi_int < bevt_26_tmpvar_phold.bevi_int) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_28_tmpvar_phold = bevo_9;
if (bevl_ac.bevi_int == bevt_28_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 169 */
 else  /* Line: 168 */ {
bevt_30_tmpvar_phold = bevo_10;
if (bevl_ac.bevi_int == bevt_30_tmpvar_phold.bevi_int) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpvar_phold);
} /* Line: 171 */
 else  /* Line: 172 */ {
bevt_32_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpvar_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 175 */
} /* Line: 168 */
} /* Line: 168 */
 else  /* Line: 165 */ {
break;
} /* Line: 165 */
} /* Line: 165 */
bevt_34_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_34_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpvar_phold, bevl_last);
bevt_4_tmpvar_phold = bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
if (bevl_npl == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 191 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 193 */
 else  /* Line: 194 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 196 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 200 */ {
if (bevl_i == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 200 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_10_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpvar_phold);
bevl_last = bevl_i;
} /* Line: 203 */
if (bevl_ispl.bevi_bool) /* Line: 205 */ {
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevl_r.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 207 */
 else  /* Line: 208 */ {
bevt_15_tmpvar_phold = bevo_14;
bevt_14_tmpvar_phold = bevl_i.bem_add_1(bevt_15_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_int < bevl_len.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_19_tmpvar_phold = bevo_15;
bevt_18_tmpvar_phold = bevl_i.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_16;
bevt_20_tmpvar_phold = bevl_i.bem_add_1(bevt_21_tmpvar_phold);
bevt_17_tmpvar_phold = beva_str.bem_substring_2(bevt_18_tmpvar_phold, bevt_20_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevl_r.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_22_tmpvar_phold = bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpvar_phold);
} /* Line: 211 */
} /* Line: 209 */
bevt_23_tmpvar_phold = bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpvar_phold, bevl_last);
bevt_24_tmpvar_phold = bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
if (bevl_npl == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 216 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 218 */
 else  /* Line: 219 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 221 */
} /* Line: 216 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_29_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpvar_phold);
} /* Line: 225 */
bevt_30_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {162, 162, 162, 162, 163, 164, 164, 165, 166, 167, 167, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 0, 0, 169, 170, 170, 170, 171, 171, 173, 173, 174, 174, 175, 178, 178, 182, 182, 183, 189, 189, 190, 190, 191, 191, 0, 191, 191, 191, 191, 0, 0, 0, 0, 0, 192, 193, 195, 196, 199, 200, 200, 201, 201, 202, 202, 203, 206, 206, 207, 207, 209, 209, 209, 209, 210, 210, 210, 210, 210, 210, 210, 211, 211, 214, 214, 215, 215, 216, 216, 0, 216, 216, 216, 216, 0, 0, 0, 0, 0, 217, 218, 220, 221, 224, 224, 225, 225, 227, 227};
public static new int[] bevs_smnlec
 = new int[] {85, 86, 87, 88, 89, 90, 91, 94, 96, 97, 98, 99, 100, 105, 106, 107, 112, 113, 116, 120, 123, 126, 127, 132, 133, 134, 139, 140, 143, 147, 150, 153, 157, 160, 161, 166, 167, 168, 173, 174, 177, 181, 184, 187, 191, 194, 195, 200, 201, 202, 207, 208, 211, 215, 218, 221, 225, 228, 229, 234, 235, 238, 242, 245, 246, 251, 252, 253, 256, 257, 258, 259, 260, 268, 269, 310, 311, 312, 313, 314, 315, 316, 317, 322, 323, 326, 331, 332, 337, 338, 341, 345, 348, 351, 355, 356, 359, 360, 362, 365, 370, 371, 376, 377, 378, 379, 382, 383, 384, 385, 388, 389, 390, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 407, 408, 409, 410, 411, 416, 417, 420, 425, 426, 431, 432, 435, 439, 442, 445, 449, 450, 453, 454, 461, 466, 467, 468, 470, 471};
/* BEGIN LINEINFO 
assign 1 162 85
sizeGet 0 162 85
assign 1 162 86
new 0 162 86
assign 1 162 87
multiply 1 162 87
assign 1 162 88
new 1 162 88
assign 1 163 89
new 1 163 89
assign 1 164 90
new 0 164 90
assign 1 164 91
new 1 164 91
assign 1 165 94
hasNextGet 0 165 94
next 1 166 96
assign 1 167 97
new 0 167 97
assign 1 167 98
getCode 1 167 98
assign 1 168 99
new 0 168 99
assign 1 168 100
greater 1 168 105
assign 1 168 106
new 0 168 106
assign 1 168 107
lesser 1 168 112
assign 1 0 113
assign 1 0 116
assign 1 0 120
assign 1 0 123
assign 1 168 126
new 0 168 126
assign 1 168 127
greater 1 168 132
assign 1 168 133
new 0 168 133
assign 1 168 134
lesser 1 168 139
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 168 160
new 0 168 160
assign 1 168 161
greater 1 168 166
assign 1 168 167
new 0 168 167
assign 1 168 168
lesser 1 168 173
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 168 194
new 0 168 194
assign 1 168 195
greater 1 168 200
assign 1 168 201
new 0 168 201
assign 1 168 202
lesser 1 168 207
assign 1 0 208
assign 1 0 211
assign 1 0 215
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 168 228
new 0 168 228
assign 1 168 229
equals 1 168 234
assign 1 0 235
assign 1 0 238
addValue 1 169 242
assign 1 170 245
new 0 170 245
assign 1 170 246
equals 1 170 251
assign 1 171 252
new 0 171 252
addValue 1 171 253
assign 1 173 256
new 0 173 256
addValue 1 173 257
assign 1 174 258
new 0 174 258
assign 1 174 259
getHex 1 174 259
addValue 1 175 260
assign 1 178 268
toString 0 178 268
return 1 178 269
assign 1 182 310
sizeGet 0 182 310
assign 1 182 311
new 1 182 311
assign 1 183 312
new 0 183 312
assign 1 189 313
new 0 189 313
assign 1 189 314
find 2 189 314
assign 1 190 315
new 0 190 315
assign 1 190 316
find 2 190 316
assign 1 191 317
undef 1 191 322
assign 1 0 323
assign 1 191 326
def 1 191 331
assign 1 191 332
lesser 1 191 337
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 0 348
assign 1 0 351
assign 1 192 355
new 0 192 355
assign 1 193 356
assign 1 195 359
new 0 195 359
assign 1 196 360
assign 1 199 362
sizeGet 0 199 362
assign 1 200 365
def 1 200 370
assign 1 201 371
greater 1 201 376
assign 1 202 377
substring 2 202 377
addValue 1 202 378
assign 1 203 379
assign 1 206 382
new 0 206 382
addValue 1 206 383
assign 1 207 384
new 0 207 384
assign 1 207 385
add 1 207 385
assign 1 209 388
new 0 209 388
assign 1 209 389
add 1 209 389
assign 1 209 390
lesser 1 209 395
assign 1 210 396
new 0 210 396
assign 1 210 397
add 1 210 397
assign 1 210 398
new 0 210 398
assign 1 210 399
add 1 210 399
assign 1 210 400
substring 2 210 400
assign 1 210 401
hexNew 1 210 401
addValue 1 210 402
assign 1 211 403
new 0 211 403
assign 1 211 404
add 1 211 404
assign 1 214 407
new 0 214 407
assign 1 214 408
find 2 214 408
assign 1 215 409
new 0 215 409
assign 1 215 410
find 2 215 410
assign 1 216 411
undef 1 216 416
assign 1 0 417
assign 1 216 420
def 1 216 425
assign 1 216 426
lesser 1 216 431
assign 1 0 432
assign 1 0 435
assign 1 0 439
assign 1 0 442
assign 1 0 445
assign 1 217 449
new 0 217 449
assign 1 218 450
assign 1 220 453
new 0 220 453
assign 1 221 454
assign 1 224 461
lesser 1 224 466
assign 1 225 467
substring 2 225 467
addValue 1 225 468
assign 1 227 470
toString 0 227 470
return 1 227 471
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 570808864: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeUrl();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeUrl.bevs_inst = (BEC_2_6_3_EncodeUrl)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeUrl.bevs_inst;
}
}
}
