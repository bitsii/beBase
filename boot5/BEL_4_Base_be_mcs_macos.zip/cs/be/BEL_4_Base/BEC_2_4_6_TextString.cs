namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_23 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_28 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bevo_39 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bevs_inst;
public BEC_2_6_6_SystemObject bevp_vstring;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public virtual BEC_2_6_6_SystemObject bem_vstringGet_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_vstringSet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 201 */
 else  /* Line: 200 */ {
bevt_1_tmpvar_phold = bevp_capacity.bem_equals_1(beva_ncap);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 202 */ {
return this;
} /* Line: 203 */
} /* Line: 200 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      bevt_2_tmpvar_phold = bevp_size.bem_greater_1(beva_ncap);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevp_size.bem_setValue_1(beva_ncap);
} /* Line: 235 */
bevp_capacity.bem_setValue_1(beva_ncap);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevp_size.bem_setValue_1(bevt_2_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
this.bem_setHex_2(bevt_4_tmpvar_phold, beva_val);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
} /* Line: 259 */
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bem_setValue_1(bevt_1_tmpvar_phold);
bevp_sizi.bem_addValue_1(bevp_size);
bevt_2_tmpvar_phold = bevp_capacity.bem_lesser_1(bevp_sizi);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_5_tmpvar_phold = bevo_4;
bevt_4_tmpvar_phold = bevp_sizi.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevo_5;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_multiply_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_6;
bevl_nsize = bevt_3_tmpvar_phold.bem_divide_1(bevt_7_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 266 */
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_open_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_close_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevp_size.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
bevp_size.bem_setValue_1(bevt_6_tmpvar_phold);
} /* Line: 302 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = bevo_11;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevp_size.bem_setValue_1(bevt_1_tmpvar_phold);
bevt_4_tmpvar_phold = bevo_12;
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
this.bem_setCodeUnchecked_2(bevt_3_tmpvar_phold, (BEC_2_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_3_tmpvar_phold = bevo_13;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 315 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevt_8_tmpvar_phold = bevo_14;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 319 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 332 */ {
bevt_3_tmpvar_phold = bevo_16;
bevt_2_tmpvar_phold = bevl_found.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 332 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 332 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 332 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 333 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 339 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 341 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 342 */
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 348 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 348 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 348 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 349 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 356 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 356 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevl_ic.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 358 */ {
bevt_5_tmpvar_phold = bevo_18;
bevt_4_tmpvar_phold = bevl_ic.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 358 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 358 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 358 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 359 */
bevl_j.bem_incrementValue_0();
} /* Line: 356 */
 else  /* Line: 356 */ {
break;
} /* Line: 356 */
} /* Line: 356 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 367 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 367 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 369 */ {
bevt_5_tmpvar_phold = bevo_20;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 369 */
 else  /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 369 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_addValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 371 */
bevl_j.bem_incrementValue_0();
} /* Line: 367 */
 else  /* Line: 367 */ {
break;
} /* Line: 367 */
} /* Line: 367 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_lowerValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 382 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 382 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_21;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevt_5_tmpvar_phold = bevo_22;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 384 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 386 */
bevl_j.bem_incrementValue_0();
} /* Line: 382 */
 else  /* Line: 382 */ {
break;
} /* Line: 382 */
} /* Line: 382 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_upperValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 403 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_posi);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 403 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bem_setValue_1(bevt_0_tmpvar_phold);
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 413 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bem_addValue_1(bevl_c);
bevl_j.bem_incrementValue_0();
} /* Line: 413 */
 else  /* Line: 413 */ {
break;
} /* Line: 413 */
} /* Line: 413 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_23;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 436 */
 else  /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 436 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 456 */
 else  /* Line: 464 */ {
return null;
} /* Line: 465 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_24;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 478 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 478 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 478 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 478 */
 else  /* Line: 478 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 478 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 502 */
 else  /* Line: 507 */ {
return null;
} /* Line: 508 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_25;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 514 */
 else  /* Line: 514 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 514 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 515 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_26;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 520 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 520 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 520 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 520 */
 else  /* Line: 520 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 520 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 521 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_27;
bevt_0_tmpvar_phold = bevp_size.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 526 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 527 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_reverseBytes_0();
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpvar_phold.bem_find_1(bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 620 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 622 */
return null;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_28;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_9_tmpvar_phold = bevo_29;
bevt_8_tmpvar_phold = beva_start.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_10_tmpvar_phold = beva_start.bem_greaterEquals_1(bevp_size);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_14_tmpvar_phold = bevo_30;
bevt_13_tmpvar_phold = bevp_size.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_31;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 634 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 634 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 634 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 634 */ {
return null;
} /* Line: 635 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevt_18_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold = bevl_strsize.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 646 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
} /* Line: 649 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
while (true)
 /* Line: 652 */ {
bevt_21_tmpvar_phold = bevl_current.bem_lesser_1(bevl_end);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 652 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
bevt_22_tmpvar_phold = bevl_myval.bem_equals_1(bevl_strfirst);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 654 */ {
bevt_24_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold = bevl_strsize.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 655 */ {
return bevl_current;
} /* Line: 656 */
bevl_current2.bem_setValue_1(bevl_current);
bevl_current2.bem_incrementValue_0();
bevl_end2.bem_setValue_1(bevl_current);
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_end2.bem_greater_1(bevp_size);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 662 */ {
return null;
} /* Line: 663 */
bevt_28_tmpvar_phold = bevo_34;
bevt_27_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_28_tmpvar_phold.bem_once_0();
bevl_currentstr2.bem_setValue_1(bevt_27_tmpvar_phold);
while (true)
 /* Line: 666 */ {
bevt_29_tmpvar_phold = bevl_current2.bem_lesser_1(bevl_end2);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 666 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
bevt_30_tmpvar_phold = bevl_myval.bem_notEquals_1(bevl_strval);
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 669 */ {
break;
} /* Line: 670 */
bevl_current2.bem_incrementValue_0();
bevl_currentstr2.bem_incrementValue_0();
} /* Line: 673 */
 else  /* Line: 666 */ {
break;
} /* Line: 666 */
} /* Line: 666 */
bevt_31_tmpvar_phold = bevl_current2.bem_equals_1(bevl_end2);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 675 */ {
return bevl_current;
} /* Line: 676 */
} /* Line: 675 */
bevl_current.bem_incrementValue_0();
} /* Line: 679 */
 else  /* Line: 652 */ {
break;
} /* Line: 652 */
} /* Line: 652 */
return null;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 689 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 689 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 692 */
 else  /* Line: 689 */ {
break;
} /* Line: 689 */
} /* Line: 689 */
bevt_2_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 694 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 695 */
return bevl_splits;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 717 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 717 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 717 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 717 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 717 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 717 */ {
return null;
} /* Line: 718 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_3_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 722 */ {
bevl_maxsize = bevl_osize;
} /* Line: 723 */
 else  /* Line: 724 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 725 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 730 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_maxsize);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 730 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
bevt_5_tmpvar_phold = bevl_mv.bem_notEquals_1(bevl_ov);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 733 */ {
bevt_6_tmpvar_phold = bevl_mv.bem_greater_1(bevl_ov);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 734 */ {
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 735 */
 else  /* Line: 736 */ {
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 737 */
} /* Line: 734 */
bevl_i.bem_incrementValue_0();
} /* Line: 730 */
 else  /* Line: 730 */ {
break;
} /* Line: 730 */
} /* Line: 730 */
bevt_10_tmpvar_phold = bevo_35;
bevt_9_tmpvar_phold = bevl_myret.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 741 */ {
bevt_11_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 742 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 743 */
 else  /* Line: 742 */ {
bevt_12_tmpvar_phold = bevl_osize.bem_greater_1(bevl_mysize);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 744 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 745 */
} /* Line: 742 */
} /* Line: 742 */
return bevl_myret;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 752 */ {
return null;
} /* Line: 752 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_36;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 753 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 754 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 760 */ {
return null;
} /* Line: 760 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_37;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 761 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 762 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 768 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 769 */

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
  if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  }
  bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpvar_phold, bevp_size, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = beva_starti.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 853 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_3_tmpvar_phold = beva_starti.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 853 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_endi.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 853 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 853 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 853 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 853 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_1));
bevt_7_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 854 */
 else  /* Line: 855 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 858 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
} /* Line: 860 */
bevp_leni.bem_setValue_1(beva_endi);
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bem_setValue_1(beva_dstarti);
bevp_sizi.bem_addValue_1(bevp_leni);
bevt_10_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_capacity);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 869 */ {
this.bem_capacitySet_1(bevp_sizi);
} /* Line: 870 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         bevt_11_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 925 */ {
bevp_size.bem_setValue_1(bevp_sizi);
} /* Line: 929 */
return this;
} /* Line: 931 */
} /*method end*/
public virtual BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1057 */ {
this.bem_new_0();
} /* Line: 1058 */
 else  /* Line: 1059 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_39;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1061 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_40;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1078 */ {
bevt_1_tmpvar_phold = bevl_e.bem_greater_1(bevl_b);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1078 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bem_incrementValue_0();
bevl_e.bem_decrementValue_0();
} /* Line: 1084 */
 else  /* Line: 1078 */ {
break;
} /* Line: 1078 */
} /* Line: 1078 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_vstringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vstring = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {182, 183, 196, 200, 201, 202, 203, 234, 235, 237, 241, 242, 243, 247, 251, 252, 256, 257, 258, 259, 261, 262, 264, 265, 266, 268, 272, 276, 280, 284, 294, 295, 296, 300, 301, 302, 307, 308, 309, 313, 314, 315, 317, 318, 319, 321, 325, 326, 327, 331, 332, 0, 332, 0, 333, 335, 339, 340, 341, 342, 344, 348, 0, 348, 0, 349, 351, 355, 356, 357, 358, 0, 358, 0, 359, 356, 362, 366, 367, 368, 369, 0, 370, 371, 367, 377, 381, 382, 383, 384, 0, 385, 386, 382, 392, 396, 401, 402, 403, 404, 403, 406, 407, 411, 412, 413, 414, 415, 416, 413, 418, 422, 426, 436, 0, 465, 467, 478, 0, 508, 510, 514, 0, 515, 520, 0, 521, 526, 527, 529, 612, 618, 620, 621, 622, 624, 628, 634, 0, 634, 0, 634, 0, 634, 0, 634, 0, 634, 0, 634, 0, 635, 638, 639, 640, 641, 642, 644, 646, 647, 648, 649, 651, 652, 653, 654, 655, 656, 658, 659, 660, 661, 662, 663, 665, 666, 667, 668, 669, 672, 673, 675, 676, 679, 681, 685, 686, 687, 688, 689, 690, 691, 692, 694, 695, 697, 701, 705, 709, 717, 0, 717, 0, 718, 720, 721, 722, 723, 725, 727, 728, 729, 730, 731, 732, 733, 734, 735, 737, 730, 741, 742, 743, 744, 745, 748, 752, 753, 754, 756, 760, 761, 762, 764, 768, 769, 813, 817, 821, 822, 823, 824, 825, 828, 853, 0, 853, 0, 853, 0, 854, 858, 859, 860, 862, 863, 864, 866, 867, 869, 870, 925, 929, 931, 936, 940, 1025, 1029, 1033, 1037, 1041, 1045, 1049, 1053, 1057, 1058, 1060, 1061, 1066, 1070, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 0};
public static new int[] bevs_smnlec
 = new int[] {93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93, 93};
/* BEGIN LINEINFO 
assign 1 182 93
new 0 182 93
capacitySet 1 183 93
assign 1 196 93
new 0 196 93
assign 1 196 93
once 0 196 93
new 1 196 93
assign 1 200 93
undef 1 200 93
assign 1 201 93
new 0 201 93
assign 1 202 93
equals 1 202 93
return 1 203 93
assign 1 234 93
greater 1 234 93
setValue 1 235 93
setValue 1 237 93
assign 1 241 93
new 0 241 93
assign 1 241 93
once 0 241 93
new 1 241 93
assign 1 242 93
new 0 242 93
assign 1 242 93
once 0 242 93
setValue 1 242 93
assign 1 243 93
new 0 243 93
assign 1 243 93
once 0 243 93
setHex 2 243 93
assign 1 247 93
new 0 247 93
assign 1 247 93
getCode 2 247 93
assign 1 247 93
new 0 247 93
assign 1 247 93
new 0 247 93
assign 1 247 93
new 0 247 93
assign 1 247 93
toString 3 247 93
return 1 247 93
assign 1 251 93
hexNew 1 251 93
setCode 2 252 93
assign 1 256 93
toString 0 256 93
assign 1 257 93
undef 1 257 93
assign 1 258 93
new 0 258 93
assign 1 259 93
new 0 259 93
assign 1 261 93
sizeGet 0 261 93
setValue 1 261 93
addValue 1 262 93
assign 1 264 93
lesser 1 264 93
assign 1 265 93
new 0 265 93
assign 1 265 93
add 1 265 93
assign 1 265 93
new 0 265 93
assign 1 265 93
multiply 1 265 93
assign 1 265 93
new 0 265 93
assign 1 265 93
divide 1 265 93
capacitySet 1 266 93
assign 1 268 93
new 0 268 93
assign 1 268 93
sizeGet 0 268 93
copyValue 4 268 93
return 1 272 93
return 1 276 93
addValue 1 280 93
write 1 284 93
assign 1 294 93
copy 0 294 93
clear 0 295 93
return 1 296 93
assign 1 300 93
new 0 300 93
assign 1 300 93
greater 1 300 93
assign 1 301 93
new 0 301 93
assign 1 301 93
once 0 301 93
assign 1 301 93
new 0 301 93
assign 1 301 93
once 0 301 93
setIntUnchecked 2 301 93
assign 1 302 93
new 0 302 93
assign 1 302 93
once 0 302 93
setValue 1 302 93
assign 1 307 93
new 0 307 93
new 1 307 93
assign 1 308 93
new 0 308 93
assign 1 308 93
once 0 308 93
setValue 1 308 93
assign 1 309 93
new 0 309 93
assign 1 309 93
once 0 309 93
setCodeUnchecked 2 309 93
assign 1 313 93
new 0 313 93
assign 1 313 93
newlineGet 0 313 93
assign 1 314 93
ends 1 314 93
assign 1 315 93
new 0 315 93
assign 1 315 93
sizeGet 0 315 93
assign 1 315 93
subtract 1 315 93
assign 1 315 93
substring 2 315 93
return 1 315 93
assign 1 317 93
new 0 317 93
assign 1 318 93
ends 1 318 93
assign 1 319 93
new 0 319 93
assign 1 319 93
sizeGet 0 319 93
assign 1 319 93
subtract 1 319 93
assign 1 319 93
substring 2 319 93
return 1 319 93
return 1 321 93
assign 1 325 93
new 0 325 93
assign 1 325 93
add 1 325 93
assign 1 325 93
new 1 325 93
addValue 1 326 93
return 1 327 93
assign 1 331 93
find 1 331 93
assign 1 332 93
undef 1 332 93
assign 1 0 93
assign 1 332 93
new 0 332 93
assign 1 332 93
notEquals 1 332 93
assign 1 0 93
assign 1 0 93
assign 1 333 93
new 0 333 93
return 1 333 93
assign 1 335 93
new 0 335 93
return 1 335 93
assign 1 339 93
undef 1 339 93
assign 1 339 93
new 0 339 93
return 1 339 93
assign 1 340 93
sizeGet 0 340 93
assign 1 340 93
subtract 1 340 93
assign 1 340 93
find 2 340 93
assign 1 341 93
undef 1 341 93
assign 1 342 93
new 0 342 93
return 1 342 93
assign 1 344 93
new 0 344 93
return 1 344 93
assign 1 348 93
undef 1 348 93
assign 1 0 93
assign 1 348 93
find 1 348 93
assign 1 348 93
undef 1 348 93
assign 1 0 93
assign 1 0 93
assign 1 349 93
new 0 349 93
return 1 349 93
assign 1 351 93
new 0 351 93
return 1 351 93
assign 1 355 93
new 0 355 93
assign 1 356 93
new 0 356 93
assign 1 356 93
lesser 1 356 93
getInt 2 357 93
assign 1 358 93
new 0 358 93
assign 1 358 93
greater 1 358 93
assign 1 0 93
assign 1 358 93
new 0 358 93
assign 1 358 93
lesser 1 358 93
assign 1 0 93
assign 1 0 93
assign 1 359 93
new 0 359 93
return 1 359 93
incrementValue 0 356 93
assign 1 362 93
new 0 362 93
return 1 362 93
assign 1 366 93
new 0 366 93
assign 1 367 93
new 0 367 93
assign 1 367 93
lesser 1 367 93
getInt 2 368 93
assign 1 369 93
new 0 369 93
assign 1 369 93
greater 1 369 93
assign 1 369 93
new 0 369 93
assign 1 369 93
lesser 1 369 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 370 93
new 0 370 93
addValue 1 370 93
setIntUnchecked 2 371 93
incrementValue 0 367 93
assign 1 377 93
copy 0 377 93
assign 1 377 93
lowerValue 0 377 93
return 1 377 93
assign 1 381 93
new 0 381 93
assign 1 382 93
new 0 382 93
assign 1 382 93
lesser 1 382 93
getInt 2 383 93
assign 1 384 93
new 0 384 93
assign 1 384 93
greater 1 384 93
assign 1 384 93
new 0 384 93
assign 1 384 93
lesser 1 384 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 385 93
new 0 385 93
subtractValue 1 385 93
setIntUnchecked 2 386 93
incrementValue 0 382 93
assign 1 392 93
copy 0 392 93
assign 1 392 93
upperValue 0 392 93
return 1 392 93
assign 1 396 93
new 0 396 93
assign 1 396 93
split 1 396 93
assign 1 396 93
join 2 396 93
return 1 396 93
assign 1 401 93
new 0 401 93
assign 1 401 93
new 1 401 93
assign 1 402 93
mbiterGet 0 402 93
assign 1 403 93
new 0 403 93
assign 1 403 93
lesser 1 403 93
next 1 404 93
assign 1 403 93
increment 0 403 93
assign 1 406 93
next 1 406 93
assign 1 406 93
toString 0 406 93
return 1 407 93
assign 1 411 93
new 0 411 93
assign 1 412 93
new 0 412 93
setValue 1 412 93
assign 1 413 93
new 0 413 93
assign 1 413 93
lesser 1 413 93
getInt 2 414 93
assign 1 415 93
new 0 415 93
multiplyValue 1 415 93
addValue 1 416 93
incrementValue 0 413 93
assign 1 418 93
absValue 0 418 93
return 1 418 93
assign 1 422 93
new 0 422 93
assign 1 422 93
hashValue 1 422 93
return 1 422 93
assign 1 426 93
new 0 426 93
assign 1 426 93
getCode 2 426 93
return 1 426 93
assign 1 436 93
new 0 436 93
assign 1 436 93
greaterEquals 1 436 93
assign 1 436 93
greater 1 436 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
return 1 465 93
return 1 467 93
assign 1 478 93
new 0 478 93
assign 1 478 93
greaterEquals 1 478 93
assign 1 478 93
greater 1 478 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
return 1 508 93
return 1 510 93
assign 1 514 93
new 0 514 93
assign 1 514 93
greaterEquals 1 514 93
assign 1 514 93
greater 1 514 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
setIntUnchecked 2 515 93
assign 1 520 93
new 0 520 93
assign 1 520 93
greaterEquals 1 520 93
assign 1 520 93
greater 1 520 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
setCodeUnchecked 2 521 93
assign 1 526 93
new 0 526 93
assign 1 526 93
lesserEquals 1 526 93
assign 1 527 93
new 0 527 93
return 1 527 93
assign 1 529 93
new 0 529 93
return 1 529 93
assign 1 612 93
rfind 1 612 93
return 1 612 93
assign 1 618 93
copy 0 618 93
assign 1 618 93
reverseBytes 0 618 93
assign 1 618 93
copy 0 618 93
assign 1 618 93
reverseBytes 0 618 93
assign 1 618 93
find 1 618 93
assign 1 620 93
def 1 620 93
assign 1 621 93
sizeGet 0 621 93
addValue 1 621 93
assign 1 622 93
subtract 1 622 93
return 1 622 93
return 1 624 93
assign 1 628 93
new 0 628 93
assign 1 628 93
find 2 628 93
return 1 628 93
assign 1 634 93
undef 1 634 93
assign 1 0 93
assign 1 634 93
undef 1 634 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 634 93
new 0 634 93
assign 1 634 93
lesser 1 634 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 634 93
greaterEquals 1 634 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 634 93
sizeGet 0 634 93
assign 1 634 93
greater 1 634 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 634 93
new 0 634 93
assign 1 634 93
equals 1 634 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 634 93
sizeGet 0 634 93
assign 1 634 93
new 0 634 93
assign 1 634 93
equals 1 634 93
assign 1 0 93
assign 1 0 93
return 1 635 93
assign 1 638 93
assign 1 639 93
copy 0 639 93
assign 1 640 93
new 0 640 93
assign 1 641 93
new 0 641 93
assign 1 642 93
new 0 642 93
getInt 2 642 93
assign 1 644 93
sizeGet 0 644 93
assign 1 646 93
new 0 646 93
assign 1 646 93
greater 1 646 93
assign 1 647 93
new 0 647 93
assign 1 648 93
new 0 648 93
assign 1 649 93
new 0 649 93
assign 1 651 93
new 0 651 93
assign 1 652 93
lesser 1 652 93
getInt 2 653 93
assign 1 654 93
equals 1 654 93
assign 1 655 93
new 0 655 93
assign 1 655 93
equals 1 655 93
return 1 656 93
setValue 1 658 93
incrementValue 0 659 93
setValue 1 660 93
assign 1 661 93
sizeGet 0 661 93
addValue 1 661 93
assign 1 662 93
greater 1 662 93
return 1 663 93
assign 1 665 93
new 0 665 93
assign 1 665 93
once 0 665 93
setValue 1 665 93
assign 1 666 93
lesser 1 666 93
getInt 2 667 93
getInt 2 668 93
assign 1 669 93
notEquals 1 669 93
incrementValue 0 672 93
incrementValue 0 673 93
assign 1 675 93
equals 1 675 93
return 1 676 93
incrementValue 0 679 93
return 1 681 93
assign 1 685 93
new 0 685 93
assign 1 686 93
new 0 686 93
assign 1 687 93
find 2 687 93
assign 1 688 93
sizeGet 0 688 93
assign 1 689 93
def 1 689 93
assign 1 690 93
substring 2 690 93
addValue 1 690 93
assign 1 691 93
add 1 691 93
assign 1 692 93
find 2 692 93
assign 1 694 93
lesser 1 694 93
assign 1 695 93
substring 2 695 93
addValue 1 695 93
return 1 697 93
assign 1 701 93
new 0 701 93
assign 1 701 93
join 2 701 93
return 1 701 93
assign 1 705 93
new 0 705 93
assign 1 705 93
lineSplitterGet 0 705 93
assign 1 705 93
tokenize 1 705 93
return 1 705 93
return 1 709 93
assign 1 717 93
undef 1 717 93
assign 1 0 93
assign 1 717 93
otherType 1 717 93
assign 1 0 93
assign 1 0 93
return 1 718 93
assign 1 720 93
assign 1 721 93
sizeGet 0 721 93
assign 1 722 93
greater 1 722 93
assign 1 723 93
assign 1 725 93
assign 1 727 93
new 0 727 93
assign 1 728 93
new 0 728 93
assign 1 729 93
new 0 729 93
assign 1 730 93
new 0 730 93
assign 1 730 93
lesser 1 730 93
getCode 2 731 93
getCode 2 732 93
assign 1 733 93
notEquals 1 733 93
assign 1 734 93
greater 1 734 93
assign 1 735 93
new 0 735 93
return 1 735 93
assign 1 737 93
new 0 737 93
return 1 737 93
incrementValue 0 730 93
assign 1 741 93
new 0 741 93
assign 1 741 93
equals 1 741 93
assign 1 742 93
greater 1 742 93
assign 1 743 93
new 0 743 93
assign 1 744 93
greater 1 744 93
assign 1 745 93
new 0 745 93
return 1 748 93
assign 1 752 93
undef 1 752 93
return 1 752 93
assign 1 753 93
compare 1 753 93
assign 1 753 93
new 0 753 93
assign 1 753 93
equals 1 753 93
assign 1 754 93
new 0 754 93
return 1 754 93
assign 1 756 93
new 0 756 93
return 1 756 93
assign 1 760 93
undef 1 760 93
return 1 760 93
assign 1 761 93
compare 1 761 93
assign 1 761 93
new 0 761 93
assign 1 761 93
equals 1 761 93
assign 1 762 93
new 0 762 93
return 1 762 93
assign 1 764 93
new 0 764 93
return 1 764 93
assign 1 768 93
undef 1 768 93
assign 1 769 93
new 0 769 93
return 1 769 93
assign 1 813 93
new 0 813 93
return 1 813 93
assign 1 817 93
equals 1 817 93
assign 1 817 93
not 0 817 93
return 1 817 93
assign 1 821 93
toString 0 821 93
assign 1 822 93
sizeGet 0 822 93
assign 1 822 93
add 1 822 93
assign 1 822 93
new 1 822 93
assign 1 823 93
new 0 823 93
assign 1 823 93
new 0 823 93
copyValue 4 823 93
assign 1 824 93
new 0 824 93
assign 1 824 93
sizeGet 0 824 93
copyValue 4 824 93
return 1 825 93
assign 1 828 93
new 0 828 93
return 1 828 93
assign 1 853 93
new 0 853 93
assign 1 853 93
lesser 1 853 93
assign 1 0 93
assign 1 853 93
sizeGet 0 853 93
assign 1 853 93
greater 1 853 93
assign 1 0 93
assign 1 853 93
sizeGet 0 853 93
assign 1 853 93
greater 1 853 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 0 93
assign 1 854 93
new 0 854 93
assign 1 854 93
new 1 854 93
throw 1 854 93
assign 1 858 93
undef 1 858 93
assign 1 859 93
new 0 859 93
assign 1 860 93
new 0 860 93
setValue 1 862 93
subtractValue 1 863 93
assign 1 864 93
setValue 1 866 93
addValue 1 867 93
assign 1 869 93
greater 1 869 93
capacitySet 1 870 93
assign 1 925 93
greater 1 925 93
setValue 1 929 93
return 1 931 93
assign 1 936 93
sizeGet 0 936 93
assign 1 936 93
substring 2 936 93
return 1 936 93
assign 1 940 93
subtract 1 940 93
assign 1 940 93
new 1 940 93
assign 1 940 93
new 0 940 93
assign 1 940 93
copyValue 4 940 93
return 1 940 93
output 0 1025 93
assign 1 1029 93
new 1 1029 93
return 1 1029 93
assign 1 1033 93
new 1 1033 93
return 1 1033 93
assign 1 1037 93
new 1 1037 93
return 1 1037 93
assign 1 1041 93
new 1 1041 93
return 1 1041 93
assign 1 1045 93
new 1 1045 93
return 1 1045 93
assign 1 1049 93
new 1 1049 93
return 1 1049 93
return 1 1053 93
assign 1 1057 93
undef 1 1057 93
new 0 1058 93
assign 1 1060 93
sizeGet 0 1060 93
assign 1 1060 93
new 0 1060 93
assign 1 1060 93
add 1 1060 93
new 1 1060 93
addValue 1 1061 93
assign 1 1066 93
new 0 1066 93
return 1 1066 93
assign 1 1070 93
new 0 1070 93
assign 1 1070 93
strip 1 1070 93
return 1 1070 93
assign 1 1074 93
new 0 1074 93
assign 1 1075 93
new 0 1075 93
assign 1 1076 93
new 0 1076 93
assign 1 1077 93
new 0 1077 93
assign 1 1077 93
subtract 1 1077 93
assign 1 1078 93
greater 1 1078 93
getInt 2 1079 93
getInt 2 1080 93
setInt 2 1081 93
setInt 2 1082 93
incrementValue 0 1083 93
decrementValue 0 1084 93
assign 1 0 93
return 1 0 93
assign 1 0 93
return 1 0 93
return 1 0 93
assign 1 0 93
return 1 0 93
assign 1 0 93
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 416660294: return bem_objectIteratorGet_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 825000909: return bem_vstringSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bevs_inst = (BEC_2_4_6_TextString)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bevs_inst;
}
}
}
