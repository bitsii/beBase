namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_23 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_28 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_35 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_36 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bevo_39 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_4_6_TextString bevs_inst;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public virtual BEC_2_6_6_SystemObject bem_vstringGet_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_vstringSet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
this.bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 197 */
 else  /* Line: 196 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 198 */ {
return this;
} /* Line: 199 */
} /* Line: 196 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 230 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 231 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpvar_phold.bevi_int;
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
this.bem_setHex_2(bevt_4_tmpvar_phold, beva_val);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 253 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 255 */
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpvar_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevt_5_tmpvar_phold = bevo_4;
bevt_4_tmpvar_phold = bevp_sizi.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevo_5;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_multiply_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_6;
bevl_nsize = bevt_3_tmpvar_phold.bem_divide_1(bevt_7_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 262 */
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_open_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_close_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpvar_phold.bevi_int;
} /* Line: 298 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = bevo_11;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpvar_phold.bevi_int;
bevt_4_tmpvar_phold = bevo_12;
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
this.bem_setCodeUnchecked_2(bevt_3_tmpvar_phold, (BEC_2_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevt_3_tmpvar_phold = bevo_13;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 311 */
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_8_tmpvar_phold = bevo_14;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 315 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 328 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 328 */ {
bevt_3_tmpvar_phold = bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 328 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 328 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 328 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 328 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 329 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 335 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 335 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 338 */
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 344 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 345 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 352 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 352 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_17;
if (bevl_ic.bevi_int > bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 354 */ {
bevt_5_tmpvar_phold = bevo_18;
if (bevl_ic.bevi_int < bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 354 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 354 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 354 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 355 */
bevl_j.bevi_int++;
} /* Line: 352 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 363 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 363 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_19;
if (bevl_vc.bevi_int > bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 365 */ {
bevt_5_tmpvar_phold = bevo_20;
if (bevl_vc.bevi_int < bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 365 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 365 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 365 */
 else  /* Line: 365 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 365 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpvar_phold.bevi_int;
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 367 */
bevl_j.bevi_int++;
} /* Line: 363 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_lowerValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 378 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 378 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_21;
if (bevl_vc.bevi_int > bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevt_5_tmpvar_phold = bevo_22;
if (bevl_vc.bevi_int < bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 380 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 380 */
 else  /* Line: 380 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 380 */ {
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 382 */
bevl_j.bevi_int++;
} /* Line: 378 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_upperValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 399 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 399 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 399 */
 else  /* Line: 399 */ {
break;
} /* Line: 399 */
} /* Line: 399 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpvar_phold.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 409 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 409 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 409 */
 else  /* Line: 409 */ {
break;
} /* Line: 409 */
} /* Line: 409 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_23;
if (beva_pos.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 432 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 432 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 432 */
 else  /* Line: 432 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 432 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 452 */
 else  /* Line: 460 */ {
return null;
} /* Line: 461 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_24;
if (beva_pos.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 474 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 474 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 474 */
 else  /* Line: 474 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 474 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 498 */
 else  /* Line: 503 */ {
return null;
} /* Line: 504 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_25;
if (beva_pos.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 510 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 510 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 510 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 510 */
 else  /* Line: 510 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 510 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 511 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 516 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 516 */
 else  /* Line: 516 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 516 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 517 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_27;
if (bevp_size.bevi_int <= bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 522 */ {
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 523 */
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_reverseBytes_0();
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) bevt_3_tmpvar_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpvar_phold.bem_find_1(bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 616 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpvar_phold.bevi_int;
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 618 */
return null;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_28;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_9_tmpvar_phold = bevo_29;
if (beva_start.bevi_int < bevt_9_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpvar_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_14_tmpvar_phold = bevo_30;
if (bevp_size.bevi_int == bevt_14_tmpvar_phold.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_31;
if (bevt_16_tmpvar_phold.bevi_int == bevt_17_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 630 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 630 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 630 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 630 */ {
return null;
} /* Line: 631 */
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_32;
if (bevl_strsize.bevi_int > bevt_20_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 642 */ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 645 */
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 648 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 648 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 650 */ {
bevt_24_tmpvar_phold = bevo_33;
if (bevl_strsize.bevi_int == bevt_24_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 651 */ {
return bevl_current;
} /* Line: 652 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpvar_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 658 */ {
return null;
} /* Line: 659 */
bevt_28_tmpvar_phold = bevo_34;
bevt_27_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_28_tmpvar_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpvar_phold.bevi_int;
while (true)
 /* Line: 662 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 662 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 665 */ {
break;
} /* Line: 666 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 669 */
 else  /* Line: 662 */ {
break;
} /* Line: 662 */
} /* Line: 662 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 671 */ {
return bevl_current;
} /* Line: 672 */
} /* Line: 671 */
bevl_current.bevi_int++;
} /* Line: 675 */
 else  /* Line: 648 */ {
break;
} /* Line: 648 */
} /* Line: 648 */
return null;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 685 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 685 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 688 */
 else  /* Line: 685 */ {
break;
} /* Line: 685 */
} /* Line: 685 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 690 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 691 */
return bevl_splits;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 713 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 713 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 713 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 713 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 713 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 713 */ {
return null;
} /* Line: 714 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 718 */ {
bevl_maxsize = bevl_osize;
} /* Line: 719 */
 else  /* Line: 720 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 721 */
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 726 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 726 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 729 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 730 */ {
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 731 */
 else  /* Line: 732 */ {
bevt_8_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 733 */
} /* Line: 730 */
bevl_i.bevi_int++;
} /* Line: 726 */
 else  /* Line: 726 */ {
break;
} /* Line: 726 */
} /* Line: 726 */
bevt_10_tmpvar_phold = bevo_35;
if (bevl_myret.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 737 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 738 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 739 */
 else  /* Line: 738 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 740 */ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 741 */
} /* Line: 738 */
} /* Line: 738 */
return bevl_myret;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 748 */ {
return null;
} /* Line: 748 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_36;
if (bevt_2_tmpvar_phold.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 749 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 750 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 756 */ {
return null;
} /* Line: 756 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_37;
if (bevt_2_tmpvar_phold.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 757 */ {
bevt_4_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 758 */
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
  //if (bevls_stri != null) {
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  //}
  bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpvar_phold, bevp_size, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_38;
if (beva_starti.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 849 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 849 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 849 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 849 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 849 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 849 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bels_1));
bevt_7_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 850 */
 else  /* Line: 851 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 854 */ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 856 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 865 */ {
this.bem_capacitySet_1(bevp_sizi);
} /* Line: 866 */

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 921 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 925 */
return this;
} /* Line: 927 */
} /*method end*/
public virtual BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
this.bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1053 */ {
this.bem_new_0();
} /* Line: 1054 */
 else  /* Line: 1055 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_39;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1057 */
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_40;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1074 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1074 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1080 */
 else  /* Line: 1074 */ {
break;
} /* Line: 1074 */
} /* Line: 1074 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {178, 179, 192, 192, 192, 196, 196, 197, 198, 198, 199, 230, 230, 231, 233, 237, 237, 237, 238, 238, 238, 239, 239, 239, 243, 243, 243, 243, 243, 243, 243, 247, 248, 252, 253, 253, 254, 255, 257, 257, 258, 260, 260, 261, 261, 261, 261, 261, 261, 262, 264, 264, 264, 268, 272, 276, 280, 290, 291, 292, 296, 296, 296, 297, 297, 297, 297, 297, 298, 298, 298, 303, 303, 304, 304, 304, 305, 305, 305, 309, 309, 310, 311, 311, 311, 311, 311, 313, 314, 315, 315, 315, 315, 315, 317, 321, 321, 321, 322, 323, 327, 328, 328, 0, 328, 328, 328, 0, 0, 329, 329, 331, 331, 335, 335, 335, 335, 336, 336, 336, 337, 337, 338, 338, 340, 340, 344, 344, 0, 344, 344, 344, 0, 0, 345, 345, 347, 347, 351, 352, 352, 352, 353, 354, 354, 354, 0, 354, 354, 354, 0, 0, 355, 355, 352, 358, 358, 362, 363, 363, 363, 364, 365, 365, 365, 365, 365, 365, 0, 0, 0, 366, 366, 367, 363, 373, 373, 373, 377, 378, 378, 378, 379, 380, 380, 380, 380, 380, 380, 0, 0, 0, 381, 381, 382, 378, 388, 388, 388, 392, 392, 392, 392, 397, 397, 398, 399, 399, 399, 400, 399, 402, 402, 403, 407, 408, 408, 409, 409, 409, 410, 411, 411, 412, 409, 414, 414, 418, 418, 418, 422, 422, 422, 432, 432, 432, 432, 432, 0, 0, 0, 461, 463, 474, 474, 474, 474, 474, 0, 0, 0, 504, 506, 510, 510, 510, 510, 510, 0, 0, 0, 511, 516, 516, 516, 516, 516, 0, 0, 0, 517, 522, 522, 522, 523, 523, 525, 525, 608, 608, 614, 614, 614, 614, 614, 616, 616, 617, 617, 618, 618, 620, 624, 624, 624, 630, 630, 0, 630, 630, 0, 0, 0, 630, 630, 630, 0, 0, 0, 630, 630, 0, 0, 0, 630, 630, 630, 0, 0, 0, 630, 630, 630, 0, 0, 0, 630, 630, 630, 630, 0, 0, 631, 634, 635, 636, 637, 638, 638, 640, 642, 642, 642, 643, 644, 645, 647, 648, 648, 649, 650, 650, 651, 651, 651, 652, 654, 655, 656, 657, 657, 658, 658, 659, 661, 661, 661, 662, 662, 663, 664, 665, 665, 668, 669, 671, 671, 672, 675, 677, 681, 682, 683, 684, 685, 685, 686, 686, 687, 688, 690, 690, 691, 691, 693, 697, 697, 697, 701, 701, 701, 701, 705, 713, 713, 0, 713, 0, 0, 714, 716, 717, 718, 718, 719, 721, 723, 724, 725, 726, 726, 726, 727, 728, 729, 729, 730, 730, 731, 731, 733, 733, 726, 737, 737, 737, 738, 738, 739, 740, 740, 741, 744, 748, 748, 748, 749, 749, 749, 749, 750, 750, 752, 752, 756, 756, 756, 757, 757, 757, 757, 758, 758, 760, 760, 809, 809, 813, 813, 813, 817, 818, 818, 818, 819, 819, 819, 820, 820, 820, 821, 824, 824, 849, 849, 849, 0, 849, 849, 849, 0, 849, 849, 849, 0, 0, 0, 0, 850, 850, 850, 854, 854, 855, 856, 858, 859, 860, 862, 863, 865, 865, 866, 921, 921, 925, 927, 932, 932, 932, 936, 936, 936, 936, 936, 1021, 1025, 1025, 1029, 1029, 1033, 1033, 1037, 1037, 1041, 1041, 1045, 1045, 1049, 1053, 1053, 1054, 1056, 1056, 1056, 1056, 1057, 1062, 1062, 1066, 1066, 1066, 1070, 1071, 1072, 1073, 1073, 1074, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {98, 99, 105, 106, 107, 114, 119, 120, 123, 128, 129, 140, 145, 146, 148, 158, 159, 160, 161, 162, 163, 164, 165, 166, 176, 177, 178, 179, 180, 181, 182, 186, 187, 203, 204, 209, 210, 211, 213, 214, 215, 216, 221, 222, 223, 224, 225, 226, 227, 228, 230, 231, 232, 236, 239, 242, 246, 257, 258, 259, 270, 271, 276, 277, 278, 279, 280, 281, 282, 283, 284, 294, 295, 296, 297, 298, 299, 300, 301, 317, 318, 319, 321, 322, 323, 324, 325, 327, 328, 330, 331, 332, 333, 334, 336, 342, 343, 344, 345, 346, 356, 357, 362, 363, 366, 367, 372, 373, 376, 380, 381, 383, 384, 395, 400, 401, 402, 404, 405, 406, 407, 412, 413, 414, 416, 417, 426, 431, 432, 435, 436, 441, 442, 445, 449, 450, 452, 453, 466, 467, 470, 475, 476, 477, 478, 483, 484, 487, 488, 493, 494, 497, 501, 502, 504, 510, 511, 523, 524, 527, 532, 533, 534, 535, 540, 541, 542, 547, 548, 551, 555, 558, 559, 560, 562, 573, 574, 575, 587, 588, 591, 596, 597, 598, 599, 604, 605, 606, 611, 612, 615, 619, 622, 623, 624, 626, 637, 638, 639, 645, 646, 647, 648, 658, 659, 660, 661, 664, 669, 670, 671, 677, 678, 679, 688, 689, 690, 691, 694, 699, 700, 701, 702, 703, 704, 710, 711, 716, 717, 718, 723, 724, 725, 732, 733, 738, 739, 744, 745, 748, 752, 762, 764, 771, 772, 777, 778, 783, 784, 787, 791, 798, 800, 807, 808, 813, 814, 819, 820, 823, 827, 830, 839, 840, 845, 846, 851, 852, 855, 859, 862, 871, 872, 877, 878, 879, 881, 882, 900, 901, 912, 913, 914, 915, 916, 917, 922, 923, 924, 925, 926, 928, 933, 934, 935, 979, 984, 985, 988, 993, 994, 997, 1001, 1004, 1005, 1010, 1011, 1014, 1018, 1021, 1026, 1027, 1030, 1034, 1037, 1038, 1043, 1044, 1047, 1051, 1054, 1055, 1060, 1061, 1064, 1068, 1071, 1072, 1073, 1078, 1079, 1082, 1086, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1101, 1102, 1103, 1104, 1106, 1109, 1114, 1115, 1116, 1121, 1122, 1123, 1128, 1129, 1131, 1132, 1133, 1134, 1135, 1136, 1141, 1142, 1144, 1145, 1146, 1149, 1154, 1155, 1156, 1157, 1162, 1165, 1166, 1172, 1177, 1178, 1181, 1187, 1198, 1199, 1200, 1201, 1204, 1209, 1210, 1211, 1212, 1213, 1219, 1224, 1225, 1226, 1228, 1233, 1234, 1235, 1241, 1242, 1243, 1244, 1247, 1270, 1275, 1276, 1279, 1281, 1284, 1288, 1290, 1291, 1292, 1297, 1298, 1301, 1303, 1304, 1305, 1306, 1309, 1314, 1315, 1316, 1317, 1322, 1323, 1328, 1329, 1330, 1333, 1334, 1337, 1343, 1344, 1349, 1350, 1355, 1356, 1359, 1364, 1365, 1369, 1378, 1383, 1384, 1386, 1387, 1388, 1393, 1394, 1395, 1397, 1398, 1407, 1412, 1413, 1415, 1416, 1417, 1422, 1423, 1424, 1426, 1427, 1443, 1444, 1449, 1450, 1455, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1480, 1481, 1498, 1499, 1504, 1505, 1508, 1509, 1514, 1515, 1518, 1519, 1524, 1525, 1528, 1532, 1535, 1539, 1540, 1541, 1544, 1549, 1550, 1551, 1553, 1554, 1555, 1556, 1557, 1558, 1563, 1564, 1569, 1574, 1575, 1577, 1583, 1584, 1585, 1592, 1593, 1594, 1595, 1596, 1612, 1617, 1618, 1622, 1623, 1627, 1628, 1632, 1633, 1637, 1638, 1642, 1643, 1646, 1653, 1658, 1659, 1662, 1663, 1664, 1665, 1666, 1672, 1673, 1678, 1679, 1680, 1689, 1690, 1691, 1692, 1693, 1696, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1716, 1719, 1723, 1726, 1729, 1733, 1736};
/* BEGIN LINEINFO 
assign 1 178 98
new 0 178 98
capacitySet 1 179 99
assign 1 192 105
new 0 192 105
assign 1 192 106
once 0 192 106
new 1 192 107
assign 1 196 114
undef 1 196 119
assign 1 197 120
new 0 197 120
assign 1 198 123
equals 1 198 128
return 1 199 129
assign 1 230 140
greater 1 230 145
setValue 1 231 146
setValue 1 233 148
assign 1 237 158
new 0 237 158
assign 1 237 159
once 0 237 159
new 1 237 160
assign 1 238 161
new 0 238 161
assign 1 238 162
once 0 238 162
setValue 1 238 163
assign 1 239 164
new 0 239 164
assign 1 239 165
once 0 239 165
setHex 2 239 166
assign 1 243 176
new 0 243 176
assign 1 243 177
getCode 2 243 177
assign 1 243 178
new 0 243 178
assign 1 243 179
new 0 243 179
assign 1 243 180
new 0 243 180
assign 1 243 181
toString 3 243 181
return 1 243 182
assign 1 247 186
hexNew 1 247 186
setCode 2 248 187
assign 1 252 203
toString 0 252 203
assign 1 253 204
undef 1 253 209
assign 1 254 210
new 0 254 210
assign 1 255 211
new 0 255 211
assign 1 257 213
sizeGet 0 257 213
setValue 1 257 214
addValue 1 258 215
assign 1 260 216
lesser 1 260 221
assign 1 261 222
new 0 261 222
assign 1 261 223
add 1 261 223
assign 1 261 224
new 0 261 224
assign 1 261 225
multiply 1 261 225
assign 1 261 226
new 0 261 226
assign 1 261 227
divide 1 261 227
capacitySet 1 262 228
assign 1 264 230
new 0 264 230
assign 1 264 231
sizeGet 0 264 231
copyValue 4 264 232
return 1 268 236
return 1 272 239
addValue 1 276 242
write 1 280 246
assign 1 290 257
copy 0 290 257
clear 0 291 258
return 1 292 259
assign 1 296 270
new 0 296 270
assign 1 296 271
greater 1 296 276
assign 1 297 277
new 0 297 277
assign 1 297 278
once 0 297 278
assign 1 297 279
new 0 297 279
assign 1 297 280
once 0 297 280
setIntUnchecked 2 297 281
assign 1 298 282
new 0 298 282
assign 1 298 283
once 0 298 283
setValue 1 298 284
assign 1 303 294
new 0 303 294
new 1 303 295
assign 1 304 296
new 0 304 296
assign 1 304 297
once 0 304 297
setValue 1 304 298
assign 1 305 299
new 0 305 299
assign 1 305 300
once 0 305 300
setCodeUnchecked 2 305 301
assign 1 309 317
new 0 309 317
assign 1 309 318
newlineGet 0 309 318
assign 1 310 319
ends 1 310 319
assign 1 311 321
new 0 311 321
assign 1 311 322
sizeGet 0 311 322
assign 1 311 323
subtract 1 311 323
assign 1 311 324
substring 2 311 324
return 1 311 325
assign 1 313 327
new 0 313 327
assign 1 314 328
ends 1 314 328
assign 1 315 330
new 0 315 330
assign 1 315 331
sizeGet 0 315 331
assign 1 315 332
subtract 1 315 332
assign 1 315 333
substring 2 315 333
return 1 315 334
return 1 317 336
assign 1 321 342
new 0 321 342
assign 1 321 343
add 1 321 343
assign 1 321 344
new 1 321 344
addValue 1 322 345
return 1 323 346
assign 1 327 356
find 1 327 356
assign 1 328 357
undef 1 328 362
assign 1 0 363
assign 1 328 366
new 0 328 366
assign 1 328 367
notEquals 1 328 372
assign 1 0 373
assign 1 0 376
assign 1 329 380
new 0 329 380
return 1 329 381
assign 1 331 383
new 0 331 383
return 1 331 384
assign 1 335 395
undef 1 335 400
assign 1 335 401
new 0 335 401
return 1 335 402
assign 1 336 404
sizeGet 0 336 404
assign 1 336 405
subtract 1 336 405
assign 1 336 406
find 2 336 406
assign 1 337 407
undef 1 337 412
assign 1 338 413
new 0 338 413
return 1 338 414
assign 1 340 416
new 0 340 416
return 1 340 417
assign 1 344 426
undef 1 344 431
assign 1 0 432
assign 1 344 435
find 1 344 435
assign 1 344 436
undef 1 344 441
assign 1 0 442
assign 1 0 445
assign 1 345 449
new 0 345 449
return 1 345 450
assign 1 347 452
new 0 347 452
return 1 347 453
assign 1 351 466
new 0 351 466
assign 1 352 467
new 0 352 467
assign 1 352 470
lesser 1 352 475
getInt 2 353 476
assign 1 354 477
new 0 354 477
assign 1 354 478
greater 1 354 483
assign 1 0 484
assign 1 354 487
new 0 354 487
assign 1 354 488
lesser 1 354 493
assign 1 0 494
assign 1 0 497
assign 1 355 501
new 0 355 501
return 1 355 502
incrementValue 0 352 504
assign 1 358 510
new 0 358 510
return 1 358 511
assign 1 362 523
new 0 362 523
assign 1 363 524
new 0 363 524
assign 1 363 527
lesser 1 363 532
getInt 2 364 533
assign 1 365 534
new 0 365 534
assign 1 365 535
greater 1 365 540
assign 1 365 541
new 0 365 541
assign 1 365 542
lesser 1 365 547
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 366 558
new 0 366 558
addValue 1 366 559
setIntUnchecked 2 367 560
incrementValue 0 363 562
assign 1 373 573
copy 0 373 573
assign 1 373 574
lowerValue 0 373 574
return 1 373 575
assign 1 377 587
new 0 377 587
assign 1 378 588
new 0 378 588
assign 1 378 591
lesser 1 378 596
getInt 2 379 597
assign 1 380 598
new 0 380 598
assign 1 380 599
greater 1 380 604
assign 1 380 605
new 0 380 605
assign 1 380 606
lesser 1 380 611
assign 1 0 612
assign 1 0 615
assign 1 0 619
assign 1 381 622
new 0 381 622
subtractValue 1 381 623
setIntUnchecked 2 382 624
incrementValue 0 378 626
assign 1 388 637
copy 0 388 637
assign 1 388 638
upperValue 0 388 638
return 1 388 639
assign 1 392 645
new 0 392 645
assign 1 392 646
split 1 392 646
assign 1 392 647
join 2 392 647
return 1 392 648
assign 1 397 658
new 0 397 658
assign 1 397 659
new 1 397 659
assign 1 398 660
mbiterGet 0 398 660
assign 1 399 661
new 0 399 661
assign 1 399 664
lesser 1 399 669
next 1 400 670
assign 1 399 671
increment 0 399 671
assign 1 402 677
next 1 402 677
assign 1 402 678
toString 0 402 678
return 1 403 679
assign 1 407 688
new 0 407 688
assign 1 408 689
new 0 408 689
setValue 1 408 690
assign 1 409 691
new 0 409 691
assign 1 409 694
lesser 1 409 699
getInt 2 410 700
assign 1 411 701
new 0 411 701
multiplyValue 1 411 702
addValue 1 412 703
incrementValue 0 409 704
assign 1 414 710
absValue 0 414 710
return 1 414 711
assign 1 418 716
new 0 418 716
assign 1 418 717
hashValue 1 418 717
return 1 418 718
assign 1 422 723
new 0 422 723
assign 1 422 724
getCode 2 422 724
return 1 422 725
assign 1 432 732
new 0 432 732
assign 1 432 733
greaterEquals 1 432 738
assign 1 432 739
greater 1 432 744
assign 1 0 745
assign 1 0 748
assign 1 0 752
return 1 461 762
return 1 463 764
assign 1 474 771
new 0 474 771
assign 1 474 772
greaterEquals 1 474 777
assign 1 474 778
greater 1 474 783
assign 1 0 784
assign 1 0 787
assign 1 0 791
return 1 504 798
return 1 506 800
assign 1 510 807
new 0 510 807
assign 1 510 808
greaterEquals 1 510 813
assign 1 510 814
greater 1 510 819
assign 1 0 820
assign 1 0 823
assign 1 0 827
setIntUnchecked 2 511 830
assign 1 516 839
new 0 516 839
assign 1 516 840
greaterEquals 1 516 845
assign 1 516 846
greater 1 516 851
assign 1 0 852
assign 1 0 855
assign 1 0 859
setCodeUnchecked 2 517 862
assign 1 522 871
new 0 522 871
assign 1 522 872
lesserEquals 1 522 877
assign 1 523 878
new 0 523 878
return 1 523 879
assign 1 525 881
new 0 525 881
return 1 525 882
assign 1 608 900
rfind 1 608 900
return 1 608 901
assign 1 614 912
copy 0 614 912
assign 1 614 913
reverseBytes 0 614 913
assign 1 614 914
copy 0 614 914
assign 1 614 915
reverseBytes 0 614 915
assign 1 614 916
find 1 614 916
assign 1 616 917
def 1 616 922
assign 1 617 923
sizeGet 0 617 923
addValue 1 617 924
assign 1 618 925
subtract 1 618 925
return 1 618 926
return 1 620 928
assign 1 624 933
new 0 624 933
assign 1 624 934
find 2 624 934
return 1 624 935
assign 1 630 979
undef 1 630 984
assign 1 0 985
assign 1 630 988
undef 1 630 993
assign 1 0 994
assign 1 0 997
assign 1 0 1001
assign 1 630 1004
new 0 630 1004
assign 1 630 1005
lesser 1 630 1010
assign 1 0 1011
assign 1 0 1014
assign 1 0 1018
assign 1 630 1021
greaterEquals 1 630 1026
assign 1 0 1027
assign 1 0 1030
assign 1 0 1034
assign 1 630 1037
sizeGet 0 630 1037
assign 1 630 1038
greater 1 630 1043
assign 1 0 1044
assign 1 0 1047
assign 1 0 1051
assign 1 630 1054
new 0 630 1054
assign 1 630 1055
equals 1 630 1060
assign 1 0 1061
assign 1 0 1064
assign 1 0 1068
assign 1 630 1071
sizeGet 0 630 1071
assign 1 630 1072
new 0 630 1072
assign 1 630 1073
equals 1 630 1078
assign 1 0 1079
assign 1 0 1082
return 1 631 1086
assign 1 634 1088
assign 1 635 1089
copy 0 635 1089
assign 1 636 1090
new 0 636 1090
assign 1 637 1091
new 0 637 1091
assign 1 638 1092
new 0 638 1092
getInt 2 638 1093
assign 1 640 1094
sizeGet 0 640 1094
assign 1 642 1095
new 0 642 1095
assign 1 642 1096
greater 1 642 1101
assign 1 643 1102
new 0 643 1102
assign 1 644 1103
new 0 644 1103
assign 1 645 1104
new 0 645 1104
assign 1 647 1106
new 0 647 1106
assign 1 648 1109
lesser 1 648 1114
getInt 2 649 1115
assign 1 650 1116
equals 1 650 1121
assign 1 651 1122
new 0 651 1122
assign 1 651 1123
equals 1 651 1128
return 1 652 1129
setValue 1 654 1131
incrementValue 0 655 1132
setValue 1 656 1133
assign 1 657 1134
sizeGet 0 657 1134
addValue 1 657 1135
assign 1 658 1136
greater 1 658 1141
return 1 659 1142
assign 1 661 1144
new 0 661 1144
assign 1 661 1145
once 0 661 1145
setValue 1 661 1146
assign 1 662 1149
lesser 1 662 1154
getInt 2 663 1155
getInt 2 664 1156
assign 1 665 1157
notEquals 1 665 1162
incrementValue 0 668 1165
incrementValue 0 669 1166
assign 1 671 1172
equals 1 671 1177
return 1 672 1178
incrementValue 0 675 1181
return 1 677 1187
assign 1 681 1198
new 0 681 1198
assign 1 682 1199
new 0 682 1199
assign 1 683 1200
find 2 683 1200
assign 1 684 1201
sizeGet 0 684 1201
assign 1 685 1204
def 1 685 1209
assign 1 686 1210
substring 2 686 1210
addValue 1 686 1211
assign 1 687 1212
add 1 687 1212
assign 1 688 1213
find 2 688 1213
assign 1 690 1219
lesser 1 690 1224
assign 1 691 1225
substring 2 691 1225
addValue 1 691 1226
return 1 693 1228
assign 1 697 1233
new 0 697 1233
assign 1 697 1234
join 2 697 1234
return 1 697 1235
assign 1 701 1241
new 0 701 1241
assign 1 701 1242
lineSplitterGet 0 701 1242
assign 1 701 1243
tokenize 1 701 1243
return 1 701 1244
return 1 705 1247
assign 1 713 1270
undef 1 713 1275
assign 1 0 1276
assign 1 713 1279
otherType 1 713 1279
assign 1 0 1281
assign 1 0 1284
return 1 714 1288
assign 1 716 1290
assign 1 717 1291
sizeGet 0 717 1291
assign 1 718 1292
greater 1 718 1297
assign 1 719 1298
assign 1 721 1301
assign 1 723 1303
new 0 723 1303
assign 1 724 1304
new 0 724 1304
assign 1 725 1305
new 0 725 1305
assign 1 726 1306
new 0 726 1306
assign 1 726 1309
lesser 1 726 1314
getCode 2 727 1315
getCode 2 728 1316
assign 1 729 1317
notEquals 1 729 1322
assign 1 730 1323
greater 1 730 1328
assign 1 731 1329
new 0 731 1329
return 1 731 1330
assign 1 733 1333
new 0 733 1333
return 1 733 1334
incrementValue 0 726 1337
assign 1 737 1343
new 0 737 1343
assign 1 737 1344
equals 1 737 1349
assign 1 738 1350
greater 1 738 1355
assign 1 739 1356
new 0 739 1356
assign 1 740 1359
greater 1 740 1364
assign 1 741 1365
new 0 741 1365
return 1 744 1369
assign 1 748 1378
undef 1 748 1383
return 1 748 1384
assign 1 749 1386
compare 1 749 1386
assign 1 749 1387
new 0 749 1387
assign 1 749 1388
equals 1 749 1393
assign 1 750 1394
new 0 750 1394
return 1 750 1395
assign 1 752 1397
new 0 752 1397
return 1 752 1398
assign 1 756 1407
undef 1 756 1412
return 1 756 1413
assign 1 757 1415
compare 1 757 1415
assign 1 757 1416
new 0 757 1416
assign 1 757 1417
equals 1 757 1422
assign 1 758 1423
new 0 758 1423
return 1 758 1424
assign 1 760 1426
new 0 760 1426
return 1 760 1427
assign 1 809 1443
new 0 809 1443
return 1 809 1444
assign 1 813 1449
equals 1 813 1449
assign 1 813 1450
not 0 813 1455
return 1 813 1455
assign 1 817 1466
toString 0 817 1466
assign 1 818 1467
sizeGet 0 818 1467
assign 1 818 1468
add 1 818 1468
assign 1 818 1469
new 1 818 1469
assign 1 819 1470
new 0 819 1470
assign 1 819 1471
new 0 819 1471
copyValue 4 819 1472
assign 1 820 1473
new 0 820 1473
assign 1 820 1474
sizeGet 0 820 1474
copyValue 4 820 1475
return 1 821 1476
assign 1 824 1480
new 0 824 1480
return 1 824 1481
assign 1 849 1498
new 0 849 1498
assign 1 849 1499
lesser 1 849 1504
assign 1 0 1505
assign 1 849 1508
sizeGet 0 849 1508
assign 1 849 1509
greater 1 849 1514
assign 1 0 1515
assign 1 849 1518
sizeGet 0 849 1518
assign 1 849 1519
greater 1 849 1524
assign 1 0 1525
assign 1 0 1528
assign 1 0 1532
assign 1 0 1535
assign 1 850 1539
new 0 850 1539
assign 1 850 1540
new 1 850 1540
throw 1 850 1541
assign 1 854 1544
undef 1 854 1549
assign 1 855 1550
new 0 855 1550
assign 1 856 1551
new 0 856 1551
setValue 1 858 1553
subtractValue 1 859 1554
assign 1 860 1555
setValue 1 862 1556
addValue 1 863 1557
assign 1 865 1558
greater 1 865 1563
capacitySet 1 866 1564
assign 1 921 1569
greater 1 921 1574
setValue 1 925 1575
return 1 927 1577
assign 1 932 1583
sizeGet 0 932 1583
assign 1 932 1584
substring 2 932 1584
return 1 932 1585
assign 1 936 1592
subtract 1 936 1592
assign 1 936 1593
new 1 936 1593
assign 1 936 1594
new 0 936 1594
assign 1 936 1595
copyValue 4 936 1595
return 1 936 1596
output 0 1021 1612
assign 1 1025 1617
new 1 1025 1617
return 1 1025 1618
assign 1 1029 1622
new 1 1029 1622
return 1 1029 1623
assign 1 1033 1627
new 1 1033 1627
return 1 1033 1628
assign 1 1037 1632
new 1 1037 1632
return 1 1037 1633
assign 1 1041 1637
new 1 1041 1637
return 1 1041 1638
assign 1 1045 1642
new 1 1045 1642
return 1 1045 1643
return 1 1049 1646
assign 1 1053 1653
undef 1 1053 1658
new 0 1054 1659
assign 1 1056 1662
sizeGet 0 1056 1662
assign 1 1056 1663
new 0 1056 1663
assign 1 1056 1664
add 1 1056 1664
new 1 1056 1665
addValue 1 1057 1666
assign 1 1062 1672
new 0 1062 1672
return 1 1062 1673
assign 1 1066 1678
new 0 1066 1678
assign 1 1066 1679
strip 1 1066 1679
return 1 1066 1680
assign 1 1070 1689
new 0 1070 1689
assign 1 1071 1690
new 0 1071 1690
assign 1 1072 1691
new 0 1072 1691
assign 1 1073 1692
new 0 1073 1692
assign 1 1073 1693
subtract 1 1073 1693
assign 1 1074 1696
greater 1 1074 1701
getInt 2 1075 1702
getInt 2 1076 1703
setInt 2 1077 1704
setInt 2 1078 1705
incrementValue 0 1079 1706
decrementValue 0 1080 1707
return 1 0 1716
assign 1 0 1719
return 1 0 1723
return 1 0 1726
assign 1 0 1729
return 1 0 1733
assign 1 0 1736
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 416660294: return bem_objectIteratorGet_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bevs_inst = (BEC_2_4_6_TextString)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bevs_inst;
}
}
}
