namespace be.BEL_4_Base {
/* File: source/build/JSEmitter.be */
public class BEC_5_9_BuildJSEmitter : BEC_5_10_BuildEmitCommon {
public BEC_5_9_BuildJSEmitter() { }
static BEC_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 41));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_45 = {};
private static byte[] bels_46 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_47 = {0x28,0x29,0x3B};
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_50 = {0x22,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_53 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_54 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_54, 60));
private static byte[] bels_55 = {0x76,0x61,0x72,0x20};
private static byte[] bels_56 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_57 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_57, 25));
private static byte[] bels_58 = {0x20,0x7B};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_58, 2));
private static byte[] bels_59 = {0x74,0x68,0x69,0x73};
private static byte[] bels_60 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_60, 17));
private static byte[] bels_61 = {0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_61, 3));
private static byte[] bels_62 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_62, 38));
private static byte[] bels_63 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_63, 4));
private static byte[] bels_64 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_64, 21));
private static byte[] bels_65 = {0x29};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_65, 1));
private static byte[] bels_66 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_66, 4));
private static byte[] bels_67 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_67, 23));
private static byte[] bels_68 = {0x29};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_68, 1));
private static byte[] bels_69 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_69, 4));
private static byte[] bels_70 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 27));
private static byte[] bels_71 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 22));
private static byte[] bels_72 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_72, 2));
private static byte[] bels_73 = {0x29};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_73, 1));
private static byte[] bels_74 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_74, 4));
private static byte[] bels_75 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_75, 32));
private static byte[] bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_76, 22));
private static byte[] bels_77 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_77, 2));
private static byte[] bels_78 = {0x29};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_80 = {0x76,0x61,0x72,0x20};
private static byte[] bels_81 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_82 = {0x7D};
private static byte[] bels_83 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_83, 5));
private static byte[] bels_84 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_84, 4));
private static byte[] bels_85 = {};
private static byte[] bels_86 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_86, 11));
private static byte[] bels_87 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_87, 5));
private static byte[] bels_88 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_89, 11));
private static byte[] bels_90 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_35 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x3B};
private static BEC_4_6_TextString bevo_36 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_91, 1));
private static byte[] bels_92 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_93 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_94 = {};
private static byte[] bels_95 = {};
private static byte[] bels_96 = {};
private static byte[] bels_97 = {};
private static byte[] bels_98 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_99 = {};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_103, 7));
private static byte[] bels_104 = {0x3A,0x20};
private static BEC_4_6_TextString bevo_38 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_104, 2));
private static byte[] bels_105 = {};
private static byte[] bels_106 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_107 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_107, 22));
private static byte[] bels_108 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_108, 5));
private static byte[] bels_109 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_110 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_111 = {0x29,0x20,0x7B};
private static byte[] bels_112 = {};
private static byte[] bels_113 = {0x5F};
private static BEC_4_6_TextString bevo_41 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_113, 1));
private static byte[] bels_114 = {0x62,0x65,0x5F};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_114, 3));
public static new BEC_5_9_BuildJSEmitter bevs_inst;
public BEC_4_6_TextString bevp_allOnceDecs;
public BEC_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_6_6_SystemObject bem_new_1(BEC_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_0));
bevp_fileExt = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_1));
bevp_exceptDec = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(44, bels_3));
bevp_falseValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(45, bels_4));
bevp_instanceEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_acceptThrow_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(38, bels_7));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_8));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_acceptCatch_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_catchVar = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpvar_phold.bem_add_1(bevt_1_tmpvar_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_10));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_11));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_8_tmpvar_phold, bevt_12_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_4_6_TextString beva_belsBase) {
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringStart_2(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_belsName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_14));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_15));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildCreate_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(37, bels_16));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_17));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_relEmitName_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_18));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_19));
bevt_14_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_14_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildPropList_0() {
BEC_5_8_BuildClassSyn bevl_syn = null;
BEC_9_5_ContainerArray bevl_ptyList = null;
BEC_5_4_LogicBool bevl_first = null;
BEC_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_5_8_BuildClassSyn) bevt_1_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_20));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevl_first = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 77 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevl_ptySyn = (BEC_5_6_BuildPtySyn) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 78 */ {
bevl_first = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
 else  /* Line: 80 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 81 */
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_22));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
} /* Line: 83 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_23));
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_12_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_buildInitial_0() {
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_0_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(50, bels_24));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_25));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_26));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(41, bels_27));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_28));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_29));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_30));
bevt_20_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringByte_5(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_lival, BEC_4_3_MathInt beva_lipos, BEC_4_3_MathInt beva_bcode, BEC_4_6_TextString beva_hs) {
BEC_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_lstringEnd_1(BEC_4_6_TextString beva_sdec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_31));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_nameForVar_1(BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_2_tmpvar_phold = bevo_3;
bevt_3_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /* Line: 128 */
bevt_4_tmpvar_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_emitLib_0() {
BEC_2_4_6_IOFileWriter bevl_libe = null;
BEC_4_6_TextString bevl_typeInstances = null;
BEC_4_6_TextString bevl_libInit = null;
BEC_4_6_TextString bevl_notNullInitConstruct = null;
BEC_4_6_TextString bevl_notNullInitDefault = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_4_6_TextString bevl_nc = null;
BEC_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_5_11_BuildClassConfig bevl_maincc = null;
BEC_4_6_TextString bevl_main = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_libInit = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 142 */ {
bevt_0_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(50, bels_33));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_11_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_34));
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_relEmitName_1(bevt_17_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_35));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_1_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 148 */ {
bevt_23_tmpvar_phold = bevo_4;
bevt_27_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_25_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_26_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_relEmitName_1(bevt_28_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_5;
bevl_nc = bevt_22_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(75, bels_38));
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_39));
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 157 */ {
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(73, bels_40));
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevt_40_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_41));
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_38_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 158 */
} /* Line: 157 */
} /* Line: 148 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_45_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_sizeGet_0();
bevt_46_tmpvar_phold = bevo_6;
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_46_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(110, bels_42));
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_48_tmpvar_phold);
bevt_47_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(112, bels_43));
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_49_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(97, bels_44));
bevt_51_tmpvar_phold = (BEC_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_51_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 170 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_53_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_53_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_45));
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_46));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_47));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(56, bels_48));
bevt_60_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_61_tmpvar_phold);
bevt_60_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(52, bels_49));
bevt_64_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_65_tmpvar_phold);
bevt_67_tmpvar_phold = bevp_build.bem_outputPlatformGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_63_tmpvar_phold = (BEC_4_6_TextString) bevt_64_tmpvar_phold.bem_addValue_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_50));
bevt_62_tmpvar_phold = (BEC_4_6_TextString) bevt_63_tmpvar_phold.bem_addValue_1(bevt_68_tmpvar_phold);
bevt_62_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_51));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_70_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_52));
bevt_69_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_70_tmpvar_phold);
bevt_69_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_72_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_53));
bevt_71_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_72_tmpvar_phold);
bevt_71_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_procStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_7;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_decForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 203 */ {
} /* Line: 203 */
 else  /* Line: 205 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 206 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_55));
beva_b.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 207 */
bevt_4_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 209 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_boolTypeGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_56));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_mainStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpvar_phold = bevo_9;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_superNameGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_59));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_extend_1(BEC_4_6_TextString beva_parent) {
BEC_4_6_TextString bevl_extstr = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_parent);
bevt_5_tmpvar_phold = bevo_11;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevl_extstr = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevl_extstr.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_12;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevl_extstr = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_4_6_TextString bem_lintConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_13;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_14;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_15;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_lfloatConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_17;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_lstringConstruct_5(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_belsName, BEC_4_3_MathInt beva_lisz, BEC_5_4_LogicBool beva_isOnce) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 241 */ {
bevt_8_tmpvar_phold = bevo_19;
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_20;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_21;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_14_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_15_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 242 */
bevt_24_tmpvar_phold = bevo_24;
bevt_26_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_25;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = bevo_26;
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(beva_belsName);
bevt_30_tmpvar_phold = bevo_27;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_30_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(beva_lisz);
bevt_31_tmpvar_phold = bevo_28;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
return bevt_16_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_classBeginGet_0() {
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_begin = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 248 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 249 */
 else  /* Line: 250 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_79));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 251 */
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_80));
bevt_6_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_81));
bevl_begin = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_82));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_4_6_TextString bem_emitNameForCall_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 267 */ {
bevt_3_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 268 */
bevt_7_tmpvar_phold = bevo_30;
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
return bevt_6_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_classEndGet_0() {
BEC_4_6_TextString bevl_end = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
bevl_end = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_85));
bevt_0_tmpvar_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 275 */ {
bevt_1_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevl_node = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpvar_phold = bevo_31;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_32;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevo_33;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_34;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_35;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 276 */
 else  /* Line: 275 */ {
break;
} /* Line: 275 */
} /* Line: 275 */
return bevl_end;
} /*method end*/
public override BEC_6_6_SystemObject bem_writeOnceDecs_2(BEC_6_6_SystemObject beva_cle, BEC_6_6_SystemObject beva_onceDecs) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevp_allOnceDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 286 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_1_tmpvar_phold;
} /*method end*/
public override BEC_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_4_6_IOFileWriter bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getLibOutput_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_finishClassOutput_1(BEC_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_4_6_TextString bevl_p = null;
BEC_2_4_IOFile bevl_jsi = null;
BEC_4_6_TextString bevl_inc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_IOFile bevt_4_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_5_tmpvar_phold = null;
BEC_2_4_IOFile bevt_6_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_6_10_SystemParameters bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 302 */ {
bevp_lineCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_fileGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_existsGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_7_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold.bem_makeDirs_0();
} /* Line: 305 */
bevt_9_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_92));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_has_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_14_tmpvar_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_93));
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_get_1(bevt_15_tmpvar_phold);
bevt_0_tmpvar_loop = bevt_13_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 310 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 310 */ {
bevl_p = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpvar_phold.bem_fileGet_0();
bevt_19_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpvar_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 314 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
} /* Line: 310 */
} /* Line: 309 */
return bevp_shlibe;
} /*method end*/
public override BEC_6_6_SystemObject bem_finishLibOutput_1(BEC_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_4_6_TextString bem_beginNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_94));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_beginNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_95));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_libNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_96));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_endNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_97));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_klassDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_98));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_spropDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_99));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_propDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_100));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_initialDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_101));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_baseSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_102));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_overrideSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_37;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_varName);
bevt_4_tmpvar_phold = bevo_38;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_typeName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_onceDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_105));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_getInitialInst_1(BEC_5_11_BuildClassConfig beva_newcc) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_106));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_onceVarDec_1(BEC_4_6_TextString beva_count) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpvar_phold = bevo_39;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_40;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_startMethod_5(BEC_4_6_TextString beva_mtdDec, BEC_5_11_BuildClassConfig beva_returnType, BEC_4_6_TextString beva_mtdName, BEC_4_6_TextString beva_argDecs, BEC_6_6_SystemObject beva_exceptDec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_109));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_110));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_111));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_formCast_1(BEC_5_11_BuildClassConfig beva_cc) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_112));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_getFullEmitName_2(BEC_4_6_TextString beva_nameSpace, BEC_4_6_TextString beva_emitName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_41;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_4_6_TextString bem_getNameSpace_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_42;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_5_11_BuildClassConfig bem_getClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public override BEC_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_11_BuildClassConfig bevl_cc = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpvar_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpvar_phold);
return bevl_cc;
} /*method end*/
public virtual BEC_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_allOnceDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allOnceDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_shlibeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shlibe = (BEC_2_4_6_IOFileWriter) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {27, 28, 29, 33, 35, 36, 38, 39, 43, 43, 43, 43, 43, 43, 43, 43, 47, 47, 47, 48, 49, 49, 49, 49, 49, 49, 51, 51, 51, 51, 51, 51, 51, 51, 51, 51, 59, 59, 59, 59, 59, 59, 59, 63, 63, 63, 63, 63, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 66, 66, 66, 71, 71, 72, 74, 74, 74, 74, 76, 77, 0, 77, 77, 79, 81, 81, 83, 83, 83, 83, 83, 83, 87, 87, 87, 92, 92, 92, 93, 95, 95, 95, 95, 95, 98, 98, 98, 98, 100, 100, 100, 102, 102, 102, 102, 102, 105, 105, 105, 105, 105, 105, 107, 107, 107, 109, 114, 115, 116, 122, 122, 122, 127, 128, 128, 128, 128, 130, 130, 136, 138, 139, 140, 141, 142, 142, 144, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 146, 148, 148, 148, 150, 150, 150, 150, 150, 150, 150, 150, 150, 156, 156, 156, 156, 156, 156, 157, 157, 157, 158, 158, 158, 158, 158, 158, 164, 167, 167, 167, 167, 168, 168, 168, 169, 169, 169, 170, 170, 170, 173, 174, 177, 178, 178, 179, 181, 182, 182, 182, 182, 182, 182, 182, 183, 183, 183, 184, 184, 184, 184, 184, 184, 184, 184, 186, 187, 188, 189, 190, 190, 190, 191, 191, 191, 192, 194, 199, 199, 199, 203, 206, 206, 207, 207, 209, 209, 214, 214, 218, 218, 218, 218, 218, 218, 222, 222, 227, 227, 227, 227, 227, 227, 227, 228, 228, 228, 228, 228, 229, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 237, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 242, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 248, 248, 249, 249, 249, 251, 251, 253, 253, 253, 253, 253, 261, 261, 261, 262, 263, 267, 267, 268, 268, 268, 268, 268, 270, 270, 270, 270, 270, 274, 275, 0, 275, 275, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 278, 285, 285, 286, 288, 289, 289, 294, 294, 302, 302, 303, 304, 304, 304, 304, 305, 305, 305, 307, 307, 307, 309, 309, 309, 310, 310, 310, 310, 0, 310, 310, 311, 311, 312, 312, 312, 313, 313, 314, 320, 324, 325, 330, 330, 334, 334, 338, 338, 342, 342, 346, 346, 350, 350, 354, 354, 359, 359, 364, 364, 368, 368, 368, 368, 368, 368, 372, 372, 376, 376, 376, 376, 376, 381, 381, 381, 381, 381, 381, 381, 386, 386, 386, 386, 386, 386, 386, 388, 390, 390, 390, 395, 395, 399, 399, 403, 403, 403, 403, 407, 407, 407, 407, 411, 412, 412, 413, 417, 418, 418, 419, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {170, 171, 172, 173, 174, 175, 176, 177, 188, 189, 190, 191, 192, 193, 194, 195, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 248, 249, 250, 251, 252, 253, 254, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 314, 315, 316, 317, 318, 319, 320, 321, 322, 322, 325, 327, 329, 332, 333, 335, 336, 337, 338, 339, 340, 346, 347, 348, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 411, 412, 413, 419, 420, 421, 430, 432, 433, 434, 435, 437, 438, 525, 526, 527, 528, 529, 530, 533, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 578, 579, 580, 581, 582, 583, 591, 592, 593, 594, 595, 597, 598, 599, 600, 601, 602, 603, 604, 605, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 649, 650, 651, 659, 663, 664, 666, 667, 669, 670, 676, 677, 685, 686, 687, 688, 689, 690, 694, 695, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 856, 861, 862, 863, 864, 867, 868, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 892, 893, 895, 896, 897, 898, 899, 901, 902, 903, 904, 905, 934, 935, 935, 938, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 969, 974, 979, 980, 982, 983, 984, 988, 989, 1019, 1024, 1025, 1026, 1027, 1028, 1029, 1031, 1032, 1033, 1035, 1036, 1037, 1038, 1039, 1040, 1042, 1043, 1044, 1045, 1045, 1048, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1066, 1069, 1070, 1075, 1076, 1080, 1081, 1085, 1086, 1090, 1091, 1095, 1096, 1100, 1101, 1105, 1106, 1110, 1111, 1115, 1116, 1124, 1125, 1126, 1127, 1128, 1129, 1133, 1134, 1141, 1142, 1143, 1144, 1145, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1181, 1186, 1187, 1191, 1192, 1198, 1199, 1200, 1201, 1207, 1208, 1209, 1210, 1215, 1216, 1217, 1218, 1223, 1224, 1225, 1226, 1229, 1232, 1236, 1239};
/* BEGIN LINEINFO 
assign 1 27 170
new 0 27 170
assign 1 28 171
new 0 28 171
assign 1 29 172
new 0 29 172
new 1 33 173
assign 1 35 174
new 0 35 174
assign 1 36 175
new 0 36 175
assign 1 38 176
new 0 38 176
assign 1 39 177
new 0 39 177
assign 1 43 188
new 0 43 188
assign 1 43 189
addValue 1 43 189
assign 1 43 190
secondGet 0 43 190
assign 1 43 191
formTarg 1 43 191
assign 1 43 192
addValue 1 43 192
assign 1 43 193
new 0 43 193
assign 1 43 194
addValue 1 43 194
addValue 1 43 195
assign 1 47 216
new 0 47 216
assign 1 47 217
toString 0 47 217
assign 1 47 218
add 1 47 218
assign 1 48 219
increment 0 48 219
assign 1 49 220
new 0 49 220
assign 1 49 221
addValue 1 49 221
assign 1 49 222
addValue 1 49 222
assign 1 49 223
new 0 49 223
assign 1 49 224
addValue 1 49 224
addValue 1 49 225
assign 1 51 226
containedGet 0 51 226
assign 1 51 227
firstGet 0 51 227
assign 1 51 228
containedGet 0 51 228
assign 1 51 229
firstGet 0 51 229
assign 1 51 230
new 0 51 230
assign 1 51 231
add 1 51 231
assign 1 51 232
new 0 51 232
assign 1 51 233
add 1 51 233
assign 1 51 234
finalAssign 3 51 234
addValue 1 51 235
assign 1 59 248
emitNameGet 0 59 248
assign 1 59 249
addValue 1 59 249
assign 1 59 250
new 0 59 250
assign 1 59 251
addValue 1 59 251
assign 1 59 252
addValue 1 59 252
assign 1 59 253
new 0 59 253
addValue 1 59 254
assign 1 63 274
emitNameGet 0 63 274
assign 1 63 275
addValue 1 63 275
assign 1 63 276
new 0 63 276
assign 1 63 277
addValue 1 63 277
addValue 1 63 278
assign 1 64 279
new 0 64 279
assign 1 64 280
addValue 1 64 280
assign 1 64 281
heldGet 0 64 281
assign 1 64 282
namepathGet 0 64 282
assign 1 64 283
getClassConfig 1 64 283
assign 1 64 284
libNameGet 0 64 284
assign 1 64 285
relEmitName 1 64 285
assign 1 64 286
addValue 1 64 286
assign 1 64 287
new 0 64 287
assign 1 64 288
addValue 1 64 288
addValue 1 64 289
assign 1 66 290
new 0 66 290
assign 1 66 291
addValue 1 66 291
addValue 1 66 292
assign 1 71 314
heldGet 0 71 314
assign 1 71 315
synGet 0 71 315
assign 1 72 316
ptyListGet 0 72 316
assign 1 74 317
emitNameGet 0 74 317
assign 1 74 318
addValue 1 74 318
assign 1 74 319
new 0 74 319
addValue 1 74 320
assign 1 76 321
new 0 76 321
assign 1 77 322
iteratorGet 0 0 322
assign 1 77 325
hasNextGet 0 77 325
assign 1 77 327
nextGet 0 77 327
assign 1 79 329
new 0 79 329
assign 1 81 332
new 0 81 332
addValue 1 81 333
assign 1 83 335
addValue 1 83 335
assign 1 83 336
new 0 83 336
assign 1 83 337
addValue 1 83 337
assign 1 83 338
nameGet 0 83 338
assign 1 83 339
addValue 1 83 339
addValue 1 83 340
assign 1 87 346
new 0 87 346
assign 1 87 347
addValue 1 87 347
addValue 1 87 348
assign 1 92 376
heldGet 0 92 376
assign 1 92 377
namepathGet 0 92 377
assign 1 92 378
getClassConfig 1 92 378
assign 1 93 379
getInitialInst 1 93 379
assign 1 95 380
emitNameGet 0 95 380
assign 1 95 381
addValue 1 95 381
assign 1 95 382
new 0 95 382
assign 1 95 383
addValue 1 95 383
addValue 1 95 384
assign 1 98 385
addValue 1 98 385
assign 1 98 386
new 0 98 386
assign 1 98 387
addValue 1 98 387
addValue 1 98 388
assign 1 100 389
new 0 100 389
assign 1 100 390
addValue 1 100 390
addValue 1 100 391
assign 1 102 392
emitNameGet 0 102 392
assign 1 102 393
addValue 1 102 393
assign 1 102 394
new 0 102 394
assign 1 102 395
addValue 1 102 395
addValue 1 102 396
assign 1 105 397
new 0 105 397
assign 1 105 398
addValue 1 105 398
assign 1 105 399
addValue 1 105 399
assign 1 105 400
new 0 105 400
assign 1 105 401
addValue 1 105 401
addValue 1 105 402
assign 1 107 403
new 0 107 403
assign 1 107 404
addValue 1 107 404
addValue 1 107 405
buildPropList 0 109 406
getCode 2 114 411
assign 1 115 412
toString 0 115 412
addValue 1 116 413
assign 1 122 419
new 0 122 419
assign 1 122 420
addValue 1 122 420
addValue 1 122 421
assign 1 127 430
isPropertyGet 0 127 430
assign 1 128 432
new 0 128 432
assign 1 128 433
nameGet 0 128 433
assign 1 128 434
add 1 128 434
return 1 128 435
assign 1 130 437
nameForVar 1 130 437
return 1 130 438
assign 1 136 525
getLibOutput 0 136 525
assign 1 138 526
new 0 138 526
assign 1 139 527
new 0 139 527
assign 1 140 528
new 0 140 528
assign 1 141 529
new 0 141 529
assign 1 142 530
iteratorGet 0 142 530
assign 1 142 533
hasNextGet 0 142 533
assign 1 144 535
nextGet 0 144 535
assign 1 146 536
new 0 146 536
assign 1 146 537
addValue 1 146 537
assign 1 146 538
addValue 1 146 538
assign 1 146 539
heldGet 0 146 539
assign 1 146 540
namepathGet 0 146 540
assign 1 146 541
toString 0 146 541
assign 1 146 542
addValue 1 146 542
assign 1 146 543
addValue 1 146 543
assign 1 146 544
new 0 146 544
assign 1 146 545
addValue 1 146 545
assign 1 146 546
heldGet 0 146 546
assign 1 146 547
namepathGet 0 146 547
assign 1 146 548
getClassConfig 1 146 548
assign 1 146 549
libNameGet 0 146 549
assign 1 146 550
relEmitName 1 146 550
assign 1 146 551
addValue 1 146 551
assign 1 146 552
new 0 146 552
assign 1 146 553
addValue 1 146 553
addValue 1 146 554
assign 1 148 555
heldGet 0 148 555
assign 1 148 556
synGet 0 148 556
assign 1 148 557
hasDefaultGet 0 148 557
assign 1 150 559
new 0 150 559
assign 1 150 560
heldGet 0 150 560
assign 1 150 561
namepathGet 0 150 561
assign 1 150 562
getClassConfig 1 150 562
assign 1 150 563
libNameGet 0 150 563
assign 1 150 564
relEmitName 1 150 564
assign 1 150 565
add 1 150 565
assign 1 150 566
new 0 150 566
assign 1 150 567
add 1 150 567
assign 1 156 568
new 0 156 568
assign 1 156 569
addValue 1 156 569
assign 1 156 570
addValue 1 156 570
assign 1 156 571
new 0 156 571
assign 1 156 572
addValue 1 156 572
addValue 1 156 573
assign 1 157 574
heldGet 0 157 574
assign 1 157 575
synGet 0 157 575
assign 1 157 576
hasDefaultGet 0 157 576
assign 1 158 578
new 0 158 578
assign 1 158 579
addValue 1 158 579
assign 1 158 580
addValue 1 158 580
assign 1 158 581
new 0 158 581
assign 1 158 582
addValue 1 158 582
addValue 1 158 583
write 1 164 591
assign 1 167 592
usedLibrarysGet 0 167 592
assign 1 167 593
sizeGet 0 167 593
assign 1 167 594
new 0 167 594
assign 1 167 595
equals 1 167 595
assign 1 168 597
new 0 168 597
assign 1 168 598
addValue 1 168 598
addValue 1 168 599
assign 1 169 600
new 0 169 600
assign 1 169 601
addValue 1 169 601
addValue 1 169 602
assign 1 170 603
new 0 170 603
assign 1 170 604
addValue 1 170 604
addValue 1 170 605
write 1 173 607
write 1 174 608
assign 1 177 609
new 0 177 609
assign 1 178 610
mainNameGet 0 178 610
fromString 1 178 611
assign 1 179 612
getClassConfig 1 179 612
assign 1 181 613
new 0 181 613
assign 1 182 614
new 0 182 614
assign 1 182 615
addValue 1 182 615
assign 1 182 616
fullEmitNameGet 0 182 616
assign 1 182 617
addValue 1 182 617
assign 1 182 618
new 0 182 618
assign 1 182 619
addValue 1 182 619
addValue 1 182 620
assign 1 183 621
new 0 183 621
assign 1 183 622
addValue 1 183 622
addValue 1 183 623
assign 1 184 624
new 0 184 624
assign 1 184 625
addValue 1 184 625
assign 1 184 626
outputPlatformGet 0 184 626
assign 1 184 627
nameGet 0 184 627
assign 1 184 628
addValue 1 184 628
assign 1 184 629
new 0 184 629
assign 1 184 630
addValue 1 184 630
addValue 1 184 631
write 1 186 632
assign 1 187 633
new 0 187 633
write 1 188 634
write 1 189 635
assign 1 190 636
new 0 190 636
assign 1 190 637
addValue 1 190 637
addValue 1 190 638
assign 1 191 639
new 0 191 639
assign 1 191 640
addValue 1 191 640
addValue 1 191 641
write 1 192 642
finishLibOutput 1 194 643
assign 1 199 649
new 0 199 649
assign 1 199 650
add 1 199 650
return 1 199 651
assign 1 203 659
isPropertyGet 0 203 659
assign 1 206 663
isArgGet 0 206 663
assign 1 206 664
not 0 206 664
assign 1 207 666
new 0 207 666
addValue 1 207 667
assign 1 209 669
nameForVar 1 209 669
addValue 1 209 670
assign 1 214 676
new 0 214 676
return 1 214 677
assign 1 218 685
new 0 218 685
assign 1 218 686
add 1 218 686
assign 1 218 687
new 0 218 687
assign 1 218 688
add 1 218 688
assign 1 218 689
add 1 218 689
return 1 218 690
assign 1 222 694
new 0 222 694
return 1 222 695
assign 1 227 709
emitNameGet 0 227 709
assign 1 227 710
new 0 227 710
assign 1 227 711
add 1 227 711
assign 1 227 712
add 1 227 712
assign 1 227 713
new 0 227 713
assign 1 227 714
add 1 227 714
assign 1 227 715
addValue 1 227 715
assign 1 228 716
emitNameGet 0 228 716
assign 1 228 717
add 1 228 717
assign 1 228 718
new 0 228 718
assign 1 228 719
add 1 228 719
assign 1 228 720
addValue 1 228 720
return 1 229 721
assign 1 233 735
new 0 233 735
assign 1 233 736
libNameGet 0 233 736
assign 1 233 737
relEmitName 1 233 737
assign 1 233 738
add 1 233 738
assign 1 233 739
new 0 233 739
assign 1 233 740
add 1 233 740
assign 1 233 741
heldGet 0 233 741
assign 1 233 742
literalValueGet 0 233 742
assign 1 233 743
add 1 233 743
assign 1 233 744
new 0 233 744
assign 1 233 745
add 1 233 745
return 1 233 746
assign 1 237 760
new 0 237 760
assign 1 237 761
libNameGet 0 237 761
assign 1 237 762
relEmitName 1 237 762
assign 1 237 763
add 1 237 763
assign 1 237 764
new 0 237 764
assign 1 237 765
add 1 237 765
assign 1 237 766
heldGet 0 237 766
assign 1 237 767
literalValueGet 0 237 767
assign 1 237 768
add 1 237 768
assign 1 237 769
new 0 237 769
assign 1 237 770
add 1 237 770
return 1 237 771
assign 1 242 807
new 0 242 807
assign 1 242 808
libNameGet 0 242 808
assign 1 242 809
relEmitName 1 242 809
assign 1 242 810
add 1 242 810
assign 1 242 811
new 0 242 811
assign 1 242 812
add 1 242 812
assign 1 242 813
emitNameGet 0 242 813
assign 1 242 814
add 1 242 814
assign 1 242 815
new 0 242 815
assign 1 242 816
add 1 242 816
assign 1 242 817
add 1 242 817
assign 1 242 818
new 0 242 818
assign 1 242 819
add 1 242 819
assign 1 242 820
add 1 242 820
assign 1 242 821
new 0 242 821
assign 1 242 822
add 1 242 822
return 1 242 823
assign 1 244 825
new 0 244 825
assign 1 244 826
libNameGet 0 244 826
assign 1 244 827
relEmitName 1 244 827
assign 1 244 828
add 1 244 828
assign 1 244 829
new 0 244 829
assign 1 244 830
add 1 244 830
assign 1 244 831
emitNameGet 0 244 831
assign 1 244 832
add 1 244 832
assign 1 244 833
new 0 244 833
assign 1 244 834
add 1 244 834
assign 1 244 835
add 1 244 835
assign 1 244 836
new 0 244 836
assign 1 244 837
add 1 244 837
assign 1 244 838
add 1 244 838
assign 1 244 839
new 0 244 839
assign 1 244 840
add 1 244 840
return 1 244 841
assign 1 248 856
def 1 248 861
assign 1 249 862
libNameGet 0 249 862
assign 1 249 863
relEmitName 1 249 863
assign 1 249 864
extend 1 249 864
assign 1 251 867
new 0 251 867
assign 1 251 868
extend 1 251 868
assign 1 253 870
new 0 253 870
assign 1 253 871
emitNameGet 0 253 871
assign 1 253 872
addValue 1 253 872
assign 1 253 873
new 0 253 873
assign 1 253 874
addValue 1 253 874
assign 1 261 875
new 0 261 875
assign 1 261 876
addValue 1 261 876
addValue 1 261 877
addValue 1 262 878
return 1 263 879
assign 1 267 892
heldGet 0 267 892
assign 1 267 893
superCallGet 0 267 893
assign 1 268 895
new 0 268 895
assign 1 268 896
heldGet 0 268 896
assign 1 268 897
nameGet 0 268 897
assign 1 268 898
add 1 268 898
return 1 268 899
assign 1 270 901
new 0 270 901
assign 1 270 902
heldGet 0 270 902
assign 1 270 903
nameGet 0 270 903
assign 1 270 904
add 1 270 904
return 1 270 905
assign 1 274 934
new 0 274 934
assign 1 275 935
iteratorGet 0 0 935
assign 1 275 938
hasNextGet 0 275 938
assign 1 275 940
nextGet 0 275 940
assign 1 276 941
emitNameGet 0 276 941
assign 1 276 942
new 0 276 942
assign 1 276 943
add 1 276 943
assign 1 276 944
new 0 276 944
assign 1 276 945
add 1 276 945
assign 1 276 946
heldGet 0 276 946
assign 1 276 947
nameGet 0 276 947
assign 1 276 948
add 1 276 948
assign 1 276 949
new 0 276 949
assign 1 276 950
add 1 276 950
assign 1 276 951
emitNameGet 0 276 951
assign 1 276 952
add 1 276 952
assign 1 276 953
new 0 276 953
assign 1 276 954
add 1 276 954
assign 1 276 955
new 0 276 955
assign 1 276 956
add 1 276 956
assign 1 276 957
heldGet 0 276 957
assign 1 276 958
nameGet 0 276 958
assign 1 276 959
add 1 276 959
assign 1 276 960
new 0 276 960
assign 1 276 961
add 1 276 961
assign 1 276 962
add 1 276 962
addValue 1 276 963
return 1 278 969
assign 1 285 974
undef 1 285 979
assign 1 286 980
new 0 286 980
addValue 1 288 982
assign 1 289 983
new 0 289 983
return 1 289 984
assign 1 294 988
getLibOutput 0 294 988
return 1 294 989
assign 1 302 1019
undef 1 302 1024
assign 1 303 1025
new 0 303 1025
assign 1 304 1026
parentGet 0 304 1026
assign 1 304 1027
fileGet 0 304 1027
assign 1 304 1028
existsGet 0 304 1028
assign 1 304 1029
not 0 304 1029
assign 1 305 1031
parentGet 0 305 1031
assign 1 305 1032
fileGet 0 305 1032
makeDirs 0 305 1033
assign 1 307 1035
fileGet 0 307 1035
assign 1 307 1036
writerGet 0 307 1036
assign 1 307 1037
open 0 307 1037
assign 1 309 1038
paramsGet 0 309 1038
assign 1 309 1039
new 0 309 1039
assign 1 309 1040
has 1 309 1040
assign 1 310 1042
paramsGet 0 310 1042
assign 1 310 1043
new 0 310 1043
assign 1 310 1044
get 1 310 1044
assign 1 310 1045
iteratorGet 0 0 1045
assign 1 310 1048
hasNextGet 0 310 1048
assign 1 310 1050
nextGet 0 310 1050
assign 1 311 1051
apNew 1 311 1051
assign 1 311 1052
fileGet 0 311 1052
assign 1 312 1053
readerGet 0 312 1053
assign 1 312 1054
open 0 312 1054
assign 1 312 1055
readString 0 312 1055
assign 1 313 1056
readerGet 0 313 1056
close 0 313 1057
write 1 314 1058
return 1 320 1066
close 0 324 1069
assign 1 325 1070
assign 1 330 1075
new 0 330 1075
return 1 330 1076
assign 1 334 1080
new 0 334 1080
return 1 334 1081
assign 1 338 1085
new 0 338 1085
return 1 338 1086
assign 1 342 1090
new 0 342 1090
return 1 342 1091
assign 1 346 1095
new 0 346 1095
return 1 346 1096
assign 1 350 1100
new 0 350 1100
return 1 350 1101
assign 1 354 1105
new 0 354 1105
return 1 354 1106
assign 1 359 1110
new 0 359 1110
return 1 359 1111
assign 1 364 1115
new 0 364 1115
return 1 364 1116
assign 1 368 1124
new 0 368 1124
assign 1 368 1125
add 1 368 1125
assign 1 368 1126
new 0 368 1126
assign 1 368 1127
add 1 368 1127
assign 1 368 1128
add 1 368 1128
return 1 368 1129
assign 1 372 1133
new 0 372 1133
return 1 372 1134
assign 1 376 1141
libNameGet 0 376 1141
assign 1 376 1142
relEmitName 1 376 1142
assign 1 376 1143
new 0 376 1143
assign 1 376 1144
add 1 376 1144
return 1 376 1145
assign 1 381 1154
emitNameGet 0 381 1154
assign 1 381 1155
new 0 381 1155
assign 1 381 1156
add 1 381 1156
assign 1 381 1157
new 0 381 1157
assign 1 381 1158
add 1 381 1158
assign 1 381 1159
add 1 381 1159
return 1 381 1160
assign 1 386 1171
emitNameGet 0 386 1171
assign 1 386 1172
addValue 1 386 1172
assign 1 386 1173
new 0 386 1173
assign 1 386 1174
addValue 1 386 1174
assign 1 386 1175
addValue 1 386 1175
assign 1 386 1176
new 0 386 1176
addValue 1 386 1177
addValue 1 388 1178
assign 1 390 1179
new 0 390 1179
assign 1 390 1180
addValue 1 390 1180
addValue 1 390 1181
assign 1 395 1186
new 0 395 1186
return 1 395 1187
assign 1 399 1191
new 0 399 1191
return 1 399 1192
assign 1 403 1198
new 0 403 1198
assign 1 403 1199
add 1 403 1199
assign 1 403 1200
add 1 403 1200
return 1 403 1201
assign 1 407 1207
new 0 407 1207
assign 1 407 1208
libEmitName 1 407 1208
assign 1 407 1209
add 1 407 1209
return 1 407 1210
assign 1 411 1215
getClassConfig 1 411 1215
assign 1 412 1216
fullEmitNameGet 0 412 1216
emitNameSet 1 412 1217
return 1 413 1218
assign 1 417 1223
getLocalClassConfig 1 417 1223
assign 1 418 1224
fullEmitNameGet 0 418 1224
emitNameSet 1 418 1225
return 1 419 1226
return 1 0 1229
assign 1 0 1232
return 1 0 1236
assign 1 0 1239
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 493012039: return bem_buildGet_0();
case 1831751774: return bem_cnodeGet_0();
case 4647121: return bem_doEmit_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 902412214: return bem_classCallsGet_0();
case 962646066: return bem_shlibeGet_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 991255330: return bem_mainStartGet_0();
case 287040793: return bem_hashGet_0();
case 402158238: return bem_inFilePathedGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 498080472: return bem_mnodeGet_0();
case 160277051: return bem_procStartGet_0();
case 622039562: return bem_intNpGet_0();
case 1638160588: return bem_lineCountGet_0();
case 681402717: return bem_boolTypeGet_0();
case 1354714650: return bem_copy_0();
case 845792839: return bem_iteratorGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 916491491: return bem_emitLib_0();
case 1052944126: return bem_csynGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case 314718434: return bem_print_0();
case 229958684: return bem_constGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 603479476: return bem_allOnceDecsGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 1947619572: return bem_msynGet_0();
case 1755995201: return bem_transGet_0();
case 1910715228: return bem_libEmitNameGet_0();
case 1727672536: return bem_propDecGet_0();
case 1064889660: return bem_trueValueGet_0();
case 362974009: return bem_parentConfGet_0();
case 1312373307: return bem_buildCreate_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 727049506: return bem_exceptDecGet_0();
case 722876119: return bem_buildClassInfo_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1820417453: return bem_create_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 254265568: return bem_buildPropList_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 2019411446: return bem_classBeginGet_0();
case 1073009537: return bem_beginNs_0();
case 378762597: return bem_boolNpGet_0();
case 89706405: return bem_ccCacheGet_0();
case 220901978: return bem_emitLangGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2055025483: return bem_serializeContents_0();
case 644675716: return bem_ntypesGet_0();
case 1372235405: return bem_superCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 388723214: return bem_preClassGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 2001798761: return bem_nlGet_0();
case 1081412016: return bem_many_0();
case 1774940957: return bem_toString_0();
case 991179882: return bem_qGet_0();
case 946095539: return bem_mainInClassGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1859739893: return bem_methodsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 729571811: return bem_serializeToString_0();
case 1181505319: return bem_buildInitial_0();
case 104713553: return bem_new_0();
case 1413054881: return bem_smnlcsGet_0();
case 57260628: return bem_getClassOutput_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1967844855: return bem_initialDecGet_0();
case 483359873: return bem_superNameGet_0();
case 294732055: return bem_floatNpGet_0();
case 443668840: return bem_methodNotDefined_0();
case 604504089: return bem_falseValueGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1012494862: return bem_once_0();
case 797225458: return bem_dynMethodsGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1369896794: return bem_objectNpGet_0();
case 1380285640: return bem_objectCcGet_0();
case 1487140092: return bem_classEndGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 2085643372: return bem_stringNpGet_0();
case 1607412815: return bem_endNs_0();
case 1431933907: return bem_lastCallGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1109279973: return bem_spropDecGet_0();
case 1498619679: return bem_getLibOutput_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 708434875: return bem_klassDecGet_0();
case 1102720804: return bem_classNameGet_0();
case 944442837: return bem_classConfGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1529527065: return bem_onceCountGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 165152860: return bem_libNs_1((BEC_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_5_4_BuildNode) bevd_0, (BEC_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_5_4_BuildNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_4_6_TextString) bevd_0, (BEC_5_11_BuildClassConfig) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_9_BuildJSEmitter.bevs_inst = (BEC_5_9_BuildJSEmitter)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_9_BuildJSEmitter.bevs_inst;
}
}
}
