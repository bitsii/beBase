namespace be.BEL_4_Base {
/* File: source/build/Build.be */
public class BEC_5_5_BuildBuild : BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
static BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x73};
private static byte[] bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_44 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_45 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_46 = {0x72,0x75,0x6E};
private static byte[] bels_47 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_48 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_49 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_50 = {0x67,0x63,0x63};
private static byte[] bels_51 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_52 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_53 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_53, 9));
private static byte[] bels_54 = {};
private static byte[] bels_55 = {0x63};
private static byte[] bels_56 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_56, 8));
private static byte[] bels_57 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_57, 7));
private static byte[] bels_58 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_59 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_60 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_60, 2));
private static byte[] bels_61 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_61, 2));
private static byte[] bels_62 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_62, 2));
private static byte[] bels_63 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_64 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_64, 19));
private static byte[] bels_65 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_65, 31));
private static byte[] bels_66 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_66, 31));
private static byte[] bels_67 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_67, 41));
private static byte[] bels_68 = {0x2F};
private static byte[] bels_69 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_69, 31));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 41));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 51));
private static byte[] bels_72 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_72, 14));
private static byte[] bels_73 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_73, 19));
private static byte[] bels_74 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_74, 9));
private static byte[] bels_75 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_75, 13));
private static byte[] bels_76 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_76, 2));
private static byte[] bels_77 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_77, 3));
private static byte[] bels_78 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_78, 4));
private static byte[] bels_79 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_79, 5));
private static byte[] bels_80 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_80, 6));
private static byte[] bels_81 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_81, 7));
private static byte[] bels_82 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_82, 8));
private static byte[] bels_83 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_83, 9));
private static byte[] bels_84 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_84, 10));
private static byte[] bels_85 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_36 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_85, 11));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_86, 12));
private static byte[] bels_87 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_38 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_87, 13));
private static byte[] bels_88 = {0x20};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_88, 1));
private static byte[] bels_89 = {0x50,0x72,0x69,0x6E,0x74,0x41,0x53,0x54};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_89, 8));
public static new BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_5_14_BuildCCallAssembler bevp_cassem;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printVisitors;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printVisitors = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_5_9_BuildConstants) (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_4_9_TextTokenizer) (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 99 */
 else  /* Line: 99 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 99 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 100 */
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_main_0() {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_6_10_SystemParameters) (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_go_0() {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_whatResult = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_config_0();
try  /* Line: 123 */ {
bevp_buildMessage = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_6));
} /* Line: 126 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_0_tmpvar_phold.bem_add_1(bevl_e);
bevl_whatResult = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 129 */
bevp_buildMessage.bem_print_0();
return bevl_whatResult;
} /*method end*/
public virtual BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 142 */
return beva_addTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_config_0() {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_3_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_IOFile bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_IOFile bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_IOFile bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_98_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_IOFile bevt_104_tmpvar_phold = null;
BEC_2_4_IOFile bevt_105_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_2_4_IOFile bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
bevl_bfiles = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_15));
bevt_3_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevt_4_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_4_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 153 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_not_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_8_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_8_tmpvar_phold);
} /* Line: 156 */
} /* Line: 154 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
bevt_11_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_nameGet_0();
bevt_12_tmpvar_phold = bevo_9;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 162 */
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_17));
bevt_13_tmpvar_phold = bevp_params.bem_get_1(bevt_14_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_firstGet_0();
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_18));
bevt_15_tmpvar_phold = bevp_params.bem_has_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_19));
bevt_17_tmpvar_phold = bevp_params.bem_get_1(bevt_18_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_firstGet_0();
} /* Line: 166 */
 else  /* Line: 167 */ {
bevp_exeName = bevp_libName;
} /* Line: 168 */
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_20));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_21));
bevt_21_tmpvar_phold = bevp_params.bem_get_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_firstGet_0();
bevt_19_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevt_20_tmpvar_phold);
bevp_buildPath = bevt_19_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_24_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_23));
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_24));
bevt_27_tmpvar_phold = bevp_params.bem_get_2(bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_firstGet_0();
bevt_25_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevt_26_tmpvar_phold);
bevp_includePath = bevt_25_tmpvar_phold.bem_pathGet_0();
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_25));
bevt_34_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_nameGet_0();
bevt_31_tmpvar_phold = bevp_params.bem_get_2(bevt_32_tmpvar_phold, bevt_33_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_30_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_26));
bevt_38_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = bevp_params.bem_get_2(bevt_37_tmpvar_phold, (BEC_4_6_TextString) bevt_38_tmpvar_phold);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_35_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_27));
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_28));
bevt_40_tmpvar_phold = bevp_params.bem_get_2(bevt_41_tmpvar_phold, bevt_42_tmpvar_phold);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_39_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_29));
bevt_43_tmpvar_phold = bevp_params.bem_get_1(bevt_44_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_43_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_30));
bevt_45_tmpvar_phold = bevp_params.bem_get_1(bevt_46_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_47_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_47_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 182 */
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_49_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 186 */
bevt_51_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_51_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 190 */
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 193 */ {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 194 */
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 198 */
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 202 */
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 206 */
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 210 */
bevt_63_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 214 */
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 217 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 218 */
bevt_67_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 224 */
bevt_69_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_42));
bevt_70_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printVisitors = bevp_params.bem_isTrue_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_43));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_44));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_72_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(19, bels_45));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_73_tmpvar_phold);
bevt_74_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_46));
bevp_run = bevp_params.bem_isTrue_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_47));
bevt_76_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_48));
bevp_emitLangs = bevp_params.bem_get_1(bevt_77_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_49));
bevt_80_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_50));
bevt_78_tmpvar_phold = bevp_params.bem_get_2(bevt_79_tmpvar_phold, bevt_80_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_78_tmpvar_phold.bem_firstGet_0();
bevt_82_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_51));
bevt_83_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_52));
bevt_81_tmpvar_phold = bevp_params.bem_get_2(bevt_82_tmpvar_phold, bevt_83_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_81_tmpvar_phold.bem_firstGet_0();
bevt_86_tmpvar_phold = bevo_10;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_54));
bevt_84_tmpvar_phold = bevp_params.bem_get_2(bevt_85_tmpvar_phold, bevt_87_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_84_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 244 */
 else  /* Line: 245 */ {
bevl_outLang = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_55));
} /* Line: 246 */
bevt_91_tmpvar_phold = bevo_11;
bevt_90_tmpvar_phold = bevl_outLang.bem_add_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevt_92_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_89_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_94_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_94_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 255 */
bevt_96_tmpvar_phold = bevo_12;
bevt_95_tmpvar_phold = bevl_outLang.bem_add_1(bevt_96_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_95_tmpvar_phold);
if (bevl_langSources == null) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_98_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_98_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 260 */
bevp_toBuild = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_99_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_1_tmpvar_loop = bevt_99_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 264 */ {
bevt_100_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_100_tmpvar_phold != null && bevt_100_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_100_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevl_istr = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_101_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_101_tmpvar_phold);
} /* Line: 265 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_104_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_existsGet_0();
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_not_0();
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_105_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_105_tmpvar_phold.bem_makeDirs_0();
} /* Line: 273 */
if (bevp_emitFileHeader == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_107_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_107_tmpvar_phold.bem_readerGet_0();
bevt_108_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_108_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 278 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_58));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_59));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 292 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 298 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 298 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 299 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
} /* Line: 298 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 303 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 304 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 304 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 305 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 303 */
} /* Line: 294 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 310 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 310 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 312 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_emitCs_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 323 */ {
return bevp_emitCommon;
} /* Line: 324 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 329 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 332 */
 else  /* Line: 331 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 333 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 334 */
 else  /* Line: 331 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 335 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 336 */
 else  /* Line: 337 */ {
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(49, bels_63));
bevt_8_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 338 */
} /* Line: 331 */
} /* Line: 331 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 341 */
return null;
} /*method end*/
public virtual BEC_4_3_MathInt bem_doWhat_0() {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (BEC_5_8_BuildEmitData) (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 351 */ {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 354 */
bevl_ulibs = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 358 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 358 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 362 */
} /* Line: 359 */
 else  /* Line: 358 */ {
break;
} /* Line: 358 */
} /* Line: 358 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 365 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 365 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 370 */
} /* Line: 366 */
 else  /* Line: 365 */ {
break;
} /* Line: 365 */
} /* Line: 365 */
if (bevp_parse.bevi_bool) /* Line: 373 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 375 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 378 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 380 */
bevt_15_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 388 */
if (bevp_doEmit.bevi_bool) /* Line: 390 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevp_cassem = (BEC_5_14_BuildCCallAssembler) (new BEC_5_14_BuildCCallAssembler()).bem_new_1(this);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 396 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
} /* Line: 400 */
bevt_26_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 408 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 411 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 413 */
if (bevp_make.bevi_bool) /* Line: 416 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 417 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 420 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 421 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 421 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 425 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 426 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 428 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 429 */
} /* Line: 428 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
} /* Line: 421 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 436 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 436 */
 else  /* Line: 436 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 436 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_68));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 440 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 441 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 443 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 444 */
} /* Line: 443 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 417 */
bevt_64_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 451 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 452 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 454 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 455 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 457 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 458 */
if (bevp_run.bevi_bool) /* Line: 461 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 465 */
bevt_79_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 471 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 471 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 475 */
 else  /* Line: 471 */ {
break;
} /* Line: 471 */
} /* Line: 471 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 477 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 477 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 481 */
 else  /* Line: 477 */ {
break;
} /* Line: 477 */
} /* Line: 477 */
bevt_6_tmpvar_phold = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 487 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 488 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 491 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 492 */
 else  /* Line: 493 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 496 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 498 */
 else  /* Line: 499 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 501 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 503 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 513 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 514 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 529 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 530 */
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_9_3_ContainerSet bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_35_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_0_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 543 */ {
bevt_2_tmpvar_phold = bevo_26;
bevt_3_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold.bem_print_0();
bevp_fromFile = beva_toParse;
bevt_6_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_4_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_7_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
bevt_9_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_9_tmpvar_phold, bevl_toks);
if (bevp_printVisitors.bevi_bool) /* Line: 559 */ {
bevt_10_tmpvar_phold = bevo_27;
bevt_10_tmpvar_phold.bem_echo_0();
} /* Line: 560 */
bevt_11_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_11_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 563 */ {
bevt_12_tmpvar_phold = bevo_28;
bevt_12_tmpvar_phold.bem_echo_0();
} /* Line: 564 */
bevt_13_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_13_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 569 */ {
bevt_14_tmpvar_phold = bevo_29;
bevt_14_tmpvar_phold.bem_echo_0();
} /* Line: 570 */
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printVisitors.bevi_bool) /* Line: 574 */ {
bevt_15_tmpvar_phold = bevo_30;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 575 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 579 */ {
bevt_17_tmpvar_phold = bevo_31;
bevt_17_tmpvar_phold.bem_echo_0();
} /* Line: 580 */
bevt_18_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 584 */ {
bevt_19_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 585 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 589 */ {
bevt_21_tmpvar_phold = bevo_33;
bevt_21_tmpvar_phold.bem_echo_0();
} /* Line: 590 */
bevt_22_tmpvar_phold = (BEC_5_5_5_BuildVisitPass7) (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 594 */ {
bevt_23_tmpvar_phold = bevo_34;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 595 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 599 */ {
bevt_25_tmpvar_phold = bevo_35;
bevt_25_tmpvar_phold.bem_echo_0();
} /* Line: 600 */
bevt_26_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 604 */ {
bevt_27_tmpvar_phold = bevo_36;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 605 */
bevt_28_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 609 */ {
bevt_29_tmpvar_phold = bevo_37;
bevt_29_tmpvar_phold.bem_echo_0();
} /* Line: 610 */
bevt_30_tmpvar_phold = (BEC_5_5_6_BuildVisitPass11) (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
if (bevp_printVisitors.bevi_bool) /* Line: 614 */ {
bevt_31_tmpvar_phold = bevo_38;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 615 */
bevt_32_tmpvar_phold = bevo_39;
bevt_32_tmpvar_phold.bem_print_0();
bevt_33_tmpvar_phold = (BEC_5_5_6_BuildVisitPass12) (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_33_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 619 */ {
if (bevp_printVisitors.bevi_bool) /* Line: 620 */ {
bevt_34_tmpvar_phold = bevo_40;
bevt_34_tmpvar_phold.bem_print_0();
} /* Line: 621 */
bevt_35_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_1(bevp_printAst);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_35_tmpvar_phold);
} /* Line: 623 */
bevt_36_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_36_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 625 */ {
bevt_37_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 625 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_38_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_38_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_40_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_39_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 636 */
 else  /* Line: 625 */ {
break;
} /* Line: 625 */
} /* Line: 625 */
} /* Line: 625 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 646 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 646 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 650 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 651 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 653 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 655 */
} /* Line: 653 */
 else  /* Line: 646 */ {
break;
} /* Line: 646 */
} /* Line: 646 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_14_BuildCCallAssembler bem_cassemGet_0() {
return bevp_cassem;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cassemSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cassem = (BEC_5_14_BuildCCallAssembler) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printVisitorsGet_0() {
return bevp_printVisitors;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printVisitorsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printVisitors = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {61, 63, 64, 65, 66, 67, 68, 69, 70, 71, 75, 77, 78, 79, 80, 80, 83, 86, 87, 92, 93, 94, 94, 99, 99, 99, 99, 0, 99, 99, 0, 0, 0, 0, 0, 100, 100, 102, 102, 106, 106, 106, 106, 110, 110, 111, 111, 115, 116, 117, 117, 121, 122, 124, 125, 126, 128, 128, 129, 131, 132, 136, 136, 136, 137, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 140, 141, 141, 141, 142, 142, 142, 144, 149, 151, 152, 152, 152, 153, 153, 0, 153, 153, 154, 154, 155, 156, 156, 161, 161, 161, 161, 162, 164, 164, 164, 165, 165, 166, 166, 166, 168, 170, 170, 170, 170, 170, 170, 171, 172, 172, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 178, 178, 178, 179, 179, 179, 180, 180, 181, 181, 182, 184, 184, 185, 185, 186, 188, 188, 189, 189, 190, 192, 192, 193, 193, 194, 196, 196, 197, 197, 198, 200, 200, 201, 201, 202, 204, 204, 205, 205, 206, 208, 208, 209, 209, 210, 212, 212, 213, 213, 214, 216, 216, 217, 217, 218, 220, 220, 221, 221, 222, 224, 226, 226, 226, 227, 227, 228, 228, 229, 229, 230, 230, 231, 231, 231, 232, 232, 233, 233, 233, 233, 234, 234, 234, 234, 235, 235, 235, 235, 235, 236, 237, 238, 239, 240, 243, 243, 244, 246, 253, 253, 253, 253, 253, 254, 254, 255, 255, 258, 258, 258, 259, 259, 260, 260, 263, 264, 264, 0, 264, 264, 265, 265, 267, 268, 269, 271, 272, 272, 272, 273, 273, 275, 275, 276, 276, 277, 277, 278, 284, 285, 285, 285, 285, 285, 286, 286, 286, 286, 286, 287, 291, 292, 292, 292, 293, 294, 294, 294, 294, 295, 295, 295, 295, 296, 296, 296, 296, 296, 297, 297, 298, 0, 298, 298, 299, 302, 302, 302, 302, 302, 303, 303, 304, 0, 304, 304, 305, 310, 310, 310, 311, 312, 312, 312, 312, 312, 312, 319, 319, 323, 323, 324, 329, 329, 330, 331, 331, 332, 333, 333, 334, 335, 335, 336, 338, 338, 338, 340, 341, 343, 348, 349, 350, 351, 351, 352, 353, 354, 354, 354, 356, 358, 0, 358, 358, 359, 359, 360, 361, 362, 365, 0, 365, 365, 366, 366, 367, 368, 369, 370, 370, 375, 375, 376, 378, 380, 383, 383, 384, 384, 384, 385, 385, 385, 387, 387, 388, 388, 391, 392, 393, 394, 394, 394, 395, 396, 398, 399, 400, 400, 400, 401, 402, 406, 406, 407, 407, 408, 408, 408, 410, 410, 410, 413, 417, 418, 419, 421, 0, 421, 421, 422, 422, 423, 423, 424, 424, 424, 425, 425, 426, 426, 428, 428, 428, 429, 429, 429, 433, 434, 436, 436, 0, 0, 0, 437, 437, 438, 438, 438, 438, 438, 438, 438, 438, 440, 440, 441, 441, 443, 443, 443, 444, 444, 444, 449, 449, 451, 451, 452, 452, 452, 454, 454, 455, 455, 455, 457, 457, 458, 458, 458, 462, 462, 463, 464, 464, 464, 464, 464, 465, 467, 467, 471, 471, 471, 472, 473, 473, 474, 475, 477, 477, 477, 478, 479, 479, 480, 481, 483, 483, 487, 487, 487, 487, 488, 488, 488, 490, 490, 491, 491, 491, 491, 492, 494, 494, 494, 494, 494, 496, 496, 497, 497, 498, 501, 501, 501, 503, 505, 505, 506, 506, 506, 506, 507, 511, 512, 512, 513, 513, 514, 520, 520, 521, 522, 529, 529, 530, 532, 537, 538, 539, 540, 541, 542, 542, 544, 544, 544, 544, 545, 547, 547, 547, 547, 548, 548, 548, 549, 556, 556, 560, 560, 562, 562, 564, 564, 566, 566, 570, 570, 572, 575, 575, 577, 577, 580, 580, 582, 582, 585, 585, 587, 587, 590, 590, 592, 592, 595, 595, 597, 597, 600, 600, 602, 602, 605, 605, 607, 607, 610, 610, 612, 612, 615, 615, 617, 617, 618, 618, 621, 621, 623, 623, 625, 625, 625, 626, 628, 629, 630, 630, 631, 632, 632, 632, 633, 634, 635, 636, 642, 643, 644, 645, 645, 646, 646, 647, 648, 648, 649, 650, 650, 651, 653, 653, 654, 655, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 242, 247, 248, 249, 251, 254, 255, 257, 260, 264, 267, 271, 274, 275, 277, 278, 284, 285, 286, 287, 293, 294, 295, 296, 300, 301, 302, 303, 309, 310, 312, 313, 314, 318, 319, 320, 322, 323, 343, 344, 345, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 368, 487, 488, 489, 490, 495, 496, 497, 497, 500, 502, 503, 504, 506, 507, 508, 516, 517, 518, 519, 521, 523, 524, 525, 526, 527, 529, 530, 531, 534, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 580, 581, 583, 584, 585, 590, 591, 593, 594, 595, 600, 601, 603, 604, 605, 610, 611, 613, 614, 615, 620, 621, 623, 624, 625, 630, 631, 633, 634, 635, 640, 641, 643, 644, 645, 650, 651, 653, 654, 655, 660, 661, 663, 664, 665, 670, 671, 673, 674, 675, 680, 681, 684, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 725, 726, 729, 731, 732, 733, 734, 735, 736, 741, 742, 743, 745, 746, 747, 748, 753, 754, 755, 757, 758, 759, 759, 762, 764, 765, 766, 772, 773, 774, 775, 776, 777, 778, 780, 781, 783, 788, 789, 790, 791, 792, 793, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 858, 859, 860, 863, 865, 866, 867, 868, 869, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 885, 886, 886, 889, 891, 892, 899, 900, 901, 902, 903, 904, 909, 910, 910, 913, 915, 916, 929, 930, 933, 935, 936, 937, 938, 939, 940, 941, 951, 952, 966, 971, 972, 974, 979, 980, 981, 982, 984, 987, 988, 990, 993, 994, 996, 999, 1000, 1001, 1005, 1006, 1008, 1105, 1106, 1107, 1108, 1113, 1114, 1115, 1116, 1117, 1118, 1120, 1121, 1121, 1124, 1126, 1127, 1128, 1130, 1131, 1132, 1139, 1139, 1142, 1144, 1145, 1146, 1148, 1149, 1150, 1151, 1152, 1160, 1163, 1165, 1166, 1172, 1174, 1175, 1176, 1177, 1178, 1179, 1180, 1185, 1186, 1187, 1188, 1189, 1192, 1193, 1194, 1195, 1196, 1199, 1201, 1202, 1208, 1209, 1210, 1211, 1214, 1216, 1217, 1224, 1225, 1226, 1231, 1232, 1233, 1234, 1236, 1237, 1238, 1240, 1243, 1245, 1246, 1248, 1248, 1251, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262, 1264, 1265, 1267, 1268, 1269, 1271, 1272, 1273, 1281, 1282, 1285, 1287, 1289, 1292, 1296, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310, 1312, 1313, 1315, 1316, 1317, 1319, 1320, 1321, 1330, 1331, 1332, 1337, 1338, 1339, 1340, 1342, 1347, 1348, 1349, 1350, 1352, 1357, 1358, 1359, 1360, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1373, 1374, 1387, 1388, 1391, 1393, 1394, 1395, 1396, 1397, 1403, 1404, 1407, 1409, 1410, 1411, 1412, 1413, 1419, 1420, 1448, 1449, 1450, 1455, 1456, 1457, 1458, 1460, 1461, 1462, 1463, 1464, 1469, 1470, 1473, 1474, 1475, 1476, 1477, 1478, 1483, 1484, 1485, 1486, 1489, 1490, 1491, 1493, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1509, 1510, 1511, 1512, 1517, 1518, 1520, 1521, 1522, 1523, 1527, 1532, 1533, 1535, 1590, 1591, 1592, 1593, 1594, 1595, 1596, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1612, 1614, 1615, 1617, 1618, 1620, 1621, 1623, 1624, 1626, 1627, 1629, 1631, 1632, 1634, 1635, 1637, 1638, 1640, 1641, 1643, 1644, 1646, 1647, 1649, 1650, 1652, 1653, 1655, 1656, 1658, 1659, 1661, 1662, 1664, 1665, 1667, 1668, 1670, 1671, 1673, 1674, 1676, 1677, 1679, 1680, 1682, 1683, 1684, 1685, 1688, 1689, 1691, 1692, 1694, 1695, 1698, 1700, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1734, 1735, 1736, 1737, 1738, 1739, 1742, 1744, 1745, 1746, 1747, 1748, 1749, 1751, 1753, 1754, 1756, 1757, 1767, 1770, 1774, 1777, 1781, 1784, 1788, 1791, 1795, 1798, 1802, 1805, 1809, 1812, 1816, 1819, 1823, 1826, 1830, 1833, 1837, 1840, 1844, 1847, 1851, 1854, 1858, 1861, 1865, 1868, 1872, 1875, 1879, 1882, 1886, 1889, 1893, 1896, 1900, 1903, 1907, 1910, 1914, 1917, 1921, 1924, 1928, 1931, 1935, 1938, 1942, 1945, 1949, 1952, 1956, 1959, 1963, 1966, 1970, 1973, 1977, 1980, 1984, 1987, 1991, 1994, 1998, 2001, 2005, 2008, 2012, 2015, 2019, 2022, 2026, 2029, 2033, 2036, 2040, 2043, 2047, 2050, 2054, 2057, 2061, 2064, 2068, 2071, 2075, 2078, 2082, 2085, 2089, 2092, 2096, 2099, 2103, 2106, 2110, 2113, 2117, 2120, 2124, 2127, 2131, 2134, 2138, 2141, 2145, 2148, 2152, 2155, 2159, 2162, 2166, 2169, 2173, 2176, 2180, 2183, 2187, 2190, 2194, 2197, 2201, 2204, 2208, 2211, 2215};
/* BEGIN LINEINFO 
assign 1 61 208
new 0 61 208
assign 1 63 209
new 0 63 209
assign 1 64 210
new 0 64 210
assign 1 65 211
new 0 65 211
assign 1 66 212
new 0 66 212
assign 1 67 213
new 0 67 213
assign 1 68 214
new 0 68 214
assign 1 69 215
new 0 69 215
assign 1 70 216
new 0 70 216
assign 1 71 217
new 0 71 217
assign 1 75 218
new 0 75 218
assign 1 77 219
new 1 77 219
assign 1 78 220
ntypesGet 0 78 220
assign 1 79 221
twtokGet 0 79 221
assign 1 80 222
new 0 80 222
assign 1 80 223
new 1 80 223
assign 1 83 224
new 0 83 224
assign 1 86 225
new 0 86 225
assign 1 87 226
new 0 87 226
assign 1 92 227
new 0 92 227
assign 1 93 228
new 0 93 228
assign 1 94 229
new 0 94 229
assign 1 94 230
new 1 94 230
assign 1 99 242
def 1 99 247
assign 1 99 248
new 0 99 248
assign 1 99 249
equals 1 99 249
assign 1 0 251
assign 1 99 254
new 0 99 254
assign 1 99 255
ends 1 99 255
assign 1 0 257
assign 1 0 260
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 100 274
new 0 100 274
return 1 100 275
assign 1 102 277
new 0 102 277
return 1 102 278
assign 1 106 284
new 0 106 284
assign 1 106 285
new 0 106 285
assign 1 106 286
swap 2 106 286
return 1 106 287
assign 1 110 293
new 0 110 293
assign 1 110 294
argsGet 0 110 294
assign 1 111 295
main 1 111 295
return 1 111 296
assign 1 115 300
assign 1 116 301
new 1 116 301
assign 1 117 302
go 0 117 302
return 1 117 303
assign 1 121 309
new 0 121 309
config 0 122 310
assign 1 124 312
new 0 124 312
assign 1 125 313
doWhat 0 125 313
assign 1 126 314
new 0 126 314
assign 1 128 318
new 0 128 318
assign 1 128 319
add 1 128 319
assign 1 129 320
new 0 129 320
print 0 131 322
return 1 132 323
assign 1 136 343
nameGet 0 136 343
assign 1 136 344
new 0 136 344
assign 1 136 345
equals 1 136 345
assign 1 137 347
new 0 137 347
assign 1 137 348
add 1 137 348
assign 1 137 349
add 1 137 349
assign 1 137 350
add 1 137 350
assign 1 138 351
new 0 138 351
assign 1 138 352
add 1 138 352
assign 1 138 353
add 1 138 353
assign 1 139 354
new 0 139 354
assign 1 139 355
add 1 139 355
assign 1 139 356
add 1 139 356
assign 1 140 357
new 0 140 357
assign 1 140 358
add 1 140 358
assign 1 140 359
add 1 140 359
assign 1 140 360
add 1 140 360
assign 1 141 361
new 0 141 361
assign 1 141 362
add 1 141 362
assign 1 141 363
add 1 141 363
assign 1 142 364
new 0 142 364
assign 1 142 365
add 1 142 365
assign 1 142 366
add 1 142 366
return 1 144 368
assign 1 149 487
new 0 149 487
assign 1 151 488
new 0 151 488
assign 1 152 489
get 1 152 489
assign 1 152 490
def 1 152 495
assign 1 153 496
get 1 153 496
assign 1 153 497
iteratorGet 0 0 497
assign 1 153 500
hasNextGet 0 153 500
assign 1 153 502
nextGet 0 153 502
assign 1 154 503
has 1 154 503
assign 1 154 504
not 0 154 504
put 1 155 506
assign 1 156 507
new 1 156 507
addFile 1 156 508
assign 1 161 516
new 0 161 516
assign 1 161 517
nameGet 0 161 517
assign 1 161 518
new 0 161 518
assign 1 161 519
equals 1 161 519
preProcessorSet 1 162 521
assign 1 164 523
new 0 164 523
assign 1 164 524
get 1 164 524
assign 1 164 525
firstGet 0 164 525
assign 1 165 526
new 0 165 526
assign 1 165 527
has 1 165 527
assign 1 166 529
new 0 166 529
assign 1 166 530
get 1 166 530
assign 1 166 531
firstGet 0 166 531
assign 1 168 534
assign 1 170 536
new 0 170 536
assign 1 170 537
new 0 170 537
assign 1 170 538
get 2 170 538
assign 1 170 539
firstGet 0 170 539
assign 1 170 540
new 1 170 540
assign 1 170 541
pathGet 0 170 541
addStep 1 171 542
assign 1 172 543
new 0 172 543
addStep 1 172 544
assign 1 173 545
new 0 173 545
assign 1 173 546
new 0 173 546
assign 1 173 547
get 2 173 547
assign 1 173 548
firstGet 0 173 548
assign 1 173 549
new 1 173 549
assign 1 173 550
pathGet 0 173 550
assign 1 174 551
new 0 174 551
assign 1 174 552
new 0 174 552
assign 1 174 553
nameGet 0 174 553
assign 1 174 554
get 2 174 554
assign 1 174 555
firstGet 0 174 555
assign 1 174 556
new 1 174 556
assign 1 175 557
new 0 175 557
assign 1 175 558
nameGet 0 175 558
assign 1 175 559
get 2 175 559
assign 1 175 560
firstGet 0 175 560
assign 1 175 561
new 1 175 561
assign 1 176 562
new 0 176 562
assign 1 176 563
new 0 176 563
assign 1 176 564
get 2 176 564
assign 1 176 565
firstGet 0 176 565
assign 1 176 566
new 1 176 566
assign 1 178 567
new 0 178 567
assign 1 178 568
get 1 178 568
assign 1 178 569
firstGet 0 178 569
assign 1 179 570
new 0 179 570
assign 1 179 571
get 1 179 571
assign 1 179 572
firstGet 0 179 572
assign 1 180 573
new 0 180 573
assign 1 180 574
get 1 180 574
assign 1 181 575
undef 1 181 580
assign 1 182 581
new 0 182 581
assign 1 184 583
new 0 184 583
assign 1 184 584
get 1 184 584
assign 1 185 585
undef 1 185 590
assign 1 186 591
new 0 186 591
assign 1 188 593
new 0 188 593
assign 1 188 594
get 1 188 594
assign 1 189 595
undef 1 189 600
assign 1 190 601
new 0 190 601
assign 1 192 603
new 0 192 603
assign 1 192 604
get 1 192 604
assign 1 193 605
undef 1 193 610
assign 1 194 611
new 0 194 611
assign 1 196 613
new 0 196 613
assign 1 196 614
get 1 196 614
assign 1 197 615
undef 1 197 620
assign 1 198 621
new 0 198 621
assign 1 200 623
new 0 200 623
assign 1 200 624
get 1 200 624
assign 1 201 625
undef 1 201 630
assign 1 202 631
new 0 202 631
assign 1 204 633
new 0 204 633
assign 1 204 634
get 1 204 634
assign 1 205 635
undef 1 205 640
assign 1 206 641
new 0 206 641
assign 1 208 643
new 0 208 643
assign 1 208 644
get 1 208 644
assign 1 209 645
undef 1 209 650
assign 1 210 651
new 0 210 651
assign 1 212 653
new 0 212 653
assign 1 212 654
get 1 212 654
assign 1 213 655
undef 1 213 660
assign 1 214 661
new 0 214 661
assign 1 216 663
new 0 216 663
assign 1 216 664
get 1 216 664
assign 1 217 665
def 1 217 670
assign 1 218 671
firstGet 0 218 671
assign 1 220 673
new 0 220 673
assign 1 220 674
get 1 220 674
assign 1 221 675
def 1 221 680
assign 1 222 681
firstGet 0 222 681
assign 1 224 684
new 0 224 684
assign 1 226 686
new 0 226 686
assign 1 226 687
new 0 226 687
assign 1 226 688
isTrue 2 226 688
assign 1 227 689
new 0 227 689
assign 1 227 690
isTrue 1 227 690
assign 1 228 691
new 0 228 691
assign 1 228 692
isTrue 1 228 692
assign 1 229 693
new 0 229 693
assign 1 229 694
isTrue 1 229 694
assign 1 230 695
new 0 230 695
assign 1 230 696
isTrue 1 230 696
assign 1 231 697
new 0 231 697
assign 1 231 698
new 0 231 698
assign 1 231 699
isTrue 2 231 699
assign 1 232 700
new 0 232 700
assign 1 232 701
get 1 232 701
assign 1 233 702
new 0 233 702
assign 1 233 703
new 0 233 703
assign 1 233 704
get 2 233 704
assign 1 233 705
firstGet 0 233 705
assign 1 234 706
new 0 234 706
assign 1 234 707
new 0 234 707
assign 1 234 708
get 2 234 708
assign 1 234 709
firstGet 0 234 709
assign 1 235 710
new 0 235 710
assign 1 235 711
add 1 235 711
assign 1 235 712
new 0 235 712
assign 1 235 713
get 2 235 713
assign 1 235 714
firstGet 0 235 714
assign 1 236 715
new 0 236 715
assign 1 237 716
new 0 237 716
assign 1 238 717
new 0 238 717
assign 1 239 718
new 0 239 718
assign 1 240 719
new 0 240 719
assign 1 243 720
def 1 243 725
assign 1 244 726
firstGet 0 244 726
assign 1 246 729
new 0 246 729
assign 1 253 731
new 0 253 731
assign 1 253 732
add 1 253 732
assign 1 253 733
nameGet 0 253 733
assign 1 253 734
add 1 253 734
assign 1 253 735
get 1 253 735
assign 1 254 736
def 1 254 741
assign 1 255 742
orderedGet 0 255 742
addAll 1 255 743
assign 1 258 745
new 0 258 745
assign 1 258 746
add 1 258 746
assign 1 258 747
get 1 258 747
assign 1 259 748
def 1 259 753
assign 1 260 754
orderedGet 0 260 754
addAll 1 260 755
assign 1 263 757
new 0 263 757
assign 1 264 758
orderedGet 0 264 758
assign 1 264 759
iteratorGet 0 0 759
assign 1 264 762
hasNextGet 0 264 762
assign 1 264 764
nextGet 0 264 764
assign 1 265 765
new 1 265 765
addValue 1 265 766
assign 1 267 772
newlineGet 0 267 772
assign 1 268 773
assign 1 269 774
new 1 269 774
assign 1 271 775
copy 0 271 775
assign 1 272 776
fileGet 0 272 776
assign 1 272 777
existsGet 0 272 777
assign 1 272 778
not 0 272 778
assign 1 273 780
fileGet 0 273 780
makeDirs 0 273 781
assign 1 275 783
def 1 275 788
assign 1 276 789
new 1 276 789
assign 1 276 790
readerGet 0 276 790
assign 1 277 791
open 0 277 791
assign 1 277 792
readString 1 277 792
close 0 278 793
assign 1 284 807
classNameGet 0 284 807
assign 1 285 808
add 1 285 808
assign 1 285 809
new 0 285 809
assign 1 285 810
add 1 285 810
assign 1 285 811
toString 0 285 811
assign 1 285 812
add 1 285 812
assign 1 286 813
add 1 286 813
assign 1 286 814
new 0 286 814
assign 1 286 815
add 1 286 815
assign 1 286 816
toString 0 286 816
assign 1 286 817
add 1 286 817
return 1 287 818
assign 1 291 858
new 0 291 858
assign 1 292 859
classesGet 0 292 859
assign 1 292 860
valueIteratorGet 0 292 860
assign 1 292 863
hasNextGet 0 292 863
assign 1 293 865
nextGet 0 293 865
assign 1 294 866
shouldEmitGet 0 294 866
assign 1 294 867
heldGet 0 294 867
assign 1 294 868
fromFileGet 0 294 868
assign 1 294 869
has 1 294 869
assign 1 295 871
heldGet 0 295 871
assign 1 295 872
namepathGet 0 295 872
assign 1 295 873
toString 0 295 873
put 1 295 874
assign 1 296 875
usedByGet 0 296 875
assign 1 296 876
heldGet 0 296 876
assign 1 296 877
namepathGet 0 296 877
assign 1 296 878
toString 0 296 878
assign 1 296 879
get 1 296 879
assign 1 297 880
def 1 297 885
assign 1 298 886
iteratorGet 0 0 886
assign 1 298 889
hasNextGet 0 298 889
assign 1 298 891
nextGet 0 298 891
put 1 299 892
assign 1 302 899
subClassesGet 0 302 899
assign 1 302 900
heldGet 0 302 900
assign 1 302 901
namepathGet 0 302 901
assign 1 302 902
toString 0 302 902
assign 1 302 903
get 1 302 903
assign 1 303 904
def 1 303 909
assign 1 304 910
iteratorGet 0 0 910
assign 1 304 913
hasNextGet 0 304 913
assign 1 304 915
nextGet 0 304 915
put 1 305 916
assign 1 310 929
classesGet 0 310 929
assign 1 310 930
valueIteratorGet 0 310 930
assign 1 310 933
hasNextGet 0 310 933
assign 1 311 935
nextGet 0 311 935
assign 1 312 936
heldGet 0 312 936
assign 1 312 937
heldGet 0 312 937
assign 1 312 938
namepathGet 0 312 938
assign 1 312 939
toString 0 312 939
assign 1 312 940
has 1 312 940
shouldWriteSet 1 312 941
assign 1 319 951
new 0 319 951
return 1 319 952
assign 1 323 966
def 1 323 971
return 1 324 972
assign 1 329 974
def 1 329 979
assign 1 330 980
firstGet 0 330 980
assign 1 331 981
new 0 331 981
assign 1 331 982
equals 1 331 982
assign 1 332 984
new 1 332 984
assign 1 333 987
new 0 333 987
assign 1 333 988
equals 1 333 988
assign 1 334 990
new 1 334 990
assign 1 335 993
new 0 335 993
assign 1 335 994
equals 1 335 994
assign 1 336 996
new 1 336 996
assign 1 338 999
new 0 338 999
assign 1 338 1000
new 1 338 1000
throw 1 338 1001
dynConditionsAllSet 1 340 1005
return 1 341 1006
return 1 343 1008
assign 1 348 1105
now 0 348 1105
assign 1 349 1106
new 0 349 1106
assign 1 350 1107
emitterGet 0 350 1107
assign 1 351 1108
def 1 351 1113
assign 1 352 1114
new 4 352 1114
put 1 353 1115
assign 1 354 1116
new 0 354 1116
assign 1 354 1117
add 1 354 1117
print 0 354 1118
assign 1 356 1120
new 0 356 1120
assign 1 358 1121
iteratorGet 0 0 1121
assign 1 358 1124
hasNextGet 0 358 1124
assign 1 358 1126
nextGet 0 358 1126
assign 1 359 1127
has 1 359 1127
assign 1 359 1128
not 0 359 1128
put 1 360 1130
assign 1 361 1131
new 2 361 1131
addValue 1 362 1132
assign 1 365 1139
iteratorGet 0 0 1139
assign 1 365 1142
hasNextGet 0 365 1142
assign 1 365 1144
nextGet 0 365 1144
assign 1 366 1145
has 1 366 1145
assign 1 366 1146
not 0 366 1146
put 1 367 1148
assign 1 368 1149
new 2 368 1149
addValue 1 369 1150
assign 1 370 1151
libNameGet 0 370 1151
put 1 370 1152
assign 1 375 1160
iteratorGet 0 375 1160
assign 1 375 1163
hasNextGet 0 375 1163
assign 1 376 1165
nextGet 0 376 1165
doParse 1 378 1166
buildSyns 1 380 1172
assign 1 383 1174
now 0 383 1174
assign 1 383 1175
subtract 1 383 1175
assign 1 384 1176
new 0 384 1176
assign 1 384 1177
add 1 384 1177
print 0 384 1178
assign 1 385 1179
emitCommonGet 0 385 1179
assign 1 385 1180
def 1 385 1185
assign 1 387 1186
emitCommonGet 0 387 1186
doEmit 0 387 1187
assign 1 388 1188
new 0 388 1188
return 1 388 1189
setClassesToWrite 0 391 1192
libnameInfoGet 0 392 1193
assign 1 393 1194
new 1 393 1194
assign 1 394 1195
classesGet 0 394 1195
assign 1 394 1196
valueIteratorGet 0 394 1196
assign 1 394 1199
hasNextGet 0 394 1199
assign 1 395 1201
nextGet 0 395 1201
doEmit 1 396 1202
emitMain 0 398 1208
emitCUInit 0 399 1209
assign 1 400 1210
classesGet 0 400 1210
assign 1 400 1211
valueIteratorGet 0 400 1211
assign 1 400 1214
hasNextGet 0 400 1214
assign 1 401 1216
nextGet 0 401 1216
emitSyn 1 402 1217
assign 1 406 1224
now 0 406 1224
assign 1 406 1225
subtract 1 406 1225
assign 1 407 1226
def 1 407 1231
assign 1 408 1232
new 0 408 1232
assign 1 408 1233
add 1 408 1233
print 0 408 1234
assign 1 410 1236
new 0 410 1236
assign 1 410 1237
add 1 410 1237
print 0 410 1238
prepMake 1 413 1240
assign 1 417 1243
not 0 417 1243
make 1 418 1245
deployLibrary 1 419 1246
assign 1 421 1248
iteratorGet 0 0 1248
assign 1 421 1251
hasNextGet 0 421 1251
assign 1 421 1253
nextGet 0 421 1253
assign 1 422 1254
libnameInfoGet 0 422 1254
assign 1 422 1255
unitShlibGet 0 422 1255
assign 1 423 1256
emitPathGet 0 423 1256
assign 1 423 1257
copy 0 423 1257
assign 1 424 1258
stepsGet 0 424 1258
assign 1 424 1259
lastGet 0 424 1259
addStep 1 424 1260
assign 1 425 1261
fileGet 0 425 1261
assign 1 425 1262
existsGet 0 425 1262
assign 1 426 1264
fileGet 0 426 1264
delete 0 426 1265
assign 1 428 1267
fileGet 0 428 1267
assign 1 428 1268
existsGet 0 428 1268
assign 1 428 1269
not 0 428 1269
assign 1 429 1271
fileGet 0 429 1271
assign 1 429 1272
fileGet 0 429 1272
deployFile 2 429 1273
assign 1 433 1281
iteratorGet 0 433 1281
assign 1 434 1282
iteratorGet 0 434 1282
assign 1 436 1285
hasNextGet 0 436 1285
assign 1 436 1287
hasNextGet 0 436 1287
assign 1 0 1289
assign 1 0 1292
assign 1 0 1296
assign 1 437 1299
nextGet 0 437 1299
assign 1 437 1300
apNew 1 437 1300
assign 1 438 1301
emitPathGet 0 438 1301
assign 1 438 1302
copy 0 438 1302
assign 1 438 1303
toString 0 438 1303
assign 1 438 1304
new 0 438 1304
assign 1 438 1305
add 1 438 1305
assign 1 438 1306
nextGet 0 438 1306
assign 1 438 1307
add 1 438 1307
assign 1 438 1308
apNew 1 438 1308
assign 1 440 1309
fileGet 0 440 1309
assign 1 440 1310
existsGet 0 440 1310
assign 1 441 1312
fileGet 0 441 1312
delete 0 441 1313
assign 1 443 1315
fileGet 0 443 1315
assign 1 443 1316
existsGet 0 443 1316
assign 1 443 1317
not 0 443 1317
assign 1 444 1319
fileGet 0 444 1319
assign 1 444 1320
fileGet 0 444 1320
deployFile 2 444 1321
assign 1 449 1330
now 0 449 1330
assign 1 449 1331
subtract 1 449 1331
assign 1 451 1332
def 1 451 1337
assign 1 452 1338
new 0 452 1338
assign 1 452 1339
add 1 452 1339
print 0 452 1340
assign 1 454 1342
def 1 454 1347
assign 1 455 1348
new 0 455 1348
assign 1 455 1349
add 1 455 1349
print 0 455 1350
assign 1 457 1352
def 1 457 1357
assign 1 458 1358
new 0 458 1358
assign 1 458 1359
add 1 458 1359
print 0 458 1360
assign 1 462 1363
new 0 462 1363
print 0 462 1364
assign 1 463 1365
run 2 463 1365
assign 1 464 1366
new 0 464 1366
assign 1 464 1367
add 1 464 1367
assign 1 464 1368
new 0 464 1368
assign 1 464 1369
add 1 464 1369
print 0 464 1370
return 1 465 1371
assign 1 467 1373
new 0 467 1373
return 1 467 1374
assign 1 471 1387
justParsedGet 0 471 1387
assign 1 471 1388
valueIteratorGet 0 471 1388
assign 1 471 1391
hasNextGet 0 471 1391
assign 1 472 1393
nextGet 0 472 1393
assign 1 473 1394
heldGet 0 473 1394
libNameSet 1 473 1395
assign 1 474 1396
getSyn 2 474 1396
libNameSet 1 475 1397
assign 1 477 1403
justParsedGet 0 477 1403
assign 1 477 1404
valueIteratorGet 0 477 1404
assign 1 477 1407
hasNextGet 0 477 1407
assign 1 478 1409
nextGet 0 478 1409
assign 1 479 1410
heldGet 0 479 1410
assign 1 479 1411
synGet 0 479 1411
checkInheritance 2 480 1412
integrate 1 481 1413
assign 1 483 1419
new 0 483 1419
justParsedSet 1 483 1420
assign 1 487 1448
heldGet 0 487 1448
assign 1 487 1449
synGet 0 487 1449
assign 1 487 1450
def 1 487 1455
assign 1 488 1456
heldGet 0 488 1456
assign 1 488 1457
synGet 0 488 1457
return 1 488 1458
assign 1 490 1460
heldGet 0 490 1460
libNameSet 1 490 1461
assign 1 491 1462
heldGet 0 491 1462
assign 1 491 1463
extendsGet 0 491 1463
assign 1 491 1464
undef 1 491 1469
assign 1 492 1470
new 1 492 1470
assign 1 494 1473
classesGet 0 494 1473
assign 1 494 1474
heldGet 0 494 1474
assign 1 494 1475
extendsGet 0 494 1475
assign 1 494 1476
toString 0 494 1476
assign 1 494 1477
get 1 494 1477
assign 1 496 1478
def 1 496 1483
assign 1 497 1484
heldGet 0 497 1484
libNameSet 1 497 1485
assign 1 498 1486
getSyn 2 498 1486
assign 1 501 1489
heldGet 0 501 1489
assign 1 501 1490
extendsGet 0 501 1490
assign 1 501 1491
loadSyn 1 501 1491
assign 1 503 1493
new 2 503 1493
assign 1 505 1495
heldGet 0 505 1495
synSet 1 505 1496
assign 1 506 1497
heldGet 0 506 1497
assign 1 506 1498
namepathGet 0 506 1498
assign 1 506 1499
toString 0 506 1499
addSynClass 2 506 1500
return 1 507 1501
assign 1 511 1509
toString 0 511 1509
assign 1 512 1510
synClassesGet 0 512 1510
assign 1 512 1511
get 1 512 1511
assign 1 513 1512
def 1 513 1517
return 1 514 1518
assign 1 520 1520
emitterGet 0 520 1520
assign 1 520 1521
loadSyn 1 520 1521
addSynClass 2 521 1522
return 1 522 1523
assign 1 529 1527
undef 1 529 1532
assign 1 530 1533
new 1 530 1533
return 1 532 1535
assign 1 537 1590
new 1 537 1590
assign 1 538 1591
new 0 538 1591
assign 1 539 1592
emitterGet 0 539 1592
assign 1 540 1593
assign 1 541 1594
new 0 541 1594
assign 1 542 1595
shouldEmitGet 0 542 1595
put 1 542 1596
assign 1 544 1598
new 0 544 1598
assign 1 544 1599
toString 0 544 1599
assign 1 544 1600
add 1 544 1600
print 0 544 1601
assign 1 545 1602
assign 1 547 1603
fileGet 0 547 1603
assign 1 547 1604
readerGet 0 547 1604
assign 1 547 1605
open 0 547 1605
assign 1 547 1606
readBuffer 1 547 1606
assign 1 548 1607
fileGet 0 548 1607
assign 1 548 1608
readerGet 0 548 1608
close 0 548 1609
assign 1 549 1610
tokenize 1 549 1610
assign 1 556 1611
outermostGet 0 556 1611
nodify 2 556 1612
assign 1 560 1614
new 0 560 1614
echo 0 560 1615
assign 1 562 1617
new 0 562 1617
traverse 1 562 1618
assign 1 564 1620
new 0 564 1620
echo 0 564 1621
assign 1 566 1623
new 0 566 1623
traverse 1 566 1624
assign 1 570 1626
new 0 570 1626
echo 0 570 1627
contain 0 572 1629
assign 1 575 1631
new 0 575 1631
echo 0 575 1632
assign 1 577 1634
new 0 577 1634
traverse 1 577 1635
assign 1 580 1637
new 0 580 1637
echo 0 580 1638
assign 1 582 1640
new 0 582 1640
traverse 1 582 1641
assign 1 585 1643
new 0 585 1643
echo 0 585 1644
assign 1 587 1646
new 0 587 1646
traverse 1 587 1647
assign 1 590 1649
new 0 590 1649
echo 0 590 1650
assign 1 592 1652
new 0 592 1652
traverse 1 592 1653
assign 1 595 1655
new 0 595 1655
echo 0 595 1656
assign 1 597 1658
new 0 597 1658
traverse 1 597 1659
assign 1 600 1661
new 0 600 1661
echo 0 600 1662
assign 1 602 1664
new 0 602 1664
traverse 1 602 1665
assign 1 605 1667
new 0 605 1667
echo 0 605 1668
assign 1 607 1670
new 0 607 1670
traverse 1 607 1671
assign 1 610 1673
new 0 610 1673
echo 0 610 1674
assign 1 612 1676
new 0 612 1676
traverse 1 612 1677
assign 1 615 1679
new 0 615 1679
echo 0 615 1680
assign 1 617 1682
new 0 617 1682
print 0 617 1683
assign 1 618 1684
new 0 618 1684
traverse 1 618 1685
assign 1 621 1688
new 0 621 1688
print 0 621 1689
assign 1 623 1691
new 1 623 1691
traverse 1 623 1692
assign 1 625 1694
classesGet 0 625 1694
assign 1 625 1695
valueIteratorGet 0 625 1695
assign 1 625 1698
hasNextGet 0 625 1698
assign 1 626 1700
nextGet 0 626 1700
assign 1 628 1701
transUnitGet 0 628 1701
assign 1 629 1702
new 1 629 1702
assign 1 630 1703
TRANSUNITGet 0 630 1703
typenameSet 1 630 1704
assign 1 631 1705
new 0 631 1705
assign 1 632 1706
heldGet 0 632 1706
assign 1 632 1707
emitsGet 0 632 1707
emitsSet 1 632 1708
heldSet 1 633 1709
delete 0 634 1710
addValue 1 635 1711
copyLoc 1 636 1712
reInitContained 0 642 1734
assign 1 643 1735
containedGet 0 643 1735
assign 1 644 1736
new 0 644 1736
assign 1 645 1737
new 0 645 1737
assign 1 645 1738
crGet 0 645 1738
assign 1 646 1739
iteratorGet 0 646 1739
assign 1 646 1742
hasNextGet 0 646 1742
assign 1 647 1744
new 1 647 1744
assign 1 648 1745
nextGet 0 648 1745
heldSet 1 648 1746
nlcSet 1 649 1747
assign 1 650 1748
heldGet 0 650 1748
assign 1 650 1749
equals 1 650 1749
assign 1 651 1751
increment 0 651 1751
assign 1 653 1753
heldGet 0 653 1753
assign 1 653 1754
notEquals 1 653 1754
addValue 1 654 1756
containerSet 1 655 1757
return 1 0 1767
assign 1 0 1770
return 1 0 1774
assign 1 0 1777
return 1 0 1781
assign 1 0 1784
return 1 0 1788
assign 1 0 1791
return 1 0 1795
assign 1 0 1798
return 1 0 1802
assign 1 0 1805
return 1 0 1809
assign 1 0 1812
return 1 0 1816
assign 1 0 1819
return 1 0 1823
assign 1 0 1826
return 1 0 1830
assign 1 0 1833
return 1 0 1837
assign 1 0 1840
return 1 0 1844
assign 1 0 1847
return 1 0 1851
assign 1 0 1854
return 1 0 1858
assign 1 0 1861
return 1 0 1865
assign 1 0 1868
return 1 0 1872
assign 1 0 1875
return 1 0 1879
assign 1 0 1882
return 1 0 1886
assign 1 0 1889
return 1 0 1893
assign 1 0 1896
return 1 0 1900
assign 1 0 1903
return 1 0 1907
assign 1 0 1910
return 1 0 1914
assign 1 0 1917
return 1 0 1921
assign 1 0 1924
return 1 0 1928
assign 1 0 1931
return 1 0 1935
assign 1 0 1938
return 1 0 1942
assign 1 0 1945
return 1 0 1949
assign 1 0 1952
return 1 0 1956
assign 1 0 1959
return 1 0 1963
assign 1 0 1966
return 1 0 1970
assign 1 0 1973
return 1 0 1977
assign 1 0 1980
return 1 0 1984
assign 1 0 1987
return 1 0 1991
assign 1 0 1994
return 1 0 1998
assign 1 0 2001
return 1 0 2005
assign 1 0 2008
return 1 0 2012
assign 1 0 2015
return 1 0 2019
assign 1 0 2022
return 1 0 2026
assign 1 0 2029
return 1 0 2033
assign 1 0 2036
return 1 0 2040
assign 1 0 2043
return 1 0 2047
assign 1 0 2050
return 1 0 2054
assign 1 0 2057
return 1 0 2061
assign 1 0 2064
return 1 0 2068
assign 1 0 2071
return 1 0 2075
assign 1 0 2078
return 1 0 2082
assign 1 0 2085
return 1 0 2089
assign 1 0 2092
return 1 0 2096
assign 1 0 2099
return 1 0 2103
assign 1 0 2106
return 1 0 2110
assign 1 0 2113
return 1 0 2117
assign 1 0 2120
return 1 0 2124
assign 1 0 2127
return 1 0 2131
assign 1 0 2134
return 1 0 2138
assign 1 0 2141
return 1 0 2145
assign 1 0 2148
return 1 0 2152
assign 1 0 2155
return 1 0 2159
assign 1 0 2162
return 1 0 2166
assign 1 0 2169
return 1 0 2173
assign 1 0 2176
return 1 0 2180
assign 1 0 2183
return 1 0 2187
assign 1 0 2190
return 1 0 2194
assign 1 0 2197
return 1 0 2201
assign 1 0 2204
return 1 0 2208
assign 1 0 2211
assign 1 0 2215
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1380984085: return bem_printVisitorsGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 102223041: return bem_cassemGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1392066338: return bem_printVisitorsSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 113305294: return bem_cassemSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
}
