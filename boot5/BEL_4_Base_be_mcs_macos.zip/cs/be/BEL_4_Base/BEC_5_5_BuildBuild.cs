namespace be.BEL_4_Base {
/* IO:File: source/build/Build.be */
public class BEC_5_5_BuildBuild : BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
static BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_30 = {0x74,0x72,0x75,0x65};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_55 = {0x67,0x63,0x63};
private static byte[] bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_58, 9));
private static byte[] bels_59 = {};
private static byte[] bels_60 = {0x63};
private static byte[] bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_61, 8));
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_62, 7));
private static byte[] bels_63 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_64 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_65, 2));
private static byte[] bels_66 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_69 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_69, 19));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 31));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 31));
private static byte[] bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_72, 41));
private static byte[] bels_73 = {0x2F};
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_74, 31));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_76, 51));
private static byte[] bels_77 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_77, 14));
private static byte[] bels_78 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_78, 19));
private static byte[] bels_79 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_79, 9));
private static byte[] bels_80 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_80, 13));
private static byte[] bels_81 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_81, 2));
private static byte[] bels_82 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_82, 22));
private static byte[] bels_83 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_83, 3));
private static byte[] bels_84 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_84, 15));
private static byte[] bels_85 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_85, 4));
private static byte[] bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_86, 15));
private static byte[] bels_87 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_87, 5));
private static byte[] bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_88, 15));
private static byte[] bels_89 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_89, 6));
private static byte[] bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_4_6_TextString bevo_36 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_90, 15));
private static byte[] bels_91 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_91, 7));
private static byte[] bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_4_6_TextString bevo_38 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_92, 15));
private static byte[] bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_93, 8));
private static byte[] bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_94, 15));
private static byte[] bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_41 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_95, 9));
private static byte[] bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_96, 15));
private static byte[] bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_43 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_97, 10));
private static byte[] bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_4_6_TextString bevo_44 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_98, 15));
private static byte[] bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_45 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_99, 11));
private static byte[] bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_4_6_TextString bevo_46 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_100, 16));
private static byte[] bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_47 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_101, 12));
private static byte[] bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_4_6_TextString bevo_48 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_102, 16));
private static byte[] bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_49 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_103, 13));
private static byte[] bels_104 = {0x20};
private static BEC_4_6_TextString bevo_50 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_104, 1));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_4_6_TextString bevo_51 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_105, 16));
public static new BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printSteps;
public BEC_5_4_LogicBool bevp_printPlaces;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_printAllAst;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_LogicBool bevp_ownProcess;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_5_9_BuildConstants) (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_4_9_TextTokenizer) (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_6_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 104 */
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_main_0() {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_6_10_SystemParameters) (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_go_0() {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_5_4_LogicBool bevl_buildFailed = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 128 */ {
bevp_buildMessage = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_6));
} /* Line: 131 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 136 */
if (bevp_printSteps.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 139 */
return bevl_whatResult;
} /*method end*/
public virtual BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 151 */
return beva_addTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_config_0() {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_9_10_ContainerLinkedList bevl_pacm = null;
BEC_4_6_TextString bevl_pa = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_111_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_112_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_4_IOFile bevt_118_tmpvar_phold = null;
BEC_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_4_IOFile bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
bevl_bfiles = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_15));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 162 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 162 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 165 */
} /* Line: 163 */
 else  /* Line: 162 */ {
break;
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
bevt_13_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 171 */
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_17));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_18));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_19));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 175 */
 else  /* Line: 176 */ {
bevp_exeName = bevp_libName;
} /* Line: 177 */
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_20));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_21));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_23));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_24));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_25));
bevt_36_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_26));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_27));
bevt_44_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_28));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_29));
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_30));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_31));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_32));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_63_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_67_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_69_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 224 */
bevt_71_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 228 */
bevt_73_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 232 */
 else  /* Line: 233 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 234 */
bevt_75_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_44));
bevt_76_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_45));
bevt_78_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_iteratorGet_0();
while (true)
 /* Line: 243 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 243 */ {
bevl_pa = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 244 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
} /* Line: 243 */
bevt_86_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_52));
bevt_90_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_54));
bevt_94_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_55));
bevt_92_tmpvar_phold = bevp_params.bem_get_2(bevt_93_tmpvar_phold, bevt_94_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_92_tmpvar_phold.bem_firstGet_0();
bevt_96_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_56));
bevt_97_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_57));
bevt_95_tmpvar_phold = bevp_params.bem_get_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_95_tmpvar_phold.bem_firstGet_0();
bevt_100_tmpvar_phold = bevo_10;
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_101_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_59));
bevt_98_tmpvar_phold = bevp_params.bem_get_2(bevt_99_tmpvar_phold, bevt_101_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 263 */
 else  /* Line: 264 */ {
bevl_outLang = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_60));
} /* Line: 265 */
bevt_105_tmpvar_phold = bevo_11;
bevt_104_tmpvar_phold = bevl_outLang.bem_add_1(bevt_105_tmpvar_phold);
bevt_106_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_add_1(bevt_106_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_103_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_108_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_108_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 274 */
bevt_110_tmpvar_phold = bevo_12;
bevt_109_tmpvar_phold = bevl_outLang.bem_add_1(bevt_110_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_109_tmpvar_phold);
if (bevl_langSources == null) {
bevt_111_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_111_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_111_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_112_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_112_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 279 */
bevp_toBuild = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_113_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 283 */ {
bevt_114_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 283 */ {
bevl_istr = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_115_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_115_tmpvar_phold);
} /* Line: 284 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_118_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_existsGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bem_not_0();
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 291 */ {
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_119_tmpvar_phold.bem_makeDirs_0();
} /* Line: 292 */
if (bevp_emitFileHeader == null) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_121_tmpvar_phold = (BEC_2_4_IOFile) (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_121_tmpvar_phold.bem_readerGet_0();
bevt_122_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_122_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 297 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_63));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_64));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 311 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 311 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 323 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 324 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 313 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 331 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_emitCs_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 342 */ {
return bevp_emitCommon;
} /* Line: 343 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 350 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 350 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(49, bels_68));
bevt_8_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 357 */
} /* Line: 350 */
} /* Line: 350 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 360 */
return null;
} /*method end*/
public virtual BEC_4_3_MathInt bem_doWhat_0() {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (BEC_5_8_BuildEmitData) (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 370 */ {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 373 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 374 */
} /* Line: 373 */
bevl_ulibs = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 379 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 379 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 383 */
} /* Line: 380 */
 else  /* Line: 379 */ {
break;
} /* Line: 379 */
} /* Line: 379 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 386 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 386 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 391 */
} /* Line: 387 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
if (bevp_parse.bevi_bool) /* Line: 394 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 396 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 399 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 401 */
bevt_15_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 405 */ {
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
} /* Line: 406 */
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 411 */
if (bevp_doEmit.bevi_bool) /* Line: 413 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 417 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 417 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 419 */
 else  /* Line: 417 */ {
break;
} /* Line: 417 */
} /* Line: 417 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 423 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 425 */
 else  /* Line: 423 */ {
break;
} /* Line: 423 */
} /* Line: 423 */
} /* Line: 423 */
bevt_26_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 431 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 434 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 436 */
if (bevp_make.bevi_bool) /* Line: 439 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 440 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 443 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 444 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 448 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 449 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 451 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 452 */
} /* Line: 451 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
} /* Line: 444 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 459 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 459 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 459 */
 else  /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 459 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_73));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 463 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 464 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 466 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 467 */
} /* Line: 466 */
 else  /* Line: 459 */ {
break;
} /* Line: 459 */
} /* Line: 459 */
} /* Line: 459 */
} /* Line: 440 */
bevt_64_tmpvar_phold = (BEC_4_8_TimeInterval) (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 475 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 481 */
if (bevp_run.bevi_bool) /* Line: 484 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 488 */
bevt_79_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 494 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 498 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 500 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 500 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 504 */
 else  /* Line: 500 */ {
break;
} /* Line: 500 */
} /* Line: 500 */
bevt_6_tmpvar_phold = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 510 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 511 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 515 */
 else  /* Line: 516 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 521 */
 else  /* Line: 522 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 524 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 526 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 536 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 537 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 552 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 553 */
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 566 */ {
if (bevp_printSteps.bevi_bool) /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 567 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 567 */ {
bevt_4_tmpvar_phold = bevo_26;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 568 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 581 */ {
bevt_11_tmpvar_phold = bevo_27;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 582 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 585 */ {
bevt_13_tmpvar_phold = bevo_28;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 587 */
if (bevp_printSteps.bevi_bool) /* Line: 590 */ {
bevt_15_tmpvar_phold = bevo_29;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 591 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 594 */ {
bevt_17_tmpvar_phold = bevo_30;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 596 */
if (bevp_printSteps.bevi_bool) /* Line: 598 */ {
bevt_19_tmpvar_phold = bevo_31;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 599 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 604 */ {
bevt_21_tmpvar_phold = bevo_32;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 606 */
if (bevp_printSteps.bevi_bool) /* Line: 609 */ {
bevt_23_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 610 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 613 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 615 */
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_27_tmpvar_phold = bevo_35;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 619 */
bevt_28_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 622 */ {
bevt_29_tmpvar_phold = bevo_36;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 624 */
if (bevp_printSteps.bevi_bool) /* Line: 627 */ {
bevt_31_tmpvar_phold = bevo_37;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 628 */
bevt_32_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 631 */ {
bevt_33_tmpvar_phold = bevo_38;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 633 */
if (bevp_printSteps.bevi_bool) /* Line: 636 */ {
bevt_35_tmpvar_phold = bevo_39;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 637 */
bevt_36_tmpvar_phold = (BEC_5_5_5_BuildVisitPass7) (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 640 */ {
bevt_37_tmpvar_phold = bevo_40;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 642 */
if (bevp_printSteps.bevi_bool) /* Line: 645 */ {
bevt_39_tmpvar_phold = bevo_41;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 646 */
bevt_40_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 649 */ {
bevt_41_tmpvar_phold = bevo_42;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 651 */
if (bevp_printSteps.bevi_bool) /* Line: 654 */ {
bevt_43_tmpvar_phold = bevo_43;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 655 */
bevt_44_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 658 */ {
bevt_45_tmpvar_phold = bevo_44;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 660 */
if (bevp_printSteps.bevi_bool) /* Line: 663 */ {
bevt_47_tmpvar_phold = bevo_45;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 664 */
bevt_48_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 667 */ {
bevt_49_tmpvar_phold = bevo_46;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 669 */
if (bevp_printSteps.bevi_bool) /* Line: 671 */ {
bevt_51_tmpvar_phold = bevo_47;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 672 */
bevt_52_tmpvar_phold = (BEC_5_5_6_BuildVisitPass11) (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 675 */ {
bevt_53_tmpvar_phold = bevo_48;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 677 */
if (bevp_printSteps.bevi_bool) /* Line: 680 */ {
bevt_55_tmpvar_phold = bevo_49;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_50;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 682 */
bevt_57_tmpvar_phold = (BEC_5_5_6_BuildVisitPass12) (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 685 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 685 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 685 */ {
bevt_58_tmpvar_phold = bevo_51;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 687 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 689 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 689 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 700 */
 else  /* Line: 689 */ {
break;
} /* Line: 689 */
} /* Line: 689 */
} /* Line: 689 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 710 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 710 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 714 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 715 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 717 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 719 */
} /* Line: 717 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printPlacesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printAllAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ownProcessSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 83, 86, 89, 90, 95, 96, 97, 98, 98, 103, 103, 103, 103, 0, 103, 103, 0, 0, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 110, 114, 114, 115, 115, 119, 120, 121, 121, 125, 126, 127, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 149, 149, 149, 149, 150, 150, 150, 151, 151, 151, 153, 158, 160, 161, 161, 161, 162, 162, 0, 162, 162, 163, 163, 164, 165, 165, 170, 170, 170, 170, 171, 173, 173, 173, 174, 174, 175, 175, 175, 177, 179, 179, 179, 179, 179, 179, 180, 181, 181, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 188, 188, 188, 189, 189, 189, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 230, 231, 231, 232, 234, 236, 236, 236, 237, 237, 237, 238, 238, 239, 239, 240, 241, 241, 242, 242, 242, 242, 0, 0, 0, 243, 0, 243, 243, 244, 247, 247, 248, 248, 249, 249, 250, 250, 250, 251, 251, 252, 252, 252, 252, 253, 253, 253, 253, 254, 254, 254, 254, 254, 255, 256, 257, 258, 259, 262, 262, 263, 265, 272, 272, 272, 272, 272, 273, 273, 274, 274, 277, 277, 277, 278, 278, 279, 279, 282, 283, 283, 0, 283, 283, 284, 284, 286, 287, 288, 290, 291, 291, 291, 292, 292, 294, 294, 295, 295, 296, 296, 297, 303, 304, 304, 304, 304, 304, 305, 305, 305, 305, 305, 306, 310, 311, 311, 311, 312, 313, 313, 313, 313, 314, 314, 314, 314, 315, 315, 315, 315, 315, 316, 316, 317, 0, 317, 317, 318, 321, 321, 321, 321, 321, 322, 322, 323, 0, 323, 323, 324, 329, 329, 329, 330, 331, 331, 331, 331, 331, 331, 338, 338, 342, 342, 343, 348, 348, 349, 350, 350, 351, 352, 352, 353, 354, 354, 355, 357, 357, 357, 359, 360, 362, 367, 368, 369, 370, 370, 371, 372, 374, 374, 374, 377, 379, 0, 379, 379, 380, 380, 381, 382, 383, 386, 0, 386, 386, 387, 387, 388, 389, 390, 391, 391, 396, 396, 397, 399, 401, 404, 404, 406, 406, 406, 408, 408, 408, 410, 410, 411, 411, 414, 415, 417, 417, 417, 418, 419, 421, 422, 423, 423, 423, 424, 425, 429, 429, 430, 430, 431, 431, 431, 433, 433, 433, 436, 440, 441, 442, 444, 0, 444, 444, 445, 445, 446, 446, 447, 447, 447, 448, 448, 449, 449, 451, 451, 451, 452, 452, 452, 456, 457, 459, 459, 0, 0, 0, 460, 460, 461, 461, 461, 461, 461, 461, 461, 461, 463, 463, 464, 464, 466, 466, 466, 467, 467, 467, 472, 472, 474, 474, 475, 475, 475, 477, 477, 478, 478, 478, 480, 480, 481, 481, 481, 485, 485, 486, 487, 487, 487, 487, 487, 488, 490, 490, 494, 494, 494, 495, 496, 496, 497, 498, 500, 500, 500, 501, 502, 502, 503, 504, 506, 506, 510, 510, 510, 510, 511, 511, 511, 513, 513, 514, 514, 514, 514, 515, 517, 517, 517, 517, 517, 519, 519, 520, 520, 521, 524, 524, 524, 526, 528, 528, 529, 529, 529, 529, 530, 534, 535, 535, 536, 536, 537, 543, 543, 544, 545, 552, 552, 553, 555, 560, 561, 562, 563, 564, 565, 565, 0, 0, 0, 568, 568, 568, 568, 570, 572, 572, 572, 572, 573, 573, 573, 574, 582, 582, 584, 584, 586, 586, 587, 587, 591, 591, 593, 593, 595, 595, 596, 596, 599, 599, 602, 602, 603, 605, 605, 606, 606, 610, 610, 612, 612, 614, 614, 615, 615, 619, 619, 621, 621, 623, 623, 624, 624, 628, 628, 630, 630, 632, 632, 633, 633, 637, 637, 639, 639, 641, 641, 642, 642, 646, 646, 648, 648, 650, 650, 651, 651, 655, 655, 657, 657, 659, 659, 660, 660, 664, 664, 666, 666, 668, 668, 669, 669, 672, 672, 674, 674, 676, 676, 677, 677, 681, 681, 682, 682, 684, 684, 0, 0, 0, 686, 686, 687, 687, 689, 689, 689, 690, 692, 693, 694, 694, 695, 696, 696, 696, 697, 698, 699, 700, 706, 707, 708, 709, 709, 710, 710, 711, 712, 712, 713, 714, 714, 715, 717, 717, 718, 719, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 275, 280, 281, 282, 284, 287, 288, 290, 293, 297, 300, 304, 307, 308, 310, 311, 317, 318, 319, 320, 326, 327, 328, 329, 333, 334, 335, 336, 344, 345, 346, 348, 349, 350, 354, 355, 356, 357, 358, 361, 365, 368, 372, 374, 394, 395, 396, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 419, 554, 555, 556, 557, 562, 563, 564, 564, 567, 569, 570, 571, 573, 574, 575, 583, 584, 585, 586, 588, 590, 591, 592, 593, 594, 596, 597, 598, 601, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 652, 653, 655, 656, 657, 662, 663, 665, 666, 667, 672, 673, 675, 676, 677, 682, 683, 685, 686, 687, 692, 693, 695, 696, 697, 702, 703, 705, 706, 707, 712, 713, 715, 716, 717, 722, 723, 725, 726, 727, 732, 733, 735, 736, 737, 742, 743, 745, 746, 747, 752, 753, 756, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 776, 777, 778, 780, 783, 787, 790, 790, 793, 795, 796, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 837, 838, 841, 843, 844, 845, 846, 847, 848, 853, 854, 855, 857, 858, 859, 860, 865, 866, 867, 869, 870, 871, 871, 874, 876, 877, 878, 884, 885, 886, 887, 888, 889, 890, 892, 893, 895, 900, 901, 902, 903, 904, 905, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 970, 971, 972, 975, 977, 978, 979, 980, 981, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 997, 998, 998, 1001, 1003, 1004, 1011, 1012, 1013, 1014, 1015, 1016, 1021, 1022, 1022, 1025, 1027, 1028, 1041, 1042, 1045, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1063, 1064, 1078, 1083, 1084, 1086, 1091, 1092, 1093, 1094, 1096, 1099, 1100, 1102, 1105, 1106, 1108, 1111, 1112, 1113, 1117, 1118, 1120, 1217, 1218, 1219, 1220, 1225, 1226, 1227, 1229, 1230, 1231, 1234, 1235, 1235, 1238, 1240, 1241, 1242, 1244, 1245, 1246, 1253, 1253, 1256, 1258, 1259, 1260, 1262, 1263, 1264, 1265, 1266, 1274, 1277, 1279, 1280, 1286, 1288, 1289, 1291, 1292, 1293, 1295, 1296, 1301, 1302, 1303, 1304, 1305, 1308, 1309, 1310, 1311, 1314, 1316, 1317, 1323, 1324, 1325, 1326, 1329, 1331, 1332, 1339, 1340, 1341, 1346, 1347, 1348, 1349, 1351, 1352, 1353, 1355, 1358, 1360, 1361, 1363, 1363, 1366, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1377, 1379, 1380, 1382, 1383, 1384, 1386, 1387, 1388, 1396, 1397, 1400, 1402, 1404, 1407, 1411, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1427, 1428, 1430, 1431, 1432, 1434, 1435, 1436, 1445, 1446, 1447, 1452, 1453, 1454, 1455, 1457, 1462, 1463, 1464, 1465, 1467, 1472, 1473, 1474, 1475, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1488, 1489, 1502, 1503, 1506, 1508, 1509, 1510, 1511, 1512, 1518, 1519, 1522, 1524, 1525, 1526, 1527, 1528, 1534, 1535, 1563, 1564, 1565, 1570, 1571, 1572, 1573, 1575, 1576, 1577, 1578, 1579, 1584, 1585, 1588, 1589, 1590, 1591, 1592, 1593, 1598, 1599, 1600, 1601, 1604, 1605, 1606, 1608, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1624, 1625, 1626, 1627, 1632, 1633, 1635, 1636, 1637, 1638, 1642, 1647, 1648, 1650, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1738, 1742, 1745, 1749, 1750, 1751, 1752, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1764, 1765, 1767, 1768, 1770, 1771, 1772, 1773, 1776, 1777, 1779, 1780, 1782, 1783, 1784, 1785, 1788, 1789, 1791, 1792, 1793, 1795, 1796, 1797, 1798, 1801, 1802, 1804, 1805, 1807, 1808, 1809, 1810, 1813, 1814, 1816, 1817, 1819, 1820, 1821, 1822, 1825, 1826, 1828, 1829, 1831, 1832, 1833, 1834, 1837, 1838, 1840, 1841, 1843, 1844, 1845, 1846, 1849, 1850, 1852, 1853, 1855, 1856, 1857, 1858, 1861, 1862, 1864, 1865, 1867, 1868, 1869, 1870, 1873, 1874, 1876, 1877, 1879, 1880, 1881, 1882, 1885, 1886, 1888, 1889, 1891, 1892, 1893, 1894, 1897, 1898, 1899, 1900, 1902, 1903, 1905, 1909, 1912, 1916, 1917, 1918, 1919, 1921, 1922, 1925, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1961, 1962, 1963, 1964, 1965, 1966, 1969, 1971, 1972, 1973, 1974, 1975, 1976, 1978, 1980, 1981, 1983, 1984, 1994, 1997, 2001, 2004, 2008, 2011, 2015, 2018, 2022, 2025, 2029, 2032, 2036, 2039, 2043, 2046, 2050, 2053, 2057, 2060, 2064, 2067, 2071, 2074, 2078, 2081, 2085, 2088, 2092, 2095, 2099, 2102, 2106, 2109, 2113, 2116, 2120, 2123, 2127, 2130, 2134, 2137, 2141, 2144, 2148, 2151, 2155, 2158, 2162, 2165, 2169, 2172, 2176, 2179, 2183, 2186, 2190, 2193, 2197, 2200, 2204, 2207, 2211, 2214, 2218, 2221, 2225, 2228, 2232, 2235, 2239, 2242, 2246, 2249, 2253, 2256, 2260, 2263, 2267, 2270, 2274, 2277, 2281, 2284, 2288, 2291, 2295, 2298, 2302, 2305, 2309, 2312, 2316, 2319, 2323, 2326, 2330, 2333, 2337, 2340, 2344, 2347, 2351, 2354, 2358, 2361, 2365, 2368, 2372, 2375, 2379, 2382, 2386, 2389, 2393, 2396, 2400, 2403, 2407, 2410, 2414, 2417, 2421, 2424, 2428, 2431, 2435, 2438, 2442, 2445, 2449, 2452, 2456, 2459, 2463};
/* BEGIN LINEINFO 
assign 1 61 238
new 0 61 238
assign 1 63 239
new 0 63 239
assign 1 64 240
new 0 64 240
assign 1 65 241
new 0 65 241
assign 1 66 242
new 0 66 242
assign 1 68 243
new 0 68 243
assign 1 69 244
new 0 69 244
assign 1 70 245
new 0 70 245
assign 1 71 246
new 0 71 246
assign 1 72 247
new 0 72 247
assign 1 73 248
new 0 73 248
assign 1 74 249
new 0 74 249
assign 1 78 250
new 0 78 250
assign 1 80 251
new 1 80 251
assign 1 81 252
ntypesGet 0 81 252
assign 1 82 253
twtokGet 0 82 253
assign 1 83 254
new 0 83 254
assign 1 83 255
new 1 83 255
assign 1 86 256
new 0 86 256
assign 1 89 257
new 0 89 257
assign 1 90 258
new 0 90 258
assign 1 95 259
new 0 95 259
assign 1 96 260
new 0 96 260
assign 1 97 261
new 0 97 261
assign 1 98 262
new 0 98 262
assign 1 98 263
new 1 98 263
assign 1 103 275
def 1 103 280
assign 1 103 281
new 0 103 281
assign 1 103 282
equals 1 103 282
assign 1 0 284
assign 1 103 287
new 0 103 287
assign 1 103 288
ends 1 103 288
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 0 300
assign 1 0 304
assign 1 104 307
new 0 104 307
return 1 104 308
assign 1 106 310
new 0 106 310
return 1 106 311
assign 1 110 317
new 0 110 317
assign 1 110 318
new 0 110 318
assign 1 110 319
swap 2 110 319
return 1 110 320
assign 1 114 326
new 0 114 326
assign 1 114 327
argsGet 0 114 327
assign 1 115 328
main 1 115 328
return 1 115 329
assign 1 119 333
assign 1 120 334
new 1 120 334
assign 1 121 335
go 0 121 335
return 1 121 336
assign 1 125 344
new 0 125 344
config 0 126 345
assign 1 127 346
new 0 127 346
assign 1 129 348
new 0 129 348
assign 1 130 349
doWhat 0 130 349
assign 1 131 350
new 0 131 350
assign 1 133 354
toString 0 133 354
assign 1 134 355
new 0 134 355
assign 1 135 356
new 0 135 356
assign 1 135 357
add 1 135 357
assign 1 136 358
new 0 136 358
assign 1 0 361
assign 1 0 365
assign 1 0 368
print 0 139 372
return 1 141 374
assign 1 145 394
nameGet 0 145 394
assign 1 145 395
new 0 145 395
assign 1 145 396
equals 1 145 396
assign 1 146 398
new 0 146 398
assign 1 146 399
add 1 146 399
assign 1 146 400
add 1 146 400
assign 1 146 401
add 1 146 401
assign 1 147 402
new 0 147 402
assign 1 147 403
add 1 147 403
assign 1 147 404
add 1 147 404
assign 1 148 405
new 0 148 405
assign 1 148 406
add 1 148 406
assign 1 148 407
add 1 148 407
assign 1 149 408
new 0 149 408
assign 1 149 409
add 1 149 409
assign 1 149 410
add 1 149 410
assign 1 149 411
add 1 149 411
assign 1 150 412
new 0 150 412
assign 1 150 413
add 1 150 413
assign 1 150 414
add 1 150 414
assign 1 151 415
new 0 151 415
assign 1 151 416
add 1 151 416
assign 1 151 417
add 1 151 417
return 1 153 419
assign 1 158 554
new 0 158 554
assign 1 160 555
new 0 160 555
assign 1 161 556
get 1 161 556
assign 1 161 557
def 1 161 562
assign 1 162 563
get 1 162 563
assign 1 162 564
iteratorGet 0 0 564
assign 1 162 567
hasNextGet 0 162 567
assign 1 162 569
nextGet 0 162 569
assign 1 163 570
has 1 163 570
assign 1 163 571
not 0 163 571
put 1 164 573
assign 1 165 574
new 1 165 574
addFile 1 165 575
assign 1 170 583
new 0 170 583
assign 1 170 584
nameGet 0 170 584
assign 1 170 585
new 0 170 585
assign 1 170 586
equals 1 170 586
preProcessorSet 1 171 588
assign 1 173 590
new 0 173 590
assign 1 173 591
get 1 173 591
assign 1 173 592
firstGet 0 173 592
assign 1 174 593
new 0 174 593
assign 1 174 594
has 1 174 594
assign 1 175 596
new 0 175 596
assign 1 175 597
get 1 175 597
assign 1 175 598
firstGet 0 175 598
assign 1 177 601
assign 1 179 603
new 0 179 603
assign 1 179 604
new 0 179 604
assign 1 179 605
get 2 179 605
assign 1 179 606
firstGet 0 179 606
assign 1 179 607
new 1 179 607
assign 1 179 608
pathGet 0 179 608
addStep 1 180 609
assign 1 181 610
new 0 181 610
addStep 1 181 611
assign 1 182 612
new 0 182 612
assign 1 182 613
new 0 182 613
assign 1 182 614
get 2 182 614
assign 1 182 615
firstGet 0 182 615
assign 1 182 616
new 1 182 616
assign 1 182 617
pathGet 0 182 617
assign 1 183 618
new 0 183 618
assign 1 183 619
new 0 183 619
assign 1 183 620
nameGet 0 183 620
assign 1 183 621
get 2 183 621
assign 1 183 622
firstGet 0 183 622
assign 1 183 623
new 1 183 623
assign 1 184 624
new 0 184 624
assign 1 184 625
nameGet 0 184 625
assign 1 184 626
get 2 184 626
assign 1 184 627
firstGet 0 184 627
assign 1 184 628
new 1 184 628
assign 1 185 629
new 0 185 629
assign 1 185 630
new 0 185 630
assign 1 185 631
get 2 185 631
assign 1 185 632
firstGet 0 185 632
assign 1 185 633
new 1 185 633
assign 1 186 634
new 0 186 634
assign 1 186 635
new 0 186 635
assign 1 186 636
get 2 186 636
assign 1 186 637
firstGet 0 186 637
assign 1 186 638
new 1 186 638
assign 1 188 639
new 0 188 639
assign 1 188 640
get 1 188 640
assign 1 188 641
firstGet 0 188 641
assign 1 189 642
new 0 189 642
assign 1 189 643
get 1 189 643
assign 1 189 644
firstGet 0 189 644
assign 1 190 645
new 0 190 645
assign 1 190 646
get 1 190 646
assign 1 191 647
undef 1 191 652
assign 1 192 653
new 0 192 653
assign 1 194 655
new 0 194 655
assign 1 194 656
get 1 194 656
assign 1 195 657
undef 1 195 662
assign 1 196 663
new 0 196 663
assign 1 198 665
new 0 198 665
assign 1 198 666
get 1 198 666
assign 1 199 667
undef 1 199 672
assign 1 200 673
new 0 200 673
assign 1 202 675
new 0 202 675
assign 1 202 676
get 1 202 676
assign 1 203 677
undef 1 203 682
assign 1 204 683
new 0 204 683
assign 1 206 685
new 0 206 685
assign 1 206 686
get 1 206 686
assign 1 207 687
undef 1 207 692
assign 1 208 693
new 0 208 693
assign 1 210 695
new 0 210 695
assign 1 210 696
get 1 210 696
assign 1 211 697
undef 1 211 702
assign 1 212 703
new 0 212 703
assign 1 214 705
new 0 214 705
assign 1 214 706
get 1 214 706
assign 1 215 707
undef 1 215 712
assign 1 216 713
new 0 216 713
assign 1 218 715
new 0 218 715
assign 1 218 716
get 1 218 716
assign 1 219 717
undef 1 219 722
assign 1 220 723
new 0 220 723
assign 1 222 725
new 0 222 725
assign 1 222 726
get 1 222 726
assign 1 223 727
undef 1 223 732
assign 1 224 733
new 0 224 733
assign 1 226 735
new 0 226 735
assign 1 226 736
get 1 226 736
assign 1 227 737
def 1 227 742
assign 1 228 743
firstGet 0 228 743
assign 1 230 745
new 0 230 745
assign 1 230 746
get 1 230 746
assign 1 231 747
def 1 231 752
assign 1 232 753
firstGet 0 232 753
assign 1 234 756
new 0 234 756
assign 1 236 758
new 0 236 758
assign 1 236 759
new 0 236 759
assign 1 236 760
isTrue 2 236 760
assign 1 237 761
new 0 237 761
assign 1 237 762
new 0 237 762
assign 1 237 763
isTrue 2 237 763
assign 1 238 764
new 0 238 764
assign 1 238 765
isTrue 1 238 765
assign 1 239 766
new 0 239 766
assign 1 239 767
isTrue 1 239 767
assign 1 240 768
new 0 240 768
assign 1 241 769
new 0 241 769
assign 1 241 770
get 1 241 770
assign 1 242 771
def 1 242 776
assign 1 242 777
isEmptyGet 0 242 777
assign 1 242 778
not 0 242 778
assign 1 0 780
assign 1 0 783
assign 1 0 787
assign 1 243 790
iteratorGet 0 0 790
assign 1 243 793
hasNextGet 0 243 793
assign 1 243 795
nextGet 0 243 795
put 1 244 796
assign 1 247 803
new 0 247 803
assign 1 247 804
isTrue 1 247 804
assign 1 248 805
new 0 248 805
assign 1 248 806
isTrue 1 248 806
assign 1 249 807
new 0 249 807
assign 1 249 808
isTrue 1 249 808
assign 1 250 809
new 0 250 809
assign 1 250 810
new 0 250 810
assign 1 250 811
isTrue 2 250 811
assign 1 251 812
new 0 251 812
assign 1 251 813
get 1 251 813
assign 1 252 814
new 0 252 814
assign 1 252 815
new 0 252 815
assign 1 252 816
get 2 252 816
assign 1 252 817
firstGet 0 252 817
assign 1 253 818
new 0 253 818
assign 1 253 819
new 0 253 819
assign 1 253 820
get 2 253 820
assign 1 253 821
firstGet 0 253 821
assign 1 254 822
new 0 254 822
assign 1 254 823
add 1 254 823
assign 1 254 824
new 0 254 824
assign 1 254 825
get 2 254 825
assign 1 254 826
firstGet 0 254 826
assign 1 255 827
new 0 255 827
assign 1 256 828
new 0 256 828
assign 1 257 829
new 0 257 829
assign 1 258 830
new 0 258 830
assign 1 259 831
new 0 259 831
assign 1 262 832
def 1 262 837
assign 1 263 838
firstGet 0 263 838
assign 1 265 841
new 0 265 841
assign 1 272 843
new 0 272 843
assign 1 272 844
add 1 272 844
assign 1 272 845
nameGet 0 272 845
assign 1 272 846
add 1 272 846
assign 1 272 847
get 1 272 847
assign 1 273 848
def 1 273 853
assign 1 274 854
orderedGet 0 274 854
addAll 1 274 855
assign 1 277 857
new 0 277 857
assign 1 277 858
add 1 277 858
assign 1 277 859
get 1 277 859
assign 1 278 860
def 1 278 865
assign 1 279 866
orderedGet 0 279 866
addAll 1 279 867
assign 1 282 869
new 0 282 869
assign 1 283 870
orderedGet 0 283 870
assign 1 283 871
iteratorGet 0 0 871
assign 1 283 874
hasNextGet 0 283 874
assign 1 283 876
nextGet 0 283 876
assign 1 284 877
new 1 284 877
addValue 1 284 878
assign 1 286 884
newlineGet 0 286 884
assign 1 287 885
assign 1 288 886
new 1 288 886
assign 1 290 887
copy 0 290 887
assign 1 291 888
fileGet 0 291 888
assign 1 291 889
existsGet 0 291 889
assign 1 291 890
not 0 291 890
assign 1 292 892
fileGet 0 292 892
makeDirs 0 292 893
assign 1 294 895
def 1 294 900
assign 1 295 901
new 1 295 901
assign 1 295 902
readerGet 0 295 902
assign 1 296 903
open 0 296 903
assign 1 296 904
readString 1 296 904
close 0 297 905
assign 1 303 919
classNameGet 0 303 919
assign 1 304 920
add 1 304 920
assign 1 304 921
new 0 304 921
assign 1 304 922
add 1 304 922
assign 1 304 923
toString 0 304 923
assign 1 304 924
add 1 304 924
assign 1 305 925
add 1 305 925
assign 1 305 926
new 0 305 926
assign 1 305 927
add 1 305 927
assign 1 305 928
toString 0 305 928
assign 1 305 929
add 1 305 929
return 1 306 930
assign 1 310 970
new 0 310 970
assign 1 311 971
classesGet 0 311 971
assign 1 311 972
valueIteratorGet 0 311 972
assign 1 311 975
hasNextGet 0 311 975
assign 1 312 977
nextGet 0 312 977
assign 1 313 978
shouldEmitGet 0 313 978
assign 1 313 979
heldGet 0 313 979
assign 1 313 980
fromFileGet 0 313 980
assign 1 313 981
has 1 313 981
assign 1 314 983
heldGet 0 314 983
assign 1 314 984
namepathGet 0 314 984
assign 1 314 985
toString 0 314 985
put 1 314 986
assign 1 315 987
usedByGet 0 315 987
assign 1 315 988
heldGet 0 315 988
assign 1 315 989
namepathGet 0 315 989
assign 1 315 990
toString 0 315 990
assign 1 315 991
get 1 315 991
assign 1 316 992
def 1 316 997
assign 1 317 998
iteratorGet 0 0 998
assign 1 317 1001
hasNextGet 0 317 1001
assign 1 317 1003
nextGet 0 317 1003
put 1 318 1004
assign 1 321 1011
subClassesGet 0 321 1011
assign 1 321 1012
heldGet 0 321 1012
assign 1 321 1013
namepathGet 0 321 1013
assign 1 321 1014
toString 0 321 1014
assign 1 321 1015
get 1 321 1015
assign 1 322 1016
def 1 322 1021
assign 1 323 1022
iteratorGet 0 0 1022
assign 1 323 1025
hasNextGet 0 323 1025
assign 1 323 1027
nextGet 0 323 1027
put 1 324 1028
assign 1 329 1041
classesGet 0 329 1041
assign 1 329 1042
valueIteratorGet 0 329 1042
assign 1 329 1045
hasNextGet 0 329 1045
assign 1 330 1047
nextGet 0 330 1047
assign 1 331 1048
heldGet 0 331 1048
assign 1 331 1049
heldGet 0 331 1049
assign 1 331 1050
namepathGet 0 331 1050
assign 1 331 1051
toString 0 331 1051
assign 1 331 1052
has 1 331 1052
shouldWriteSet 1 331 1053
assign 1 338 1063
new 0 338 1063
return 1 338 1064
assign 1 342 1078
def 1 342 1083
return 1 343 1084
assign 1 348 1086
def 1 348 1091
assign 1 349 1092
firstGet 0 349 1092
assign 1 350 1093
new 0 350 1093
assign 1 350 1094
equals 1 350 1094
assign 1 351 1096
new 1 351 1096
assign 1 352 1099
new 0 352 1099
assign 1 352 1100
equals 1 352 1100
assign 1 353 1102
new 1 353 1102
assign 1 354 1105
new 0 354 1105
assign 1 354 1106
equals 1 354 1106
assign 1 355 1108
new 1 355 1108
assign 1 357 1111
new 0 357 1111
assign 1 357 1112
new 1 357 1112
throw 1 357 1113
dynConditionsAllSet 1 359 1117
return 1 360 1118
return 1 362 1120
assign 1 367 1217
now 0 367 1217
assign 1 368 1218
new 0 368 1218
assign 1 369 1219
emitterGet 0 369 1219
assign 1 370 1220
def 1 370 1225
assign 1 371 1226
new 4 371 1226
put 1 372 1227
assign 1 374 1229
new 0 374 1229
assign 1 374 1230
add 1 374 1230
print 0 374 1231
assign 1 377 1234
new 0 377 1234
assign 1 379 1235
iteratorGet 0 0 1235
assign 1 379 1238
hasNextGet 0 379 1238
assign 1 379 1240
nextGet 0 379 1240
assign 1 380 1241
has 1 380 1241
assign 1 380 1242
not 0 380 1242
put 1 381 1244
assign 1 382 1245
new 2 382 1245
addValue 1 383 1246
assign 1 386 1253
iteratorGet 0 0 1253
assign 1 386 1256
hasNextGet 0 386 1256
assign 1 386 1258
nextGet 0 386 1258
assign 1 387 1259
has 1 387 1259
assign 1 387 1260
not 0 387 1260
put 1 388 1262
assign 1 389 1263
new 2 389 1263
addValue 1 390 1264
assign 1 391 1265
libNameGet 0 391 1265
put 1 391 1266
assign 1 396 1274
iteratorGet 0 396 1274
assign 1 396 1277
hasNextGet 0 396 1277
assign 1 397 1279
nextGet 0 397 1279
doParse 1 399 1280
buildSyns 1 401 1286
assign 1 404 1288
now 0 404 1288
assign 1 404 1289
subtract 1 404 1289
assign 1 406 1291
new 0 406 1291
assign 1 406 1292
add 1 406 1292
print 0 406 1293
assign 1 408 1295
emitCommonGet 0 408 1295
assign 1 408 1296
def 1 408 1301
assign 1 410 1302
emitCommonGet 0 410 1302
doEmit 0 410 1303
assign 1 411 1304
new 0 411 1304
return 1 411 1305
setClassesToWrite 0 414 1308
libnameInfoGet 0 415 1309
assign 1 417 1310
classesGet 0 417 1310
assign 1 417 1311
valueIteratorGet 0 417 1311
assign 1 417 1314
hasNextGet 0 417 1314
assign 1 418 1316
nextGet 0 418 1316
doEmit 1 419 1317
emitMain 0 421 1323
emitCUInit 0 422 1324
assign 1 423 1325
classesGet 0 423 1325
assign 1 423 1326
valueIteratorGet 0 423 1326
assign 1 423 1329
hasNextGet 0 423 1329
assign 1 424 1331
nextGet 0 424 1331
emitSyn 1 425 1332
assign 1 429 1339
now 0 429 1339
assign 1 429 1340
subtract 1 429 1340
assign 1 430 1341
def 1 430 1346
assign 1 431 1347
new 0 431 1347
assign 1 431 1348
add 1 431 1348
print 0 431 1349
assign 1 433 1351
new 0 433 1351
assign 1 433 1352
add 1 433 1352
print 0 433 1353
prepMake 1 436 1355
assign 1 440 1358
not 0 440 1358
make 1 441 1360
deployLibrary 1 442 1361
assign 1 444 1363
iteratorGet 0 0 1363
assign 1 444 1366
hasNextGet 0 444 1366
assign 1 444 1368
nextGet 0 444 1368
assign 1 445 1369
libnameInfoGet 0 445 1369
assign 1 445 1370
unitShlibGet 0 445 1370
assign 1 446 1371
emitPathGet 0 446 1371
assign 1 446 1372
copy 0 446 1372
assign 1 447 1373
stepsGet 0 447 1373
assign 1 447 1374
lastGet 0 447 1374
addStep 1 447 1375
assign 1 448 1376
fileGet 0 448 1376
assign 1 448 1377
existsGet 0 448 1377
assign 1 449 1379
fileGet 0 449 1379
delete 0 449 1380
assign 1 451 1382
fileGet 0 451 1382
assign 1 451 1383
existsGet 0 451 1383
assign 1 451 1384
not 0 451 1384
assign 1 452 1386
fileGet 0 452 1386
assign 1 452 1387
fileGet 0 452 1387
deployFile 2 452 1388
assign 1 456 1396
iteratorGet 0 456 1396
assign 1 457 1397
iteratorGet 0 457 1397
assign 1 459 1400
hasNextGet 0 459 1400
assign 1 459 1402
hasNextGet 0 459 1402
assign 1 0 1404
assign 1 0 1407
assign 1 0 1411
assign 1 460 1414
nextGet 0 460 1414
assign 1 460 1415
apNew 1 460 1415
assign 1 461 1416
emitPathGet 0 461 1416
assign 1 461 1417
copy 0 461 1417
assign 1 461 1418
toString 0 461 1418
assign 1 461 1419
new 0 461 1419
assign 1 461 1420
add 1 461 1420
assign 1 461 1421
nextGet 0 461 1421
assign 1 461 1422
add 1 461 1422
assign 1 461 1423
apNew 1 461 1423
assign 1 463 1424
fileGet 0 463 1424
assign 1 463 1425
existsGet 0 463 1425
assign 1 464 1427
fileGet 0 464 1427
delete 0 464 1428
assign 1 466 1430
fileGet 0 466 1430
assign 1 466 1431
existsGet 0 466 1431
assign 1 466 1432
not 0 466 1432
assign 1 467 1434
fileGet 0 467 1434
assign 1 467 1435
fileGet 0 467 1435
deployFile 2 467 1436
assign 1 472 1445
now 0 472 1445
assign 1 472 1446
subtract 1 472 1446
assign 1 474 1447
def 1 474 1452
assign 1 475 1453
new 0 475 1453
assign 1 475 1454
add 1 475 1454
print 0 475 1455
assign 1 477 1457
def 1 477 1462
assign 1 478 1463
new 0 478 1463
assign 1 478 1464
add 1 478 1464
print 0 478 1465
assign 1 480 1467
def 1 480 1472
assign 1 481 1473
new 0 481 1473
assign 1 481 1474
add 1 481 1474
print 0 481 1475
assign 1 485 1478
new 0 485 1478
print 0 485 1479
assign 1 486 1480
run 2 486 1480
assign 1 487 1481
new 0 487 1481
assign 1 487 1482
add 1 487 1482
assign 1 487 1483
new 0 487 1483
assign 1 487 1484
add 1 487 1484
print 0 487 1485
return 1 488 1486
assign 1 490 1488
new 0 490 1488
return 1 490 1489
assign 1 494 1502
justParsedGet 0 494 1502
assign 1 494 1503
valueIteratorGet 0 494 1503
assign 1 494 1506
hasNextGet 0 494 1506
assign 1 495 1508
nextGet 0 495 1508
assign 1 496 1509
heldGet 0 496 1509
libNameSet 1 496 1510
assign 1 497 1511
getSyn 2 497 1511
libNameSet 1 498 1512
assign 1 500 1518
justParsedGet 0 500 1518
assign 1 500 1519
valueIteratorGet 0 500 1519
assign 1 500 1522
hasNextGet 0 500 1522
assign 1 501 1524
nextGet 0 501 1524
assign 1 502 1525
heldGet 0 502 1525
assign 1 502 1526
synGet 0 502 1526
checkInheritance 2 503 1527
integrate 1 504 1528
assign 1 506 1534
new 0 506 1534
justParsedSet 1 506 1535
assign 1 510 1563
heldGet 0 510 1563
assign 1 510 1564
synGet 0 510 1564
assign 1 510 1565
def 1 510 1570
assign 1 511 1571
heldGet 0 511 1571
assign 1 511 1572
synGet 0 511 1572
return 1 511 1573
assign 1 513 1575
heldGet 0 513 1575
libNameSet 1 513 1576
assign 1 514 1577
heldGet 0 514 1577
assign 1 514 1578
extendsGet 0 514 1578
assign 1 514 1579
undef 1 514 1584
assign 1 515 1585
new 1 515 1585
assign 1 517 1588
classesGet 0 517 1588
assign 1 517 1589
heldGet 0 517 1589
assign 1 517 1590
extendsGet 0 517 1590
assign 1 517 1591
toString 0 517 1591
assign 1 517 1592
get 1 517 1592
assign 1 519 1593
def 1 519 1598
assign 1 520 1599
heldGet 0 520 1599
libNameSet 1 520 1600
assign 1 521 1601
getSyn 2 521 1601
assign 1 524 1604
heldGet 0 524 1604
assign 1 524 1605
extendsGet 0 524 1605
assign 1 524 1606
loadSyn 1 524 1606
assign 1 526 1608
new 2 526 1608
assign 1 528 1610
heldGet 0 528 1610
synSet 1 528 1611
assign 1 529 1612
heldGet 0 529 1612
assign 1 529 1613
namepathGet 0 529 1613
assign 1 529 1614
toString 0 529 1614
addSynClass 2 529 1615
return 1 530 1616
assign 1 534 1624
toString 0 534 1624
assign 1 535 1625
synClassesGet 0 535 1625
assign 1 535 1626
get 1 535 1626
assign 1 536 1627
def 1 536 1632
return 1 537 1633
assign 1 543 1635
emitterGet 0 543 1635
assign 1 543 1636
loadSyn 1 543 1636
addSynClass 2 544 1637
return 1 545 1638
assign 1 552 1642
undef 1 552 1647
assign 1 553 1648
new 1 553 1648
return 1 555 1650
assign 1 560 1729
new 1 560 1729
assign 1 561 1730
new 0 561 1730
assign 1 562 1731
emitterGet 0 562 1731
assign 1 563 1732
assign 1 564 1733
new 0 564 1733
assign 1 565 1734
shouldEmitGet 0 565 1734
put 1 565 1735
assign 1 0 1738
assign 1 0 1742
assign 1 0 1745
assign 1 568 1749
new 0 568 1749
assign 1 568 1750
toString 0 568 1750
assign 1 568 1751
add 1 568 1751
print 0 568 1752
assign 1 570 1754
assign 1 572 1755
fileGet 0 572 1755
assign 1 572 1756
readerGet 0 572 1756
assign 1 572 1757
open 0 572 1757
assign 1 572 1758
readBuffer 1 572 1758
assign 1 573 1759
fileGet 0 573 1759
assign 1 573 1760
readerGet 0 573 1760
close 0 573 1761
assign 1 574 1762
tokenize 1 574 1762
assign 1 582 1764
new 0 582 1764
echo 0 582 1765
assign 1 584 1767
outermostGet 0 584 1767
nodify 2 584 1768
assign 1 586 1770
new 0 586 1770
print 0 586 1771
assign 1 587 1772
new 2 587 1772
traverse 1 587 1773
assign 1 591 1776
new 0 591 1776
echo 0 591 1777
assign 1 593 1779
new 0 593 1779
traverse 1 593 1780
assign 1 595 1782
new 0 595 1782
print 0 595 1783
assign 1 596 1784
new 2 596 1784
traverse 1 596 1785
assign 1 599 1788
new 0 599 1788
echo 0 599 1789
assign 1 602 1791
new 0 602 1791
traverse 1 602 1792
contain 0 603 1793
assign 1 605 1795
new 0 605 1795
print 0 605 1796
assign 1 606 1797
new 2 606 1797
traverse 1 606 1798
assign 1 610 1801
new 0 610 1801
echo 0 610 1802
assign 1 612 1804
new 0 612 1804
traverse 1 612 1805
assign 1 614 1807
new 0 614 1807
print 0 614 1808
assign 1 615 1809
new 2 615 1809
traverse 1 615 1810
assign 1 619 1813
new 0 619 1813
echo 0 619 1814
assign 1 621 1816
new 0 621 1816
traverse 1 621 1817
assign 1 623 1819
new 0 623 1819
print 0 623 1820
assign 1 624 1821
new 2 624 1821
traverse 1 624 1822
assign 1 628 1825
new 0 628 1825
echo 0 628 1826
assign 1 630 1828
new 0 630 1828
traverse 1 630 1829
assign 1 632 1831
new 0 632 1831
print 0 632 1832
assign 1 633 1833
new 2 633 1833
traverse 1 633 1834
assign 1 637 1837
new 0 637 1837
echo 0 637 1838
assign 1 639 1840
new 0 639 1840
traverse 1 639 1841
assign 1 641 1843
new 0 641 1843
print 0 641 1844
assign 1 642 1845
new 2 642 1845
traverse 1 642 1846
assign 1 646 1849
new 0 646 1849
echo 0 646 1850
assign 1 648 1852
new 0 648 1852
traverse 1 648 1853
assign 1 650 1855
new 0 650 1855
print 0 650 1856
assign 1 651 1857
new 2 651 1857
traverse 1 651 1858
assign 1 655 1861
new 0 655 1861
echo 0 655 1862
assign 1 657 1864
new 0 657 1864
traverse 1 657 1865
assign 1 659 1867
new 0 659 1867
print 0 659 1868
assign 1 660 1869
new 2 660 1869
traverse 1 660 1870
assign 1 664 1873
new 0 664 1873
echo 0 664 1874
assign 1 666 1876
new 0 666 1876
traverse 1 666 1877
assign 1 668 1879
new 0 668 1879
print 0 668 1880
assign 1 669 1881
new 2 669 1881
traverse 1 669 1882
assign 1 672 1885
new 0 672 1885
echo 0 672 1886
assign 1 674 1888
new 0 674 1888
traverse 1 674 1889
assign 1 676 1891
new 0 676 1891
print 0 676 1892
assign 1 677 1893
new 2 677 1893
traverse 1 677 1894
assign 1 681 1897
new 0 681 1897
echo 0 681 1898
assign 1 682 1899
new 0 682 1899
print 0 682 1900
assign 1 684 1902
new 0 684 1902
traverse 1 684 1903
assign 1 0 1905
assign 1 0 1909
assign 1 0 1912
assign 1 686 1916
new 0 686 1916
print 0 686 1917
assign 1 687 1918
new 2 687 1918
traverse 1 687 1919
assign 1 689 1921
classesGet 0 689 1921
assign 1 689 1922
valueIteratorGet 0 689 1922
assign 1 689 1925
hasNextGet 0 689 1925
assign 1 690 1927
nextGet 0 690 1927
assign 1 692 1928
transUnitGet 0 692 1928
assign 1 693 1929
new 1 693 1929
assign 1 694 1930
TRANSUNITGet 0 694 1930
typenameSet 1 694 1931
assign 1 695 1932
new 0 695 1932
assign 1 696 1933
heldGet 0 696 1933
assign 1 696 1934
emitsGet 0 696 1934
emitsSet 1 696 1935
heldSet 1 697 1936
delete 0 698 1937
addValue 1 699 1938
copyLoc 1 700 1939
reInitContained 0 706 1961
assign 1 707 1962
containedGet 0 707 1962
assign 1 708 1963
new 0 708 1963
assign 1 709 1964
new 0 709 1964
assign 1 709 1965
crGet 0 709 1965
assign 1 710 1966
iteratorGet 0 710 1966
assign 1 710 1969
hasNextGet 0 710 1969
assign 1 711 1971
new 1 711 1971
assign 1 712 1972
nextGet 0 712 1972
heldSet 1 712 1973
nlcSet 1 713 1974
assign 1 714 1975
heldGet 0 714 1975
assign 1 714 1976
equals 1 714 1976
assign 1 715 1978
increment 0 715 1978
assign 1 717 1980
heldGet 0 717 1980
assign 1 717 1981
notEquals 1 717 1981
addValue 1 718 1983
containerSet 1 719 1984
return 1 0 1994
assign 1 0 1997
return 1 0 2001
assign 1 0 2004
return 1 0 2008
assign 1 0 2011
return 1 0 2015
assign 1 0 2018
return 1 0 2022
assign 1 0 2025
return 1 0 2029
assign 1 0 2032
return 1 0 2036
assign 1 0 2039
return 1 0 2043
assign 1 0 2046
return 1 0 2050
assign 1 0 2053
return 1 0 2057
assign 1 0 2060
return 1 0 2064
assign 1 0 2067
return 1 0 2071
assign 1 0 2074
return 1 0 2078
assign 1 0 2081
return 1 0 2085
assign 1 0 2088
return 1 0 2092
assign 1 0 2095
return 1 0 2099
assign 1 0 2102
return 1 0 2106
assign 1 0 2109
return 1 0 2113
assign 1 0 2116
return 1 0 2120
assign 1 0 2123
return 1 0 2127
assign 1 0 2130
return 1 0 2134
assign 1 0 2137
return 1 0 2141
assign 1 0 2144
return 1 0 2148
assign 1 0 2151
return 1 0 2155
assign 1 0 2158
return 1 0 2162
assign 1 0 2165
return 1 0 2169
assign 1 0 2172
return 1 0 2176
assign 1 0 2179
return 1 0 2183
assign 1 0 2186
return 1 0 2190
assign 1 0 2193
return 1 0 2197
assign 1 0 2200
return 1 0 2204
assign 1 0 2207
return 1 0 2211
assign 1 0 2214
return 1 0 2218
assign 1 0 2221
return 1 0 2225
assign 1 0 2228
return 1 0 2232
assign 1 0 2235
return 1 0 2239
assign 1 0 2242
return 1 0 2246
assign 1 0 2249
return 1 0 2253
assign 1 0 2256
return 1 0 2260
assign 1 0 2263
return 1 0 2267
assign 1 0 2270
return 1 0 2274
assign 1 0 2277
return 1 0 2281
assign 1 0 2284
return 1 0 2288
assign 1 0 2291
return 1 0 2295
assign 1 0 2298
return 1 0 2302
assign 1 0 2305
return 1 0 2309
assign 1 0 2312
return 1 0 2316
assign 1 0 2319
return 1 0 2323
assign 1 0 2326
return 1 0 2330
assign 1 0 2333
return 1 0 2337
assign 1 0 2340
return 1 0 2344
assign 1 0 2347
return 1 0 2351
assign 1 0 2354
return 1 0 2358
assign 1 0 2361
return 1 0 2365
assign 1 0 2368
return 1 0 2372
assign 1 0 2375
return 1 0 2379
assign 1 0 2382
return 1 0 2386
assign 1 0 2389
return 1 0 2393
assign 1 0 2396
return 1 0 2400
assign 1 0 2403
return 1 0 2407
assign 1 0 2410
return 1 0 2414
assign 1 0 2417
return 1 0 2421
assign 1 0 2424
return 1 0 2428
assign 1 0 2431
return 1 0 2435
assign 1 0 2438
return 1 0 2442
assign 1 0 2445
return 1 0 2449
assign 1 0 2452
return 1 0 2456
assign 1 0 2459
assign 1 0 2463
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
}
