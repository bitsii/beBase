namespace be.BEL_4_Base {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog : BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
static BEC_2_2_3_IOLog() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 4));
public static new BEC_2_2_3_IOLog bevs_inst;
public BEC_2_4_3_MathInt bevp_debug;
public BEC_2_4_3_MathInt bevp_info;
public BEC_2_4_3_MathInt bevp_warn;
public BEC_2_4_3_MathInt bevp_error;
public BEC_2_4_3_MathInt bevp_fatal;
public BEC_2_4_3_MathInt bevp_level;
public virtual BEC_2_2_3_IOLog bem_default_0() {
bevp_debug = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(400));
bevp_info = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(300));
bevp_warn = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(200));
bevp_error = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(100));
bevp_fatal = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_level = bevp_fatal;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (beva__level.bevi_int <= bevp_level.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 28 */ {
bevt_1_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 29 */
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
if (beva__level.bevi_int <= bevp_level.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 35 */ {
if (beva_msg == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 36 */ {
beva_msg.bem_print_0();
} /* Line: 37 */
 else  /* Line: 38 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
} /* Line: 39 */
} /* Line: 36 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_debug = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_infoGet_0() {
return bevp_info;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_infoSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_info = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_warnGet_0() {
return bevp_warn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_warnSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_warn = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_errorGet_0() {
return bevp_error;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_errorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_error = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_fatalGet_0() {
return bevp_fatal;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fatalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fatal = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_levelGet_0() {
return bevp_level;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 21, 22, 23, 28, 28, 29, 29, 31, 31, 35, 35, 36, 36, 37, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 21, 22, 23, 30, 35, 36, 37, 39, 40, 46, 51, 52, 57, 58, 61, 62, 68, 71, 75, 78, 82, 85, 89, 92, 96, 99, 103, 106};
/* BEGIN LINEINFO 
assign 1 18 18
new 0 18 18
assign 1 19 19
new 0 19 19
assign 1 20 20
new 0 20 20
assign 1 21 21
new 0 21 21
assign 1 22 22
new 0 22 22
assign 1 23 23
assign 1 28 30
lesserEquals 1 28 35
assign 1 29 36
new 0 29 36
return 1 29 37
assign 1 31 39
new 0 31 39
return 1 31 40
assign 1 35 46
lesserEquals 1 35 51
assign 1 36 52
def 1 36 57
print 0 37 58
assign 1 39 61
new 0 39 61
print 0 39 62
return 1 0 68
assign 1 0 71
return 1 0 75
assign 1 0 78
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
return 1 0 96
assign 1 0 99
return 1 0 103
assign 1 0 106
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1862823180: return bem_debugGet_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1209042297: return bem_infoGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1770701151: return bem_warnGet_0();
case 1557756643: return bem_fatalGet_0();
case 184493155: return bem_levelGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 1613586527: return bem_errorGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1759618898: return bem_warnSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 195575408: return bem_levelSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1220124550: return bem_infoSet_1(bevd_0);
case 1851740927: return bem_debugSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1624668780: return bem_errorSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1568838896: return bem_fatalSet_1(bevd_0);
case 787804412: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 103149047: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_3_IOLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_3_IOLog.bevs_inst = (BEC_2_2_3_IOLog)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_3_IOLog.bevs_inst;
}
}
}
