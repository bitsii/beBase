namespace be.BEL_4_Base {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser : BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
static BEC_2_4_6_JsonParser() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x7B};
private static byte[] bels_1 = {0x7D};
private static byte[] bels_2 = {0x5B};
private static byte[] bels_3 = {0x5D};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x2C};
private static byte[] bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 6));
private static byte[] bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55296));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56319));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56320));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57343));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
private static byte[] bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_9 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_11 = {0x38,0x30};
private static byte[] bels_12 = {0x38,0x30,0x30};
private static byte[] bels_13 = {0x43,0x30};
private static byte[] bels_14 = {0x37,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_15 = {0x38,0x30};
private static byte[] bels_16 = {0x30,0x33,0x46};
private static byte[] bels_17 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bels_18 = {0x45,0x30};
private static byte[] bels_19 = {0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_11 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_20 = {0x38,0x30};
private static byte[] bels_21 = {0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_22 = {0x38,0x30};
private static byte[] bels_23 = {0x30,0x30,0x33,0x46};
private static byte[] bels_24 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bels_25 = {0x46,0x30};
private static byte[] bels_26 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x38,0x30};
private static byte[] bels_28 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_29 = {0x38,0x30};
private static byte[] bels_30 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_31 = {0x38,0x30};
private static byte[] bels_32 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static BEC_2_4_3_MathInt bevo_16 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_33 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bels_34 = {0x75};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_34, 1));
private static byte[] bels_35 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bels_36 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bels_37 = {0x74};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_37, 1));
private static byte[] bels_38 = {0x72};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_38, 1));
private static byte[] bels_39 = {0x66};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
private static byte[] bels_40 = {0x6E};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_40, 1));
private static byte[] bels_41 = {0x75,0x65};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_41, 2));
private static byte[] bels_42 = {0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_42, 4));
private static byte[] bels_43 = {0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_43, 3));
public static new BEC_2_4_6_JsonParser bevs_inst;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_quote = bevt_0_tmpvar_phold.bem_quoteGet_0();
bevp_lbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
bevp_rbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_1));
bevp_lbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_2));
bevp_rbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_space = bevt_1_tmpvar_phold.bem_spaceGet_0();
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_colon = bevt_2_tmpvar_phold.bem_colonGet_0();
bevp_escape = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_3_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_cr = bevt_3_tmpvar_phold.bem_crGet_0();
bevt_4_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_lf = bevt_4_tmpvar_phold.bem_lfGet_0();
bevp_comma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_5));
bevt_14_tmpvar_phold = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevp_rbrace);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevp_lbracket);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevp_rbracket);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_space);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevp_colon);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevp_escape);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevp_cr);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_lf);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_comma);
bevt_15_tmpvar_phold = bevo_0;
bevp_tokens = bevt_5_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_7));
bevp_hsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_8));
bevp_vsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_9));
bevp_hmAdd = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_toker.bem_tokenize_1(beva_str);
this.bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_phold, beva_handler);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_1;
if (bevt_2_tmpvar_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_4_tmpvar_phold = bevo_2;
if (beva_value.bevi_int <= bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 65 */
 else  /* Line: 65 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 65 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 68 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_3;
if (bevt_2_tmpvar_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_4_tmpvar_phold = bevo_4;
if (beva_value.bevi_int <= bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 76 */
 else  /* Line: 76 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 76 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 77 */
 else  /* Line: 78 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 79 */
return bevl_result;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevo_5;
if (bevt_1_tmpvar_phold.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_3_tmpvar_phold = beva_tok.bem_substring_1(bevt_4_tmpvar_phold);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevo_6;
if (bevt_1_tmpvar_phold.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 93 */ {
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_10));
bevt_3_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 94 */
bevt_7_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_6_tmpvar_phold = beva_tok.bem_substring_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_tmpvar_phold);
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_accum.bem_capacityGet_0();
bevt_3_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_subtract_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevo_7;
if (bevt_1_tmpvar_phold.bevi_int < bevt_4_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_6_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_7_tmpvar_phold = bevo_8;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
beva_accum.bem_capacitySet_1(bevt_5_tmpvar_phold);
} /* Line: 102 */
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_tmpvar_phold);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bem_addValue_1(beva_value);
bevl_heldm.bem_addValue_1(bevp_hmAdd);
beva_value = bevl_heldm;
} /* Line: 115 */
bevt_11_tmpvar_phold = bevo_9;
if (beva_value.bevi_int < bevt_11_tmpvar_phold.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 122 */
 else  /* Line: 121 */ {
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_11));
bevt_13_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_tmpvar_phold);
if (beva_value.bevi_int < bevt_13_tmpvar_phold.bevi_int) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 123 */ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 125 */
 else  /* Line: 121 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_12));
bevt_16_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpvar_phold);
if (beva_value.bevi_int < bevt_16_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_13));
bevt_19_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_14));
bevt_23_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_tmpvar_phold);
bevt_22_tmpvar_phold = beva_value.bem_and_1(bevt_23_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_shiftRight_1(bevt_25_tmpvar_phold);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_10;
bevt_26_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_15));
bevt_29_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_16));
bevt_32_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_tmpvar_phold);
bevt_31_tmpvar_phold = beva_value.bem_and_1(bevt_32_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_26_tmpvar_phold, bevt_28_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 129 */
 else  /* Line: 121 */ {
bevt_36_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_17));
bevt_35_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_tmpvar_phold);
if (beva_value.bevi_int < bevt_35_tmpvar_phold.bevi_int) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 130 */ {
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_18));
bevt_38_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_19));
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_tmpvar_phold);
bevt_41_tmpvar_phold = beva_value.bem_and_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_shiftRight_1(bevt_44_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_add_1(bevt_40_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_tmpvar_phold);
bevt_46_tmpvar_phold = bevo_11;
bevt_45_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_20));
bevt_48_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_21));
bevt_52_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_tmpvar_phold);
bevt_51_tmpvar_phold = beva_value.bem_and_1(bevt_52_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bem_shiftRight_1(bevt_54_tmpvar_phold);
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_add_1(bevt_50_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_45_tmpvar_phold, bevt_47_tmpvar_phold);
bevt_56_tmpvar_phold = bevo_12;
bevt_55_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_56_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_22));
bevt_58_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_23));
bevt_61_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = beva_value.bem_and_1(bevt_61_tmpvar_phold);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_add_1(bevt_60_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_55_tmpvar_phold, bevt_57_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 134 */
 else  /* Line: 121 */ {
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_24));
bevt_64_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpvar_phold);
if (beva_value.bevi_int <= bevt_64_tmpvar_phold.bevi_int) {
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_68_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_25));
bevt_67_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_26));
bevt_71_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_tmpvar_phold);
bevt_70_tmpvar_phold = beva_value.bem_and_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_shiftRight_1(bevt_73_tmpvar_phold);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_69_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_tmpvar_phold);
bevt_75_tmpvar_phold = bevo_13;
bevt_74_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_75_tmpvar_phold);
bevt_78_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_27));
bevt_77_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_28));
bevt_81_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_tmpvar_phold);
bevt_80_tmpvar_phold = beva_value.bem_and_1(bevt_81_tmpvar_phold);
bevt_83_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_shiftRight_1(bevt_83_tmpvar_phold);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevt_79_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_74_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_85_tmpvar_phold = bevo_14;
bevt_84_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_85_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevt_87_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_30));
bevt_91_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_tmpvar_phold);
bevt_90_tmpvar_phold = beva_value.bem_and_1(bevt_91_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_shiftRight_1(bevt_93_tmpvar_phold);
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bem_add_1(bevt_89_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_84_tmpvar_phold, bevt_86_tmpvar_phold);
bevt_95_tmpvar_phold = bevo_15;
bevt_94_tmpvar_phold = bevl_sizeNow.bem_add_1(bevt_95_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
bevt_97_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_tmpvar_phold);
bevt_101_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_32));
bevt_100_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_tmpvar_phold);
bevt_99_tmpvar_phold = beva_value.bem_and_1(bevt_100_tmpvar_phold);
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_add_1(bevt_99_tmpvar_phold);
beva_accum.bem_setIntUnchecked_2(bevt_94_tmpvar_phold, bevt_96_tmpvar_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 142 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
bevt_103_tmpvar_phold = bevo_16;
if (bevl_size.bevi_int < bevt_103_tmpvar_phold.bevi_int) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_105_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bels_33));
bevt_104_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_104_tmpvar_phold);
} /* Line: 146 */
bevt_107_tmpvar_phold = beva_accum.bem_sizeGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpvar_phold = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bevs_inst;
bevl_fromEscapes = bevt_9_tmpvar_phold.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 179 */ {
bevt_10_tmpvar_phold = bevl_tokIter.bem_hasNextGet_0();
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 179 */ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool) /* Line: 182 */ {
bevt_11_tmpvar_phold = bevl_inEscape.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevt_12_tmpvar_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 183 */
 else  /* Line: 183 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 183 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_13_tmpvar_phold = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(1774332469, BEL_4_Base.bevn_handleString_1, bevt_13_tmpvar_phold);
} /* Line: 185 */
 else  /* Line: 186 */ {
if (bevl_inEscape.bevi_bool) /* Line: 187 */ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 190 */
 else  /* Line: 189 */ {
bevt_16_tmpvar_phold = bevo_17;
bevt_15_tmpvar_phold = bevl_tok.bem_begins_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevl_value = this.bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = this.bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_19_tmpvar_phold = this.bem_jsonUcIsPairEnd_1(bevl_value);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_not_0();
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bels_35));
bevt_20_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 196 */
 else  /* Line: 195 */ {
if (bevl_heldValue == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevl_isStart = this.bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 198 */
} /* Line: 195 */
if (bevl_isStart.bevi_bool) /* Line: 200 */ {
if (bevl_remainder == null) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 200 */ {
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bels_36));
bevt_24_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 201 */
if (bevl_isStart.bevi_bool) /* Line: 203 */ {
bevl_heldValue = bevl_value;
} /* Line: 204 */
 else  /* Line: 205 */ {
this.bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 209 */
} /* Line: 208 */
} /* Line: 203 */
 else  /* Line: 212 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 213 */
} /* Line: 189 */
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 215 */
 else  /* Line: 187 */ {
bevt_27_tmpvar_phold = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 217 */
 else  /* Line: 218 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 219 */
} /* Line: 187 */
} /* Line: 187 */
} /* Line: 183 */
 else  /* Line: 222 */ {
bevt_28_tmpvar_phold = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_29_tmpvar_phold = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_30_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_31_tmpvar_phold = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 224 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 224 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 224 */ {
} /* Line: 224 */
 else  /* Line: 224 */ {
bevt_32_tmpvar_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 226 */
 else  /* Line: 224 */ {
bevt_33_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 227 */ {
beva_handler.bemd_0(1095000804, BEL_4_Base.bevn_beginMap_0);
} /* Line: 228 */
 else  /* Line: 224 */ {
bevt_34_tmpvar_phold = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 229 */ {
beva_handler.bemd_0(1708368370, BEL_4_Base.bevn_endMap_0);
} /* Line: 230 */
 else  /* Line: 224 */ {
bevt_35_tmpvar_phold = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 231 */ {
beva_handler.bemd_0(368775858, BEL_4_Base.bevn_kvMid_0);
} /* Line: 232 */
 else  /* Line: 224 */ {
bevt_36_tmpvar_phold = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 233 */ {
beva_handler.bemd_0(435843368, BEL_4_Base.bevn_beginList_0);
} /* Line: 234 */
 else  /* Line: 224 */ {
bevt_37_tmpvar_phold = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 235 */ {
beva_handler.bemd_0(1398681994, BEL_4_Base.bevn_endList_0);
} /* Line: 236 */
 else  /* Line: 237 */ {
bevt_39_tmpvar_phold = bevo_18;
bevt_38_tmpvar_phold = bevl_tok.bem_equals_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_41_tmpvar_phold = bevo_19;
bevt_40_tmpvar_phold = bevl_tok.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_43_tmpvar_phold = bevo_20;
bevt_42_tmpvar_phold = bevl_tok.bem_equals_1(bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_45_tmpvar_phold = bevo_21;
bevt_44_tmpvar_phold = bevl_tok.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 240 */ {
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_47_tmpvar_phold = bevo_22;
bevt_46_tmpvar_phold = bevl_tok.bem_equals_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 243 */ {
beva_handler.bemd_0(1262128633, BEL_4_Base.bevn_handleTrue_0);
} /* Line: 244 */
 else  /* Line: 240 */ {
bevt_49_tmpvar_phold = bevo_23;
bevt_48_tmpvar_phold = bevl_tok.bem_equals_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 245 */ {
beva_handler.bemd_0(506014516, BEL_4_Base.bevn_handleFalse_0);
} /* Line: 246 */
 else  /* Line: 240 */ {
bevt_51_tmpvar_phold = bevo_24;
bevt_50_tmpvar_phold = bevl_tok.bem_equals_1(bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 247 */ {
beva_handler.bemd_0(1431394368, BEL_4_Base.bevn_handleNull_0);
} /* Line: 248 */
 else  /* Line: 249 */ {
bevt_52_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(1512002600, BEL_4_Base.bevn_handleInteger_1, bevt_52_tmpvar_phold);
} /* Line: 251 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 224 */
} /* Line: 182 */
 else  /* Line: 179 */ {
break;
} /* Line: 179 */
} /* Line: 179 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbraceGet_0() {
return bevp_lbrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbraceGet_0() {
return bevp_rbrace;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbracketGet_0() {
return bevp_lbracket;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbracketGet_0() {
return bevp_rbracket;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapeGet_0() {
return bevp_escape;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_commaGet_0() {
return bevp_comma;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_tokensGet_0() {
return bevp_tokens;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hsubGet_0() {
return bevp_hsub;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vsubGet_0() {
return bevp_vsub;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hmAddGet_0() {
return bevp_hmAdd;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {39, 39, 40, 41, 42, 43, 44, 44, 45, 45, 46, 47, 47, 48, 48, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 53, 53, 54, 54, 60, 60, 65, 65, 65, 65, 65, 65, 0, 0, 0, 66, 68, 70, 76, 76, 76, 76, 76, 76, 0, 0, 0, 77, 79, 81, 86, 86, 86, 86, 87, 89, 89, 89, 93, 93, 93, 93, 94, 94, 94, 96, 96, 96, 96, 101, 101, 101, 101, 101, 101, 102, 102, 102, 102, 104, 107, 107, 109, 110, 111, 111, 112, 113, 114, 115, 121, 121, 121, 122, 123, 123, 123, 123, 124, 125, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 128, 128, 128, 128, 128, 128, 128, 128, 128, 129, 130, 130, 130, 130, 131, 131, 131, 131, 131, 131, 131, 131, 131, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 132, 133, 133, 133, 133, 133, 133, 133, 133, 133, 134, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 137, 138, 138, 138, 138, 138, 138, 138, 138, 138, 138, 138, 139, 139, 139, 139, 139, 139, 139, 139, 139, 140, 142, 145, 145, 145, 146, 146, 146, 148, 148, 148, 169, 170, 171, 173, 173, 175, 179, 180, 183, 183, 0, 0, 0, 184, 185, 185, 188, 189, 189, 190, 191, 191, 192, 193, 194, 195, 195, 195, 195, 0, 0, 0, 196, 196, 196, 197, 197, 198, 200, 200, 0, 0, 0, 201, 201, 201, 204, 206, 207, 208, 208, 209, 213, 215, 216, 217, 219, 224, 0, 224, 0, 0, 0, 224, 0, 0, 0, 224, 0, 0, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 240, 240, 0, 240, 240, 0, 0, 0, 240, 240, 0, 0, 0, 240, 240, 0, 0, 243, 243, 244, 245, 245, 246, 247, 247, 248, 251, 251, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 155, 156, 166, 167, 172, 173, 174, 179, 180, 183, 187, 190, 193, 195, 204, 205, 210, 211, 212, 217, 218, 221, 225, 228, 231, 233, 241, 242, 243, 248, 249, 251, 252, 253, 264, 265, 266, 271, 272, 273, 274, 276, 277, 278, 279, 393, 394, 395, 396, 397, 402, 403, 404, 405, 406, 408, 409, 414, 415, 416, 417, 418, 419, 420, 421, 422, 424, 425, 430, 431, 434, 435, 436, 441, 442, 443, 446, 447, 448, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 475, 476, 477, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 515, 516, 517, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 566, 572, 573, 578, 579, 580, 581, 583, 584, 585, 653, 654, 655, 656, 657, 658, 661, 663, 665, 667, 669, 672, 676, 679, 680, 681, 685, 686, 691, 692, 695, 696, 698, 699, 700, 701, 706, 707, 708, 710, 713, 717, 720, 721, 722, 725, 730, 731, 735, 740, 741, 744, 748, 751, 752, 753, 756, 759, 760, 761, 766, 767, 772, 775, 778, 780, 783, 789, 791, 794, 796, 799, 803, 806, 808, 811, 815, 818, 820, 823, 829, 831, 834, 836, 839, 841, 844, 846, 849, 851, 854, 856, 859, 860, 862, 865, 866, 868, 871, 875, 878, 879, 881, 884, 888, 891, 892, 894, 897, 903, 904, 906, 909, 910, 912, 915, 916, 918, 921, 922, 943, 946, 950, 953, 957, 960, 964, 967, 971, 974, 978, 981, 985, 988, 992, 995, 999, 1002, 1006, 1009, 1013, 1016, 1020, 1023, 1027, 1030, 1034, 1037, 1041, 1044, 1048, 1051};
/* BEGIN LINEINFO 
assign 1 39 115
new 0 39 115
assign 1 39 116
quoteGet 0 39 116
assign 1 40 117
new 0 40 117
assign 1 41 118
new 0 41 118
assign 1 42 119
new 0 42 119
assign 1 43 120
new 0 43 120
assign 1 44 121
new 0 44 121
assign 1 44 122
spaceGet 0 44 122
assign 1 45 123
new 0 45 123
assign 1 45 124
colonGet 0 45 124
assign 1 46 125
new 0 46 125
assign 1 47 126
new 0 47 126
assign 1 47 127
crGet 0 47 127
assign 1 48 128
new 0 48 128
assign 1 48 129
lfGet 0 48 129
assign 1 49 130
new 0 49 130
assign 1 50 131
add 1 50 131
assign 1 50 132
add 1 50 132
assign 1 50 133
add 1 50 133
assign 1 50 134
add 1 50 134
assign 1 50 135
add 1 50 135
assign 1 50 136
add 1 50 136
assign 1 50 137
add 1 50 137
assign 1 50 138
add 1 50 138
assign 1 50 139
add 1 50 139
assign 1 50 140
add 1 50 140
assign 1 50 141
new 0 50 141
assign 1 50 142
add 1 50 142
assign 1 51 143
new 0 51 143
assign 1 51 144
new 2 51 144
assign 1 52 145
new 0 52 145
assign 1 52 146
hexNew 1 52 146
assign 1 53 147
new 0 53 147
assign 1 53 148
hexNew 1 53 148
assign 1 54 149
new 0 54 149
assign 1 54 150
hexNew 1 54 150
assign 1 60 155
tokenize 1 60 155
parseTokens 2 60 156
assign 1 65 166
new 0 65 166
assign 1 65 167
lesserEquals 1 65 172
assign 1 65 173
new 0 65 173
assign 1 65 174
lesserEquals 1 65 179
assign 1 0 180
assign 1 0 183
assign 1 0 187
assign 1 66 190
new 0 66 190
assign 1 68 193
new 0 68 193
return 1 70 195
assign 1 76 204
new 0 76 204
assign 1 76 205
lesserEquals 1 76 210
assign 1 76 211
new 0 76 211
assign 1 76 212
lesserEquals 1 76 217
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 77 228
new 0 77 228
assign 1 79 231
new 0 79 231
return 1 81 233
assign 1 86 241
sizeGet 0 86 241
assign 1 86 242
new 0 86 242
assign 1 86 243
lesser 1 86 248
return 1 87 249
assign 1 89 251
new 0 89 251
assign 1 89 252
substring 1 89 252
return 1 89 253
assign 1 93 264
sizeGet 0 93 264
assign 1 93 265
new 0 93 265
assign 1 93 266
lesser 1 93 271
assign 1 94 272
new 0 94 272
assign 1 94 273
new 1 94 273
throw 1 94 274
assign 1 96 276
new 0 96 276
assign 1 96 277
substring 1 96 277
assign 1 96 278
hexNew 1 96 278
return 1 96 279
assign 1 101 393
capacityGet 0 101 393
assign 1 101 394
sizeGet 0 101 394
assign 1 101 395
subtract 1 101 395
assign 1 101 396
new 0 101 396
assign 1 101 397
lesser 1 101 402
assign 1 102 403
sizeGet 0 102 403
assign 1 102 404
new 0 102 404
assign 1 102 405
add 1 102 405
capacitySet 1 102 406
assign 1 104 408
sizeGet 0 104 408
assign 1 107 409
def 1 107 414
assign 1 109 415
subtractValue 1 110 416
assign 1 111 417
new 0 111 417
shiftLeftValue 1 111 418
subtractValue 1 112 419
addValue 1 113 420
addValue 1 114 421
assign 1 115 422
assign 1 121 424
new 0 121 424
assign 1 121 425
lesser 1 121 430
assign 1 122 431
new 0 122 431
assign 1 123 434
new 0 123 434
assign 1 123 435
hexNew 1 123 435
assign 1 123 436
lesser 1 123 441
setIntUnchecked 2 124 442
assign 1 125 443
new 0 125 443
assign 1 126 446
new 0 126 446
assign 1 126 447
hexNew 1 126 447
assign 1 126 448
lesser 1 126 453
assign 1 127 454
new 0 127 454
assign 1 127 455
hexNew 1 127 455
assign 1 127 456
new 0 127 456
assign 1 127 457
hexNew 1 127 457
assign 1 127 458
and 1 127 458
assign 1 127 459
new 0 127 459
assign 1 127 460
shiftRight 1 127 460
assign 1 127 461
add 1 127 461
setIntUnchecked 2 127 462
assign 1 128 463
new 0 128 463
assign 1 128 464
add 1 128 464
assign 1 128 465
new 0 128 465
assign 1 128 466
hexNew 1 128 466
assign 1 128 467
new 0 128 467
assign 1 128 468
hexNew 1 128 468
assign 1 128 469
and 1 128 469
assign 1 128 470
add 1 128 470
setIntUnchecked 2 128 471
assign 1 129 472
new 0 129 472
assign 1 130 475
new 0 130 475
assign 1 130 476
hexNew 1 130 476
assign 1 130 477
lesser 1 130 482
assign 1 131 483
new 0 131 483
assign 1 131 484
hexNew 1 131 484
assign 1 131 485
new 0 131 485
assign 1 131 486
hexNew 1 131 486
assign 1 131 487
and 1 131 487
assign 1 131 488
new 0 131 488
assign 1 131 489
shiftRight 1 131 489
assign 1 131 490
add 1 131 490
setIntUnchecked 2 131 491
assign 1 132 492
new 0 132 492
assign 1 132 493
add 1 132 493
assign 1 132 494
new 0 132 494
assign 1 132 495
hexNew 1 132 495
assign 1 132 496
new 0 132 496
assign 1 132 497
hexNew 1 132 497
assign 1 132 498
and 1 132 498
assign 1 132 499
new 0 132 499
assign 1 132 500
shiftRight 1 132 500
assign 1 132 501
add 1 132 501
setIntUnchecked 2 132 502
assign 1 133 503
new 0 133 503
assign 1 133 504
add 1 133 504
assign 1 133 505
new 0 133 505
assign 1 133 506
hexNew 1 133 506
assign 1 133 507
new 0 133 507
assign 1 133 508
hexNew 1 133 508
assign 1 133 509
and 1 133 509
assign 1 133 510
add 1 133 510
setIntUnchecked 2 133 511
assign 1 134 512
new 0 134 512
assign 1 135 515
new 0 135 515
assign 1 135 516
hexNew 1 135 516
assign 1 135 517
lesserEquals 1 135 522
assign 1 136 523
new 0 136 523
assign 1 136 524
hexNew 1 136 524
assign 1 136 525
new 0 136 525
assign 1 136 526
hexNew 1 136 526
assign 1 136 527
and 1 136 527
assign 1 136 528
new 0 136 528
assign 1 136 529
shiftRight 1 136 529
assign 1 136 530
add 1 136 530
setIntUnchecked 2 136 531
assign 1 137 532
new 0 137 532
assign 1 137 533
add 1 137 533
assign 1 137 534
new 0 137 534
assign 1 137 535
hexNew 1 137 535
assign 1 137 536
new 0 137 536
assign 1 137 537
hexNew 1 137 537
assign 1 137 538
and 1 137 538
assign 1 137 539
new 0 137 539
assign 1 137 540
shiftRight 1 137 540
assign 1 137 541
add 1 137 541
setIntUnchecked 2 137 542
assign 1 138 543
new 0 138 543
assign 1 138 544
add 1 138 544
assign 1 138 545
new 0 138 545
assign 1 138 546
hexNew 1 138 546
assign 1 138 547
new 0 138 547
assign 1 138 548
hexNew 1 138 548
assign 1 138 549
and 1 138 549
assign 1 138 550
new 0 138 550
assign 1 138 551
shiftRight 1 138 551
assign 1 138 552
add 1 138 552
setIntUnchecked 2 138 553
assign 1 139 554
new 0 139 554
assign 1 139 555
add 1 139 555
assign 1 139 556
new 0 139 556
assign 1 139 557
hexNew 1 139 557
assign 1 139 558
new 0 139 558
assign 1 139 559
hexNew 1 139 559
assign 1 139 560
and 1 139 560
assign 1 139 561
add 1 139 561
setIntUnchecked 2 139 562
assign 1 140 563
new 0 140 563
assign 1 142 566
new 0 142 566
assign 1 145 572
new 0 145 572
assign 1 145 573
lesser 1 145 578
assign 1 146 579
new 0 146 579
assign 1 146 580
new 1 146 580
throw 1 146 581
assign 1 148 583
sizeGet 0 148 583
assign 1 148 584
add 1 148 584
sizeSet 1 148 585
assign 1 169 653
new 0 169 653
assign 1 170 654
new 0 170 654
assign 1 171 655
new 0 171 655
assign 1 173 656
new 0 173 656
assign 1 173 657
fromEscapesGet 0 173 657
assign 1 175 658
linkedListIteratorGet 0 175 658
assign 1 179 661
hasNextGet 0 179 661
assign 1 180 663
nextGet 0 180 663
assign 1 183 665
not 0 183 665
assign 1 183 667
equals 1 183 667
assign 1 0 669
assign 1 0 672
assign 1 0 676
assign 1 184 679
new 0 184 679
assign 1 185 680
extractString 0 185 680
handleString 1 185 681
assign 1 188 685
get 1 188 685
assign 1 189 686
def 1 189 691
addValue 1 190 692
assign 1 191 695
new 0 191 695
assign 1 191 696
begins 1 191 696
assign 1 192 698
jsonUcUnescape 1 192 698
assign 1 193 699
jsonUcGetAfterPart 1 193 699
assign 1 194 700
new 0 194 700
assign 1 195 701
def 1 195 706
assign 1 195 707
jsonUcIsPairEnd 1 195 707
assign 1 195 708
not 0 195 708
assign 1 0 710
assign 1 0 713
assign 1 0 717
assign 1 196 720
new 0 196 720
assign 1 196 721
new 1 196 721
throw 1 196 722
assign 1 197 725
undef 1 197 730
assign 1 198 731
jsonUcIsPairStart 1 198 731
assign 1 200 735
def 1 200 740
assign 1 0 741
assign 1 0 744
assign 1 0 748
assign 1 201 751
new 0 201 751
assign 1 201 752
new 1 201 752
throw 1 201 753
assign 1 204 756
jsonUcAppendValue 3 206 759
assign 1 207 760
assign 1 208 761
def 1 208 766
addValue 1 209 767
addValue 1 213 772
assign 1 215 775
new 0 215 775
assign 1 216 778
equals 1 216 778
assign 1 217 780
new 0 217 780
addValue 1 219 783
assign 1 224 789
equals 1 224 789
assign 1 0 791
assign 1 224 794
equals 1 224 794
assign 1 0 796
assign 1 0 799
assign 1 0 803
assign 1 224 806
equals 1 224 806
assign 1 0 808
assign 1 0 811
assign 1 0 815
assign 1 224 818
equals 1 224 818
assign 1 0 820
assign 1 0 823
assign 1 225 829
equals 1 225 829
assign 1 226 831
new 0 226 831
assign 1 227 834
equals 1 227 834
beginMap 0 228 836
assign 1 229 839
equals 1 229 839
endMap 0 230 841
assign 1 231 844
equals 1 231 844
kvMid 0 232 846
assign 1 233 849
equals 1 233 849
beginList 0 234 851
assign 1 235 854
equals 1 235 854
endList 0 236 856
assign 1 240 859
new 0 240 859
assign 1 240 860
equals 1 240 860
assign 1 0 862
assign 1 240 865
new 0 240 865
assign 1 240 866
equals 1 240 866
assign 1 0 868
assign 1 0 871
assign 1 0 875
assign 1 240 878
new 0 240 878
assign 1 240 879
equals 1 240 879
assign 1 0 881
assign 1 0 884
assign 1 0 888
assign 1 240 891
new 0 240 891
assign 1 240 892
equals 1 240 892
assign 1 0 894
assign 1 0 897
assign 1 243 903
new 0 243 903
assign 1 243 904
equals 1 243 904
handleTrue 0 244 906
assign 1 245 909
new 0 245 909
assign 1 245 910
equals 1 245 910
handleFalse 0 246 912
assign 1 247 915
new 0 247 915
assign 1 247 916
equals 1 247 916
handleNull 0 248 918
assign 1 251 921
new 1 251 921
handleInteger 1 251 922
return 1 0 943
assign 1 0 946
return 1 0 950
assign 1 0 953
return 1 0 957
assign 1 0 960
return 1 0 964
assign 1 0 967
return 1 0 971
assign 1 0 974
return 1 0 978
assign 1 0 981
return 1 0 985
assign 1 0 988
return 1 0 992
assign 1 0 995
return 1 0 999
assign 1 0 1002
return 1 0 1006
assign 1 0 1009
return 1 0 1013
assign 1 0 1016
return 1 0 1020
assign 1 0 1023
return 1 0 1027
assign 1 0 1030
return 1 0 1034
assign 1 0 1037
return 1 0 1041
assign 1 0 1044
return 1 0 1048
assign 1 0 1051
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1098879089: return bem_hsubGet_0();
case 1887047473: return bem_rbracketGet_0();
case 1081412016: return bem_many_0();
case 589384576: return bem_lbraceGet_0();
case 633437795: return bem_vsubGet_0();
case 399609227: return bem_hmAddGet_0();
case 748189618: return bem_commaGet_0();
case 617801715: return bem_tokensGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 1000967768: return bem_crGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 647501781: return bem_lbracketGet_0();
case 1152565608: return bem_colonGet_0();
case 55016493: return bem_lfGet_0();
case 1259904107: return bem_quoteGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 193407370: return bem_tokerGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1513809158: return bem_rbraceGet_0();
case 1820417453: return bem_create_0();
case 482013217: return bem_spaceGet_0();
case 53269894: return bem_escapeGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 64352147: return bem_escapeSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1012050021: return bem_crSet_1(bevd_0);
case 410691480: return bem_hmAddSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2072727009: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1087796836: return bem_hsubSet_1(bevd_0);
case 1180729747: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1898129726: return bem_rbracketSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 493095470: return bem_spaceSet_1(bevd_0);
case 204489623: return bem_tokerSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1270986360: return bem_quoteSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 519708122: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case 606719462: return bem_tokensSet_1(bevd_0);
case 622355542: return bem_vsubSet_1(bevd_0);
case 636419528: return bem_lbracketSet_1(bevd_0);
case 759271871: return bem_commaSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1163647861: return bem_colonSet_1(bevd_0);
case 66098746: return bem_lfSet_1(bevd_0);
case 578302323: return bem_lbraceSet_1(bevd_0);
case 1524891411: return bem_rbraceSet_1(bevd_0);
case 1855747134: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 792967770: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1886933344: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callHash) {
case 1217293707: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_JsonParser();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_JsonParser.bevs_inst = (BEC_2_4_6_JsonParser)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_JsonParser.bevs_inst;
}
}
}
