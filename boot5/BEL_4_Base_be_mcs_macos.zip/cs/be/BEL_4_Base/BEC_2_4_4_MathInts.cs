namespace be.BEL_4_Base {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public class BEC_2_4_4_MathInts : BEC_2_6_6_SystemObject {
public BEC_2_4_4_MathInts() { }
static BEC_2_4_4_MathInts() { }
private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_4_MathInts bevs_inst;
public BEC_2_4_3_MathInt bevp_max;
public BEC_2_4_3_MathInt bevp_min;
public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_3_MathInt bevp_one;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_4_4_MathInts bem_default_0() {
BEC_2_4_3_MathInt bevl__max = null;
BEC_2_4_3_MathInt bevl__min = null;
bevl__max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl__min = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl__max.bevi_int = int.MaxValue;
      bevl__min.bevi_int = int.MinValue;
      //Stream stdout = Console.OpenStandardOutput();
      //Console.WriteLine(bevl__max.bevi_int.ToString());
      //Console.WriteLine(bevl__min.bevi_int.ToString());
      bevp_max = bevl__max;
bevp_min = bevl__min;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_one = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_min_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (beva_a == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 816 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 816 */ {
if (beva_a.bevi_int < beva_b.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 816 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 816 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 816 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 816 */ {
return beva_a;
} /* Line: 817 */
return beva_b;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_max_2(BEC_2_4_3_MathInt beva_a, BEC_2_4_3_MathInt beva_b) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (beva_a == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 823 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 823 */ {
if (beva_a.bevi_int > beva_b.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 823 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 823 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 823 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 823 */ {
return beva_a;
} /* Line: 824 */
return beva_b;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_minGet_0() {
return bevp_min;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_minSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_min = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_oneGet_0() {
return bevp_one;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_one = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {768, 769, 808, 809, 810, 811, 816, 816, 0, 816, 816, 0, 0, 817, 819, 823, 823, 0, 823, 823, 0, 0, 824, 826, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 30, 31, 32, 33, 40, 45, 46, 49, 54, 55, 58, 62, 64, 70, 75, 76, 79, 84, 85, 88, 92, 94, 97, 100, 104, 107, 111, 114, 118, 121};
/* BEGIN LINEINFO 
assign 1 768 22
new 0 768 22
assign 1 769 23
new 0 769 23
assign 1 808 30
assign 1 809 31
assign 1 810 32
new 0 810 32
assign 1 811 33
new 0 811 33
assign 1 816 40
undef 1 816 45
assign 1 0 46
assign 1 816 49
lesser 1 816 54
assign 1 0 55
assign 1 0 58
return 1 817 62
return 1 819 64
assign 1 823 70
undef 1 823 75
assign 1 0 76
assign 1 823 79
greater 1 823 84
assign 1 0 85
assign 1 0 88
return 1 824 92
return 1 826 94
return 1 0 97
assign 1 0 100
return 1 0 104
assign 1 0 107
return 1 0 111
assign 1 0 114
return 1 0 118
assign 1 0 121
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 1390695851: return bem_minGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 193194049: return bem_zeroGet_0();
case 385500803: return bem_maxGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 1979813569: return bem_oneGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 182111796: return bem_zeroSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 396583056: return bem_maxSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1990895822: return bem_oneSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1379613598: return bem_minSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 103900549: return bem_min_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 103671831: return bem_max_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_MathInts();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_MathInts.bevs_inst = (BEC_2_4_4_MathInts)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_MathInts.bevs_inst;
}
}
}
