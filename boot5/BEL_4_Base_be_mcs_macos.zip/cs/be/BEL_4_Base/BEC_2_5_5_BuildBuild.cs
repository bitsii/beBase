namespace be.BEL_4_Base {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 12));
private static byte[] bels_12 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 21));
private static byte[] bels_13 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 6));
private static byte[] bels_14 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 13));
private static byte[] bels_15 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 21));
private static byte[] bels_16 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 6));
private static byte[] bels_17 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_18 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_21 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_22 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_23 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_24 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_25 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_26 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_27 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_28 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_29 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_30 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_31 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_32 = {0x74,0x72,0x75,0x65};
private static byte[] bels_33 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_35 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_36 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_37 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_38 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_39 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_40 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_42 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_43 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_44 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_45 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_49 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_50 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_51 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_52 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_53 = {0x72,0x75,0x6E};
private static byte[] bels_54 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_55 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_56 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_57 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_58 = {0x67,0x63,0x63};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_60 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_61 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_61, 9));
private static byte[] bels_62 = {};
private static byte[] bels_63 = {0x63};
private static byte[] bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_64, 8));
private static byte[] bels_65 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_65, 7));
private static byte[] bels_66 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_67 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_68 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_69, 2));
private static byte[] bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_70, 2));
private static byte[] bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_74, 41));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_75, 30));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_20 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_76, 31));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_77, 41));
private static byte[] bels_78 = {0x2F};
private static BEC_2_4_6_TextString bevo_22 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_79, 31));
private static byte[] bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_24 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_80, 41));
private static byte[] bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_25 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_81, 51));
private static byte[] bels_82 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_26 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_82, 14));
private static byte[] bels_83 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_27 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_83, 19));
private static byte[] bels_84 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_84, 9));
private static byte[] bels_85 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_29 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_85, 13));
private static byte[] bels_86 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_86, 2));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_31 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_87, 22));
private static byte[] bels_88 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_33 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_92, 5));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_37 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_94, 6));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_96, 7));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_41 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_98, 8));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_43 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_100, 9));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_45 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_102, 10));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_47 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_103, 15));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_104, 11));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_49 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_50 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_106, 12));
private static byte[] bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_51 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_107, 16));
private static byte[] bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_52 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_108, 13));
private static byte[] bels_109 = {0x20};
private static BEC_2_4_6_TextString bevo_53 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_109, 1));
private static byte[] bels_110 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_54 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_110, 16));
public static new BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 97 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 148 */
return beva_addTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_113_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_17));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 159 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 159 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 162 */
} /* Line: 160 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
} /* Line: 159 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 168 */
bevt_16_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_19));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_20));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_21));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 172 */
 else  /* Line: 173 */ {
bevp_exeName = bevp_libName;
} /* Line: 174 */
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_22));
bevt_25_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_23));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_24));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_25));
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_26));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_27));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_28));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bels_29));
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_30));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_31));
bevt_48_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_32));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_33));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_34));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_35));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_36));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_57_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_37));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_59_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_38));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_61_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_39));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_40));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_41));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_67_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_42));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_69_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_43));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_71_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_44));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 225 */
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_45));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_75_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_46));
bevt_76_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_47));
bevt_78_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_48));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_49));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bels_50));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_84_tmpvar_phold.bevi_bool) {
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_51));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bels_52));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_53));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bels_54));
bevt_90_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_55));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_56));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_57));
bevt_95_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_58));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_59));
bevt_98_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_60));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_62));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_63));
} /* Line: 263 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
if (bevt_118_tmpvar_phold.bevi_bool) {
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_122_tmpvar_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 295 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bels_66));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bels_67));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_9_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bels_71));
bevt_8_tmpvar_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 355 */
} /* Line: 348 */
} /* Line: 348 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 358 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_23_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_24_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_37_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_64_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_76_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
bevt_4_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 371 */ {
bevt_7_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 372 */
} /* Line: 371 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 377 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 378 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 381 */
} /* Line: 378 */
 else  /* Line: 377 */ {
break;
} /* Line: 377 */
} /* Line: 377 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 384 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 389 */
} /* Line: 385 */
 else  /* Line: 384 */ {
break;
} /* Line: 384 */
} /* Line: 384 */
if (bevp_parse.bevi_bool) /* Line: 392 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 397 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 399 */
bevt_17_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_19_tmpvar_phold = bevo_17;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_22_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_22_tmpvar_phold.bem_now_0();
bevt_23_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_23_tmpvar_phold.bem_doEmit_0();
bevt_25_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_24_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_25_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_24_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_27_tmpvar_phold = bevo_18;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_26_tmpvar_phold.bem_print_0();
bevt_29_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpvar_phold.bem_now_0();
bevl_emitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevl_emitStart);
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevl_emitTime);
bevt_30_tmpvar_phold.bem_print_0();
bevt_32_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_32_tmpvar_phold;
} /* Line: 414 */
if (bevp_doEmit.bevi_bool) /* Line: 416 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_33_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_33_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 420 */ {
bevt_34_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 420 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_35_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_35_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 426 */ {
bevt_36_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 426 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 428 */
 else  /* Line: 426 */ {
break;
} /* Line: 426 */
} /* Line: 426 */
} /* Line: 426 */
bevt_38_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_37_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_38_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_37_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 433 */ {
bevt_41_tmpvar_phold = bevo_20;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_40_tmpvar_phold.bem_print_0();
} /* Line: 434 */
bevt_43_tmpvar_phold = bevo_21;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_42_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 437 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 439 */
if (bevp_make.bevi_bool) /* Line: 442 */ {
if (bevp_genOnly.bevi_bool) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 443 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 446 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 447 */ {
bevt_45_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 447 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_46_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_46_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_47_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_47_tmpvar_phold.bem_copy_0();
bevt_49_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_48_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 451 */ {
bevt_52_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_52_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 452 */
bevt_55_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 454 */ {
bevt_56_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
} /* Line: 455 */
} /* Line: 454 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
} /* Line: 447 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 462 */ {
bevt_58_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_59_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 462 */ {
bevt_60_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_60_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_64_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpvar_phold.bem_copy_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_toString_0();
bevt_66_tmpvar_phold = bevo_22;
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_add_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_add_1(bevt_67_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_61_tmpvar_phold);
bevt_69_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_68_tmpvar_phold != null && bevt_68_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpvar_phold).bevi_bool) /* Line: 466 */ {
bevt_70_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_70_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 467 */
bevt_73_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 469 */ {
bevt_74_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_75_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
} /* Line: 470 */
} /* Line: 469 */
 else  /* Line: 462 */ {
break;
} /* Line: 462 */
} /* Line: 462 */
} /* Line: 462 */
} /* Line: 443 */
bevt_77_tmpvar_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_76_tmpvar_phold = (BEC_2_4_8_TimeInterval) bevt_77_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_76_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_80_tmpvar_phold = bevo_23;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_79_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_parseEmitTime == null) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_83_tmpvar_phold = bevo_24;
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_82_tmpvar_phold.bem_print_0();
} /* Line: 481 */
if (bevp_parseEmitCompileTime == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevt_86_tmpvar_phold = bevo_25;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_85_tmpvar_phold.bem_print_0();
} /* Line: 484 */
if (bevp_run.bevi_bool) /* Line: 487 */ {
bevt_87_tmpvar_phold = bevo_26;
bevt_87_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_90_tmpvar_phold = bevo_27;
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevl_result);
bevt_91_tmpvar_phold = bevo_28;
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_add_1(bevt_91_tmpvar_phold);
bevt_88_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 491 */
bevt_92_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_92_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 501 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 503 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 503 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 507 */
 else  /* Line: 503 */ {
break;
} /* Line: 503 */
} /* Line: 503 */
bevt_6_tmpvar_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 513 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 514 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 517 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 522 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 524 */
 else  /* Line: 525 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 527 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 529 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 539 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 540 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 555 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 556 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 569 */ {
if (bevp_printSteps.bevi_bool) /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 570 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 570 */ {
bevt_4_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 571 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 580 */ {
bevt_11_tmpvar_phold = bevo_30;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 581 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 584 */ {
bevt_13_tmpvar_phold = bevo_31;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 586 */
if (bevp_printSteps.bevi_bool) /* Line: 589 */ {
bevt_15_tmpvar_phold = bevo_32;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 590 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 593 */ {
bevt_17_tmpvar_phold = bevo_33;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 595 */
if (bevp_printSteps.bevi_bool) /* Line: 597 */ {
bevt_19_tmpvar_phold = bevo_34;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 598 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 603 */ {
bevt_21_tmpvar_phold = bevo_35;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 605 */
if (bevp_printSteps.bevi_bool) /* Line: 608 */ {
bevt_23_tmpvar_phold = bevo_36;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 609 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 612 */ {
bevt_25_tmpvar_phold = bevo_37;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 614 */
if (bevp_printSteps.bevi_bool) /* Line: 617 */ {
bevt_27_tmpvar_phold = bevo_38;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 618 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 621 */ {
bevt_29_tmpvar_phold = bevo_39;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 623 */
if (bevp_printSteps.bevi_bool) /* Line: 626 */ {
bevt_31_tmpvar_phold = bevo_40;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 627 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 630 */ {
bevt_33_tmpvar_phold = bevo_41;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 632 */
if (bevp_printSteps.bevi_bool) /* Line: 635 */ {
bevt_35_tmpvar_phold = bevo_42;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 636 */
bevt_36_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 639 */ {
bevt_37_tmpvar_phold = bevo_43;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 641 */
if (bevp_printSteps.bevi_bool) /* Line: 644 */ {
bevt_39_tmpvar_phold = bevo_44;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 645 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 648 */ {
bevt_41_tmpvar_phold = bevo_45;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 650 */
if (bevp_printSteps.bevi_bool) /* Line: 653 */ {
bevt_43_tmpvar_phold = bevo_46;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 654 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 657 */ {
bevt_45_tmpvar_phold = bevo_47;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 659 */
if (bevp_printSteps.bevi_bool) /* Line: 662 */ {
bevt_47_tmpvar_phold = bevo_48;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 663 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 666 */ {
bevt_49_tmpvar_phold = bevo_49;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 668 */
if (bevp_printSteps.bevi_bool) /* Line: 670 */ {
bevt_51_tmpvar_phold = bevo_50;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 671 */
bevt_52_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 674 */ {
bevt_53_tmpvar_phold = bevo_51;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 676 */
if (bevp_printSteps.bevi_bool) /* Line: 679 */ {
bevt_55_tmpvar_phold = bevo_52;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_53;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 681 */
bevt_57_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 684 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 684 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 684 */ {
bevt_58_tmpvar_phold = bevo_54;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 686 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 688 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 688 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 699 */
 else  /* Line: 688 */ {
break;
} /* Line: 688 */
} /* Line: 688 */
} /* Line: 688 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 709 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 709 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 713 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 714 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 716 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 718 */
} /* Line: 716 */
 else  /* Line: 709 */ {
break;
} /* Line: 709 */
} /* Line: 709 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 91, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 150, 155, 157, 158, 158, 158, 159, 159, 0, 159, 159, 160, 160, 160, 161, 162, 162, 167, 167, 167, 167, 168, 170, 170, 170, 171, 171, 172, 172, 172, 174, 176, 176, 176, 176, 176, 176, 177, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 355, 355, 355, 357, 358, 360, 365, 365, 366, 367, 368, 368, 369, 370, 372, 372, 372, 375, 377, 0, 377, 377, 378, 378, 378, 379, 380, 381, 384, 0, 384, 384, 385, 385, 385, 386, 387, 388, 389, 389, 394, 394, 395, 397, 399, 402, 402, 402, 404, 404, 404, 406, 406, 406, 408, 408, 409, 409, 410, 410, 410, 411, 411, 411, 412, 412, 412, 413, 413, 413, 414, 414, 417, 418, 420, 420, 420, 421, 422, 424, 425, 426, 426, 426, 427, 428, 432, 432, 432, 433, 433, 434, 434, 434, 436, 436, 436, 439, 443, 443, 444, 445, 447, 0, 447, 447, 448, 448, 449, 449, 450, 450, 450, 451, 451, 452, 452, 454, 454, 454, 455, 455, 455, 459, 460, 462, 462, 0, 0, 0, 463, 463, 464, 464, 464, 464, 464, 464, 464, 464, 466, 466, 467, 467, 469, 469, 469, 470, 470, 470, 475, 475, 475, 477, 477, 478, 478, 478, 480, 480, 481, 481, 481, 483, 483, 484, 484, 484, 488, 488, 489, 490, 490, 490, 490, 490, 491, 493, 493, 497, 497, 497, 498, 499, 499, 500, 501, 503, 503, 503, 504, 505, 505, 506, 507, 509, 509, 513, 513, 513, 513, 514, 514, 514, 516, 516, 517, 517, 517, 517, 518, 520, 520, 520, 520, 520, 522, 522, 523, 523, 524, 527, 527, 527, 529, 531, 531, 532, 532, 532, 532, 533, 537, 538, 538, 539, 539, 540, 546, 546, 547, 548, 555, 555, 556, 558, 563, 564, 565, 566, 567, 568, 568, 0, 0, 0, 571, 571, 571, 571, 573, 575, 575, 575, 575, 576, 576, 576, 577, 581, 581, 583, 583, 585, 585, 586, 586, 590, 590, 592, 592, 594, 594, 595, 595, 598, 598, 601, 601, 602, 604, 604, 605, 605, 609, 609, 611, 611, 613, 613, 614, 614, 618, 618, 620, 620, 622, 622, 623, 623, 627, 627, 629, 629, 631, 631, 632, 632, 636, 636, 638, 638, 640, 640, 641, 641, 645, 645, 647, 647, 649, 649, 650, 650, 654, 654, 656, 656, 658, 658, 659, 659, 663, 663, 665, 665, 667, 667, 668, 668, 671, 671, 673, 673, 675, 675, 676, 676, 680, 680, 681, 681, 683, 683, 0, 0, 0, 685, 685, 686, 686, 688, 688, 688, 689, 691, 692, 693, 693, 694, 695, 695, 695, 696, 697, 698, 699, 705, 706, 707, 708, 708, 709, 709, 710, 711, 711, 712, 713, 713, 714, 716, 716, 717, 718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 284, 289, 290, 291, 293, 296, 297, 299, 302, 306, 309, 313, 316, 317, 319, 320, 326, 327, 328, 329, 336, 337, 338, 339, 340, 352, 353, 354, 355, 356, 357, 358, 359, 362, 367, 368, 369, 375, 383, 384, 385, 387, 388, 389, 393, 394, 395, 396, 397, 400, 404, 407, 411, 413, 433, 434, 435, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 458, 594, 595, 596, 597, 602, 603, 604, 604, 607, 609, 610, 611, 616, 617, 618, 619, 627, 628, 629, 630, 632, 634, 635, 636, 637, 638, 640, 641, 642, 645, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 696, 697, 699, 700, 701, 706, 707, 709, 710, 711, 716, 717, 719, 720, 721, 726, 727, 729, 730, 731, 736, 737, 739, 740, 741, 746, 747, 749, 750, 751, 756, 757, 759, 760, 761, 766, 767, 769, 770, 771, 776, 777, 779, 780, 781, 786, 787, 789, 790, 791, 796, 797, 800, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 820, 821, 822, 827, 828, 831, 835, 838, 838, 841, 843, 844, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 887, 888, 891, 893, 894, 895, 896, 897, 898, 903, 904, 905, 907, 908, 909, 910, 915, 916, 917, 919, 920, 921, 921, 924, 926, 927, 928, 934, 935, 936, 937, 938, 939, 940, 945, 946, 947, 949, 954, 955, 956, 957, 958, 959, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 1024, 1025, 1026, 1029, 1031, 1032, 1033, 1034, 1035, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1051, 1052, 1052, 1055, 1057, 1058, 1065, 1066, 1067, 1068, 1069, 1070, 1075, 1076, 1076, 1079, 1081, 1082, 1095, 1096, 1099, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1117, 1118, 1132, 1137, 1138, 1140, 1145, 1146, 1147, 1148, 1150, 1153, 1154, 1156, 1159, 1160, 1162, 1165, 1166, 1167, 1171, 1172, 1174, 1286, 1287, 1288, 1289, 1290, 1295, 1296, 1297, 1299, 1300, 1301, 1304, 1305, 1305, 1308, 1310, 1311, 1312, 1317, 1318, 1319, 1320, 1327, 1327, 1330, 1332, 1333, 1334, 1339, 1340, 1341, 1342, 1343, 1344, 1352, 1355, 1357, 1358, 1364, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1399, 1400, 1401, 1402, 1405, 1407, 1408, 1414, 1415, 1416, 1417, 1420, 1422, 1423, 1430, 1431, 1432, 1433, 1438, 1439, 1440, 1441, 1443, 1444, 1445, 1447, 1450, 1455, 1456, 1457, 1459, 1459, 1462, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1475, 1476, 1478, 1479, 1480, 1482, 1483, 1484, 1492, 1493, 1496, 1498, 1500, 1503, 1507, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1523, 1524, 1526, 1527, 1528, 1530, 1531, 1532, 1541, 1542, 1543, 1544, 1549, 1550, 1551, 1552, 1554, 1559, 1560, 1561, 1562, 1564, 1569, 1570, 1571, 1572, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1585, 1586, 1599, 1600, 1603, 1605, 1606, 1607, 1608, 1609, 1615, 1616, 1619, 1621, 1622, 1623, 1624, 1625, 1631, 1632, 1660, 1661, 1662, 1667, 1668, 1669, 1670, 1672, 1673, 1674, 1675, 1676, 1681, 1682, 1685, 1686, 1687, 1688, 1689, 1690, 1695, 1696, 1697, 1698, 1701, 1702, 1703, 1705, 1707, 1708, 1709, 1710, 1711, 1712, 1713, 1721, 1722, 1723, 1724, 1729, 1730, 1732, 1733, 1734, 1735, 1739, 1744, 1745, 1747, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1835, 1839, 1842, 1846, 1847, 1848, 1849, 1851, 1852, 1853, 1854, 1855, 1856, 1857, 1858, 1859, 1861, 1862, 1864, 1865, 1867, 1868, 1869, 1870, 1873, 1874, 1876, 1877, 1879, 1880, 1881, 1882, 1885, 1886, 1888, 1889, 1890, 1892, 1893, 1894, 1895, 1898, 1899, 1901, 1902, 1904, 1905, 1906, 1907, 1910, 1911, 1913, 1914, 1916, 1917, 1918, 1919, 1922, 1923, 1925, 1926, 1928, 1929, 1930, 1931, 1934, 1935, 1937, 1938, 1940, 1941, 1942, 1943, 1946, 1947, 1949, 1950, 1952, 1953, 1954, 1955, 1958, 1959, 1961, 1962, 1964, 1965, 1966, 1967, 1970, 1971, 1973, 1974, 1976, 1977, 1978, 1979, 1982, 1983, 1985, 1986, 1988, 1989, 1990, 1991, 1994, 1995, 1996, 1997, 1999, 2000, 2002, 2006, 2009, 2013, 2014, 2015, 2016, 2018, 2019, 2022, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2058, 2059, 2060, 2061, 2062, 2063, 2066, 2068, 2069, 2070, 2071, 2072, 2073, 2075, 2077, 2078, 2080, 2081, 2091, 2094, 2098, 2101, 2105, 2108, 2112, 2115, 2119, 2122, 2126, 2129, 2133, 2136, 2140, 2143, 2147, 2150, 2154, 2157, 2161, 2164, 2168, 2171, 2175, 2178, 2182, 2185, 2189, 2192, 2196, 2199, 2203, 2206, 2210, 2213, 2217, 2220, 2224, 2227, 2231, 2234, 2238, 2241, 2245, 2248, 2252, 2255, 2259, 2262, 2266, 2269, 2273, 2276, 2280, 2283, 2287, 2290, 2294, 2297, 2301, 2304, 2308, 2311, 2315, 2318, 2322, 2325, 2329, 2332, 2336, 2339, 2343, 2346, 2350, 2353, 2357, 2360, 2364, 2367, 2371, 2374, 2378, 2381, 2385, 2388, 2392, 2395, 2399, 2402, 2406, 2409, 2413, 2416, 2420, 2423, 2427, 2430, 2434, 2437, 2441, 2444, 2448, 2451, 2455, 2458, 2462, 2465, 2469, 2472, 2476, 2479, 2483, 2486, 2490, 2493, 2497, 2500, 2504, 2507, 2511, 2514, 2518, 2521, 2525, 2528, 2532, 2535, 2539, 2542, 2546, 2549, 2553, 2556, 2560, 2563, 2567};
/* BEGIN LINEINFO 
assign 1 53 247
new 0 53 247
assign 1 55 248
new 0 55 248
assign 1 56 249
new 0 56 249
assign 1 57 250
new 0 57 250
assign 1 58 251
new 0 58 251
assign 1 60 252
new 0 60 252
assign 1 61 253
new 0 61 253
assign 1 62 254
new 0 62 254
assign 1 63 255
new 0 63 255
assign 1 64 256
new 0 64 256
assign 1 65 257
new 0 65 257
assign 1 66 258
new 0 66 258
assign 1 70 259
new 0 70 259
assign 1 72 260
new 1 72 260
assign 1 73 261
ntypesGet 0 73 261
assign 1 74 262
twtokGet 0 74 262
assign 1 75 263
new 0 75 263
assign 1 75 264
new 1 75 264
assign 1 78 265
new 0 78 265
assign 1 81 266
new 0 81 266
assign 1 82 267
new 0 82 267
assign 1 88 268
new 0 88 268
assign 1 89 269
new 0 89 269
assign 1 90 270
new 0 90 270
assign 1 91 271
new 0 91 271
assign 1 91 272
new 1 91 272
assign 1 96 284
def 1 96 289
assign 1 96 290
new 0 96 290
assign 1 96 291
equals 1 96 291
assign 1 0 293
assign 1 96 296
new 0 96 296
assign 1 96 297
ends 1 96 297
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 97 316
new 0 97 316
return 1 97 317
assign 1 99 319
new 0 99 319
return 1 99 320
assign 1 103 326
new 0 103 326
assign 1 103 327
new 0 103 327
assign 1 103 328
swap 2 103 328
return 1 103 329
assign 1 107 336
new 0 107 336
assign 1 107 337
argsGet 0 107 337
assign 1 108 338
new 0 108 338
assign 1 108 339
main 1 108 339
exit 1 108 340
assign 1 112 352
assign 1 113 353
new 1 113 353
assign 1 114 354
new 0 114 354
assign 1 114 355
new 0 114 355
assign 1 114 356
get 2 114 356
assign 1 114 357
firstGet 0 114 357
assign 1 114 358
new 1 114 358
assign 1 115 359
new 0 115 359
assign 1 115 362
lesser 1 115 367
assign 1 116 368
go 0 116 368
incrementValue 0 115 369
return 1 118 375
assign 1 122 383
new 0 122 383
config 0 123 384
assign 1 124 385
new 0 124 385
assign 1 126 387
new 0 126 387
assign 1 127 388
doWhat 0 127 388
assign 1 128 389
new 0 128 389
assign 1 130 393
toString 0 130 393
assign 1 131 394
new 0 131 394
assign 1 132 395
new 0 132 395
assign 1 132 396
add 1 132 396
assign 1 133 397
new 0 133 397
assign 1 0 400
assign 1 0 404
assign 1 0 407
print 0 136 411
return 1 138 413
assign 1 142 433
nameGet 0 142 433
assign 1 142 434
new 0 142 434
assign 1 142 435
equals 1 142 435
assign 1 143 437
new 0 143 437
assign 1 143 438
add 1 143 438
assign 1 143 439
add 1 143 439
assign 1 143 440
add 1 143 440
assign 1 144 441
new 0 144 441
assign 1 144 442
add 1 144 442
assign 1 144 443
add 1 144 443
assign 1 145 444
new 0 145 444
assign 1 145 445
add 1 145 445
assign 1 145 446
add 1 145 446
assign 1 146 447
new 0 146 447
assign 1 146 448
add 1 146 448
assign 1 146 449
add 1 146 449
assign 1 146 450
add 1 146 450
assign 1 147 451
new 0 147 451
assign 1 147 452
add 1 147 452
assign 1 147 453
add 1 147 453
assign 1 148 454
new 0 148 454
assign 1 148 455
add 1 148 455
assign 1 148 456
add 1 148 456
return 1 150 458
assign 1 155 594
new 0 155 594
assign 1 157 595
new 0 157 595
assign 1 158 596
get 1 158 596
assign 1 158 597
def 1 158 602
assign 1 159 603
get 1 159 603
assign 1 159 604
iteratorGet 0 0 604
assign 1 159 607
hasNextGet 0 159 607
assign 1 159 609
nextGet 0 159 609
assign 1 160 610
has 1 160 610
assign 1 160 611
not 0 160 616
put 1 161 617
assign 1 162 618
new 1 162 618
addFile 1 162 619
assign 1 167 627
new 0 167 627
assign 1 167 628
nameGet 0 167 628
assign 1 167 629
new 0 167 629
assign 1 167 630
equals 1 167 630
preProcessorSet 1 168 632
assign 1 170 634
new 0 170 634
assign 1 170 635
get 1 170 635
assign 1 170 636
firstGet 0 170 636
assign 1 171 637
new 0 171 637
assign 1 171 638
has 1 171 638
assign 1 172 640
new 0 172 640
assign 1 172 641
get 1 172 641
assign 1 172 642
firstGet 0 172 642
assign 1 174 645
assign 1 176 647
new 0 176 647
assign 1 176 648
new 0 176 648
assign 1 176 649
get 2 176 649
assign 1 176 650
firstGet 0 176 650
assign 1 176 651
new 1 176 651
assign 1 176 652
pathGet 0 176 652
addStep 1 177 653
assign 1 178 654
new 0 178 654
addStep 1 178 655
assign 1 179 656
new 0 179 656
assign 1 179 657
new 0 179 657
assign 1 179 658
get 2 179 658
assign 1 179 659
firstGet 0 179 659
assign 1 179 660
new 1 179 660
assign 1 179 661
pathGet 0 179 661
assign 1 180 662
new 0 180 662
assign 1 180 663
new 0 180 663
assign 1 180 664
nameGet 0 180 664
assign 1 180 665
get 2 180 665
assign 1 180 666
firstGet 0 180 666
assign 1 180 667
new 1 180 667
assign 1 181 668
new 0 181 668
assign 1 181 669
nameGet 0 181 669
assign 1 181 670
get 2 181 670
assign 1 181 671
firstGet 0 181 671
assign 1 181 672
new 1 181 672
assign 1 182 673
new 0 182 673
assign 1 182 674
new 0 182 674
assign 1 182 675
get 2 182 675
assign 1 182 676
firstGet 0 182 676
assign 1 182 677
new 1 182 677
assign 1 183 678
new 0 183 678
assign 1 183 679
new 0 183 679
assign 1 183 680
get 2 183 680
assign 1 183 681
firstGet 0 183 681
assign 1 183 682
new 1 183 682
assign 1 185 683
new 0 185 683
assign 1 185 684
get 1 185 684
assign 1 185 685
firstGet 0 185 685
assign 1 186 686
new 0 186 686
assign 1 186 687
get 1 186 687
assign 1 186 688
firstGet 0 186 688
assign 1 187 689
new 0 187 689
assign 1 187 690
get 1 187 690
assign 1 188 691
undef 1 188 696
assign 1 189 697
new 0 189 697
assign 1 191 699
new 0 191 699
assign 1 191 700
get 1 191 700
assign 1 192 701
undef 1 192 706
assign 1 193 707
new 0 193 707
assign 1 195 709
new 0 195 709
assign 1 195 710
get 1 195 710
assign 1 196 711
undef 1 196 716
assign 1 197 717
new 0 197 717
assign 1 199 719
new 0 199 719
assign 1 199 720
get 1 199 720
assign 1 200 721
undef 1 200 726
assign 1 201 727
new 0 201 727
assign 1 203 729
new 0 203 729
assign 1 203 730
get 1 203 730
assign 1 204 731
undef 1 204 736
assign 1 205 737
new 0 205 737
assign 1 207 739
new 0 207 739
assign 1 207 740
get 1 207 740
assign 1 208 741
undef 1 208 746
assign 1 209 747
new 0 209 747
assign 1 211 749
new 0 211 749
assign 1 211 750
get 1 211 750
assign 1 212 751
undef 1 212 756
assign 1 213 757
new 0 213 757
assign 1 215 759
new 0 215 759
assign 1 215 760
get 1 215 760
assign 1 216 761
undef 1 216 766
assign 1 217 767
new 0 217 767
assign 1 219 769
new 0 219 769
assign 1 219 770
get 1 219 770
assign 1 220 771
undef 1 220 776
assign 1 221 777
new 0 221 777
assign 1 223 779
new 0 223 779
assign 1 223 780
get 1 223 780
assign 1 224 781
def 1 224 786
assign 1 225 787
firstGet 0 225 787
assign 1 227 789
new 0 227 789
assign 1 227 790
get 1 227 790
assign 1 228 791
def 1 228 796
assign 1 229 797
firstGet 0 229 797
assign 1 231 800
new 0 231 800
assign 1 233 802
new 0 233 802
assign 1 233 803
new 0 233 803
assign 1 233 804
isTrue 2 233 804
assign 1 234 805
new 0 234 805
assign 1 234 806
new 0 234 806
assign 1 234 807
isTrue 2 234 807
assign 1 235 808
new 0 235 808
assign 1 235 809
isTrue 1 235 809
assign 1 236 810
new 0 236 810
assign 1 236 811
isTrue 1 236 811
assign 1 237 812
new 0 237 812
assign 1 238 813
new 0 238 813
assign 1 238 814
get 1 238 814
assign 1 239 815
def 1 239 820
assign 1 239 821
isEmptyGet 0 239 821
assign 1 239 822
not 0 239 827
assign 1 0 828
assign 1 0 831
assign 1 0 835
assign 1 240 838
linkedListIteratorGet 0 0 838
assign 1 240 841
hasNextGet 0 240 841
assign 1 240 843
nextGet 0 240 843
put 1 241 844
assign 1 244 851
new 0 244 851
assign 1 244 852
isTrue 1 244 852
assign 1 245 853
new 0 245 853
assign 1 245 854
isTrue 1 245 854
assign 1 246 855
new 0 246 855
assign 1 246 856
isTrue 1 246 856
assign 1 247 857
new 0 247 857
assign 1 247 858
new 0 247 858
assign 1 247 859
isTrue 2 247 859
assign 1 248 860
new 0 248 860
assign 1 248 861
get 1 248 861
assign 1 249 862
new 0 249 862
assign 1 249 863
get 1 249 863
assign 1 250 864
new 0 250 864
assign 1 250 865
new 0 250 865
assign 1 250 866
get 2 250 866
assign 1 250 867
firstGet 0 250 867
assign 1 251 868
new 0 251 868
assign 1 251 869
new 0 251 869
assign 1 251 870
get 2 251 870
assign 1 251 871
firstGet 0 251 871
assign 1 252 872
new 0 252 872
assign 1 252 873
add 1 252 873
assign 1 252 874
new 0 252 874
assign 1 252 875
get 2 252 875
assign 1 252 876
firstGet 0 252 876
assign 1 253 877
new 0 253 877
assign 1 254 878
new 0 254 878
assign 1 255 879
new 0 255 879
assign 1 256 880
new 0 256 880
assign 1 257 881
new 0 257 881
assign 1 260 882
def 1 260 887
assign 1 261 888
firstGet 0 261 888
assign 1 263 891
new 0 263 891
assign 1 270 893
new 0 270 893
assign 1 270 894
add 1 270 894
assign 1 270 895
nameGet 0 270 895
assign 1 270 896
add 1 270 896
assign 1 270 897
get 1 270 897
assign 1 271 898
def 1 271 903
assign 1 272 904
orderedGet 0 272 904
addAll 1 272 905
assign 1 275 907
new 0 275 907
assign 1 275 908
add 1 275 908
assign 1 275 909
get 1 275 909
assign 1 276 910
def 1 276 915
assign 1 277 916
orderedGet 0 277 916
addAll 1 277 917
assign 1 280 919
new 0 280 919
assign 1 281 920
orderedGet 0 281 920
assign 1 281 921
iteratorGet 0 0 921
assign 1 281 924
hasNextGet 0 281 924
assign 1 281 926
nextGet 0 281 926
assign 1 282 927
new 1 282 927
addValue 1 282 928
assign 1 284 934
newlineGet 0 284 934
assign 1 285 935
assign 1 286 936
new 1 286 936
assign 1 288 937
copy 0 288 937
assign 1 289 938
fileGet 0 289 938
assign 1 289 939
existsGet 0 289 939
assign 1 289 940
not 0 289 945
assign 1 290 946
fileGet 0 290 946
makeDirs 0 290 947
assign 1 292 949
def 1 292 954
assign 1 293 955
new 1 293 955
assign 1 293 956
readerGet 0 293 956
assign 1 294 957
open 0 294 957
assign 1 294 958
readString 0 294 958
close 0 295 959
assign 1 301 973
classNameGet 0 301 973
assign 1 302 974
add 1 302 974
assign 1 302 975
new 0 302 975
assign 1 302 976
add 1 302 976
assign 1 302 977
toString 0 302 977
assign 1 302 978
add 1 302 978
assign 1 303 979
add 1 303 979
assign 1 303 980
new 0 303 980
assign 1 303 981
add 1 303 981
assign 1 303 982
toString 0 303 982
assign 1 303 983
add 1 303 983
return 1 304 984
assign 1 308 1024
new 0 308 1024
assign 1 309 1025
classesGet 0 309 1025
assign 1 309 1026
valueIteratorGet 0 309 1026
assign 1 309 1029
hasNextGet 0 309 1029
assign 1 310 1031
nextGet 0 310 1031
assign 1 311 1032
shouldEmitGet 0 311 1032
assign 1 311 1033
heldGet 0 311 1033
assign 1 311 1034
fromFileGet 0 311 1034
assign 1 311 1035
has 1 311 1035
assign 1 312 1037
heldGet 0 312 1037
assign 1 312 1038
namepathGet 0 312 1038
assign 1 312 1039
toString 0 312 1039
put 1 312 1040
assign 1 313 1041
usedByGet 0 313 1041
assign 1 313 1042
heldGet 0 313 1042
assign 1 313 1043
namepathGet 0 313 1043
assign 1 313 1044
toString 0 313 1044
assign 1 313 1045
get 1 313 1045
assign 1 314 1046
def 1 314 1051
assign 1 315 1052
setIteratorGet 0 0 1052
assign 1 315 1055
hasNextGet 0 315 1055
assign 1 315 1057
nextGet 0 315 1057
put 1 316 1058
assign 1 319 1065
subClassesGet 0 319 1065
assign 1 319 1066
heldGet 0 319 1066
assign 1 319 1067
namepathGet 0 319 1067
assign 1 319 1068
toString 0 319 1068
assign 1 319 1069
get 1 319 1069
assign 1 320 1070
def 1 320 1075
assign 1 321 1076
setIteratorGet 0 0 1076
assign 1 321 1079
hasNextGet 0 321 1079
assign 1 321 1081
nextGet 0 321 1081
put 1 322 1082
assign 1 327 1095
classesGet 0 327 1095
assign 1 327 1096
valueIteratorGet 0 327 1096
assign 1 327 1099
hasNextGet 0 327 1099
assign 1 328 1101
nextGet 0 328 1101
assign 1 329 1102
heldGet 0 329 1102
assign 1 329 1103
heldGet 0 329 1103
assign 1 329 1104
namepathGet 0 329 1104
assign 1 329 1105
toString 0 329 1105
assign 1 329 1106
has 1 329 1106
shouldWriteSet 1 329 1107
assign 1 336 1117
new 0 336 1117
return 1 336 1118
assign 1 340 1132
def 1 340 1137
return 1 341 1138
assign 1 346 1140
def 1 346 1145
assign 1 347 1146
firstGet 0 347 1146
assign 1 348 1147
new 0 348 1147
assign 1 348 1148
equals 1 348 1148
assign 1 349 1150
new 1 349 1150
assign 1 350 1153
new 0 350 1153
assign 1 350 1154
equals 1 350 1154
assign 1 351 1156
new 1 351 1156
assign 1 352 1159
new 0 352 1159
assign 1 352 1160
equals 1 352 1160
assign 1 353 1162
new 1 353 1162
assign 1 355 1165
new 0 355 1165
assign 1 355 1166
new 1 355 1166
throw 1 355 1167
dynConditionsAllSet 1 357 1171
return 1 358 1172
return 1 360 1174
assign 1 365 1286
new 0 365 1286
assign 1 365 1287
now 0 365 1287
assign 1 366 1288
new 0 366 1288
assign 1 367 1289
emitterGet 0 367 1289
assign 1 368 1290
def 1 368 1295
assign 1 369 1296
new 4 369 1296
put 1 370 1297
assign 1 372 1299
new 0 372 1299
assign 1 372 1300
add 1 372 1300
print 0 372 1301
assign 1 375 1304
new 0 375 1304
assign 1 377 1305
iteratorGet 0 0 1305
assign 1 377 1308
hasNextGet 0 377 1308
assign 1 377 1310
nextGet 0 377 1310
assign 1 378 1311
has 1 378 1311
assign 1 378 1312
not 0 378 1317
put 1 379 1318
assign 1 380 1319
new 2 380 1319
addValue 1 381 1320
assign 1 384 1327
iteratorGet 0 0 1327
assign 1 384 1330
hasNextGet 0 384 1330
assign 1 384 1332
nextGet 0 384 1332
assign 1 385 1333
has 1 385 1333
assign 1 385 1334
not 0 385 1339
put 1 386 1340
assign 1 387 1341
new 2 387 1341
addValue 1 388 1342
assign 1 389 1343
libNameGet 0 389 1343
put 1 389 1344
assign 1 394 1352
iteratorGet 0 394 1352
assign 1 394 1355
hasNextGet 0 394 1355
assign 1 395 1357
nextGet 0 395 1357
doParse 1 397 1358
buildSyns 1 399 1364
assign 1 402 1366
new 0 402 1366
assign 1 402 1367
now 0 402 1367
assign 1 402 1368
subtract 1 402 1368
assign 1 404 1369
new 0 404 1369
assign 1 404 1370
add 1 404 1370
print 0 404 1371
assign 1 406 1372
emitCommonGet 0 406 1372
assign 1 406 1373
def 1 406 1378
assign 1 408 1379
new 0 408 1379
assign 1 408 1380
now 0 408 1380
assign 1 409 1381
emitCommonGet 0 409 1381
doEmit 0 409 1382
assign 1 410 1383
new 0 410 1383
assign 1 410 1384
now 0 410 1384
assign 1 410 1385
subtract 1 410 1385
assign 1 411 1386
new 0 411 1386
assign 1 411 1387
add 1 411 1387
print 0 411 1388
assign 1 412 1389
new 0 412 1389
assign 1 412 1390
now 0 412 1390
assign 1 412 1391
subtract 1 412 1391
assign 1 413 1392
new 0 413 1392
assign 1 413 1393
add 1 413 1393
print 0 413 1394
assign 1 414 1395
new 0 414 1395
return 1 414 1396
setClassesToWrite 0 417 1399
libnameInfoGet 0 418 1400
assign 1 420 1401
classesGet 0 420 1401
assign 1 420 1402
valueIteratorGet 0 420 1402
assign 1 420 1405
hasNextGet 0 420 1405
assign 1 421 1407
nextGet 0 421 1407
doEmit 1 422 1408
emitMain 0 424 1414
emitCUInit 0 425 1415
assign 1 426 1416
classesGet 0 426 1416
assign 1 426 1417
valueIteratorGet 0 426 1417
assign 1 426 1420
hasNextGet 0 426 1420
assign 1 427 1422
nextGet 0 427 1422
emitSyn 1 428 1423
assign 1 432 1430
new 0 432 1430
assign 1 432 1431
now 0 432 1431
assign 1 432 1432
subtract 1 432 1432
assign 1 433 1433
def 1 433 1438
assign 1 434 1439
new 0 434 1439
assign 1 434 1440
add 1 434 1440
print 0 434 1441
assign 1 436 1443
new 0 436 1443
assign 1 436 1444
add 1 436 1444
print 0 436 1445
prepMake 1 439 1447
assign 1 443 1450
not 0 443 1455
make 1 444 1456
deployLibrary 1 445 1457
assign 1 447 1459
linkedListIteratorGet 0 0 1459
assign 1 447 1462
hasNextGet 0 447 1462
assign 1 447 1464
nextGet 0 447 1464
assign 1 448 1465
libnameInfoGet 0 448 1465
assign 1 448 1466
unitShlibGet 0 448 1466
assign 1 449 1467
emitPathGet 0 449 1467
assign 1 449 1468
copy 0 449 1468
assign 1 450 1469
stepsGet 0 450 1469
assign 1 450 1470
lastGet 0 450 1470
addStep 1 450 1471
assign 1 451 1472
fileGet 0 451 1472
assign 1 451 1473
existsGet 0 451 1473
assign 1 452 1475
fileGet 0 452 1475
delete 0 452 1476
assign 1 454 1478
fileGet 0 454 1478
assign 1 454 1479
existsGet 0 454 1479
assign 1 454 1480
not 0 454 1480
assign 1 455 1482
fileGet 0 455 1482
assign 1 455 1483
fileGet 0 455 1483
deployFile 2 455 1484
assign 1 459 1492
iteratorGet 0 459 1492
assign 1 460 1493
iteratorGet 0 460 1493
assign 1 462 1496
hasNextGet 0 462 1496
assign 1 462 1498
hasNextGet 0 462 1498
assign 1 0 1500
assign 1 0 1503
assign 1 0 1507
assign 1 463 1510
nextGet 0 463 1510
assign 1 463 1511
apNew 1 463 1511
assign 1 464 1512
emitPathGet 0 464 1512
assign 1 464 1513
copy 0 464 1513
assign 1 464 1514
toString 0 464 1514
assign 1 464 1515
new 0 464 1515
assign 1 464 1516
add 1 464 1516
assign 1 464 1517
nextGet 0 464 1517
assign 1 464 1518
add 1 464 1518
assign 1 464 1519
apNew 1 464 1519
assign 1 466 1520
fileGet 0 466 1520
assign 1 466 1521
existsGet 0 466 1521
assign 1 467 1523
fileGet 0 467 1523
delete 0 467 1524
assign 1 469 1526
fileGet 0 469 1526
assign 1 469 1527
existsGet 0 469 1527
assign 1 469 1528
not 0 469 1528
assign 1 470 1530
fileGet 0 470 1530
assign 1 470 1531
fileGet 0 470 1531
deployFile 2 470 1532
assign 1 475 1541
new 0 475 1541
assign 1 475 1542
now 0 475 1542
assign 1 475 1543
subtract 1 475 1543
assign 1 477 1544
def 1 477 1549
assign 1 478 1550
new 0 478 1550
assign 1 478 1551
add 1 478 1551
print 0 478 1552
assign 1 480 1554
def 1 480 1559
assign 1 481 1560
new 0 481 1560
assign 1 481 1561
add 1 481 1561
print 0 481 1562
assign 1 483 1564
def 1 483 1569
assign 1 484 1570
new 0 484 1570
assign 1 484 1571
add 1 484 1571
print 0 484 1572
assign 1 488 1575
new 0 488 1575
print 0 488 1576
assign 1 489 1577
run 2 489 1577
assign 1 490 1578
new 0 490 1578
assign 1 490 1579
add 1 490 1579
assign 1 490 1580
new 0 490 1580
assign 1 490 1581
add 1 490 1581
print 0 490 1582
return 1 491 1583
assign 1 493 1585
new 0 493 1585
return 1 493 1586
assign 1 497 1599
justParsedGet 0 497 1599
assign 1 497 1600
valueIteratorGet 0 497 1600
assign 1 497 1603
hasNextGet 0 497 1603
assign 1 498 1605
nextGet 0 498 1605
assign 1 499 1606
heldGet 0 499 1606
libNameSet 1 499 1607
assign 1 500 1608
getSyn 2 500 1608
libNameSet 1 501 1609
assign 1 503 1615
justParsedGet 0 503 1615
assign 1 503 1616
valueIteratorGet 0 503 1616
assign 1 503 1619
hasNextGet 0 503 1619
assign 1 504 1621
nextGet 0 504 1621
assign 1 505 1622
heldGet 0 505 1622
assign 1 505 1623
synGet 0 505 1623
checkInheritance 2 506 1624
integrate 1 507 1625
assign 1 509 1631
new 0 509 1631
justParsedSet 1 509 1632
assign 1 513 1660
heldGet 0 513 1660
assign 1 513 1661
synGet 0 513 1661
assign 1 513 1662
def 1 513 1667
assign 1 514 1668
heldGet 0 514 1668
assign 1 514 1669
synGet 0 514 1669
return 1 514 1670
assign 1 516 1672
heldGet 0 516 1672
libNameSet 1 516 1673
assign 1 517 1674
heldGet 0 517 1674
assign 1 517 1675
extendsGet 0 517 1675
assign 1 517 1676
undef 1 517 1681
assign 1 518 1682
new 1 518 1682
assign 1 520 1685
classesGet 0 520 1685
assign 1 520 1686
heldGet 0 520 1686
assign 1 520 1687
extendsGet 0 520 1687
assign 1 520 1688
toString 0 520 1688
assign 1 520 1689
get 1 520 1689
assign 1 522 1690
def 1 522 1695
assign 1 523 1696
heldGet 0 523 1696
libNameSet 1 523 1697
assign 1 524 1698
getSyn 2 524 1698
assign 1 527 1701
heldGet 0 527 1701
assign 1 527 1702
extendsGet 0 527 1702
assign 1 527 1703
loadSyn 1 527 1703
assign 1 529 1705
new 2 529 1705
assign 1 531 1707
heldGet 0 531 1707
synSet 1 531 1708
assign 1 532 1709
heldGet 0 532 1709
assign 1 532 1710
namepathGet 0 532 1710
assign 1 532 1711
toString 0 532 1711
addSynClass 2 532 1712
return 1 533 1713
assign 1 537 1721
toString 0 537 1721
assign 1 538 1722
synClassesGet 0 538 1722
assign 1 538 1723
get 1 538 1723
assign 1 539 1724
def 1 539 1729
return 1 540 1730
assign 1 546 1732
emitterGet 0 546 1732
assign 1 546 1733
loadSyn 1 546 1733
addSynClass 2 547 1734
return 1 548 1735
assign 1 555 1739
undef 1 555 1744
assign 1 556 1745
new 1 556 1745
return 1 558 1747
assign 1 563 1826
new 1 563 1826
assign 1 564 1827
new 0 564 1827
assign 1 565 1828
emitterGet 0 565 1828
assign 1 566 1829
assign 1 567 1830
new 0 567 1830
assign 1 568 1831
shouldEmitGet 0 568 1831
put 1 568 1832
assign 1 0 1835
assign 1 0 1839
assign 1 0 1842
assign 1 571 1846
new 0 571 1846
assign 1 571 1847
toString 0 571 1847
assign 1 571 1848
add 1 571 1848
print 0 571 1849
assign 1 573 1851
assign 1 575 1852
fileGet 0 575 1852
assign 1 575 1853
readerGet 0 575 1853
assign 1 575 1854
open 0 575 1854
assign 1 575 1855
readBuffer 1 575 1855
assign 1 576 1856
fileGet 0 576 1856
assign 1 576 1857
readerGet 0 576 1857
close 0 576 1858
assign 1 577 1859
tokenize 1 577 1859
assign 1 581 1861
new 0 581 1861
echo 0 581 1862
assign 1 583 1864
outermostGet 0 583 1864
nodify 2 583 1865
assign 1 585 1867
new 0 585 1867
print 0 585 1868
assign 1 586 1869
new 2 586 1869
traverse 1 586 1870
assign 1 590 1873
new 0 590 1873
echo 0 590 1874
assign 1 592 1876
new 0 592 1876
traverse 1 592 1877
assign 1 594 1879
new 0 594 1879
print 0 594 1880
assign 1 595 1881
new 2 595 1881
traverse 1 595 1882
assign 1 598 1885
new 0 598 1885
echo 0 598 1886
assign 1 601 1888
new 0 601 1888
traverse 1 601 1889
contain 0 602 1890
assign 1 604 1892
new 0 604 1892
print 0 604 1893
assign 1 605 1894
new 2 605 1894
traverse 1 605 1895
assign 1 609 1898
new 0 609 1898
echo 0 609 1899
assign 1 611 1901
new 0 611 1901
traverse 1 611 1902
assign 1 613 1904
new 0 613 1904
print 0 613 1905
assign 1 614 1906
new 2 614 1906
traverse 1 614 1907
assign 1 618 1910
new 0 618 1910
echo 0 618 1911
assign 1 620 1913
new 0 620 1913
traverse 1 620 1914
assign 1 622 1916
new 0 622 1916
print 0 622 1917
assign 1 623 1918
new 2 623 1918
traverse 1 623 1919
assign 1 627 1922
new 0 627 1922
echo 0 627 1923
assign 1 629 1925
new 0 629 1925
traverse 1 629 1926
assign 1 631 1928
new 0 631 1928
print 0 631 1929
assign 1 632 1930
new 2 632 1930
traverse 1 632 1931
assign 1 636 1934
new 0 636 1934
echo 0 636 1935
assign 1 638 1937
new 0 638 1937
traverse 1 638 1938
assign 1 640 1940
new 0 640 1940
print 0 640 1941
assign 1 641 1942
new 2 641 1942
traverse 1 641 1943
assign 1 645 1946
new 0 645 1946
echo 0 645 1947
assign 1 647 1949
new 0 647 1949
traverse 1 647 1950
assign 1 649 1952
new 0 649 1952
print 0 649 1953
assign 1 650 1954
new 2 650 1954
traverse 1 650 1955
assign 1 654 1958
new 0 654 1958
echo 0 654 1959
assign 1 656 1961
new 0 656 1961
traverse 1 656 1962
assign 1 658 1964
new 0 658 1964
print 0 658 1965
assign 1 659 1966
new 2 659 1966
traverse 1 659 1967
assign 1 663 1970
new 0 663 1970
echo 0 663 1971
assign 1 665 1973
new 0 665 1973
traverse 1 665 1974
assign 1 667 1976
new 0 667 1976
print 0 667 1977
assign 1 668 1978
new 2 668 1978
traverse 1 668 1979
assign 1 671 1982
new 0 671 1982
echo 0 671 1983
assign 1 673 1985
new 0 673 1985
traverse 1 673 1986
assign 1 675 1988
new 0 675 1988
print 0 675 1989
assign 1 676 1990
new 2 676 1990
traverse 1 676 1991
assign 1 680 1994
new 0 680 1994
echo 0 680 1995
assign 1 681 1996
new 0 681 1996
print 0 681 1997
assign 1 683 1999
new 0 683 1999
traverse 1 683 2000
assign 1 0 2002
assign 1 0 2006
assign 1 0 2009
assign 1 685 2013
new 0 685 2013
print 0 685 2014
assign 1 686 2015
new 2 686 2015
traverse 1 686 2016
assign 1 688 2018
classesGet 0 688 2018
assign 1 688 2019
valueIteratorGet 0 688 2019
assign 1 688 2022
hasNextGet 0 688 2022
assign 1 689 2024
nextGet 0 689 2024
assign 1 691 2025
transUnitGet 0 691 2025
assign 1 692 2026
new 1 692 2026
assign 1 693 2027
TRANSUNITGet 0 693 2027
typenameSet 1 693 2028
assign 1 694 2029
new 0 694 2029
assign 1 695 2030
heldGet 0 695 2030
assign 1 695 2031
emitsGet 0 695 2031
emitsSet 1 695 2032
heldSet 1 696 2033
delete 0 697 2034
addValue 1 698 2035
copyLoc 1 699 2036
reInitContained 0 705 2058
assign 1 706 2059
containedGet 0 706 2059
assign 1 707 2060
new 0 707 2060
assign 1 708 2061
new 0 708 2061
assign 1 708 2062
crGet 0 708 2062
assign 1 709 2063
linkedListIteratorGet 0 709 2063
assign 1 709 2066
hasNextGet 0 709 2066
assign 1 710 2068
new 1 710 2068
assign 1 711 2069
nextGet 0 711 2069
heldSet 1 711 2070
nlcSet 1 712 2071
assign 1 713 2072
heldGet 0 713 2072
assign 1 713 2073
equals 1 713 2073
assign 1 714 2075
increment 0 714 2075
assign 1 716 2077
heldGet 0 716 2077
assign 1 716 2078
notEquals 1 716 2078
addValue 1 717 2080
containerSet 1 718 2081
return 1 0 2091
assign 1 0 2094
return 1 0 2098
assign 1 0 2101
return 1 0 2105
assign 1 0 2108
return 1 0 2112
assign 1 0 2115
return 1 0 2119
assign 1 0 2122
return 1 0 2126
assign 1 0 2129
return 1 0 2133
assign 1 0 2136
return 1 0 2140
assign 1 0 2143
return 1 0 2147
assign 1 0 2150
return 1 0 2154
assign 1 0 2157
return 1 0 2161
assign 1 0 2164
return 1 0 2168
assign 1 0 2171
return 1 0 2175
assign 1 0 2178
return 1 0 2182
assign 1 0 2185
return 1 0 2189
assign 1 0 2192
return 1 0 2196
assign 1 0 2199
return 1 0 2203
assign 1 0 2206
return 1 0 2210
assign 1 0 2213
return 1 0 2217
assign 1 0 2220
return 1 0 2224
assign 1 0 2227
return 1 0 2231
assign 1 0 2234
return 1 0 2238
assign 1 0 2241
return 1 0 2245
assign 1 0 2248
return 1 0 2252
assign 1 0 2255
return 1 0 2259
assign 1 0 2262
return 1 0 2266
assign 1 0 2269
return 1 0 2273
assign 1 0 2276
return 1 0 2280
assign 1 0 2283
return 1 0 2287
assign 1 0 2290
return 1 0 2294
assign 1 0 2297
return 1 0 2301
assign 1 0 2304
return 1 0 2308
assign 1 0 2311
return 1 0 2315
assign 1 0 2318
return 1 0 2322
assign 1 0 2325
return 1 0 2329
assign 1 0 2332
return 1 0 2336
assign 1 0 2339
return 1 0 2343
assign 1 0 2346
return 1 0 2350
assign 1 0 2353
return 1 0 2357
assign 1 0 2360
return 1 0 2364
assign 1 0 2367
return 1 0 2371
assign 1 0 2374
return 1 0 2378
assign 1 0 2381
return 1 0 2385
assign 1 0 2388
return 1 0 2392
assign 1 0 2395
return 1 0 2399
assign 1 0 2402
return 1 0 2406
assign 1 0 2409
return 1 0 2413
assign 1 0 2416
return 1 0 2420
assign 1 0 2423
return 1 0 2427
assign 1 0 2430
return 1 0 2434
assign 1 0 2437
return 1 0 2441
assign 1 0 2444
return 1 0 2448
assign 1 0 2451
return 1 0 2455
assign 1 0 2458
return 1 0 2462
assign 1 0 2465
return 1 0 2469
assign 1 0 2472
return 1 0 2476
assign 1 0 2479
return 1 0 2483
assign 1 0 2486
return 1 0 2490
assign 1 0 2493
return 1 0 2497
assign 1 0 2500
return 1 0 2504
assign 1 0 2507
return 1 0 2511
assign 1 0 2514
return 1 0 2518
assign 1 0 2521
return 1 0 2525
assign 1 0 2528
return 1 0 2532
assign 1 0 2535
return 1 0 2539
assign 1 0 2542
return 1 0 2546
assign 1 0 2549
return 1 0 2553
assign 1 0 2556
return 1 0 2560
assign 1 0 2563
assign 1 0 2567
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
}
