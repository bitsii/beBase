namespace be.BEL_4_Base {
/* File: source/build/CEmitVisit.be */
public class BEC_5_10_BuildCallCursor : BEC_6_6_SystemObject {
public BEC_5_10_BuildCallCursor() { }
static BEC_5_10_BuildCallCursor() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x61,0x6C,0x6C,0x43,0x75,0x72,0x73,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x56,0x69,0x73,0x69,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x70,0x61,0x73,0x73,0x42,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x70,0x61,0x73,0x73,0x42,0x61,0x63,0x6B};
private static byte[] bels_2 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x70,0x61,0x73,0x73,0x42,0x61,0x63,0x6B,0x20,0x3D,0x20,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static byte[] bels_3 = {};
private static byte[] bels_4 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x70,0x61,0x73,0x73,0x42,0x61,0x63,0x6B,0x20,0x3D,0x20};
private static byte[] bels_5 = {};
private static byte[] bels_6 = {0x47,0x45,0x54};
public static new BEC_5_10_BuildCallCursor bevs_inst;
public BEC_5_4_BuildNode bevp_asnR;
public BEC_5_4_BuildNode bevp_asnCall;
public BEC_4_6_TextString bevp_targs;
public BEC_4_6_TextString bevp_rtargs;
public BEC_4_6_TextString bevp_callArgs;
public BEC_5_8_BuildClassSyn bevp_asyn;
public BEC_5_8_BuildClassSyn bevp_typeCheckSyn;
public BEC_5_9_BuildClassInfo bevp_ainfo;
public BEC_5_6_BuildMtdSyn bevp_mtds;
public BEC_4_6_TextString bevp_prepCldef;
public BEC_4_6_TextString bevp_prepMdef;
public BEC_4_6_TextString bevp_utPreCheck;
public BEC_4_6_TextString bevp_tcall;
public BEC_4_6_TextString bevp_utPostCheckBB;
public BEC_4_6_TextString bevp_utPostCheckC;
public BEC_4_6_TextString bevp_utPostCheckEB;
public BEC_5_5_5_BuildVisitCEmit bevp_emvisit;
public BEC_5_4_BuildNode bevp_node;
public BEC_5_4_LogicBool bevp_checkAssignTypes;
public BEC_4_6_TextString bevp_preOnceEval;
public BEC_4_6_TextString bevp_callAssign;
public BEC_4_6_TextString bevp_assignTypeCheck;
public BEC_4_6_TextString bevp_postOnceEval;
public BEC_5_4_LogicBool bevp_optimizedCall;
public BEC_5_4_LogicBool bevp_isTyped;
public BEC_5_4_LogicBool bevp_embedAssign;
public BEC_5_4_LogicBool bevp_retainTo;
public BEC_4_6_TextString bevp_embedAssignVV;
public BEC_4_6_TextString bevp_embedAssignV;
public BEC_4_6_TextString bevp_embedTarg;
public BEC_4_6_TextString bevp_literalCdef;
public BEC_4_6_TextString bevp_belsName;
public BEC_4_6_TextString bevp_belsValue;
public virtual BEC_5_10_BuildCallCursor bem_new_2(BEC_5_5_5_BuildVisitCEmit beva__emvisit, BEC_5_4_BuildNode beva__node) {
bevp_prepCldef = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_prepMdef = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPreCheck = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckBB = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckC = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckEB = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_emvisit = beva__emvisit;
bevp_node = beva__node;
bevp_checkAssignTypes = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_preOnceEval = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_callAssign = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_assignTypeCheck = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_postOnceEval = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_optimizedCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_embedAssign = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_retainTo = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_embedTarg = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_0));
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_hasOnceAssignGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (bevp_asnCall == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1514 */ {
bevt_3_tmpvar_phold = bevp_asnCall.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1362267230, BEL_4_Base.bevn_isManyGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 1515 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 1516 */
bevt_6_tmpvar_phold = bevp_asnCall.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1478834556, BEL_4_Base.bevn_isOnceGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 1518 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1518 */ {
bevt_7_tmpvar_phold = bevp_asnCall.bem_isLiteralOnceGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1518 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1518 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1518 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1518 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 1519 */
} /* Line: 1518 */
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_checkRetainTo_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1530 */ {
bevt_1_tmpvar_phold = bevp_targs.bem_equals_1(bevp_embedTarg);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1530 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1530 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1530 */
 else  /* Line: 1530 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1530 */ {
bevp_retainTo = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_embedAssign = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_embedTarg = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_1));
} /* Line: 1537 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_assignToVGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1542 */ {
return bevp_embedAssignV;
} /* Line: 1543 */
 else  /* Line: 1542 */ {
if (bevp_asnR == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1544 */ {
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_2));
return bevt_1_tmpvar_phold;
} /* Line: 1545 */
} /* Line: 1542 */
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_3));
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_assignToVVGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1551 */ {
return bevp_embedAssignVV;
} /* Line: 1552 */
 else  /* Line: 1551 */ {
if (bevp_asnR == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1553 */ {
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_4));
return bevt_1_tmpvar_phold;
} /* Line: 1554 */
} /* Line: 1551 */
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_5));
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_assignToCheckGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1560 */ {
return bevp_assignTypeCheck;
} /* Line: 1561 */
bevt_0_tmpvar_phold = this.bem_typeCheckAssignGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isValidGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1567 */ {
bevt_3_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_1_tmpvar_phold = bevp_callAssign.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1567 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1567 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 1568 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_typeCheckAssignGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
if (bevp_embedAssign.bevi_bool) /* Line: 1574 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1574 */ {
if (bevp_retainTo.bevi_bool) /* Line: 1574 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1574 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1574 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1574 */ {
bevt_1_tmpvar_phold = bevp_callAssign.bem_add_1(bevp_assignTypeCheck);
return bevt_1_tmpvar_phold;
} /* Line: 1574 */
bevt_2_tmpvar_phold = bevp_assignTypeCheck.bem_add_1(bevp_callAssign);
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_10_BuildCallCursor bem_new_4(BEC_5_5_5_BuildVisitCEmit beva__emvisit, BEC_5_4_BuildNode beva__node, BEC_5_4_BuildNode beva__asnR, BEC_5_4_LogicBool beva__checkAssignTypes) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevp_prepCldef = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_prepMdef = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPreCheck = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckBB = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckC = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_utPostCheckEB = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_emvisit = beva__emvisit;
bevp_node = beva__node;
bevp_asnR = beva__asnR;
if (bevp_asnR == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1589 */ {
bevp_targs = bevp_emvisit.bem_formTarg_1(bevp_asnR);
bevp_rtargs = bevp_emvisit.bem_formRTarg_1(bevp_asnR);
} /* Line: 1591 */
bevp_checkAssignTypes = beva__checkAssignTypes;
bevp_preOnceEval = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_callAssign = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_assignTypeCheck = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_postOnceEval = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_optimizedCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isGetterGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_optimizedCall.bem_not_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1602 */ {
bevt_5_tmpvar_phold = bevp_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(682709225, BEL_4_Base.bevn_wasAccessorGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1602 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1602 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1602 */
 else  /* Line: 1602 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1602 */ {
bevt_8_tmpvar_phold = bevp_node.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_6));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 1602 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1602 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1602 */
 else  /* Line: 1602 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1602 */ {
if (bevp_asnR == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 1602 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1602 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1602 */
 else  /* Line: 1602 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1602 */ {
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 1603 */
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_asnRGet_0() {
return bevp_asnR;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_asnRSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_asnR = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_asnCallGet_0() {
return bevp_asnCall;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_asnCallSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_asnCall = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_targsGet_0() {
return bevp_targs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_targsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_targs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_rtargsGet_0() {
return bevp_rtargs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_rtargsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rtargs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_callArgsGet_0() {
return bevp_callArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_callArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_callArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_asynGet_0() {
return bevp_asyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_asynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_asyn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_typeCheckSynGet_0() {
return bevp_typeCheckSyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeCheckSynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typeCheckSyn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildClassInfo bem_ainfoGet_0() {
return bevp_ainfo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ainfoSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ainfo = (BEC_5_9_BuildClassInfo) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_6_BuildMtdSyn bem_mtdsGet_0() {
return bevp_mtds;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtds = (BEC_5_6_BuildMtdSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_prepCldefGet_0() {
return bevp_prepCldef;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepCldefSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepCldef = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_prepMdefGet_0() {
return bevp_prepMdef;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepMdefSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_prepMdef = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_utPreCheckGet_0() {
return bevp_utPreCheck;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_utPreCheckSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_utPreCheck = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_tcallGet_0() {
return bevp_tcall;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tcallSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tcall = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_utPostCheckBBGet_0() {
return bevp_utPostCheckBB;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_utPostCheckBBSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_utPostCheckBB = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_utPostCheckCGet_0() {
return bevp_utPostCheckC;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_utPostCheckCSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_utPostCheckC = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_utPostCheckEBGet_0() {
return bevp_utPostCheckEB;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_utPostCheckEBSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_utPostCheckEB = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_5_5_BuildVisitCEmit bem_emvisitGet_0() {
return bevp_emvisit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emvisitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emvisit = (BEC_5_5_5_BuildVisitCEmit) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nodeGet_0() {
return bevp_node;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_node = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_checkAssignTypesGet_0() {
return bevp_checkAssignTypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_checkAssignTypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_checkAssignTypes = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_preOnceEvalGet_0() {
return bevp_preOnceEval;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_preOnceEvalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_preOnceEval = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_callAssignGet_0() {
return bevp_callAssign;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_callAssignSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_callAssign = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_assignTypeCheckGet_0() {
return bevp_assignTypeCheck;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_assignTypeCheckSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_assignTypeCheck = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_postOnceEvalGet_0() {
return bevp_postOnceEval;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_postOnceEvalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_postOnceEval = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_optimizedCallGet_0() {
return bevp_optimizedCall;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_optimizedCallSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_optimizedCall = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_isTypedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_isTyped = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_embedAssignGet_0() {
return bevp_embedAssign;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_embedAssignSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_embedAssign = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_retainToGet_0() {
return bevp_retainTo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_retainToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_retainTo = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_embedAssignVVGet_0() {
return bevp_embedAssignVV;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_embedAssignVVSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_embedAssignVV = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_embedAssignVGet_0() {
return bevp_embedAssignV;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_embedAssignVSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_embedAssignV = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_embedTargGet_0() {
return bevp_embedTarg;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_embedTargSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_embedTarg = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_literalCdefGet_0() {
return bevp_literalCdef;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_literalCdefSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_literalCdef = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_belsNameGet_0() {
return bevp_belsName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_belsNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_belsName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_belsValueGet_0() {
return bevp_belsValue;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_belsValueSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_belsValue = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1505, 1514, 1514, 1515, 1515, 1516, 1516, 1518, 1518, 0, 1518, 0, 0, 1519, 1519, 1522, 1522, 1530, 0, 0, 0, 1535, 1536, 1537, 1543, 1544, 1544, 1545, 1545, 1547, 1547, 1552, 1553, 1553, 1554, 1554, 1556, 1556, 1561, 1563, 1563, 0, 1567, 1567, 1567, 0, 0, 1568, 1568, 1570, 1570, 0, 0, 0, 1574, 1574, 1575, 1575, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1589, 1590, 1591, 1593, 1594, 1595, 1596, 1597, 1598, 1602, 1602, 1602, 0, 0, 0, 1602, 1602, 1602, 1602, 0, 0, 0, 1602, 1602, 0, 0, 0, 1603, 1603, 1605, 1605, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 82, 87, 88, 89, 91, 92, 94, 95, 97, 100, 102, 105, 109, 110, 113, 114, 120, 122, 125, 129, 132, 133, 134, 143, 146, 151, 152, 153, 156, 157, 164, 167, 172, 173, 174, 177, 178, 183, 185, 186, 196, 199, 200, 201, 203, 206, 210, 211, 213, 214, 221, 225, 228, 232, 233, 235, 236, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 255, 256, 257, 259, 260, 261, 262, 263, 264, 281, 283, 284, 286, 289, 293, 296, 297, 298, 299, 301, 304, 308, 311, 316, 317, 320, 324, 327, 328, 330, 331, 334, 337, 341, 344, 348, 351, 355, 358, 362, 365, 369, 372, 376, 379, 383, 386, 390, 393, 397, 400, 404, 407, 411, 414, 418, 421, 425, 428, 432, 435, 439, 442, 446, 449, 453, 456, 460, 463, 467, 470, 474, 477, 481, 484, 488, 491, 495, 498, 502, 505, 509, 512, 516, 519, 523, 526, 530, 533, 537, 540, 544, 547, 551, 554, 558, 561};
/* BEGIN LINEINFO 
assign 1 1484 50
new 0 1484 50
assign 1 1485 51
new 0 1485 51
assign 1 1486 52
new 0 1486 52
assign 1 1487 53
new 0 1487 53
assign 1 1488 54
new 0 1488 54
assign 1 1489 55
new 0 1489 55
assign 1 1490 56
new 0 1490 56
assign 1 1491 57
assign 1 1492 58
assign 1 1493 59
new 0 1493 59
assign 1 1494 60
new 0 1494 60
assign 1 1495 61
new 0 1495 61
assign 1 1496 62
new 0 1496 62
assign 1 1497 63
new 0 1497 63
assign 1 1498 64
new 0 1498 64
assign 1 1499 65
new 0 1499 65
assign 1 1500 66
new 0 1500 66
assign 1 1501 67
new 0 1501 67
assign 1 1505 68
new 0 1505 68
assign 1 1514 82
def 1 1514 87
assign 1 1515 88
heldGet 0 1515 88
assign 1 1515 89
isManyGet 0 1515 89
assign 1 1516 91
new 0 1516 91
return 1 1516 92
assign 1 1518 94
heldGet 0 1518 94
assign 1 1518 95
isOnceGet 0 1518 95
assign 1 0 97
assign 1 1518 100
isLiteralOnceGet 0 1518 100
assign 1 0 102
assign 1 0 105
assign 1 1519 109
new 0 1519 109
return 1 1519 110
assign 1 1522 113
new 0 1522 113
return 1 1522 114
assign 1 1530 120
equals 1 1530 120
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 1535 132
new 0 1535 132
assign 1 1536 133
new 0 1536 133
assign 1 1537 134
new 0 1537 134
return 1 1543 143
assign 1 1544 146
def 1 1544 151
assign 1 1545 152
new 0 1545 152
return 1 1545 153
assign 1 1547 156
new 0 1547 156
return 1 1547 157
return 1 1552 164
assign 1 1553 167
def 1 1553 172
assign 1 1554 173
new 0 1554 173
return 1 1554 174
assign 1 1556 177
new 0 1556 177
return 1 1556 178
return 1 1561 183
assign 1 1563 185
typeCheckAssignGet 0 1563 185
return 1 1563 186
assign 1 0 196
assign 1 1567 199
new 0 1567 199
assign 1 1567 200
emptyGet 0 1567 200
assign 1 1567 201
equals 1 1567 201
assign 1 0 203
assign 1 0 206
assign 1 1568 210
new 0 1568 210
return 1 1568 211
assign 1 1570 213
new 0 1570 213
return 1 1570 214
assign 1 0 221
assign 1 0 225
assign 1 0 228
assign 1 1574 232
add 1 1574 232
return 1 1574 233
assign 1 1575 235
add 1 1575 235
return 1 1575 236
assign 1 1579 240
new 0 1579 240
assign 1 1580 241
new 0 1580 241
assign 1 1581 242
new 0 1581 242
assign 1 1582 243
new 0 1582 243
assign 1 1583 244
new 0 1583 244
assign 1 1584 245
new 0 1584 245
assign 1 1585 246
new 0 1585 246
assign 1 1586 247
assign 1 1587 248
assign 1 1588 249
assign 1 1589 250
def 1 1589 255
assign 1 1590 256
formTarg 1 1590 256
assign 1 1591 257
formRTarg 1 1591 257
assign 1 1593 259
assign 1 1594 260
new 0 1594 260
assign 1 1595 261
new 0 1595 261
assign 1 1596 262
new 0 1596 262
assign 1 1597 263
new 0 1597 263
assign 1 1598 264
new 0 1598 264
assign 1 1602 281
not 0 1602 281
assign 1 1602 283
heldGet 0 1602 283
assign 1 1602 284
wasAccessorGet 0 1602 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 1602 296
heldGet 0 1602 296
assign 1 1602 297
accessorTypeGet 0 1602 297
assign 1 1602 298
new 0 1602 298
assign 1 1602 299
equals 1 1602 299
assign 1 0 301
assign 1 0 304
assign 1 0 308
assign 1 1602 311
def 1 1602 316
assign 1 0 317
assign 1 0 320
assign 1 0 324
assign 1 1603 327
new 0 1603 327
return 1 1603 328
assign 1 1605 330
new 0 1605 330
return 1 1605 331
return 1 0 334
assign 1 0 337
return 1 0 341
assign 1 0 344
return 1 0 348
assign 1 0 351
return 1 0 355
assign 1 0 358
return 1 0 362
assign 1 0 365
return 1 0 369
assign 1 0 372
return 1 0 376
assign 1 0 379
return 1 0 383
assign 1 0 386
return 1 0 390
assign 1 0 393
return 1 0 397
assign 1 0 400
return 1 0 404
assign 1 0 407
return 1 0 411
assign 1 0 414
return 1 0 418
assign 1 0 421
return 1 0 425
assign 1 0 428
return 1 0 432
assign 1 0 435
return 1 0 439
assign 1 0 442
return 1 0 446
assign 1 0 449
return 1 0 453
assign 1 0 456
return 1 0 460
assign 1 0 463
return 1 0 467
assign 1 0 470
return 1 0 474
assign 1 0 477
return 1 0 481
assign 1 0 484
return 1 0 488
assign 1 0 491
return 1 0 495
assign 1 0 498
return 1 0 502
assign 1 0 505
return 1 0 509
assign 1 0 512
return 1 0 516
assign 1 0 519
return 1 0 523
assign 1 0 526
return 1 0 530
assign 1 0 533
return 1 0 537
assign 1 0 540
return 1 0 544
assign 1 0 547
return 1 0 551
assign 1 0 554
return 1 0 558
assign 1 0 561
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 219408889: return bem_embedAssignVGet_0();
case 207518316: return bem_embedTargGet_0();
case 1135093859: return bem_assignToVVGet_0();
case 1820417453: return bem_create_0();
case 443216037: return bem_nodeGet_0();
case 1956849667: return bem_utPreCheckGet_0();
case 443668840: return bem_methodNotDefined_0();
case 61198675: return bem_asnCallGet_0();
case 1044653139: return bem_typeCheckSynGet_0();
case 2142618968: return bem_rtargsGet_0();
case 1584756928: return bem_belsValueGet_0();
case 603750629: return bem_assignToVGet_0();
case 786424307: return bem_tagGet_0();
case 876861192: return bem_assignTypeCheckGet_0();
case 1713166649: return bem_checkRetainTo_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1668435649: return bem_embedAssignGet_0();
case 2103261109: return bem_isValidGet_0();
case 794857477: return bem_checkAssignTypesGet_0();
case 1081412016: return bem_many_0();
case 1347593718: return bem_literalCdefGet_0();
case 1557598110: return bem_optimizedCallGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1309826791: return bem_preOnceEvalGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 502737142: return bem_typeCheckAssignGet_0();
case 476471454: return bem_utPostCheckBBGet_0();
case 1905573845: return bem_tcallGet_0();
case 846373046: return bem_targsGet_0();
case 1537431598: return bem_belsNameGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 712089096: return bem_prepCldefGet_0();
case 1347723063: return bem_assignToCheckGet_0();
case 691774713: return bem_retainToGet_0();
case 15741460: return bem_callArgsGet_0();
case 1733002496: return bem_asynGet_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 613232718: return bem_isGetterGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 55340902: return bem_callAssignGet_0();
case 1286331402: return bem_postOnceEvalGet_0();
case 1102720804: return bem_classNameGet_0();
case 1386952577: return bem_embedAssignVVGet_0();
case 1012494862: return bem_once_0();
case 1519371599: return bem_mtdsGet_0();
case 1155984799: return bem_utPostCheckEBGet_0();
case 672898504: return bem_ainfoGet_0();
case 742260909: return bem_utPostCheckCGet_0();
case 1193313287: return bem_isTypedGet_0();
case 587742673: return bem_asnRGet_0();
case 314718434: return bem_print_0();
case 1752996195: return bem_hasOnceAssignGet_0();
case 575752258: return bem_prepMdefGet_0();
case 16658012: return bem_emvisitGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1144902546: return bem_utPostCheckEBSet_1(bevd_0);
case 1297413655: return bem_postOnceEvalSet_1(bevd_0);
case 1573674675: return bem_belsValueSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1358675971: return bem_literalCdefSet_1(bevd_0);
case 598824926: return bem_asnRSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 805939730: return bem_checkAssignTypesSet_1(bevd_0);
case 1033570886: return bem_typeCheckSynSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 753343162: return bem_utPostCheckCSet_1(bevd_0);
case 857455299: return bem_targsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1375870324: return bem_embedAssignVVSet_1(bevd_0);
case 661816251: return bem_ainfoSet_1(bevd_0);
case 1657353396: return bem_embedAssignSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 230491142: return bem_embedAssignVSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1320909044: return bem_preOnceEvalSet_1(bevd_0);
case 50116422: return bem_asnCallSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1967931920: return bem_utPreCheckSet_1(bevd_0);
case 1526349345: return bem_belsNameSet_1(bevd_0);
case 1546515857: return bem_optimizedCallSet_1(bevd_0);
case 701006843: return bem_prepCldefSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 454298290: return bem_nodeSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1916656098: return bem_tcallSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 4659207: return bem_callArgsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1204395540: return bem_isTypedSet_1(bevd_0);
case 1508289346: return bem_mtdsSet_1(bevd_0);
case 887943445: return bem_assignTypeCheckSet_1(bevd_0);
case 44258649: return bem_callAssignSet_1(bevd_0);
case 2131536715: return bem_rtargsSet_1(bevd_0);
case 5575759: return bem_emvisitSet_1(bevd_0);
case 586834511: return bem_prepMdefSet_1(bevd_0);
case 218600569: return bem_embedTargSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 680692460: return bem_retainToSet_1(bevd_0);
case 1721920243: return bem_asynSet_1(bevd_0);
case 487553707: return bem_utPostCheckBBSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_5_5_5_BuildVisitCEmit) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 104713557: return bem_new_4((BEC_5_5_5_BuildVisitCEmit) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_5_4_BuildNode) bevd_2, (BEC_5_4_LogicBool) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_10_BuildCallCursor();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_10_BuildCallCursor.bevs_inst = (BEC_5_10_BuildCallCursor)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_10_BuildCallCursor.bevs_inst;
}
}
}
