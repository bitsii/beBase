namespace be.BEL_4_Base {
/* File: source/build/CCallAssembler.be */
public class BEC_5_12_BuildCAssembleInt : BEC_5_14_BuildCCallAssembler {
public BEC_5_12_BuildCAssembleInt() { }
static BEC_5_12_BuildCAssembleInt() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x49,0x6E,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_3 = {0x3C};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_5 = {0x3E};
private static byte[] bels_6 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_7 = {0x3C,0x3D};
private static byte[] bels_8 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_9 = {0x3E,0x3D};
private static byte[] bels_10 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_11 = {0x2B};
private static byte[] bels_12 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_13 = {0x2D};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_15 = {0x2A};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_17 = {0x2F};
private static byte[] bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_19 = {0x25};
private static byte[] bels_20 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x30};
private static byte[] bels_21 = {0x2B};
private static byte[] bels_22 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x30};
private static byte[] bels_23 = {0x2D};
private static byte[] bels_24 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_24, 31));
private static byte[] bels_25 = {0x2C,0x20,0x30,0x29,0x3B};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_25, 5));
private static byte[] bels_26 = {0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_26, 13));
private static byte[] bels_27 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_27, 15));
private static byte[] bels_28 = {0x3B};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_28, 1));
private static byte[] bels_29 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_29, 4));
private static byte[] bels_30 = {0x20,0x3D,0x3D,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x7C,0x7C,0x20,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_30, 22));
private static byte[] bels_31 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_31, 13));
private static byte[] bels_32 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_33 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_34 = {0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_35 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_36 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_36, 37));
private static byte[] bels_37 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_37, 16));
private static byte[] bels_38 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_39 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_40 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D,0x20,0x7D};
private static byte[] bels_41 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_41, 4));
private static byte[] bels_42 = {0x20,0x3D,0x3D,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x7C,0x7C,0x20,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_42, 22));
private static byte[] bels_43 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_43, 13));
private static byte[] bels_44 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_45 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_46 = {0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_47 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_48 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x21,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_48, 37));
private static byte[] bels_49 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_49, 16));
private static byte[] bels_50 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_51 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_52 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D,0x20,0x7D};
private static byte[] bels_53 = {0x69,0x66,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_53, 14));
private static byte[] bels_54 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_54, 13));
private static byte[] bels_55 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_56 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_57 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_58 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_59 = {0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_59, 23));
private static byte[] bels_60 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_60, 16));
private static byte[] bels_61 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_62 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_63 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_64 = {0x7D};
private static byte[] bels_65 = {0x69,0x66,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_65, 14));
private static byte[] bels_66 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_66, 13));
private static byte[] bels_67 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_68 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_69 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x42,0x45,0x55,0x56,0x5F,0x34,0x5F,0x33,0x5F,0x4D,0x61,0x74,0x68,0x49,0x6E,0x74,0x5F,0x63,0x6C,0x44,0x65,0x66,0x2C,0x20,0x30,0x29,0x3B};
private static byte[] bels_70 = {0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28};
private static byte[] bels_71 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_72 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_73 = {0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_73, 23));
private static byte[] bels_74 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x3B};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_74, 13));
private static byte[] bels_75 = {0x7D};
private static byte[] bels_76 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x42,0x45,0x55,0x56,0x5F,0x34,0x5F,0x33,0x5F,0x4D,0x61,0x74,0x68,0x49,0x6E,0x74,0x5F,0x63,0x6C,0x44,0x65,0x66,0x2C,0x20,0x30,0x29,0x3B};
private static byte[] bels_77 = {0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28,0x28};
private static byte[] bels_78 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x49,0x4E,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_79 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_80 = {0x20,0x31,0x3B};
public static new BEC_5_12_BuildCAssembleInt bevs_inst;
public override BEC_5_14_BuildCCallAssembler bem_new_1(BEC_6_6_SystemObject beva_build) {
this.bem_loadBuild_1(beva_build);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_processCall_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_6_tmpvar_phold = beva_ca.bem_asnRGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_9_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_10_tmpvar_phold = this.bem_processLiteralConstruct_1(beva_ca);
return bevt_10_tmpvar_phold;
} /* Line: 246 */
bevt_14_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_0));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_15_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_16_tmpvar_phold = this.bem_processEquals_1(beva_ca);
return bevt_16_tmpvar_phold;
} /* Line: 249 */
 else  /* Line: 248 */ {
bevt_20_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 250 */ {
bevt_22_tmpvar_phold = this.bem_processNotEquals_1(beva_ca);
return bevt_22_tmpvar_phold;
} /* Line: 251 */
 else  /* Line: 248 */ {
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_heldGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 252 */ {
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_3));
bevt_28_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_29_tmpvar_phold);
return bevt_28_tmpvar_phold;
} /* Line: 253 */
 else  /* Line: 248 */ {
bevt_33_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_heldGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_4));
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_34_tmpvar_phold);
if (bevt_30_tmpvar_phold != null && bevt_30_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_30_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_5));
bevt_35_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_36_tmpvar_phold);
return bevt_35_tmpvar_phold;
} /* Line: 255 */
 else  /* Line: 248 */ {
bevt_40_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_6));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_7));
bevt_42_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_43_tmpvar_phold);
return bevt_42_tmpvar_phold;
} /* Line: 257 */
 else  /* Line: 248 */ {
bevt_47_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_heldGet_0();
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_8));
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_48_tmpvar_phold);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 258 */ {
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_9));
bevt_49_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_50_tmpvar_phold);
return bevt_49_tmpvar_phold;
} /* Line: 259 */
 else  /* Line: 248 */ {
bevt_54_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_10));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_51_tmpvar_phold != null && bevt_51_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_51_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_11));
bevt_56_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_57_tmpvar_phold);
return bevt_56_tmpvar_phold;
} /* Line: 261 */
 else  /* Line: 248 */ {
bevt_61_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_heldGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_12));
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpvar_phold);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 262 */ {
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_13));
bevt_63_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_64_tmpvar_phold);
return bevt_63_tmpvar_phold;
} /* Line: 263 */
 else  /* Line: 248 */ {
bevt_68_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bem_heldGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_69_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_14));
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_65_tmpvar_phold != null && bevt_65_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_65_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevt_71_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_15));
bevt_70_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_71_tmpvar_phold);
return bevt_70_tmpvar_phold;
} /* Line: 265 */
 else  /* Line: 248 */ {
bevt_75_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_76_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_16));
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 266 */ {
bevt_78_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_17));
bevt_77_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_78_tmpvar_phold);
return bevt_77_tmpvar_phold;
} /* Line: 267 */
 else  /* Line: 248 */ {
bevt_82_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_83_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_18));
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 268 */ {
bevt_85_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_19));
bevt_84_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_85_tmpvar_phold);
return bevt_84_tmpvar_phold;
} /* Line: 269 */
 else  /* Line: 248 */ {
bevt_89_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_heldGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_20));
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpvar_phold);
if (bevt_86_tmpvar_phold != null && bevt_86_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_86_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_21));
bevt_91_tmpvar_phold = this.bem_processIncDec_2(beva_ca, bevt_92_tmpvar_phold);
return bevt_91_tmpvar_phold;
} /* Line: 271 */
 else  /* Line: 248 */ {
bevt_96_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_heldGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_22));
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_97_tmpvar_phold);
if (bevt_93_tmpvar_phold != null && bevt_93_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_93_tmpvar_phold).bevi_bool) /* Line: 272 */ {
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_23));
bevt_98_tmpvar_phold = this.bem_processIncDec_2(beva_ca, bevt_99_tmpvar_phold);
return bevt_98_tmpvar_phold;
} /* Line: 273 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
} /* Line: 248 */
bevt_100_tmpvar_phold = this.bem_standardCall_1(beva_ca);
return bevt_100_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_processLiteralConstruct_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_4_6_TextString bevl_callRet = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_6_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_0;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_ca.bem_literalCdefGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_0_tmpvar_phold);
bevt_16_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_17_tmpvar_phold = bevo_2;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_3;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_24_tmpvar_phold = bevo_4;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_10_tmpvar_phold);
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_25_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevl_callRet.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_28_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processEquals_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_18_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_5;
bevt_16_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_19_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_containedGet_0();
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_get_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_getBeavArg_1(bevt_17_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_6;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_containedGet_0();
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_get_1(bevt_27_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_getBeavArg_1(bevt_24_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_7;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_29_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_32));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(23, bels_33));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_34));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_35));
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_8;
bevt_46_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_49_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_containedGet_0();
bevt_50_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_get_1(bevt_50_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_getBeavArg_1(bevt_47_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_51_tmpvar_phold = bevo_9;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_51_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_52_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevt_37_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_38));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevt_36_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_35_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_39));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(25, bels_40));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_60_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_61_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_61_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processNotEquals_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_18_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_10;
bevt_16_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_19_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_containedGet_0();
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_get_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_getBeavArg_1(bevt_17_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_11;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_containedGet_0();
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_get_1(bevt_27_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_getBeavArg_1(bevt_24_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_12;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_29_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_44));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_45));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_46));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_47));
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_13;
bevt_46_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_49_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_containedGet_0();
bevt_50_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_get_1(bevt_50_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_getBeavArg_1(bevt_47_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_51_tmpvar_phold = bevo_14;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_51_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_52_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevt_37_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_50));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevt_36_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_35_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_51));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(25, bels_52));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_60_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_61_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_61_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processCompare_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_17_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevt_13_tmpvar_phold = bevo_15;
bevt_15_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_18_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_containedGet_0();
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_get_1(bevt_19_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_getBeavArg_1(bevt_16_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_16;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_21_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_55));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevl_nl);
this.bem_standardBlockAssign_2(beva_ca, bevl_callRet);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_56));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 334 */
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_57));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_58));
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevt_29_tmpvar_phold.bem_addValue_1(beva_action);
bevt_37_tmpvar_phold = bevo_17;
bevt_39_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_42_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_containedGet_0();
bevt_43_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_get_1(bevt_43_tmpvar_phold);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_getBeavArg_1(bevt_40_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_38_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_18;
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevt_28_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_45_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_61));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_46_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_62));
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_51_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(23, bels_63));
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_47_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_53_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_56_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_heldGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 339 */ {
bevt_58_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_64));
bevt_57_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_57_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 340 */
bevt_59_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_59_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processModify_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_17_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_47_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
beva_ca.bem_checkRetainTo_0();
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 354 */ {
bevt_13_tmpvar_phold = bevo_19;
bevt_15_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_18_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_containedGet_0();
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_get_1(bevt_19_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_getBeavArg_1(bevt_16_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_20;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_21_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_67));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevl_nl);
this.bem_standardBlockAssign_2(beva_ca, bevl_callRet);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_68));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 357 */
bevt_27_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(58, bels_69));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_70));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_34_tmpvar_phold = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_addValue_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(27, bels_71));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevt_34_tmpvar_phold.bem_addValue_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_72));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(beva_action);
bevt_43_tmpvar_phold = bevo_21;
bevt_45_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_48_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_containedGet_0();
bevt_49_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_getBeavArg_1(bevt_46_tmpvar_phold);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_50_tmpvar_phold = bevo_22;
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_add_1(bevt_50_tmpvar_phold);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_51_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 362 */ {
bevt_56_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_75));
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_55_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 363 */
bevt_57_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processIncDec_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
beva_ca.bem_checkRetainTo_0();
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(58, bels_76));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_77));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_14_tmpvar_phold = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(27, bels_78));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevt_14_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_79));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(beva_action);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_80));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_22_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_23_tmpvar_phold);
return bevl_callRet;
} /*method end*/
//int[] bevs_nlcs = {242, 245, 245, 245, 245, 245, 245, 0, 0, 0, 245, 245, 245, 0, 0, 0, 246, 246, 248, 248, 248, 248, 248, 249, 249, 250, 250, 250, 250, 250, 251, 251, 252, 252, 252, 252, 252, 253, 253, 253, 254, 254, 254, 254, 254, 255, 255, 255, 256, 256, 256, 256, 256, 257, 257, 257, 258, 258, 258, 258, 258, 259, 259, 259, 260, 260, 260, 260, 260, 261, 261, 261, 262, 262, 262, 262, 262, 263, 263, 263, 264, 264, 264, 264, 264, 265, 265, 265, 266, 266, 266, 266, 266, 267, 267, 267, 268, 268, 268, 268, 268, 269, 269, 269, 270, 270, 270, 270, 270, 271, 271, 271, 272, 272, 272, 272, 272, 273, 273, 273, 275, 275, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 279, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 280, 281, 282, 282, 283, 283, 284, 284, 285, 285, 286, 291, 291, 293, 293, 293, 294, 295, 295, 296, 296, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 298, 298, 298, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 300, 300, 300, 300, 300, 300, 300, 301, 301, 302, 302, 303, 308, 308, 310, 310, 310, 311, 312, 312, 313, 313, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 314, 315, 315, 315, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 316, 317, 317, 317, 317, 317, 317, 317, 318, 318, 319, 319, 320, 325, 325, 327, 327, 327, 328, 329, 329, 330, 330, 331, 331, 331, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 332, 333, 334, 334, 334, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 337, 337, 337, 337, 337, 337, 337, 338, 338, 339, 339, 339, 340, 340, 340, 342, 342, 343, 348, 348, 349, 350, 350, 350, 351, 352, 352, 353, 353, 354, 354, 354, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 355, 356, 357, 357, 357, 359, 359, 359, 359, 359, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 360, 361, 361, 362, 362, 362, 363, 363, 363, 365, 365, 366, 371, 371, 372, 373, 373, 373, 374, 375, 375, 376, 376, 377, 377, 377, 377, 377, 378, 378, 378, 378, 378, 378, 378, 378, 378, 378, 378, 378, 378, 378, 379, 379, 380, 380, 381};
//int[] bevs_nlecs = {114, 219, 220, 221, 223, 224, 229, 230, 233, 237, 240, 241, 242, 244, 247, 251, 254, 255, 257, 258, 259, 260, 261, 263, 264, 267, 268, 269, 270, 271, 273, 274, 277, 278, 279, 280, 281, 283, 284, 285, 288, 289, 290, 291, 292, 294, 295, 296, 299, 300, 301, 302, 303, 305, 306, 307, 310, 311, 312, 313, 314, 316, 317, 318, 321, 322, 323, 324, 325, 327, 328, 329, 332, 333, 334, 335, 336, 338, 339, 340, 343, 344, 345, 346, 347, 349, 350, 351, 354, 355, 356, 357, 358, 360, 361, 362, 365, 366, 367, 368, 369, 371, 372, 373, 376, 377, 378, 379, 380, 382, 383, 384, 387, 388, 389, 390, 391, 393, 394, 395, 409, 410, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 895, 896, 897, 899, 900, 901, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1034, 1035, 1036, 1038, 1039, 1040, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102, 1103};
/* BEGIN LINEINFO 
loadBuild 1 242 114
assign 1 245 219
nodeGet 0 245 219
assign 1 245 220
heldGet 0 245 220
assign 1 245 221
isConstructGet 0 245 221
assign 1 245 223
asnRGet 0 245 223
assign 1 245 224
def 1 245 229
assign 1 0 230
assign 1 0 233
assign 1 0 237
assign 1 245 240
nodeGet 0 245 240
assign 1 245 241
heldGet 0 245 241
assign 1 245 242
isLiteralGet 0 245 242
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 246 254
processLiteralConstruct 1 246 254
return 1 246 255
assign 1 248 257
nodeGet 0 248 257
assign 1 248 258
heldGet 0 248 258
assign 1 248 259
nameGet 0 248 259
assign 1 248 260
new 0 248 260
assign 1 248 261
equals 1 248 261
assign 1 249 263
processEquals 1 249 263
return 1 249 264
assign 1 250 267
nodeGet 0 250 267
assign 1 250 268
heldGet 0 250 268
assign 1 250 269
nameGet 0 250 269
assign 1 250 270
new 0 250 270
assign 1 250 271
equals 1 250 271
assign 1 251 273
processNotEquals 1 251 273
return 1 251 274
assign 1 252 277
nodeGet 0 252 277
assign 1 252 278
heldGet 0 252 278
assign 1 252 279
nameGet 0 252 279
assign 1 252 280
new 0 252 280
assign 1 252 281
equals 1 252 281
assign 1 253 283
new 0 253 283
assign 1 253 284
processCompare 2 253 284
return 1 253 285
assign 1 254 288
nodeGet 0 254 288
assign 1 254 289
heldGet 0 254 289
assign 1 254 290
nameGet 0 254 290
assign 1 254 291
new 0 254 291
assign 1 254 292
equals 1 254 292
assign 1 255 294
new 0 255 294
assign 1 255 295
processCompare 2 255 295
return 1 255 296
assign 1 256 299
nodeGet 0 256 299
assign 1 256 300
heldGet 0 256 300
assign 1 256 301
nameGet 0 256 301
assign 1 256 302
new 0 256 302
assign 1 256 303
equals 1 256 303
assign 1 257 305
new 0 257 305
assign 1 257 306
processCompare 2 257 306
return 1 257 307
assign 1 258 310
nodeGet 0 258 310
assign 1 258 311
heldGet 0 258 311
assign 1 258 312
nameGet 0 258 312
assign 1 258 313
new 0 258 313
assign 1 258 314
equals 1 258 314
assign 1 259 316
new 0 259 316
assign 1 259 317
processCompare 2 259 317
return 1 259 318
assign 1 260 321
nodeGet 0 260 321
assign 1 260 322
heldGet 0 260 322
assign 1 260 323
nameGet 0 260 323
assign 1 260 324
new 0 260 324
assign 1 260 325
equals 1 260 325
assign 1 261 327
new 0 261 327
assign 1 261 328
processModify 2 261 328
return 1 261 329
assign 1 262 332
nodeGet 0 262 332
assign 1 262 333
heldGet 0 262 333
assign 1 262 334
nameGet 0 262 334
assign 1 262 335
new 0 262 335
assign 1 262 336
equals 1 262 336
assign 1 263 338
new 0 263 338
assign 1 263 339
processModify 2 263 339
return 1 263 340
assign 1 264 343
nodeGet 0 264 343
assign 1 264 344
heldGet 0 264 344
assign 1 264 345
nameGet 0 264 345
assign 1 264 346
new 0 264 346
assign 1 264 347
equals 1 264 347
assign 1 265 349
new 0 265 349
assign 1 265 350
processModify 2 265 350
return 1 265 351
assign 1 266 354
nodeGet 0 266 354
assign 1 266 355
heldGet 0 266 355
assign 1 266 356
nameGet 0 266 356
assign 1 266 357
new 0 266 357
assign 1 266 358
equals 1 266 358
assign 1 267 360
new 0 267 360
assign 1 267 361
processModify 2 267 361
return 1 267 362
assign 1 268 365
nodeGet 0 268 365
assign 1 268 366
heldGet 0 268 366
assign 1 268 367
nameGet 0 268 367
assign 1 268 368
new 0 268 368
assign 1 268 369
equals 1 268 369
assign 1 269 371
new 0 269 371
assign 1 269 372
processModify 2 269 372
return 1 269 373
assign 1 270 376
nodeGet 0 270 376
assign 1 270 377
heldGet 0 270 377
assign 1 270 378
nameGet 0 270 378
assign 1 270 379
new 0 270 379
assign 1 270 380
equals 1 270 380
assign 1 271 382
new 0 271 382
assign 1 271 383
processIncDec 2 271 383
return 1 271 384
assign 1 272 387
nodeGet 0 272 387
assign 1 272 388
heldGet 0 272 388
assign 1 272 389
nameGet 0 272 389
assign 1 272 390
new 0 272 390
assign 1 272 391
equals 1 272 391
assign 1 273 393
new 0 273 393
assign 1 273 394
processIncDec 2 273 394
return 1 273 395
assign 1 275 409
standardCall 1 275 409
return 1 275 410
assign 1 279 443
tcallGet 0 279 443
assign 1 279 444
assignToVVGet 0 279 444
assign 1 279 445
add 1 279 445
assign 1 279 446
new 0 279 446
assign 1 279 447
add 1 279 447
assign 1 279 448
literalCdefGet 0 279 448
assign 1 279 449
add 1 279 449
assign 1 279 450
new 0 279 450
assign 1 279 451
add 1 279 451
assign 1 279 452
add 1 279 452
tcallSet 1 279 453
assign 1 280 454
tcallGet 0 280 454
assign 1 280 455
new 0 280 455
assign 1 280 456
add 1 280 456
assign 1 280 457
embedTargGet 0 280 457
assign 1 280 458
add 1 280 458
assign 1 280 459
new 0 280 459
assign 1 280 460
add 1 280 460
assign 1 280 461
nodeGet 0 280 461
assign 1 280 462
heldGet 0 280 462
assign 1 280 463
literalValueGet 0 280 463
assign 1 280 464
toString 0 280 464
assign 1 280 465
add 1 280 465
assign 1 280 466
new 0 280 466
assign 1 280 467
add 1 280 467
assign 1 280 468
add 1 280 468
tcallSet 1 280 469
assign 1 281 470
new 0 281 470
assign 1 282 471
preOnceEvalGet 0 282 471
addValue 1 282 472
assign 1 283 473
tcallGet 0 283 473
addValue 1 283 474
assign 1 284 475
assignToCheckGet 0 284 475
addValue 1 284 476
assign 1 285 477
postOnceEvalGet 0 285 477
addValue 1 285 478
return 1 286 479
assign 1 291 546
isValidGet 0 291 546
assertTrue 1 291 547
assign 1 293 548
emvisitGet 0 293 548
assign 1 293 549
buildGet 0 293 549
assign 1 293 550
nlGet 0 293 550
assign 1 294 551
new 0 294 551
assign 1 295 552
preOnceEvalGet 0 295 552
addValue 1 295 553
assign 1 296 554
callArgsGet 0 296 554
addValue 1 296 555
assign 1 297 556
new 0 297 556
assign 1 297 557
emvisitGet 0 297 557
assign 1 297 558
nodeGet 0 297 558
assign 1 297 559
containedGet 0 297 559
assign 1 297 560
new 0 297 560
assign 1 297 561
get 1 297 561
assign 1 297 562
getBeavArg 1 297 562
assign 1 297 563
add 1 297 563
assign 1 297 564
new 0 297 564
assign 1 297 565
add 1 297 565
assign 1 297 566
emvisitGet 0 297 566
assign 1 297 567
nodeGet 0 297 567
assign 1 297 568
containedGet 0 297 568
assign 1 297 569
new 0 297 569
assign 1 297 570
get 1 297 570
assign 1 297 571
getBeavArg 1 297 571
assign 1 297 572
add 1 297 572
assign 1 297 573
new 0 297 573
assign 1 297 574
add 1 297 574
assign 1 297 575
addValue 1 297 575
assign 1 297 576
targsGet 0 297 576
assign 1 297 577
addValue 1 297 577
assign 1 297 578
new 0 297 578
assign 1 297 579
addValue 1 297 579
assign 1 297 580
assignToVVGet 0 297 580
assign 1 297 581
addValue 1 297 581
assign 1 297 582
new 0 297 582
assign 1 297 583
addValue 1 297 583
addValue 1 297 584
assign 1 298 585
new 0 298 585
assign 1 298 586
addValue 1 298 586
addValue 1 298 587
assign 1 299 588
new 0 299 588
assign 1 299 589
addValue 1 299 589
assign 1 299 590
targsGet 0 299 590
assign 1 299 591
addValue 1 299 591
assign 1 299 592
new 0 299 592
assign 1 299 593
emvisitGet 0 299 593
assign 1 299 594
nodeGet 0 299 594
assign 1 299 595
containedGet 0 299 595
assign 1 299 596
new 0 299 596
assign 1 299 597
get 1 299 597
assign 1 299 598
getBeavArg 1 299 598
assign 1 299 599
add 1 299 599
assign 1 299 600
new 0 299 600
assign 1 299 601
add 1 299 601
assign 1 299 602
addValue 1 299 602
assign 1 299 603
assignToVVGet 0 299 603
assign 1 299 604
addValue 1 299 604
assign 1 299 605
new 0 299 605
assign 1 299 606
addValue 1 299 606
addValue 1 299 607
assign 1 300 608
new 0 300 608
assign 1 300 609
addValue 1 300 609
assign 1 300 610
assignToVVGet 0 300 610
assign 1 300 611
addValue 1 300 611
assign 1 300 612
new 0 300 612
assign 1 300 613
addValue 1 300 613
addValue 1 300 614
assign 1 301 615
assignToCheckGet 0 301 615
addValue 1 301 616
assign 1 302 617
postOnceEvalGet 0 302 617
addValue 1 302 618
return 1 303 619
assign 1 308 686
isValidGet 0 308 686
assertTrue 1 308 687
assign 1 310 688
emvisitGet 0 310 688
assign 1 310 689
buildGet 0 310 689
assign 1 310 690
nlGet 0 310 690
assign 1 311 691
new 0 311 691
assign 1 312 692
preOnceEvalGet 0 312 692
addValue 1 312 693
assign 1 313 694
callArgsGet 0 313 694
addValue 1 313 695
assign 1 314 696
new 0 314 696
assign 1 314 697
emvisitGet 0 314 697
assign 1 314 698
nodeGet 0 314 698
assign 1 314 699
containedGet 0 314 699
assign 1 314 700
new 0 314 700
assign 1 314 701
get 1 314 701
assign 1 314 702
getBeavArg 1 314 702
assign 1 314 703
add 1 314 703
assign 1 314 704
new 0 314 704
assign 1 314 705
add 1 314 705
assign 1 314 706
emvisitGet 0 314 706
assign 1 314 707
nodeGet 0 314 707
assign 1 314 708
containedGet 0 314 708
assign 1 314 709
new 0 314 709
assign 1 314 710
get 1 314 710
assign 1 314 711
getBeavArg 1 314 711
assign 1 314 712
add 1 314 712
assign 1 314 713
new 0 314 713
assign 1 314 714
add 1 314 714
assign 1 314 715
addValue 1 314 715
assign 1 314 716
targsGet 0 314 716
assign 1 314 717
addValue 1 314 717
assign 1 314 718
new 0 314 718
assign 1 314 719
addValue 1 314 719
assign 1 314 720
assignToVVGet 0 314 720
assign 1 314 721
addValue 1 314 721
assign 1 314 722
new 0 314 722
assign 1 314 723
addValue 1 314 723
addValue 1 314 724
assign 1 315 725
new 0 315 725
assign 1 315 726
addValue 1 315 726
addValue 1 315 727
assign 1 316 728
new 0 316 728
assign 1 316 729
addValue 1 316 729
assign 1 316 730
targsGet 0 316 730
assign 1 316 731
addValue 1 316 731
assign 1 316 732
new 0 316 732
assign 1 316 733
emvisitGet 0 316 733
assign 1 316 734
nodeGet 0 316 734
assign 1 316 735
containedGet 0 316 735
assign 1 316 736
new 0 316 736
assign 1 316 737
get 1 316 737
assign 1 316 738
getBeavArg 1 316 738
assign 1 316 739
add 1 316 739
assign 1 316 740
new 0 316 740
assign 1 316 741
add 1 316 741
assign 1 316 742
addValue 1 316 742
assign 1 316 743
assignToVVGet 0 316 743
assign 1 316 744
addValue 1 316 744
assign 1 316 745
new 0 316 745
assign 1 316 746
addValue 1 316 746
addValue 1 316 747
assign 1 317 748
new 0 317 748
assign 1 317 749
addValue 1 317 749
assign 1 317 750
assignToVVGet 0 317 750
assign 1 317 751
addValue 1 317 751
assign 1 317 752
new 0 317 752
assign 1 317 753
addValue 1 317 753
addValue 1 317 754
assign 1 318 755
assignToCheckGet 0 318 755
addValue 1 318 756
assign 1 319 757
postOnceEvalGet 0 319 757
addValue 1 319 758
return 1 320 759
assign 1 325 824
isValidGet 0 325 824
assertTrue 1 325 825
assign 1 327 826
emvisitGet 0 327 826
assign 1 327 827
buildGet 0 327 827
assign 1 327 828
nlGet 0 327 828
assign 1 328 829
new 0 328 829
assign 1 329 830
preOnceEvalGet 0 329 830
addValue 1 329 831
assign 1 330 832
callArgsGet 0 330 832
addValue 1 330 833
assign 1 331 834
nodeGet 0 331 834
assign 1 331 835
heldGet 0 331 835
assign 1 331 836
checkTypesGet 0 331 836
assign 1 332 838
new 0 332 838
assign 1 332 839
emvisitGet 0 332 839
assign 1 332 840
nodeGet 0 332 840
assign 1 332 841
containedGet 0 332 841
assign 1 332 842
new 0 332 842
assign 1 332 843
get 1 332 843
assign 1 332 844
getBeavArg 1 332 844
assign 1 332 845
add 1 332 845
assign 1 332 846
new 0 332 846
assign 1 332 847
add 1 332 847
assign 1 332 848
addValue 1 332 848
assign 1 332 849
targsGet 0 332 849
assign 1 332 850
addValue 1 332 850
assign 1 332 851
new 0 332 851
assign 1 332 852
addValue 1 332 852
addValue 1 332 853
standardBlockAssign 2 333 854
assign 1 334 855
new 0 334 855
assign 1 334 856
addValue 1 334 856
addValue 1 334 857
assign 1 336 859
new 0 336 859
assign 1 336 860
addValue 1 336 860
assign 1 336 861
targsGet 0 336 861
assign 1 336 862
addValue 1 336 862
assign 1 336 863
new 0 336 863
assign 1 336 864
addValue 1 336 864
assign 1 336 865
addValue 1 336 865
assign 1 336 866
new 0 336 866
assign 1 336 867
emvisitGet 0 336 867
assign 1 336 868
nodeGet 0 336 868
assign 1 336 869
containedGet 0 336 869
assign 1 336 870
new 0 336 870
assign 1 336 871
get 1 336 871
assign 1 336 872
getBeavArg 1 336 872
assign 1 336 873
add 1 336 873
assign 1 336 874
new 0 336 874
assign 1 336 875
add 1 336 875
assign 1 336 876
addValue 1 336 876
assign 1 336 877
assignToVVGet 0 336 877
assign 1 336 878
addValue 1 336 878
assign 1 336 879
new 0 336 879
assign 1 336 880
addValue 1 336 880
addValue 1 336 881
assign 1 337 882
new 0 337 882
assign 1 337 883
addValue 1 337 883
assign 1 337 884
assignToVVGet 0 337 884
assign 1 337 885
addValue 1 337 885
assign 1 337 886
new 0 337 886
assign 1 337 887
addValue 1 337 887
addValue 1 337 888
assign 1 338 889
assignToCheckGet 0 338 889
addValue 1 338 890
assign 1 339 891
nodeGet 0 339 891
assign 1 339 892
heldGet 0 339 892
assign 1 339 893
checkTypesGet 0 339 893
assign 1 340 895
new 0 340 895
assign 1 340 896
addValue 1 340 896
addValue 1 340 897
assign 1 342 899
postOnceEvalGet 0 342 899
addValue 1 342 900
return 1 343 901
assign 1 348 964
isValidGet 0 348 964
assertTrue 1 348 965
checkRetainTo 0 349 966
assign 1 350 967
emvisitGet 0 350 967
assign 1 350 968
buildGet 0 350 968
assign 1 350 969
nlGet 0 350 969
assign 1 351 970
new 0 351 970
assign 1 352 971
preOnceEvalGet 0 352 971
addValue 1 352 972
assign 1 353 973
callArgsGet 0 353 973
addValue 1 353 974
assign 1 354 975
nodeGet 0 354 975
assign 1 354 976
heldGet 0 354 976
assign 1 354 977
checkTypesGet 0 354 977
assign 1 355 979
new 0 355 979
assign 1 355 980
emvisitGet 0 355 980
assign 1 355 981
nodeGet 0 355 981
assign 1 355 982
containedGet 0 355 982
assign 1 355 983
new 0 355 983
assign 1 355 984
get 1 355 984
assign 1 355 985
getBeavArg 1 355 985
assign 1 355 986
add 1 355 986
assign 1 355 987
new 0 355 987
assign 1 355 988
add 1 355 988
assign 1 355 989
addValue 1 355 989
assign 1 355 990
targsGet 0 355 990
assign 1 355 991
addValue 1 355 991
assign 1 355 992
new 0 355 992
assign 1 355 993
addValue 1 355 993
addValue 1 355 994
standardBlockAssign 2 356 995
assign 1 357 996
new 0 357 996
assign 1 357 997
addValue 1 357 997
addValue 1 357 998
assign 1 359 1000
assignToVVGet 0 359 1000
assign 1 359 1001
addValue 1 359 1001
assign 1 359 1002
new 0 359 1002
assign 1 359 1003
addValue 1 359 1003
addValue 1 359 1004
assign 1 360 1005
new 0 360 1005
assign 1 360 1006
addValue 1 360 1006
assign 1 360 1007
embedTargGet 0 360 1007
assign 1 360 1008
addValue 1 360 1008
assign 1 360 1009
new 0 360 1009
assign 1 360 1010
addValue 1 360 1010
assign 1 360 1011
targsGet 0 360 1011
assign 1 360 1012
addValue 1 360 1012
assign 1 360 1013
new 0 360 1013
assign 1 360 1014
addValue 1 360 1014
assign 1 360 1015
addValue 1 360 1015
assign 1 360 1016
new 0 360 1016
assign 1 360 1017
emvisitGet 0 360 1017
assign 1 360 1018
nodeGet 0 360 1018
assign 1 360 1019
containedGet 0 360 1019
assign 1 360 1020
new 0 360 1020
assign 1 360 1021
get 1 360 1021
assign 1 360 1022
getBeavArg 1 360 1022
assign 1 360 1023
add 1 360 1023
assign 1 360 1024
new 0 360 1024
assign 1 360 1025
add 1 360 1025
assign 1 360 1026
addValue 1 360 1026
addValue 1 360 1027
assign 1 361 1028
assignToCheckGet 0 361 1028
addValue 1 361 1029
assign 1 362 1030
nodeGet 0 362 1030
assign 1 362 1031
heldGet 0 362 1031
assign 1 362 1032
checkTypesGet 0 362 1032
assign 1 363 1034
new 0 363 1034
assign 1 363 1035
addValue 1 363 1035
addValue 1 363 1036
assign 1 365 1038
postOnceEvalGet 0 365 1038
addValue 1 365 1039
return 1 366 1040
assign 1 371 1069
isValidGet 0 371 1069
assertTrue 1 371 1070
checkRetainTo 0 372 1071
assign 1 373 1072
emvisitGet 0 373 1072
assign 1 373 1073
buildGet 0 373 1073
assign 1 373 1074
nlGet 0 373 1074
assign 1 374 1075
new 0 374 1075
assign 1 375 1076
preOnceEvalGet 0 375 1076
addValue 1 375 1077
assign 1 376 1078
callArgsGet 0 376 1078
addValue 1 376 1079
assign 1 377 1080
assignToVVGet 0 377 1080
assign 1 377 1081
addValue 1 377 1081
assign 1 377 1082
new 0 377 1082
assign 1 377 1083
addValue 1 377 1083
addValue 1 377 1084
assign 1 378 1085
new 0 378 1085
assign 1 378 1086
addValue 1 378 1086
assign 1 378 1087
embedTargGet 0 378 1087
assign 1 378 1088
addValue 1 378 1088
assign 1 378 1089
new 0 378 1089
assign 1 378 1090
addValue 1 378 1090
assign 1 378 1091
targsGet 0 378 1091
assign 1 378 1092
addValue 1 378 1092
assign 1 378 1093
new 0 378 1093
assign 1 378 1094
addValue 1 378 1094
assign 1 378 1095
addValue 1 378 1095
assign 1 378 1096
new 0 378 1096
assign 1 378 1097
addValue 1 378 1097
addValue 1 378 1098
assign 1 379 1099
assignToCheckGet 0 379 1099
addValue 1 379 1100
assign 1 380 1101
postOnceEvalGet 0 380 1101
addValue 1 380 1102
return 1 381 1103
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 2001798761: return bem_nlGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1178476504: return bem_fromTypesGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 846242271: return bem_processCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 281832742: return bem_loadBuild_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1189558757: return bem_fromTypesSet_1(bevd_0);
case 224779883: return bem_processOptimizedGetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 77715863: return bem_processLiteralConstruct_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2051196096: return bem_processEquals_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1292480624: return bem_processAssign_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1833349037: return bem_standardCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1977543830: return bem_processNot_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 825908811: return bem_processNotEquals_1((BEC_5_10_BuildCallCursor) bevd_0);
case 785892343: return bem_processOptimizedSetter_1((BEC_5_10_BuildCallCursor) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 429177731: return bem_standardBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 19297983: return bem_accessorCheckBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1419087447: return bem_processCompare_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1046864252: return bem_processModify_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 436992814: return bem_standardBlockAssign_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1715203462: return bem_processIncDec_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_12_BuildCAssembleInt();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_12_BuildCAssembleInt.bevs_inst = (BEC_5_12_BuildCAssembleInt)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_12_BuildCAssembleInt.bevs_inst;
}
}
}
