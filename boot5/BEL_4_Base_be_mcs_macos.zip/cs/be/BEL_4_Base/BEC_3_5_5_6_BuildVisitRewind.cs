namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_6_BuildVisitRewind : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
static BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 11));
private static byte[] bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 2));
private static byte[] bels_3 = {0x5F,0x30};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 2));
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 27));
private static byte[] bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_8 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 13));
private static byte[] bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 10));
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitRewind bevs_inst;
public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(654935401, BEL_4_Base.bevn_wasForeachGennedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 241 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 241 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 241 */
 else  /* Line: 241 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 241 */ {
bevt_15_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_typenameGet_0();
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpvar_phold.bevi_int == bevt_16_tmpvar_phold.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_20_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_0));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 243 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_22_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_26_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_firstGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_firstGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpvar_phold.bem_lastGet_0();
bevt_39_tmpvar_phold = bevo_0;
bevt_40_tmpvar_phold = bevo_1;
bevt_38_tmpvar_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpvar_phold, bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_2_4_6_TextString) bevt_38_tmpvar_phold.bem_lowerValue_0();
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_tmpvar_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_43_tmpvar_phold = bevo_2;
bevl_fgin = bevt_36_tmpvar_phold.bem_add_1(bevt_43_tmpvar_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpvar_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpvar_phold = bevo_3;
bevt_45_tmpvar_phold = bevl_fgin.bem_add_1(bevt_46_tmpvar_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpvar_phold.bem_get_1(bevt_45_tmpvar_phold);
if (bevl_fgms == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_48_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_fgin);
bevt_49_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevo_4;
bevt_50_tmpvar_phold = bevl_fgin.bem_add_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 255 */
} /* Line: 252 */
} /* Line: 245 */
} /* Line: 243 */
bevt_53_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevp_inClass = beva_node;
bevt_55_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 263 */
bevt_58_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpvar_phold.bevi_int == bevt_59_tmpvar_phold.bevi_int) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 267 */
 else  /* Line: 265 */ {
bevt_61_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpvar_phold.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 268 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
 else  /* Line: 268 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 268 */ {
bevt_66_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_65_tmpvar_phold, bevt_67_tmpvar_phold);
bevt_69_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_68_tmpvar_phold);
if (bevl_ll == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_71_tmpvar_phold, bevl_ll);
} /* Line: 273 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 275 */
 else  /* Line: 265 */ {
bevt_74_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpvar_phold.bevi_int == bevt_75_tmpvar_phold.bevi_int) {
bevt_73_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_77_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_80_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_containerGet_0();
if (bevt_79_tmpvar_phold == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_84_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_containerGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_typenameGet_0();
bevt_85_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpvar_phold.bevi_int == bevt_85_tmpvar_phold.bevi_int) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
this.bem_processTmps_0();
} /* Line: 278 */
} /* Line: 265 */
} /* Line: 265 */
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_processTmps_0() {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tvar = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_ovar = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
while (true)
 /* Line: 292 */ {
if (bevl_foundone != null && bevl_foundone is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 292 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 294 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 297 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 302 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 302 */ {
bevl_k = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevt_15_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_16_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 303 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 303 */
 else  /* Line: 303 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 303 */ {
bevt_20_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_4));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 303 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 303 */
 else  /* Line: 303 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 303 */ {
bevt_25_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_26_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 303 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 303 */
 else  /* Line: 303 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 303 */ {
bevt_27_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_27_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_30_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_29_tmpvar_phold == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_31_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_31_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 308 */
 else  /* Line: 309 */ {
bevt_32_tmpvar_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_32_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_34_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 314 */ {
bevl_tvar = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 315 */
 else  /* Line: 316 */ {
bevt_36_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_38_tmpvar_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_37_tmpvar_phold);
bevl_tvar = bevt_35_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 317 */
bevt_39_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_targNp = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 321 */
} /* Line: 320 */
if (bevl_targNp == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_41_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_43_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_41_tmpvar_phold.bem_get_1(bevt_42_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 328 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_ovar == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevt_46_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 331 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 331 */
 else  /* Line: 331 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 331 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_47_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 334 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 335 */
 else  /* Line: 336 */ {
bevt_48_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_48_tmpvar_phold);
} /* Line: 337 */
bevt_49_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_49_tmpvar_phold);
bevt_50_tmpvar_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_50_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_55_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_5));
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 341 */ {
bevt_57_tmpvar_phold = bevo_5;
bevt_58_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 341 */
} /* Line: 341 */
} /* Line: 331 */
 else  /* Line: 328 */ {
bevt_61_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_7));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 343 */ {
bevt_67_tmpvar_phold = bevo_6;
bevt_69_tmpvar_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = bevo_7;
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_add_1(bevt_71_tmpvar_phold);
bevt_63_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpvar_phold, bevl_tcall);
throw new be.BELS_Base.BECS_ThrowBack(bevt_63_tmpvar_phold);
} /* Line: 344 */
} /* Line: 328 */
} /* Line: 328 */
} /* Line: 324 */
 else  /* Line: 303 */ {
bevt_72_tmpvar_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_75_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 349 */ {
bevt_80_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_10));
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 349 */ {
bevt_85_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_86_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 349 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 349 */ {
bevt_88_tmpvar_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_87_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_89_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_89_tmpvar_phold != null && bevt_89_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_89_tmpvar_phold).bevi_bool) /* Line: 352 */ {
bevl_foundone = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_90_tmpvar_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_91_tmpvar_phold);
} /* Line: 357 */
} /* Line: 352 */
} /* Line: 303 */
} /* Line: 303 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
} /* Line: 302 */
} /* Line: 297 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
} /* Line: 294 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_tvmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_rmap = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {241, 241, 241, 241, 241, 241, 0, 0, 0, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 0, 0, 0, 243, 0, 0, 0, 245, 245, 245, 245, 245, 245, 245, 245, 245, 0, 0, 0, 246, 246, 246, 246, 247, 247, 248, 248, 248, 248, 248, 248, 248, 248, 248, 250, 251, 251, 251, 251, 252, 252, 254, 254, 255, 255, 255, 255, 260, 260, 260, 260, 261, 262, 262, 263, 263, 265, 265, 265, 265, 266, 267, 268, 268, 268, 268, 268, 268, 0, 0, 0, 269, 269, 269, 269, 270, 270, 270, 271, 271, 272, 273, 273, 273, 275, 276, 276, 276, 276, 276, 276, 276, 0, 0, 0, 276, 276, 276, 276, 0, 0, 0, 276, 276, 276, 276, 276, 276, 0, 0, 0, 278, 280, 280, 284, 293, 294, 294, 295, 297, 297, 300, 301, 302, 0, 302, 302, 303, 303, 303, 303, 303, 0, 0, 0, 303, 303, 303, 303, 303, 0, 0, 0, 303, 303, 303, 303, 303, 0, 0, 0, 305, 305, 306, 307, 307, 307, 307, 308, 308, 310, 310, 314, 314, 315, 317, 317, 317, 317, 317, 320, 321, 324, 324, 326, 327, 327, 327, 327, 328, 328, 330, 331, 331, 331, 0, 0, 0, 332, 334, 335, 337, 337, 339, 339, 340, 340, 340, 341, 341, 341, 341, 341, 341, 341, 341, 343, 343, 343, 343, 344, 344, 344, 344, 344, 344, 344, 344, 344, 344, 349, 349, 349, 349, 349, 0, 0, 0, 349, 349, 349, 349, 349, 0, 0, 0, 349, 349, 349, 349, 349, 0, 0, 0, 350, 350, 350, 352, 354, 356, 356, 357, 357, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {132, 133, 134, 139, 140, 141, 143, 146, 150, 153, 154, 155, 156, 161, 162, 163, 164, 165, 166, 168, 171, 175, 178, 180, 183, 187, 190, 191, 192, 193, 194, 196, 197, 198, 199, 201, 204, 208, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 236, 237, 238, 239, 240, 241, 242, 247, 248, 249, 254, 255, 256, 257, 258, 259, 261, 262, 263, 268, 269, 270, 273, 274, 275, 280, 281, 282, 284, 287, 291, 294, 295, 296, 297, 298, 299, 300, 301, 306, 307, 308, 309, 310, 312, 315, 316, 317, 322, 323, 324, 329, 330, 333, 337, 340, 341, 342, 347, 348, 351, 355, 358, 359, 360, 361, 362, 367, 368, 371, 375, 378, 382, 383, 491, 495, 496, 499, 501, 502, 503, 505, 506, 507, 507, 510, 512, 513, 515, 516, 517, 518, 520, 523, 527, 530, 531, 532, 533, 534, 536, 539, 543, 546, 547, 548, 549, 550, 552, 555, 559, 562, 563, 564, 565, 566, 567, 572, 573, 574, 577, 578, 579, 580, 582, 585, 586, 587, 588, 589, 591, 593, 596, 601, 602, 603, 604, 605, 606, 607, 612, 613, 614, 619, 620, 622, 625, 629, 632, 633, 635, 638, 639, 641, 642, 643, 644, 645, 646, 647, 648, 649, 651, 652, 653, 654, 659, 660, 661, 662, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 679, 681, 682, 683, 684, 686, 689, 693, 696, 697, 698, 699, 700, 702, 705, 709, 712, 713, 714, 715, 716, 718, 721, 725, 728, 729, 730, 731, 733, 734, 735, 736, 737, 760, 763, 767, 770, 774, 777, 781, 784, 788, 791, 795, 798, 802, 805};
/* BEGIN LINEINFO 
assign 1 241 132
typenameGet 0 241 132
assign 1 241 133
CALLGet 0 241 133
assign 1 241 134
equals 1 241 139
assign 1 241 140
heldGet 0 241 140
assign 1 241 141
wasForeachGennedGet 0 241 141
assign 1 0 143
assign 1 0 146
assign 1 0 150
assign 1 243 153
containerGet 0 243 153
assign 1 243 154
typenameGet 0 243 154
assign 1 243 155
CALLGet 0 243 155
assign 1 243 156
equals 1 243 161
assign 1 243 162
containerGet 0 243 162
assign 1 243 163
heldGet 0 243 163
assign 1 243 164
orgNameGet 0 243 164
assign 1 243 165
new 0 243 165
assign 1 243 166
equals 1 243 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 243 178
isSecondGet 0 243 178
assign 1 0 180
assign 1 0 183
assign 1 0 187
assign 1 245 190
containedGet 0 245 190
assign 1 245 191
firstGet 0 245 191
assign 1 245 192
typenameGet 0 245 192
assign 1 245 193
VARGet 0 245 193
assign 1 245 194
equals 1 245 194
assign 1 245 196
containedGet 0 245 196
assign 1 245 197
firstGet 0 245 197
assign 1 245 198
heldGet 0 245 198
assign 1 245 199
isTypedGet 0 245 199
assign 1 0 201
assign 1 0 204
assign 1 0 208
assign 1 246 211
containedGet 0 246 211
assign 1 246 212
firstGet 0 246 212
assign 1 246 213
heldGet 0 246 213
assign 1 246 214
namepathGet 0 246 214
assign 1 247 215
stepsGet 0 247 215
assign 1 247 216
lastGet 0 247 216
assign 1 248 217
new 0 248 217
assign 1 248 218
new 0 248 218
assign 1 248 219
substring 2 248 219
assign 1 248 220
lowerValue 0 248 220
assign 1 248 221
new 0 248 221
assign 1 248 222
substring 1 248 222
assign 1 248 223
add 1 248 223
assign 1 248 224
new 0 248 224
assign 1 248 225
add 1 248 225
assign 1 250 226
getSynNp 1 250 226
assign 1 251 227
mtdMapGet 0 251 227
assign 1 251 228
new 0 251 228
assign 1 251 229
add 1 251 229
assign 1 251 230
get 1 251 230
assign 1 252 231
def 1 252 236
assign 1 254 237
heldGet 0 254 237
orgNameSet 1 254 238
assign 1 255 239
heldGet 0 255 239
assign 1 255 240
new 0 255 240
assign 1 255 241
add 1 255 241
nameSet 1 255 242
assign 1 260 247
typenameGet 0 260 247
assign 1 260 248
CLASSGet 0 260 248
assign 1 260 249
equals 1 260 254
assign 1 261 255
assign 1 262 256
heldGet 0 262 256
assign 1 262 257
namepathGet 0 262 257
assign 1 263 258
heldGet 0 263 258
assign 1 263 259
synGet 0 263 259
assign 1 265 261
typenameGet 0 265 261
assign 1 265 262
METHODGet 0 265 262
assign 1 265 263
equals 1 265 268
assign 1 266 269
new 0 266 269
assign 1 267 270
new 0 267 270
assign 1 268 273
typenameGet 0 268 273
assign 1 268 274
VARGet 0 268 274
assign 1 268 275
equals 1 268 280
assign 1 268 281
heldGet 0 268 281
assign 1 268 282
isTmpVarGet 0 268 282
assign 1 0 284
assign 1 0 287
assign 1 0 291
assign 1 269 294
heldGet 0 269 294
assign 1 269 295
nameGet 0 269 295
assign 1 269 296
heldGet 0 269 296
put 2 269 297
assign 1 270 298
heldGet 0 270 298
assign 1 270 299
nameGet 0 270 299
assign 1 270 300
get 1 270 300
assign 1 271 301
undef 1 271 306
assign 1 272 307
new 0 272 307
assign 1 273 308
heldGet 0 273 308
assign 1 273 309
nameGet 0 273 309
put 2 273 310
addValue 1 275 312
assign 1 276 315
typenameGet 0 276 315
assign 1 276 316
RBRACESGet 0 276 316
assign 1 276 317
equals 1 276 322
assign 1 276 323
containerGet 0 276 323
assign 1 276 324
def 1 276 329
assign 1 0 330
assign 1 0 333
assign 1 0 337
assign 1 276 340
containerGet 0 276 340
assign 1 276 341
containerGet 0 276 341
assign 1 276 342
def 1 276 347
assign 1 0 348
assign 1 0 351
assign 1 0 355
assign 1 276 358
containerGet 0 276 358
assign 1 276 359
containerGet 0 276 359
assign 1 276 360
typenameGet 0 276 360
assign 1 276 361
METHODGet 0 276 361
assign 1 276 362
equals 1 276 367
assign 1 0 368
assign 1 0 371
assign 1 0 375
processTmps 0 278 378
assign 1 280 382
nextDescendGet 0 280 382
return 1 280 383
assign 1 284 491
new 0 284 491
assign 1 293 495
new 0 293 495
assign 1 294 496
valueIteratorGet 0 294 496
assign 1 294 499
hasNextGet 0 294 499
assign 1 295 501
nextGet 0 295 501
assign 1 297 502
isTypedGet 0 297 502
assign 1 297 503
not 0 297 503
assign 1 300 505
nameGet 0 300 505
assign 1 301 506
get 1 301 506
assign 1 302 507
iteratorGet 0 0 507
assign 1 302 510
hasNextGet 0 302 510
assign 1 302 512
nextGet 0 302 512
assign 1 303 513
isFirstGet 0 303 513
assign 1 303 515
containerGet 0 303 515
assign 1 303 516
typenameGet 0 303 516
assign 1 303 517
CALLGet 0 303 517
assign 1 303 518
equals 1 303 518
assign 1 0 520
assign 1 0 523
assign 1 0 527
assign 1 303 530
containerGet 0 303 530
assign 1 303 531
heldGet 0 303 531
assign 1 303 532
orgNameGet 0 303 532
assign 1 303 533
new 0 303 533
assign 1 303 534
equals 1 303 534
assign 1 0 536
assign 1 0 539
assign 1 0 543
assign 1 303 546
containerGet 0 303 546
assign 1 303 547
secondGet 0 303 547
assign 1 303 548
typenameGet 0 303 548
assign 1 303 549
CALLGet 0 303 549
assign 1 303 550
equals 1 303 550
assign 1 0 552
assign 1 0 555
assign 1 0 559
assign 1 305 562
containerGet 0 305 562
assign 1 305 563
secondGet 0 305 563
assign 1 306 564
assign 1 307 565
heldGet 0 307 565
assign 1 307 566
newNpGet 0 307 566
assign 1 307 567
def 1 307 572
assign 1 308 573
heldGet 0 308 573
assign 1 308 574
newNpGet 0 308 574
assign 1 310 577
containedGet 0 310 577
assign 1 310 578
firstGet 0 310 578
assign 1 314 579
heldGet 0 314 579
assign 1 314 580
isDeclaredGet 0 314 580
assign 1 315 582
heldGet 0 315 582
assign 1 317 585
ptyMapGet 0 317 585
assign 1 317 586
heldGet 0 317 586
assign 1 317 587
nameGet 0 317 587
assign 1 317 588
get 1 317 588
assign 1 317 589
memSynGet 0 317 589
assign 1 320 591
isTypedGet 0 320 591
assign 1 321 593
namepathGet 0 321 593
assign 1 324 596
def 1 324 601
assign 1 326 602
getSynNp 1 326 602
assign 1 327 603
mtdMapGet 0 327 603
assign 1 327 604
heldGet 0 327 604
assign 1 327 605
nameGet 0 327 605
assign 1 327 606
get 1 327 606
assign 1 328 607
def 1 328 612
assign 1 330 613
rsynGet 0 330 613
assign 1 331 614
def 1 331 619
assign 1 331 620
isTypedGet 0 331 620
assign 1 0 622
assign 1 0 625
assign 1 0 629
assign 1 332 632
new 0 332 632
assign 1 334 633
isSelfGet 0 334 633
namepathSet 1 335 635
assign 1 337 638
namepathGet 0 337 638
namepathSet 1 337 639
assign 1 339 641
isTypedGet 0 339 641
isTypedSet 1 339 642
assign 1 340 643
heldGet 0 340 643
assign 1 340 644
namepathGet 0 340 644
addUsed 1 340 645
assign 1 341 646
namepathGet 0 341 646
assign 1 341 647
toString 0 341 647
assign 1 341 648
new 0 341 648
assign 1 341 649
equals 1 341 649
assign 1 341 651
new 0 341 651
assign 1 341 652
isSelfGet 0 341 652
assign 1 341 653
add 1 341 653
print 0 341 654
assign 1 343 659
heldGet 0 343 659
assign 1 343 660
orgNameGet 0 343 660
assign 1 343 661
new 0 343 661
assign 1 343 662
notEquals 1 343 662
assign 1 344 664
new 0 344 664
assign 1 344 665
heldGet 0 344 665
assign 1 344 666
nameGet 0 344 666
assign 1 344 667
add 1 344 667
assign 1 344 668
new 0 344 668
assign 1 344 669
add 1 344 669
assign 1 344 670
toString 0 344 670
assign 1 344 671
add 1 344 671
assign 1 344 672
new 2 344 672
throw 1 344 673
assign 1 349 679
isFirstGet 0 349 679
assign 1 349 681
containerGet 0 349 681
assign 1 349 682
typenameGet 0 349 682
assign 1 349 683
CALLGet 0 349 683
assign 1 349 684
equals 1 349 684
assign 1 0 686
assign 1 0 689
assign 1 0 693
assign 1 349 696
containerGet 0 349 696
assign 1 349 697
heldGet 0 349 697
assign 1 349 698
orgNameGet 0 349 698
assign 1 349 699
new 0 349 699
assign 1 349 700
equals 1 349 700
assign 1 0 702
assign 1 0 705
assign 1 0 709
assign 1 349 712
containerGet 0 349 712
assign 1 349 713
secondGet 0 349 713
assign 1 349 714
typenameGet 0 349 714
assign 1 349 715
VARGet 0 349 715
assign 1 349 716
equals 1 349 716
assign 1 0 718
assign 1 0 721
assign 1 0 725
assign 1 350 728
containerGet 0 350 728
assign 1 350 729
secondGet 0 350 729
assign 1 350 730
heldGet 0 350 730
assign 1 352 731
isTypedGet 0 352 731
assign 1 354 733
new 0 354 733
assign 1 356 734
isTypedGet 0 356 734
isTypedSet 1 356 735
assign 1 357 736
namepathGet 0 357 736
namepathSet 1 357 737
return 1 0 760
assign 1 0 763
return 1 0 767
assign 1 0 770
return 1 0 774
assign 1 0 777
return 1 0 781
assign 1 0 784
return 1 0 788
assign 1 0 791
return 1 0 795
assign 1 0 798
return 1 0 802
assign 1 0 805
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitRewind.bevs_inst = (BEC_3_5_5_6_BuildVisitRewind)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitRewind.bevs_inst;
}
}
}
