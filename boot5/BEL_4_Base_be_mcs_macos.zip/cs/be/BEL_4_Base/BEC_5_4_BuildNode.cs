namespace be.BEL_4_Base {
/* IO:File: source/build/Nodes.be */
public class BEC_5_4_BuildNode : BEC_6_6_SystemObject {
public BEC_5_4_BuildNode() { }
static BEC_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_9_3_ContainerSet bevo_4;
private static BEC_9_3_ContainerSet bevo_5;
private static BEC_9_3_ContainerSet bevo_6;
private static BEC_9_3_ContainerSet bevo_7;
private static BEC_9_3_ContainerSet bevo_8;
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_5_4_BuildNode bevs_inst;
public BEC_9_8_ContainerNodeList bevp_contained;
public BEC_5_4_BuildNode bevp_container;
public BEC_6_6_SystemObject bevp_held;
public BEC_6_6_SystemObject bevp_heldBy;
public BEC_6_6_SystemObject bevp_condvar;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_6_6_SystemObject bevp_typeDetail;
public BEC_5_4_LogicBool bevp_delayDelete;
public BEC_4_3_MathInt bevp_nlc;
public BEC_4_3_MathInt bevp_nlec;
public BEC_5_4_LogicBool bevp_wideString;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_3_MathInt bevp_typename;
public virtual BEC_5_4_BuildNode bem_new_1(BEC_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_nlec = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_wideString = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copyLoc_1(BEC_5_4_BuildNode beva_fromNode) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextDescendGet_0() {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 53 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 57 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 57 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 59 */
 else  /* Line: 57 */ {
break;
} /* Line: 57 */
} /* Line: 57 */
return bevl_ret;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextAscendGet_0() {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 67 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 67 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 67 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 67 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 69 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
return bevl_ret;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextPeerGet_0() {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 75 */ {
return null;
} /* Line: 76 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 79 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 80 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_priorPeerGet_0() {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 90 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 91 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_firstGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_secondGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_thirdGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isFirstGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 110 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isSecondGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 117 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isThirdGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 124 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delayDelete_0() {
bevp_delayDelete = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
return null;
} /* Line: 135 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_beforeInsert_1(BEC_5_4_BuildNode beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 143 */ {
return null;
} /* Line: 144 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepend_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 151 */ {
this.bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addValue_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 159 */ {
this.bem_initContained_0();
} /* Line: 160 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_reInitContained_0() {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_initContained_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 172 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_6_6_SystemObject bevl_e = null;
BEC_4_6_TextString bevl_res = null;
try  /* Line: 178 */ {
bevl_res = this.bem_toStringCompact_0();
} /* Line: 179 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 182 */
return bevl_res;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringBig_0() {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_6_6_SystemObject bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 191 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_22_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 192 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_32_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 196 */
return (BEC_4_6_TextString) bevl_ret;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringCompact_0() {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_4_6_TextString bevl_ret = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_7));
bevl_ret = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
if (bevp_nlc == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_7_tmpvar_phold = bevo_0;
bevt_6_tmpvar_phold = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 205 */
if (bevp_inClassNp == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_ret.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 208 */
if (bevp_held == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_ret.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_14_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
} /* Line: 211 */
return bevl_ret;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_depthGet_0() {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 219 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 221 */
 else  /* Line: 219 */ {
break;
} /* Line: 219 */
} /* Line: 219 */
return bevl_d;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prefixGet_0() {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_p = null;
BEC_6_6_SystemObject bevl_q = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_4_6_TextString(2, bels_11));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 230 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 230 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 230 */
 else  /* Line: 230 */ {
break;
} /* Line: 230 */
} /* Line: 230 */
return bevl_p;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_transUnitGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 238 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 238 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 239 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tmpVar_2(BEC_6_6_SystemObject beva_suffix, BEC_6_6_SystemObject beva_build) {
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tmpvarn = null;
BEC_6_6_SystemObject bevl_tmpvar = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 246 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_12));
bevt_3_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 247 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_13));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 260 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 262 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 264 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addVariable_0() {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 274 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(54, bels_14));
bevt_7_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 275 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 277 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 279 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 282 */ {
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_15));
bevt_16_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 283 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 286 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_syncAddVariable_0() {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 292 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 296 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 297 */
 else  /* Line: 298 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 300 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 301 */
 else  /* Line: 302 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 305 */ {
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_16));
bevt_20_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 306 */
} /* Line: 305 */
} /* Line: 300 */
} /* Line: 296 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_syncVariable_1(BEC_5_5_7_BuildVisitVisitor beva_visit) {
BEC_6_6_SystemObject bevl_vname = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 318 */
 else  /* Line: 319 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 321 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 322 */
 else  /* Line: 323 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevl_np);
bevt_13_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_14_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_13_tmpvar_phold);
} /* Line: 327 */
 else  /* Line: 328 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_18));
bevt_16_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 332 */ {
bevp_held = bevl_v;
bevt_18_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_20_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_21_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_21_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 337 */
 else  /* Line: 338 */ {
bevt_22_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_23_tmpvar_phold);
bevp_held = bevl_v;
bevt_24_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_24_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_25_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_25_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 343 */
} /* Line: 332 */
} /* Line: 326 */
} /* Line: 321 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_anchorGet_0() {
BEC_6_6_SystemObject bevl_node = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 352 */ {
while (true)
 /* Line: 353 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 354 */ {
return bevl_node;
} /* Line: 355 */
 else  /* Line: 356 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_19));
bevt_5_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 359 */
} /* Line: 358 */
} /* Line: 354 */
} /* Line: 353 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 368 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 368 */
 else  /* Line: 368 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 368 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 369 */
 else  /* Line: 368 */ {
break;
} /* Line: 368 */
} /* Line: 368 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_scopeGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 376 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 376 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 377 */
 else  /* Line: 376 */ {
break;
} /* Line: 376 */
} /* Line: 376 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_replaceWith_1(BEC_5_4_BuildNode beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 383 */ {
return null;
} /* Line: 384 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deleteAndAppend_1(BEC_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_takeContents_1(BEC_5_4_BuildNode beva_other) {
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 397 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 399 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_resolveNp_0() {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_0_tmpvar_phold = bevp_typename.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 405 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 408 */
} /* Line: 407 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 414 */
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 417 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 418 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 420 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_9_tmpvar_phold = bevp_typename.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 425 */
} /* Line: 424 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_callIsSafe_1(BEC_5_4_BuildNode beva_call) {
BEC_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_9_3_ContainerSet bevl_okClasses = null;
BEC_9_3_ContainerSet bevl_okCalls = null;
BEC_9_3_ContainerSet bevl_okClasses2 = null;
BEC_9_3_ContainerSet bevl_okCalls2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 435 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_20));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 435 */
 else  /* Line: 435 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 435 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 436 */
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_4 == null) {
bevo_4 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_4;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_5 == null) {
bevo_5 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_5;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_6 == null) {
bevo_6 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_6;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_7 == null) {
bevo_7 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_7;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_8 == null) {
bevo_8 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_8;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_9;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 444 */ {
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 494 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 498 */ {
bevt_49_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 500 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 504 */ {
bevt_55_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 506 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_65_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 517 */
 else  /* Line: 518 */ {
} /* Line: 518 */
} /* Line: 515 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 522 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 523 */ {
bevt_75_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 525 */
 else  /* Line: 526 */ {
} /* Line: 526 */
} /* Line: 523 */
bevt_76_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isLiteralOnceGet_0() {
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_BuildNode bevl_c0 = null;
BEC_5_4_BuildNode bevl_c1 = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_4_BuildNode bevl_call = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 547 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 547 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_55));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 548 */ {
bevl_c0 = (BEC_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 551 */
 else  /* Line: 551 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 551 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 552 */
 else  /* Line: 552 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 552 */ {
bevl_result = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 554 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 554 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_call = (BEC_5_4_BuildNode) bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 556 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_not_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 557 */ {
bevt_24_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 558 */
} /* Line: 557 */
} /* Line: 556 */
 else  /* Line: 554 */ {
break;
} /* Line: 554 */
} /* Line: 554 */
} /* Line: 554 */
} /* Line: 552 */
} /* Line: 551 */
return bevl_result;
} /*method end*/
public virtual BEC_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_contained = (BEC_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldBySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_condvarGet_0() {
return bevp_condvar;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_condvarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDetailSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delayDeleteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_delayDelete = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlec = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_wideStringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_wideString = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typenameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typename = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 33, 34, 35, 37, 38, 39, 40, 45, 46, 47, 48, 52, 0, 53, 55, 56, 57, 0, 58, 59, 61, 65, 66, 67, 0, 68, 69, 71, 75, 76, 78, 79, 80, 82, 86, 87, 89, 90, 91, 93, 97, 101, 105, 109, 110, 112, 116, 0, 116, 0, 117, 119, 123, 0, 123, 0, 123, 0, 124, 126, 130, 134, 135, 137, 138, 139, 143, 144, 146, 147, 151, 152, 154, 155, 159, 160, 162, 163, 167, 171, 172, 179, 181, 182, 184, 188, 189, 190, 191, 0, 192, 194, 195, 196, 198, 202, 203, 204, 205, 207, 208, 210, 211, 213, 217, 218, 219, 220, 221, 223, 227, 228, 229, 230, 231, 230, 233, 237, 238, 0, 239, 241, 245, 246, 247, 249, 250, 251, 252, 253, 254, 255, 259, 260, 261, 262, 264, 266, 270, 271, 272, 273, 274, 275, 277, 0, 278, 279, 281, 282, 283, 285, 286, 291, 292, 293, 294, 295, 296, 297, 299, 300, 301, 303, 304, 305, 306, 315, 316, 317, 318, 320, 321, 322, 324, 325, 326, 327, 330, 331, 332, 333, 334, 335, 336, 337, 339, 340, 341, 342, 343, 351, 352, 354, 355, 357, 358, 359, 367, 368, 0, 369, 371, 375, 376, 0, 376, 0, 376, 0, 377, 379, 383, 384, 386, 387, 391, 392, 396, 397, 398, 399, 405, 406, 407, 408, 411, 412, 413, 414, 416, 417, 418, 420, 422, 423, 424, 425, 435, 0, 436, 439, 440, 441, 442, 443, 444, 451, 454, 455, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 485, 486, 487, 488, 493, 494, 498, 500, 504, 506, 514, 515, 517, 522, 523, 525, 531, 542, 547, 548, 549, 550, 551, 0, 552, 0, 553, 554, 0, 554, 555, 556, 557, 558, 569, 0};
public static new int[] bevs_smnlec
 = new int[] {92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 93, 93, 93, 93, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92, 92};
/* BEGIN LINEINFO 
assign 1 32 92
new 0 32 92
assign 1 33 92
new 0 33 92
assign 1 34 92
new 0 34 92
assign 1 35 92
new 0 35 92
assign 1 37 92
assign 1 38 92
constantsGet 0 38 92
assign 1 39 92
ntypesGet 0 39 92
assign 1 40 92
TOKENGet 0 40 92
assign 1 45 92
nlcGet 0 45 92
assign 1 45 92
copy 0 45 92
assign 1 46 92
nlecGet 0 46 92
assign 1 46 92
copy 0 46 92
assign 1 47 92
inClassNpGet 0 47 92
assign 1 48 92
inFileGet 0 48 92
assign 1 52 92
def 1 52 92
assign 1 52 92
firstGet 0 52 92
assign 1 52 92
def 1 52 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 53 92
firstGet 0 53 92
return 1 53 92
assign 1 55 92
nextPeerGet 0 55 92
assign 1 56 92
assign 1 57 92
undef 1 57 92
assign 1 57 92
def 1 57 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 58 92
nextPeerGet 0 58 92
assign 1 59 92
containerGet 0 59 92
return 1 61 92
assign 1 65 92
nextPeerGet 0 65 92
assign 1 66 92
assign 1 67 92
undef 1 67 92
assign 1 67 92
def 1 67 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 68 92
nextPeerGet 0 68 92
assign 1 69 92
containerGet 0 69 92
return 1 71 92
assign 1 75 92
undef 1 75 92
return 1 76 92
assign 1 78 92
nextGet 0 78 92
assign 1 79 92
undef 1 79 92
return 1 80 92
assign 1 82 92
heldGet 0 82 92
return 1 82 92
assign 1 86 92
undef 1 86 92
return 1 87 92
assign 1 89 92
priorGet 0 89 92
assign 1 90 92
undef 1 90 92
return 1 91 92
assign 1 93 92
heldGet 0 93 92
return 1 93 92
assign 1 97 92
firstGet 0 97 92
return 1 97 92
assign 1 101 92
secondGet 0 101 92
return 1 101 92
assign 1 105 92
thirdGet 0 105 92
return 1 105 92
assign 1 109 92
undef 1 109 92
assign 1 110 92
new 0 110 92
return 1 110 92
assign 1 112 92
priorGet 0 112 92
assign 1 112 92
undef 1 112 92
return 1 112 92
assign 1 116 92
undef 1 116 92
assign 1 0 92
assign 1 116 92
priorGet 0 116 92
assign 1 116 92
undef 1 116 92
assign 1 0 92
assign 1 0 92
assign 1 117 92
new 0 117 92
return 1 117 92
assign 1 119 92
priorGet 0 119 92
assign 1 119 92
priorGet 0 119 92
assign 1 119 92
undef 1 119 92
return 1 119 92
assign 1 123 92
undef 1 123 92
assign 1 0 92
assign 1 123 92
priorGet 0 123 92
assign 1 123 92
undef 1 123 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 123 92
priorGet 0 123 92
assign 1 123 92
priorGet 0 123 92
assign 1 123 92
undef 1 123 92
assign 1 0 92
assign 1 0 92
assign 1 124 92
new 0 124 92
return 1 124 92
assign 1 126 92
priorGet 0 126 92
assign 1 126 92
priorGet 0 126 92
assign 1 126 92
priorGet 0 126 92
assign 1 126 92
undef 1 126 92
return 1 126 92
assign 1 130 92
new 0 130 92
assign 1 134 92
undef 1 134 92
return 1 135 92
delete 0 137 92
assign 1 138 92
assign 1 139 92
assign 1 143 92
undef 1 143 92
return 1 144 92
assign 1 146 92
mylistGet 0 146 92
assign 1 146 92
newNode 1 146 92
insertBefore 1 146 92
containerSet 1 147 92
assign 1 151 92
undef 1 151 92
initContained 0 152 92
prepend 1 154 92
containerSet 1 155 92
assign 1 159 92
undef 1 159 92
initContained 0 160 92
addValue 1 162 92
containerSet 1 163 92
assign 1 167 92
new 0 167 92
assign 1 171 92
undef 1 171 92
assign 1 172 92
new 0 172 92
assign 1 179 93
toStringCompact 0 179 93
print 0 181 93
throw 1 182 93
return 1 184 93
assign 1 188 92
prefixGet 0 188 92
assign 1 189 92
new 0 189 92
assign 1 189 92
add 1 189 92
assign 1 189 92
toString 0 189 92
assign 1 189 92
add 1 189 92
assign 1 189 92
new 0 189 92
assign 1 189 92
add 1 189 92
assign 1 190 92
new 0 190 92
assign 1 190 92
newlineGet 0 190 92
assign 1 190 92
add 1 190 92
assign 1 190 92
add 1 190 92
assign 1 190 92
new 0 190 92
assign 1 190 92
add 1 190 92
assign 1 190 92
toString 0 190 92
assign 1 190 92
add 1 190 92
assign 1 191 92
def 1 191 92
assign 1 191 92
def 1 191 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 192 92
new 0 192 92
assign 1 192 92
newlineGet 0 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
new 0 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
toString 0 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
new 0 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
add 1 192 92
assign 1 192 92
new 0 192 92
assign 1 192 92
newlineGet 0 192 92
assign 1 192 92
add 1 192 92
assign 1 194 92
def 1 194 92
assign 1 195 92
new 0 195 92
assign 1 195 92
newlineGet 0 195 92
assign 1 195 92
add 1 195 92
assign 1 195 92
add 1 195 92
assign 1 195 92
new 0 195 92
assign 1 195 92
add 1 195 92
assign 1 196 92
toString 0 196 92
assign 1 196 92
add 1 196 92
return 1 198 92
assign 1 202 92
prefixGet 0 202 92
assign 1 203 92
new 0 203 92
assign 1 203 92
add 1 203 92
assign 1 203 92
toString 0 203 92
assign 1 203 92
add 1 203 92
assign 1 203 92
new 0 203 92
assign 1 203 92
add 1 203 92
assign 1 204 92
def 1 204 92
assign 1 205 92
new 0 205 92
assign 1 205 92
add 1 205 92
assign 1 205 92
toString 0 205 92
assign 1 205 92
add 1 205 92
assign 1 207 92
def 1 207 92
assign 1 208 92
new 0 208 92
assign 1 208 92
add 1 208 92
assign 1 208 92
toString 0 208 92
assign 1 208 92
add 1 208 92
assign 1 210 92
def 1 210 92
assign 1 211 92
new 0 211 92
assign 1 211 92
add 1 211 92
assign 1 211 92
toString 0 211 92
assign 1 211 92
add 1 211 92
return 1 213 92
assign 1 217 92
new 0 217 92
assign 1 218 92
assign 1 219 92
def 1 219 92
assign 1 220 92
increment 0 220 92
assign 1 221 92
containerGet 0 221 92
return 1 223 92
assign 1 227 92
depthGet 0 227 92
assign 1 228 92
new 0 228 92
assign 1 229 92
new 0 229 92
assign 1 230 92
new 0 230 92
assign 1 230 92
lesser 1 230 92
assign 1 231 92
add 1 231 92
assign 1 230 92
increment 0 230 92
return 1 233 92
assign 1 237 92
assign 1 238 92
def 1 238 92
assign 1 238 92
typenameGet 0 238 92
assign 1 238 92
TRANSUNITGet 0 238 92
assign 1 238 92
notEquals 1 238 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 239 92
containerGet 0 239 92
return 1 241 92
assign 1 245 92
scopeGet 0 245 92
assign 1 246 92
typenameGet 0 246 92
assign 1 246 92
METHODGet 0 246 92
assign 1 246 92
notEquals 1 246 92
assign 1 247 92
new 0 247 92
assign 1 247 92
new 2 247 92
throw 1 247 92
assign 1 249 92
heldGet 0 249 92
assign 1 249 92
tmpCntGet 0 249 92
assign 1 249 92
toString 0 249 92
assign 1 250 92
heldGet 0 250 92
assign 1 250 92
heldGet 0 250 92
assign 1 250 92
tmpCntGet 0 250 92
assign 1 250 92
increment 0 250 92
tmpCntSet 1 250 92
assign 1 251 92
new 0 251 92
assign 1 252 92
new 0 252 92
isTmpVarSet 1 252 92
suffixSet 1 253 92
assign 1 254 92
new 0 254 92
assign 1 254 92
add 1 254 92
assign 1 254 92
add 1 254 92
nameSet 1 254 92
return 1 255 92
assign 1 259 92
assign 1 260 92
def 1 260 92
assign 1 261 92
typenameGet 0 261 92
assign 1 261 92
PROPERTIESGet 0 261 92
assign 1 261 92
equals 1 261 92
assign 1 262 92
new 0 262 92
return 1 262 92
assign 1 264 92
containerGet 0 264 92
assign 1 266 92
new 0 266 92
return 1 266 92
assign 1 270 92
assign 1 271 92
isAddedGet 0 271 92
assign 1 271 92
not 0 271 92
assign 1 272 92
new 0 272 92
isAddedSet 1 272 92
assign 1 273 92
scopeGet 0 273 92
assign 1 274 92
typenameGet 0 274 92
assign 1 274 92
CLASSGet 0 274 92
assign 1 274 92
equals 1 274 92
assign 1 275 92
new 0 275 92
assign 1 275 92
new 2 275 92
throw 1 275 92
assign 1 277 92
inPropertiesGet 0 277 92
assign 1 277 92
isTmpVarGet 0 277 92
assign 1 277 92
not 0 277 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 278 92
classGet 0 278 92
assign 1 279 92
new 0 279 92
isPropertySet 1 279 92
assign 1 281 92
heldGet 0 281 92
assign 1 282 92
varMapGet 0 282 92
assign 1 282 92
nameGet 0 282 92
assign 1 282 92
has 1 282 92
assign 1 283 92
new 0 283 92
assign 1 283 92
new 2 283 92
throw 1 283 92
assign 1 285 92
varMapGet 0 285 92
assign 1 285 92
nameGet 0 285 92
put 2 285 92
assign 1 286 92
orderedVarsGet 0 286 92
addValue 1 286 92
assign 1 291 92
assign 1 292 92
isAddedGet 0 292 92
assign 1 292 92
not 0 292 92
assign 1 293 92
new 0 293 92
isAddedSet 1 293 92
assign 1 294 92
scopeGet 0 294 92
assign 1 295 92
heldGet 0 295 92
assign 1 296 92
varMapGet 0 296 92
assign 1 296 92
nameGet 0 296 92
assign 1 296 92
has 1 296 92
assign 1 297 92
varMapGet 0 297 92
assign 1 297 92
nameGet 0 297 92
assign 1 297 92
get 1 297 92
assign 1 299 92
classGet 0 299 92
assign 1 299 92
heldGet 0 299 92
assign 1 300 92
varMapGet 0 300 92
assign 1 300 92
nameGet 0 300 92
assign 1 300 92
has 1 300 92
assign 1 301 92
varMapGet 0 301 92
assign 1 301 92
nameGet 0 301 92
assign 1 301 92
get 1 301 92
assign 1 303 92
varMapGet 0 303 92
assign 1 303 92
nameGet 0 303 92
put 2 303 92
assign 1 304 92
orderedVarsGet 0 304 92
addValue 1 304 92
assign 1 305 92
typenameGet 0 305 92
assign 1 305 92
CLASSGet 0 305 92
assign 1 305 92
equals 1 305 92
assign 1 306 92
new 0 306 92
assign 1 306 92
new 2 306 92
throw 1 306 92
assign 1 315 92
assign 1 316 92
scopeGet 0 316 92
assign 1 316 92
heldGet 0 316 92
assign 1 317 92
varMapGet 0 317 92
assign 1 317 92
has 1 317 92
assign 1 318 92
varMapGet 0 318 92
assign 1 318 92
get 1 318 92
assign 1 318 92
heldGet 0 318 92
assign 1 320 92
classGet 0 320 92
assign 1 320 92
heldGet 0 320 92
assign 1 321 92
varMapGet 0 321 92
assign 1 321 92
has 1 321 92
assign 1 322 92
varMapGet 0 322 92
assign 1 322 92
get 1 322 92
assign 1 322 92
heldGet 0 322 92
assign 1 324 92
transUnitGet 0 324 92
assign 1 325 92
heldGet 0 325 92
assign 1 325 92
aliasedGet 0 325 92
assign 1 325 92
get 1 325 92
assign 1 326 92
def 1 326 92
assign 1 327 92
new 0 327 92
assign 1 327 92
add 1 327 92
assign 1 327 92
new 2 327 92
throw 1 327 92
assign 1 330 92
new 0 330 92
nameSet 1 331 92
assign 1 332 92
new 0 332 92
assign 1 332 92
equals 1 332 92
assign 1 333 92
assign 1 334 92
new 0 334 92
isTypedSet 1 334 92
assign 1 335 92
extendsGet 0 335 92
namepathSet 1 335 92
assign 1 336 92
varMapGet 0 336 92
put 2 336 92
assign 1 337 92
orderedVarsGet 0 337 92
addValue 1 337 92
assign 1 339 92
new 0 339 92
isDeclaredSet 1 339 92
assign 1 340 92
new 0 340 92
isPropertySet 1 340 92
assign 1 341 92
assign 1 342 92
varMapGet 0 342 92
put 2 342 92
assign 1 343 92
orderedVarsGet 0 343 92
addValue 1 343 92
assign 1 351 92
assign 1 352 92
new 0 352 92
assign 1 354 92
anchorTypesGet 0 354 92
assign 1 354 92
typenameGet 0 354 92
assign 1 354 92
has 1 354 92
return 1 355 92
assign 1 357 92
containerGet 0 357 92
assign 1 358 92
undef 1 358 92
assign 1 359 92
new 0 359 92
assign 1 359 92
new 2 359 92
throw 1 359 92
assign 1 367 92
assign 1 368 92
def 1 368 92
assign 1 368 92
typenameGet 0 368 92
assign 1 368 92
CLASSGet 0 368 92
assign 1 368 92
notEquals 1 368 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 369 92
containerGet 0 369 92
return 1 371 92
assign 1 375 92
assign 1 376 92
def 1 376 92
assign 1 376 92
typenameGet 0 376 92
assign 1 376 92
CLASSGet 0 376 92
assign 1 376 92
notEquals 1 376 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 376 92
typenameGet 0 376 92
assign 1 376 92
METHODGet 0 376 92
assign 1 376 92
notEquals 1 376 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 376 92
typenameGet 0 376 92
assign 1 376 92
TRANSUNITGet 0 376 92
assign 1 376 92
notEquals 1 376 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 377 92
containerGet 0 377 92
return 1 379 92
assign 1 383 92
undef 1 383 92
return 1 384 92
containerSet 1 386 92
heldSet 1 387 92
delete 0 391 92
addValue 1 392 92
assign 1 396 92
containedGet 0 396 92
assign 1 397 92
iteratorGet 0 397 92
assign 1 397 92
hasNextGet 0 397 92
assign 1 398 92
nextGet 0 398 92
containerSet 1 399 92
assign 1 405 92
NAMEPATHGet 0 405 92
assign 1 405 92
equals 1 405 92
assign 1 406 92
assign 1 407 92
def 1 407 92
resolve 1 408 92
assign 1 411 92
CLASSGet 0 411 92
assign 1 411 92
equals 1 411 92
assign 1 412 92
namepathGet 0 412 92
assign 1 413 92
def 1 413 92
resolve 1 414 92
assign 1 416 92
extendsGet 0 416 92
assign 1 417 92
def 1 417 92
resolve 1 418 92
assign 1 420 92
namepathGet 0 420 92
assign 1 420 92
toString 0 420 92
nameSet 1 420 92
assign 1 422 92
VARGet 0 422 92
assign 1 422 92
equals 1 422 92
assign 1 423 92
namepathGet 0 423 92
assign 1 424 92
def 1 424 92
resolve 1 425 92
assign 1 435 92
heldGet 0 435 92
assign 1 435 92
isConstructGet 0 435 92
assign 1 435 92
heldGet 0 435 92
assign 1 435 92
newNpGet 0 435 92
assign 1 435 92
toString 0 435 92
assign 1 435 92
new 0 435 92
assign 1 435 92
equals 1 435 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 436 92
new 0 436 92
return 1 436 92
assign 1 439 92
new 0 439 92
assign 1 440 92
new 0 440 92
assign 1 441 92
new 0 441 92
assign 1 442 92
new 0 442 92
assign 1 443 92
new 0 443 92
assign 1 444 92
sizeGet 0 444 92
assign 1 444 92
new 0 444 92
assign 1 444 92
equals 1 444 92
assign 1 451 92
new 0 451 92
put 1 451 92
assign 1 454 92
new 0 454 92
put 1 454 92
assign 1 455 92
new 0 455 92
put 1 455 92
assign 1 457 92
new 0 457 92
put 1 457 92
assign 1 458 92
new 0 458 92
put 1 458 92
assign 1 459 92
new 0 459 92
put 1 459 92
assign 1 460 92
new 0 460 92
put 1 460 92
assign 1 461 92
new 0 461 92
put 1 461 92
assign 1 462 92
new 0 462 92
put 1 462 92
assign 1 463 92
new 0 463 92
put 1 463 92
assign 1 464 92
new 0 464 92
put 1 464 92
assign 1 465 92
new 0 465 92
put 1 465 92
assign 1 466 92
new 0 466 92
put 1 466 92
assign 1 467 92
new 0 467 92
put 1 467 92
assign 1 468 92
new 0 468 92
put 1 468 92
assign 1 469 92
new 0 469 92
put 1 469 92
assign 1 470 92
new 0 470 92
put 1 470 92
assign 1 471 92
new 0 471 92
put 1 471 92
assign 1 472 92
new 0 472 92
put 1 472 92
assign 1 473 92
new 0 473 92
put 1 473 92
assign 1 474 92
new 0 474 92
put 1 474 92
assign 1 475 92
new 0 475 92
put 1 475 92
assign 1 476 92
new 0 476 92
put 1 476 92
assign 1 477 92
new 0 477 92
put 1 477 92
assign 1 478 92
new 0 478 92
put 1 478 92
assign 1 479 92
new 0 479 92
put 1 479 92
assign 1 480 92
new 0 480 92
put 1 480 92
assign 1 481 92
new 0 481 92
put 1 481 92
assign 1 485 92
new 0 485 92
put 1 485 92
assign 1 486 92
new 0 486 92
put 1 486 92
assign 1 487 92
new 0 487 92
put 1 487 92
assign 1 488 92
new 0 488 92
put 1 488 92
assign 1 493 92
new 0 493 92
put 1 493 92
assign 1 494 92
new 0 494 92
put 1 494 92
assign 1 498 92
heldGet 0 498 92
assign 1 498 92
nameGet 0 498 92
assign 1 498 92
has 1 498 92
assign 1 500 92
new 0 500 92
return 1 500 92
assign 1 504 92
containedGet 0 504 92
assign 1 504 92
firstGet 0 504 92
assign 1 504 92
heldGet 0 504 92
assign 1 504 92
isTypedGet 0 504 92
assign 1 504 92
not 0 504 92
assign 1 506 92
new 0 506 92
return 1 506 92
assign 1 514 92
containedGet 0 514 92
assign 1 514 92
firstGet 0 514 92
assign 1 514 92
heldGet 0 514 92
assign 1 514 92
namepathGet 0 514 92
assign 1 514 92
toString 0 514 92
assign 1 514 92
has 1 514 92
assign 1 515 92
heldGet 0 515 92
assign 1 515 92
nameGet 0 515 92
assign 1 515 92
has 1 515 92
assign 1 517 92
new 0 517 92
return 1 517 92
assign 1 522 92
containedGet 0 522 92
assign 1 522 92
firstGet 0 522 92
assign 1 522 92
heldGet 0 522 92
assign 1 522 92
namepathGet 0 522 92
assign 1 522 92
toString 0 522 92
assign 1 522 92
has 1 522 92
assign 1 523 92
heldGet 0 523 92
assign 1 523 92
nameGet 0 523 92
assign 1 523 92
has 1 523 92
assign 1 525 92
new 0 525 92
return 1 525 92
assign 1 531 92
new 0 531 92
return 1 531 92
assign 1 542 92
new 0 542 92
assign 1 547 92
CALLGet 0 547 92
assign 1 547 92
notEquals 1 547 92
assign 1 547 92
new 0 547 92
return 1 547 92
assign 1 548 92
orgNameGet 0 548 92
assign 1 548 92
new 0 548 92
assign 1 548 92
equals 1 548 92
assign 1 549 92
firstGet 0 549 92
assign 1 550 92
secondGet 0 550 92
assign 1 551 92
def 1 551 92
assign 1 551 92
typenameGet 0 551 92
assign 1 551 92
CALLGet 0 551 92
assign 1 551 92
equals 1 551 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 552 92
heldGet 0 552 92
assign 1 552 92
isLiteralGet 0 552 92
assign 1 552 92
heldGet 0 552 92
assign 1 552 92
isPropertyGet 0 552 92
assign 1 552 92
not 0 552 92
assign 1 0 92
assign 1 0 92
assign 1 0 92
assign 1 553 92
new 0 553 92
assign 1 554 92
heldGet 0 554 92
assign 1 554 92
allCallsGet 0 554 92
assign 1 554 92
iteratorGet 0 0 92
assign 1 554 92
hasNextGet 0 554 92
assign 1 554 92
nextGet 0 554 92
assign 1 555 92
keyGet 0 555 92
assign 1 556 92
notEquals 1 556 92
assign 1 557 92
callIsSafe 1 557 92
assign 1 557 92
not 0 557 92
assign 1 558 92
new 0 558 92
return 1 558 92
return 1 569 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
return 1 0 92
assign 1 0 92
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case 1595262430: return bem_nlcGet_0();
case 786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1522157789: return bem_wideStringGet_0();
case 68392679: return bem_delayDeleteGet_0();
case 1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case 1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case 312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case 1014444004: return bem_typeDetailGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case 1692872440: return bem_toStringCompact_0();
case 1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case 576537281: return bem_delayDelete_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case 183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case 1471053772: return bem_initContained_0();
case 1866790687: return bem_isLiteralOnceGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 819712668: return bem_delete_0();
case 978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case 1566845998: return bem_anchorGet_0();
case 213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case 1779180144: return bem_nextDescendGet_0();
case 644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case 1012494862: return bem_once_0();
case 493012039: return bem_buildGet_0();
case 314718434: return bem_print_0();
case 124944494: return bem_nextPeerGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1279784069: return bem_defined_1(bevd_0);
case 57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 205397975: return bem_syncVariable_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_5_4_BuildNode) bevd_0);
case 1671186230: return bem_beforeInsert_1((BEC_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_5_4_BuildNode) bevd_0);
case 1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case 1668215656: return bem_deleteAndAppend_1((BEC_5_4_BuildNode) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case 167727545: return bem_callIsSafe_1((BEC_5_4_BuildNode) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1584180177: return bem_nlcSet_1(bevd_0);
case 1007846464: return bem_prepend_1((BEC_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_4_BuildNode.bevs_inst = (BEC_5_4_BuildNode)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_4_BuildNode.bevs_inst;
}
}
}
