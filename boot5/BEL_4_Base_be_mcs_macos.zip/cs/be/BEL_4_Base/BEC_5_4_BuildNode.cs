namespace be.BEL_4_Base {
/* File: source/build/Nodes.be */
public class BEC_5_4_BuildNode : BEC_6_6_SystemObject {
public BEC_5_4_BuildNode() { }
static BEC_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_9_3_ContainerSet bevo_4;
private static BEC_9_3_ContainerSet bevo_5;
private static BEC_9_3_ContainerSet bevo_6;
private static BEC_9_3_ContainerSet bevo_7;
private static BEC_9_3_ContainerSet bevo_8;
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_5_4_BuildNode bevs_inst;
public BEC_9_8_ContainerNodeList bevp_contained;
public BEC_5_4_BuildNode bevp_container;
public BEC_6_6_SystemObject bevp_held;
public BEC_6_6_SystemObject bevp_heldBy;
public BEC_6_6_SystemObject bevp_condvar;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_6_6_SystemObject bevp_typeDetail;
public BEC_5_4_LogicBool bevp_delayDelete;
public BEC_4_3_MathInt bevp_nlc;
public BEC_4_3_MathInt bevp_nlec;
public BEC_5_4_LogicBool bevp_wideString;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_3_MathInt bevp_typename;
public virtual BEC_5_4_BuildNode bem_new_1(BEC_5_5_BuildBuild beva__build) {
bevp_delayDelete = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nlc = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_nlec = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_wideString = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_copyLoc_1(BEC_5_4_BuildNode beva_fromNode) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextDescendGet_0() {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 53 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 57 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 57 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 59 */
 else  /* Line: 57 */ {
break;
} /* Line: 57 */
} /* Line: 57 */
return bevl_ret;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextAscendGet_0() {
BEC_5_4_BuildNode bevl_ret = null;
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 67 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 67 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 67 */
 else  /* Line: 67 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 67 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 69 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
return bevl_ret;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_nextPeerGet_0() {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 75 */ {
return null;
} /* Line: 76 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 79 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 80 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_priorPeerGet_0() {
BEC_6_6_SystemObject bevl_hh = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {
return null;
} /* Line: 87 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 90 */ {
return (BEC_5_4_BuildNode) bevl_hh;
} /* Line: 91 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_firstGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_secondGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_thirdGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isFirstGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 110 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isSecondGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 117 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isThirdGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 124 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delayDelete_0() {
bevp_delayDelete = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 134 */ {
return null;
} /* Line: 135 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_beforeInsert_1(BEC_5_4_BuildNode beva_x) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 143 */ {
return null;
} /* Line: 144 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepend_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 151 */ {
this.bem_initContained_0();
} /* Line: 152 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addValue_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 159 */ {
this.bem_initContained_0();
} /* Line: 160 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_reInitContained_0() {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_initContained_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_contained = (BEC_9_8_ContainerNodeList) (new BEC_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 172 */
return this;
} /*method end*/
public override BEC_4_6_TextString bem_toString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringCompact_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringBig_0() {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_6_6_SystemObject bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 184 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 184 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 184 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 184 */
 else  /* Line: 184 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 184 */ {
bevt_22_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 185 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_32_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 189 */
return (BEC_4_6_TextString) bevl_ret;
} /*method end*/
public virtual BEC_4_6_TextString bem_toStringCompact_0() {
BEC_6_6_SystemObject bevl_prefix = null;
BEC_4_6_TextString bevl_ret = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_7));
bevl_ret = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevl_ret.bem_add_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevt_10_tmpvar_phold = bevo_1;
bevt_9_tmpvar_phold = bevl_ret.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_9_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
} /* Line: 199 */
if (bevp_held == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_14_tmpvar_phold = bevo_2;
bevt_13_tmpvar_phold = bevl_ret.bem_add_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
} /* Line: 202 */
return bevl_ret;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_depthGet_0() {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 210 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 212 */
 else  /* Line: 210 */ {
break;
} /* Line: 210 */
} /* Line: 210 */
return bevl_d;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prefixGet_0() {
BEC_6_6_SystemObject bevl_d = null;
BEC_6_6_SystemObject bevl_p = null;
BEC_6_6_SystemObject bevl_q = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_4_6_TextString(2, bels_11));
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 221 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 221 */
 else  /* Line: 221 */ {
break;
} /* Line: 221 */
} /* Line: 221 */
return bevl_p;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_transUnitGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 229 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 229 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 229 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
 else  /* Line: 229 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 229 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 230 */
 else  /* Line: 229 */ {
break;
} /* Line: 229 */
} /* Line: 229 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_tmpVar_2(BEC_6_6_SystemObject beva_suffix, BEC_6_6_SystemObject beva_build) {
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tmpvarn = null;
BEC_6_6_SystemObject bevl_tmpvar = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 237 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_12));
bevt_3_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 238 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_13));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_inPropertiesGet_0() {
BEC_5_4_BuildNode bevl_con = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 251 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 253 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 255 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addVariable_0() {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 262 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(54, bels_14));
bevt_7_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 266 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 268 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 268 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
 else  /* Line: 268 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 268 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 270 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 273 */ {
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_15));
bevt_16_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 274 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 277 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_syncAddVariable_0() {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_sco = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 283 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 288 */
 else  /* Line: 289 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 292 */
 else  /* Line: 293 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 296 */ {
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_16));
bevt_20_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 297 */
} /* Line: 296 */
} /* Line: 291 */
} /* Line: 287 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_syncVariable_1(BEC_5_5_7_BuildVisitVisitor beva_visit) {
BEC_6_6_SystemObject bevl_vname = null;
BEC_6_6_SystemObject bevl_sc = null;
BEC_6_6_SystemObject bevl_cl = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 309 */
 else  /* Line: 310 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 312 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 317 */ {
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevl_np);
bevt_13_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_14_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_13_tmpvar_phold);
} /* Line: 318 */
 else  /* Line: 319 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_18));
bevt_16_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 323 */ {
bevp_held = bevl_v;
bevt_18_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_20_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_21_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_21_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 328 */
 else  /* Line: 329 */ {
bevt_22_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_23_tmpvar_phold);
bevp_held = bevl_v;
bevt_24_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_24_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_25_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_25_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 334 */
} /* Line: 323 */
} /* Line: 317 */
} /* Line: 312 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_anchorGet_0() {
BEC_6_6_SystemObject bevl_node = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 343 */ {
while (true)
 /* Line: 344 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
return bevl_node;
} /* Line: 346 */
 else  /* Line: 347 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_19));
bevt_5_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 350 */
} /* Line: 349 */
} /* Line: 345 */
} /* Line: 344 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 359 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 359 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 359 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 359 */
 else  /* Line: 359 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 359 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 360 */
 else  /* Line: 359 */ {
break;
} /* Line: 359 */
} /* Line: 359 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_scopeGet_0() {
BEC_6_6_SystemObject bevl_targ = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 367 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 367 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 367 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 367 */
 else  /* Line: 367 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 367 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 367 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 367 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 367 */
 else  /* Line: 367 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 367 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 367 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 367 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 367 */
 else  /* Line: 367 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 367 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 368 */
 else  /* Line: 367 */ {
break;
} /* Line: 367 */
} /* Line: 367 */
return bevl_targ;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_replaceWith_1(BEC_5_4_BuildNode beva_other) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 374 */ {
return null;
} /* Line: 375 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_deleteAndAppend_1(BEC_5_4_BuildNode beva_other) {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_takeContents_1(BEC_5_4_BuildNode beva_other) {
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 388 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 388 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 390 */
 else  /* Line: 388 */ {
break;
} /* Line: 388 */
} /* Line: 388 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_resolveNp_0() {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_0_tmpvar_phold = bevp_typename.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 396 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 398 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 399 */
} /* Line: 398 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 402 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 404 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 405 */
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 409 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 411 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_9_tmpvar_phold = bevp_typename.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevl_np = (BEC_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 416 */
} /* Line: 415 */
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_callIsSafe_1(BEC_5_4_BuildNode beva_call) {
BEC_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_9_3_ContainerSet bevl_okClasses = null;
BEC_9_3_ContainerSet bevl_okCalls = null;
BEC_9_3_ContainerSet bevl_okClasses2 = null;
BEC_9_3_ContainerSet bevl_okCalls2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 426 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_20));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 426 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 426 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 426 */
 else  /* Line: 426 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 426 */ {
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 427 */
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_4 == null) {
bevo_4 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_4;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_5 == null) {
bevo_5 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_5;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_6 == null) {
bevo_6 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_6;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_7 == null) {
bevo_7 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_7;
lock (typeof(BEC_5_4_BuildNode)) {
if (bevo_8 == null) {
bevo_8 = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_8;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_9;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 485 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 489 */ {
bevt_49_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 491 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 495 */ {
bevt_55_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 497 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 505 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 506 */ {
bevt_65_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 508 */
 else  /* Line: 509 */ {
} /* Line: 509 */
} /* Line: 506 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 513 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevt_75_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 516 */
 else  /* Line: 517 */ {
} /* Line: 517 */
} /* Line: 514 */
bevt_76_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isLiteralOnceGet_0() {
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_BuildNode bevl_c0 = null;
BEC_5_4_BuildNode bevl_c1 = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_4_BuildNode bevl_call = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_3_tmpvar_phold = bevp_typename.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 538 */ {
bevt_5_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 538 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_55));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 539 */ {
bevl_c0 = (BEC_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 542 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 542 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 542 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 542 */
 else  /* Line: 542 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 542 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 543 */ {
bevl_result = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 545 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 545 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_call = (BEC_5_4_BuildNode) bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 547 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_not_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_24_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 549 */
} /* Line: 548 */
} /* Line: 547 */
 else  /* Line: 545 */ {
break;
} /* Line: 545 */
} /* Line: 545 */
} /* Line: 545 */
} /* Line: 543 */
} /* Line: 542 */
return bevl_result;
} /*method end*/
public virtual BEC_9_8_ContainerNodeList bem_containedGet_0() {
return bevp_contained;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_contained = (BEC_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldGet_0() {
return bevp_held;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldByGet_0() {
return bevp_heldBy;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_heldBySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_condvarGet_0() {
return bevp_condvar;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_condvarSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDetailGet_0() {
return bevp_typeDetail;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDetailSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_delayDeleteGet_0() {
return bevp_delayDelete;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delayDeleteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_delayDelete = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nlcGet_0() {
return bevp_nlc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlc = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nlecGet_0() {
return bevp_nlec;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nlec = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_wideStringGet_0() {
return bevp_wideString;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_wideStringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_wideString = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_typenameGet_0() {
return bevp_typename;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typenameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_typename = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {32, 33, 34, 35, 37, 38, 39, 40, 45, 45, 46, 46, 47, 48, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 55, 56, 57, 57, 57, 57, 0, 0, 0, 58, 59, 61, 65, 66, 67, 67, 67, 67, 0, 0, 0, 68, 69, 71, 75, 75, 76, 78, 79, 79, 80, 82, 82, 86, 86, 87, 89, 90, 90, 91, 93, 93, 97, 97, 101, 101, 105, 105, 109, 109, 110, 110, 112, 112, 112, 116, 116, 0, 116, 116, 116, 0, 0, 117, 117, 119, 119, 119, 119, 123, 123, 0, 123, 123, 123, 0, 0, 0, 123, 123, 123, 123, 0, 0, 124, 124, 126, 126, 126, 126, 126, 130, 134, 134, 135, 137, 138, 139, 143, 143, 144, 146, 146, 146, 147, 151, 151, 152, 154, 155, 159, 159, 160, 162, 163, 167, 171, 171, 172, 177, 177, 181, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 185, 187, 187, 188, 188, 188, 188, 188, 188, 189, 189, 191, 195, 196, 196, 196, 196, 196, 196, 197, 197, 197, 197, 198, 198, 199, 199, 199, 199, 201, 201, 202, 202, 202, 202, 204, 208, 209, 210, 210, 211, 212, 214, 218, 219, 220, 221, 221, 222, 221, 224, 228, 229, 229, 229, 229, 229, 0, 0, 0, 230, 232, 236, 237, 237, 237, 238, 238, 238, 240, 240, 240, 241, 241, 241, 241, 241, 242, 243, 243, 244, 245, 245, 245, 245, 246, 250, 251, 251, 252, 252, 252, 253, 253, 255, 257, 257, 261, 262, 262, 263, 263, 264, 265, 265, 265, 266, 266, 266, 268, 268, 268, 0, 0, 0, 269, 270, 270, 272, 273, 273, 273, 274, 274, 274, 276, 276, 276, 277, 277, 282, 283, 283, 284, 284, 285, 286, 287, 287, 287, 288, 288, 288, 290, 290, 291, 291, 291, 292, 292, 292, 294, 294, 294, 295, 295, 296, 296, 296, 297, 297, 297, 306, 307, 307, 308, 308, 309, 309, 309, 311, 311, 312, 312, 313, 313, 313, 315, 316, 316, 316, 317, 317, 318, 318, 318, 318, 321, 322, 323, 323, 324, 325, 325, 326, 326, 327, 327, 328, 328, 330, 330, 331, 331, 332, 333, 333, 334, 334, 342, 343, 345, 345, 345, 346, 348, 349, 349, 350, 350, 350, 358, 359, 359, 359, 359, 359, 0, 0, 0, 360, 362, 366, 367, 367, 367, 367, 367, 0, 0, 0, 367, 367, 367, 0, 0, 0, 367, 367, 367, 0, 0, 0, 368, 370, 374, 374, 375, 377, 378, 382, 383, 387, 388, 388, 389, 390, 396, 396, 397, 398, 398, 399, 402, 402, 403, 404, 404, 405, 407, 408, 408, 409, 411, 411, 411, 413, 413, 414, 415, 415, 416, 426, 426, 426, 426, 426, 426, 426, 0, 0, 0, 427, 427, 430, 431, 432, 433, 434, 435, 435, 435, 442, 442, 445, 445, 446, 446, 448, 448, 449, 449, 450, 450, 451, 451, 452, 452, 453, 453, 454, 454, 455, 455, 456, 456, 457, 457, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 476, 476, 477, 477, 478, 478, 479, 479, 484, 484, 485, 485, 489, 489, 489, 491, 491, 495, 495, 495, 495, 495, 497, 497, 505, 505, 505, 505, 505, 505, 506, 506, 506, 508, 508, 513, 513, 513, 513, 513, 513, 514, 514, 514, 516, 516, 522, 522, 533, 538, 538, 538, 538, 539, 539, 539, 540, 541, 542, 542, 542, 542, 542, 0, 0, 0, 543, 543, 543, 543, 543, 0, 0, 0, 544, 545, 545, 545, 0, 545, 545, 546, 547, 548, 548, 549, 549, 560, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {92, 93, 94, 95, 96, 97, 98, 99, 105, 106, 107, 108, 109, 110, 124, 129, 130, 131, 136, 137, 140, 144, 147, 148, 150, 151, 154, 159, 160, 165, 166, 169, 173, 176, 177, 183, 191, 192, 195, 200, 201, 206, 207, 210, 214, 217, 218, 224, 231, 236, 237, 239, 240, 245, 246, 248, 249, 256, 261, 262, 264, 265, 270, 271, 273, 274, 278, 279, 283, 284, 288, 289, 296, 301, 302, 303, 305, 306, 311, 322, 327, 328, 331, 332, 337, 338, 341, 345, 346, 348, 349, 350, 355, 371, 376, 377, 380, 381, 386, 387, 390, 394, 397, 398, 399, 404, 405, 408, 412, 413, 415, 416, 417, 418, 423, 426, 431, 436, 437, 439, 440, 441, 448, 453, 454, 456, 457, 458, 459, 464, 469, 470, 472, 473, 478, 483, 484, 486, 487, 491, 496, 501, 502, 508, 509, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 569, 570, 575, 576, 579, 583, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 601, 606, 607, 608, 609, 610, 611, 612, 613, 614, 616, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 653, 654, 655, 656, 657, 659, 664, 665, 666, 667, 668, 670, 676, 677, 680, 685, 686, 687, 693, 701, 702, 703, 704, 707, 709, 710, 716, 725, 728, 733, 734, 735, 736, 738, 741, 745, 748, 754, 775, 776, 777, 778, 780, 781, 782, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 810, 813, 818, 819, 820, 821, 823, 824, 826, 832, 833, 860, 861, 862, 864, 865, 866, 867, 868, 869, 871, 872, 873, 875, 877, 878, 880, 883, 887, 890, 891, 892, 894, 895, 896, 897, 899, 900, 901, 903, 904, 905, 906, 907, 938, 939, 940, 942, 943, 944, 945, 946, 947, 948, 950, 951, 952, 955, 956, 957, 958, 959, 961, 962, 963, 966, 967, 968, 969, 970, 971, 972, 973, 975, 976, 977, 1017, 1018, 1019, 1020, 1021, 1023, 1024, 1025, 1028, 1029, 1030, 1031, 1033, 1034, 1035, 1038, 1039, 1040, 1041, 1042, 1047, 1048, 1049, 1050, 1051, 1054, 1055, 1056, 1057, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1094, 1095, 1099, 1100, 1101, 1103, 1106, 1107, 1112, 1113, 1114, 1115, 1129, 1132, 1137, 1138, 1139, 1140, 1142, 1145, 1149, 1152, 1158, 1175, 1178, 1183, 1184, 1185, 1186, 1188, 1191, 1195, 1198, 1199, 1200, 1202, 1205, 1209, 1212, 1213, 1214, 1216, 1219, 1223, 1226, 1232, 1236, 1241, 1242, 1244, 1245, 1249, 1250, 1257, 1258, 1261, 1263, 1264, 1286, 1287, 1289, 1290, 1295, 1296, 1299, 1300, 1302, 1303, 1308, 1309, 1311, 1312, 1317, 1318, 1320, 1321, 1322, 1324, 1325, 1327, 1328, 1333, 1334, 1422, 1423, 1425, 1426, 1427, 1428, 1429, 1431, 1434, 1438, 1441, 1442, 1444, 1450, 1456, 1462, 1468, 1474, 1475, 1476, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1547, 1548, 1549, 1551, 1552, 1554, 1555, 1556, 1557, 1558, 1560, 1561, 1563, 1564, 1565, 1566, 1567, 1568, 1570, 1571, 1572, 1574, 1575, 1580, 1581, 1582, 1583, 1584, 1585, 1587, 1588, 1589, 1591, 1592, 1597, 1598, 1631, 1632, 1633, 1635, 1636, 1638, 1639, 1640, 1642, 1643, 1644, 1649, 1650, 1651, 1652, 1654, 1657, 1661, 1664, 1665, 1667, 1668, 1669, 1671, 1674, 1678, 1681, 1682, 1683, 1684, 1684, 1687, 1689, 1690, 1691, 1693, 1694, 1696, 1697, 1708, 1711, 1714, 1718, 1721, 1725, 1728, 1732, 1735, 1739, 1742, 1746, 1749, 1753, 1756, 1760, 1763, 1767, 1770, 1774, 1777, 1781, 1784, 1788, 1791, 1795, 1798, 1802, 1805, 1809, 1812, 1816, 1819};
/* BEGIN LINEINFO 
assign 1 32 92
new 0 32 92
assign 1 33 93
new 0 33 93
assign 1 34 94
new 0 34 94
assign 1 35 95
new 0 35 95
assign 1 37 96
assign 1 38 97
constantsGet 0 38 97
assign 1 39 98
ntypesGet 0 39 98
assign 1 40 99
TOKENGet 0 40 99
assign 1 45 105
nlcGet 0 45 105
assign 1 45 106
copy 0 45 106
assign 1 46 107
nlecGet 0 46 107
assign 1 46 108
copy 0 46 108
assign 1 47 109
inClassNpGet 0 47 109
assign 1 48 110
inFileGet 0 48 110
assign 1 52 124
def 1 52 129
assign 1 52 130
firstGet 0 52 130
assign 1 52 131
def 1 52 136
assign 1 0 137
assign 1 0 140
assign 1 0 144
assign 1 53 147
firstGet 0 53 147
return 1 53 148
assign 1 55 150
nextPeerGet 0 55 150
assign 1 56 151
assign 1 57 154
undef 1 57 159
assign 1 57 160
def 1 57 165
assign 1 0 166
assign 1 0 169
assign 1 0 173
assign 1 58 176
nextPeerGet 0 58 176
assign 1 59 177
containerGet 0 59 177
return 1 61 183
assign 1 65 191
nextPeerGet 0 65 191
assign 1 66 192
assign 1 67 195
undef 1 67 200
assign 1 67 201
def 1 67 206
assign 1 0 207
assign 1 0 210
assign 1 0 214
assign 1 68 217
nextPeerGet 0 68 217
assign 1 69 218
containerGet 0 69 218
return 1 71 224
assign 1 75 231
undef 1 75 236
return 1 76 237
assign 1 78 239
nextGet 0 78 239
assign 1 79 240
undef 1 79 245
return 1 80 246
assign 1 82 248
heldGet 0 82 248
return 1 82 249
assign 1 86 256
undef 1 86 261
return 1 87 262
assign 1 89 264
priorGet 0 89 264
assign 1 90 265
undef 1 90 270
return 1 91 271
assign 1 93 273
heldGet 0 93 273
return 1 93 274
assign 1 97 278
firstGet 0 97 278
return 1 97 279
assign 1 101 283
secondGet 0 101 283
return 1 101 284
assign 1 105 288
thirdGet 0 105 288
return 1 105 289
assign 1 109 296
undef 1 109 301
assign 1 110 302
new 0 110 302
return 1 110 303
assign 1 112 305
priorGet 0 112 305
assign 1 112 306
undef 1 112 311
return 1 112 311
assign 1 116 322
undef 1 116 327
assign 1 0 328
assign 1 116 331
priorGet 0 116 331
assign 1 116 332
undef 1 116 337
assign 1 0 338
assign 1 0 341
assign 1 117 345
new 0 117 345
return 1 117 346
assign 1 119 348
priorGet 0 119 348
assign 1 119 349
priorGet 0 119 349
assign 1 119 350
undef 1 119 355
return 1 119 355
assign 1 123 371
undef 1 123 376
assign 1 0 377
assign 1 123 380
priorGet 0 123 380
assign 1 123 381
undef 1 123 386
assign 1 0 387
assign 1 0 390
assign 1 0 394
assign 1 123 397
priorGet 0 123 397
assign 1 123 398
priorGet 0 123 398
assign 1 123 399
undef 1 123 404
assign 1 0 405
assign 1 0 408
assign 1 124 412
new 0 124 412
return 1 124 413
assign 1 126 415
priorGet 0 126 415
assign 1 126 416
priorGet 0 126 416
assign 1 126 417
priorGet 0 126 417
assign 1 126 418
undef 1 126 423
return 1 126 423
assign 1 130 426
new 0 130 426
assign 1 134 431
undef 1 134 436
return 1 135 437
delete 0 137 439
assign 1 138 440
assign 1 139 441
assign 1 143 448
undef 1 143 453
return 1 144 454
assign 1 146 456
mylistGet 0 146 456
assign 1 146 457
newNode 1 146 457
insertBefore 1 146 458
containerSet 1 147 459
assign 1 151 464
undef 1 151 469
initContained 0 152 470
prepend 1 154 472
containerSet 1 155 473
assign 1 159 478
undef 1 159 483
initContained 0 160 484
addValue 1 162 486
containerSet 1 163 487
assign 1 167 491
new 0 167 491
assign 1 171 496
undef 1 171 501
assign 1 172 502
new 0 172 502
assign 1 177 508
toStringCompact 0 177 508
return 1 177 509
assign 1 181 549
prefixGet 0 181 549
assign 1 182 550
new 0 182 550
assign 1 182 551
add 1 182 551
assign 1 182 552
toString 0 182 552
assign 1 182 553
add 1 182 553
assign 1 182 554
new 0 182 554
assign 1 182 555
add 1 182 555
assign 1 183 556
new 0 183 556
assign 1 183 557
newlineGet 0 183 557
assign 1 183 558
add 1 183 558
assign 1 183 559
add 1 183 559
assign 1 183 560
new 0 183 560
assign 1 183 561
add 1 183 561
assign 1 183 562
toString 0 183 562
assign 1 183 563
add 1 183 563
assign 1 184 564
def 1 184 569
assign 1 184 570
def 1 184 575
assign 1 0 576
assign 1 0 579
assign 1 0 583
assign 1 185 586
new 0 185 586
assign 1 185 587
newlineGet 0 185 587
assign 1 185 588
add 1 185 588
assign 1 185 589
add 1 185 589
assign 1 185 590
new 0 185 590
assign 1 185 591
add 1 185 591
assign 1 185 592
toString 0 185 592
assign 1 185 593
add 1 185 593
assign 1 185 594
new 0 185 594
assign 1 185 595
add 1 185 595
assign 1 185 596
add 1 185 596
assign 1 185 597
new 0 185 597
assign 1 185 598
newlineGet 0 185 598
assign 1 185 599
add 1 185 599
assign 1 187 601
def 1 187 606
assign 1 188 607
new 0 188 607
assign 1 188 608
newlineGet 0 188 608
assign 1 188 609
add 1 188 609
assign 1 188 610
add 1 188 610
assign 1 188 611
new 0 188 611
assign 1 188 612
add 1 188 612
assign 1 189 613
toString 0 189 613
assign 1 189 614
add 1 189 614
return 1 191 616
assign 1 195 637
prefixGet 0 195 637
assign 1 196 638
new 0 196 638
assign 1 196 639
add 1 196 639
assign 1 196 640
toString 0 196 640
assign 1 196 641
add 1 196 641
assign 1 196 642
new 0 196 642
assign 1 196 643
add 1 196 643
assign 1 197 644
new 0 197 644
assign 1 197 645
add 1 197 645
assign 1 197 646
toString 0 197 646
assign 1 197 647
add 1 197 647
assign 1 198 648
def 1 198 653
assign 1 199 654
new 0 199 654
assign 1 199 655
add 1 199 655
assign 1 199 656
toString 0 199 656
assign 1 199 657
add 1 199 657
assign 1 201 659
def 1 201 664
assign 1 202 665
new 0 202 665
assign 1 202 666
add 1 202 666
assign 1 202 667
toString 0 202 667
assign 1 202 668
add 1 202 668
return 1 204 670
assign 1 208 676
new 0 208 676
assign 1 209 677
assign 1 210 680
def 1 210 685
assign 1 211 686
increment 0 211 686
assign 1 212 687
containerGet 0 212 687
return 1 214 693
assign 1 218 701
depthGet 0 218 701
assign 1 219 702
new 0 219 702
assign 1 220 703
new 0 220 703
assign 1 221 704
new 0 221 704
assign 1 221 707
lesser 1 221 707
assign 1 222 709
add 1 222 709
assign 1 221 710
increment 0 221 710
return 1 224 716
assign 1 228 725
assign 1 229 728
def 1 229 733
assign 1 229 734
typenameGet 0 229 734
assign 1 229 735
TRANSUNITGet 0 229 735
assign 1 229 736
notEquals 1 229 736
assign 1 0 738
assign 1 0 741
assign 1 0 745
assign 1 230 748
containerGet 0 230 748
return 1 232 754
assign 1 236 775
scopeGet 0 236 775
assign 1 237 776
typenameGet 0 237 776
assign 1 237 777
METHODGet 0 237 777
assign 1 237 778
notEquals 1 237 778
assign 1 238 780
new 0 238 780
assign 1 238 781
new 2 238 781
throw 1 238 782
assign 1 240 784
heldGet 0 240 784
assign 1 240 785
tmpCntGet 0 240 785
assign 1 240 786
toString 0 240 786
assign 1 241 787
heldGet 0 241 787
assign 1 241 788
heldGet 0 241 788
assign 1 241 789
tmpCntGet 0 241 789
assign 1 241 790
increment 0 241 790
tmpCntSet 1 241 791
assign 1 242 792
new 0 242 792
assign 1 243 793
new 0 243 793
isTmpVarSet 1 243 794
suffixSet 1 244 795
assign 1 245 796
new 0 245 796
assign 1 245 797
add 1 245 797
assign 1 245 798
add 1 245 798
nameSet 1 245 799
return 1 246 800
assign 1 250 810
assign 1 251 813
def 1 251 818
assign 1 252 819
typenameGet 0 252 819
assign 1 252 820
PROPERTIESGet 0 252 820
assign 1 252 821
equals 1 252 821
assign 1 253 823
new 0 253 823
return 1 253 824
assign 1 255 826
containerGet 0 255 826
assign 1 257 832
new 0 257 832
return 1 257 833
assign 1 261 860
assign 1 262 861
isAddedGet 0 262 861
assign 1 262 862
not 0 262 862
assign 1 263 864
new 0 263 864
isAddedSet 1 263 865
assign 1 264 866
scopeGet 0 264 866
assign 1 265 867
typenameGet 0 265 867
assign 1 265 868
CLASSGet 0 265 868
assign 1 265 869
equals 1 265 869
assign 1 266 871
new 0 266 871
assign 1 266 872
new 2 266 872
throw 1 266 873
assign 1 268 875
inPropertiesGet 0 268 875
assign 1 268 877
isTmpVarGet 0 268 877
assign 1 268 878
not 0 268 878
assign 1 0 880
assign 1 0 883
assign 1 0 887
assign 1 269 890
classGet 0 269 890
assign 1 270 891
new 0 270 891
isPropertySet 1 270 892
assign 1 272 894
heldGet 0 272 894
assign 1 273 895
varMapGet 0 273 895
assign 1 273 896
nameGet 0 273 896
assign 1 273 897
has 1 273 897
assign 1 274 899
new 0 274 899
assign 1 274 900
new 2 274 900
throw 1 274 901
assign 1 276 903
varMapGet 0 276 903
assign 1 276 904
nameGet 0 276 904
put 2 276 905
assign 1 277 906
orderedVarsGet 0 277 906
addValue 1 277 907
assign 1 282 938
assign 1 283 939
isAddedGet 0 283 939
assign 1 283 940
not 0 283 940
assign 1 284 942
new 0 284 942
isAddedSet 1 284 943
assign 1 285 944
scopeGet 0 285 944
assign 1 286 945
heldGet 0 286 945
assign 1 287 946
varMapGet 0 287 946
assign 1 287 947
nameGet 0 287 947
assign 1 287 948
has 1 287 948
assign 1 288 950
varMapGet 0 288 950
assign 1 288 951
nameGet 0 288 951
assign 1 288 952
get 1 288 952
assign 1 290 955
classGet 0 290 955
assign 1 290 956
heldGet 0 290 956
assign 1 291 957
varMapGet 0 291 957
assign 1 291 958
nameGet 0 291 958
assign 1 291 959
has 1 291 959
assign 1 292 961
varMapGet 0 292 961
assign 1 292 962
nameGet 0 292 962
assign 1 292 963
get 1 292 963
assign 1 294 966
varMapGet 0 294 966
assign 1 294 967
nameGet 0 294 967
put 2 294 968
assign 1 295 969
orderedVarsGet 0 295 969
addValue 1 295 970
assign 1 296 971
typenameGet 0 296 971
assign 1 296 972
CLASSGet 0 296 972
assign 1 296 973
equals 1 296 973
assign 1 297 975
new 0 297 975
assign 1 297 976
new 2 297 976
throw 1 297 977
assign 1 306 1017
assign 1 307 1018
scopeGet 0 307 1018
assign 1 307 1019
heldGet 0 307 1019
assign 1 308 1020
varMapGet 0 308 1020
assign 1 308 1021
has 1 308 1021
assign 1 309 1023
varMapGet 0 309 1023
assign 1 309 1024
get 1 309 1024
assign 1 309 1025
heldGet 0 309 1025
assign 1 311 1028
classGet 0 311 1028
assign 1 311 1029
heldGet 0 311 1029
assign 1 312 1030
varMapGet 0 312 1030
assign 1 312 1031
has 1 312 1031
assign 1 313 1033
varMapGet 0 313 1033
assign 1 313 1034
get 1 313 1034
assign 1 313 1035
heldGet 0 313 1035
assign 1 315 1038
transUnitGet 0 315 1038
assign 1 316 1039
heldGet 0 316 1039
assign 1 316 1040
aliasedGet 0 316 1040
assign 1 316 1041
get 1 316 1041
assign 1 317 1042
def 1 317 1047
assign 1 318 1048
new 0 318 1048
assign 1 318 1049
add 1 318 1049
assign 1 318 1050
new 2 318 1050
throw 1 318 1051
assign 1 321 1054
new 0 321 1054
nameSet 1 322 1055
assign 1 323 1056
new 0 323 1056
assign 1 323 1057
equals 1 323 1057
assign 1 324 1059
assign 1 325 1060
new 0 325 1060
isTypedSet 1 325 1061
assign 1 326 1062
extendsGet 0 326 1062
namepathSet 1 326 1063
assign 1 327 1064
varMapGet 0 327 1064
put 2 327 1065
assign 1 328 1066
orderedVarsGet 0 328 1066
addValue 1 328 1067
assign 1 330 1070
new 0 330 1070
isDeclaredSet 1 330 1071
assign 1 331 1072
new 0 331 1072
isPropertySet 1 331 1073
assign 1 332 1074
assign 1 333 1075
varMapGet 0 333 1075
put 2 333 1076
assign 1 334 1077
orderedVarsGet 0 334 1077
addValue 1 334 1078
assign 1 342 1094
assign 1 343 1095
new 0 343 1095
assign 1 345 1099
anchorTypesGet 0 345 1099
assign 1 345 1100
typenameGet 0 345 1100
assign 1 345 1101
has 1 345 1101
return 1 346 1103
assign 1 348 1106
containerGet 0 348 1106
assign 1 349 1107
undef 1 349 1112
assign 1 350 1113
new 0 350 1113
assign 1 350 1114
new 2 350 1114
throw 1 350 1115
assign 1 358 1129
assign 1 359 1132
def 1 359 1137
assign 1 359 1138
typenameGet 0 359 1138
assign 1 359 1139
CLASSGet 0 359 1139
assign 1 359 1140
notEquals 1 359 1140
assign 1 0 1142
assign 1 0 1145
assign 1 0 1149
assign 1 360 1152
containerGet 0 360 1152
return 1 362 1158
assign 1 366 1175
assign 1 367 1178
def 1 367 1183
assign 1 367 1184
typenameGet 0 367 1184
assign 1 367 1185
CLASSGet 0 367 1185
assign 1 367 1186
notEquals 1 367 1186
assign 1 0 1188
assign 1 0 1191
assign 1 0 1195
assign 1 367 1198
typenameGet 0 367 1198
assign 1 367 1199
METHODGet 0 367 1199
assign 1 367 1200
notEquals 1 367 1200
assign 1 0 1202
assign 1 0 1205
assign 1 0 1209
assign 1 367 1212
typenameGet 0 367 1212
assign 1 367 1213
TRANSUNITGet 0 367 1213
assign 1 367 1214
notEquals 1 367 1214
assign 1 0 1216
assign 1 0 1219
assign 1 0 1223
assign 1 368 1226
containerGet 0 368 1226
return 1 370 1232
assign 1 374 1236
undef 1 374 1241
return 1 375 1242
containerSet 1 377 1244
heldSet 1 378 1245
delete 0 382 1249
addValue 1 383 1250
assign 1 387 1257
containedGet 0 387 1257
assign 1 388 1258
iteratorGet 0 388 1258
assign 1 388 1261
hasNextGet 0 388 1261
assign 1 389 1263
nextGet 0 389 1263
containerSet 1 390 1264
assign 1 396 1286
NAMEPATHGet 0 396 1286
assign 1 396 1287
equals 1 396 1287
assign 1 397 1289
assign 1 398 1290
def 1 398 1295
resolve 1 399 1296
assign 1 402 1299
CLASSGet 0 402 1299
assign 1 402 1300
equals 1 402 1300
assign 1 403 1302
namepathGet 0 403 1302
assign 1 404 1303
def 1 404 1308
resolve 1 405 1309
assign 1 407 1311
extendsGet 0 407 1311
assign 1 408 1312
def 1 408 1317
resolve 1 409 1318
assign 1 411 1320
namepathGet 0 411 1320
assign 1 411 1321
toString 0 411 1321
nameSet 1 411 1322
assign 1 413 1324
VARGet 0 413 1324
assign 1 413 1325
equals 1 413 1325
assign 1 414 1327
namepathGet 0 414 1327
assign 1 415 1328
def 1 415 1333
resolve 1 416 1334
assign 1 426 1422
heldGet 0 426 1422
assign 1 426 1423
isConstructGet 0 426 1423
assign 1 426 1425
heldGet 0 426 1425
assign 1 426 1426
newNpGet 0 426 1426
assign 1 426 1427
toString 0 426 1427
assign 1 426 1428
new 0 426 1428
assign 1 426 1429
equals 1 426 1429
assign 1 0 1431
assign 1 0 1434
assign 1 0 1438
assign 1 427 1441
new 0 427 1441
return 1 427 1442
assign 1 430 1444
new 0 430 1444
assign 1 431 1450
new 0 431 1450
assign 1 432 1456
new 0 432 1456
assign 1 433 1462
new 0 433 1462
assign 1 434 1468
new 0 434 1468
assign 1 435 1474
sizeGet 0 435 1474
assign 1 435 1475
new 0 435 1475
assign 1 435 1476
equals 1 435 1476
assign 1 442 1478
new 0 442 1478
put 1 442 1479
assign 1 445 1480
new 0 445 1480
put 1 445 1481
assign 1 446 1482
new 0 446 1482
put 1 446 1483
assign 1 448 1484
new 0 448 1484
put 1 448 1485
assign 1 449 1486
new 0 449 1486
put 1 449 1487
assign 1 450 1488
new 0 450 1488
put 1 450 1489
assign 1 451 1490
new 0 451 1490
put 1 451 1491
assign 1 452 1492
new 0 452 1492
put 1 452 1493
assign 1 453 1494
new 0 453 1494
put 1 453 1495
assign 1 454 1496
new 0 454 1496
put 1 454 1497
assign 1 455 1498
new 0 455 1498
put 1 455 1499
assign 1 456 1500
new 0 456 1500
put 1 456 1501
assign 1 457 1502
new 0 457 1502
put 1 457 1503
assign 1 458 1504
new 0 458 1504
put 1 458 1505
assign 1 459 1506
new 0 459 1506
put 1 459 1507
assign 1 460 1508
new 0 460 1508
put 1 460 1509
assign 1 461 1510
new 0 461 1510
put 1 461 1511
assign 1 462 1512
new 0 462 1512
put 1 462 1513
assign 1 463 1514
new 0 463 1514
put 1 463 1515
assign 1 464 1516
new 0 464 1516
put 1 464 1517
assign 1 465 1518
new 0 465 1518
put 1 465 1519
assign 1 466 1520
new 0 466 1520
put 1 466 1521
assign 1 467 1522
new 0 467 1522
put 1 467 1523
assign 1 468 1524
new 0 468 1524
put 1 468 1525
assign 1 469 1526
new 0 469 1526
put 1 469 1527
assign 1 470 1528
new 0 470 1528
put 1 470 1529
assign 1 471 1530
new 0 471 1530
put 1 471 1531
assign 1 472 1532
new 0 472 1532
put 1 472 1533
assign 1 476 1534
new 0 476 1534
put 1 476 1535
assign 1 477 1536
new 0 477 1536
put 1 477 1537
assign 1 478 1538
new 0 478 1538
put 1 478 1539
assign 1 479 1540
new 0 479 1540
put 1 479 1541
assign 1 484 1542
new 0 484 1542
put 1 484 1543
assign 1 485 1544
new 0 485 1544
put 1 485 1545
assign 1 489 1547
heldGet 0 489 1547
assign 1 489 1548
nameGet 0 489 1548
assign 1 489 1549
has 1 489 1549
assign 1 491 1551
new 0 491 1551
return 1 491 1552
assign 1 495 1554
containedGet 0 495 1554
assign 1 495 1555
firstGet 0 495 1555
assign 1 495 1556
heldGet 0 495 1556
assign 1 495 1557
isTypedGet 0 495 1557
assign 1 495 1558
not 0 495 1558
assign 1 497 1560
new 0 497 1560
return 1 497 1561
assign 1 505 1563
containedGet 0 505 1563
assign 1 505 1564
firstGet 0 505 1564
assign 1 505 1565
heldGet 0 505 1565
assign 1 505 1566
namepathGet 0 505 1566
assign 1 505 1567
toString 0 505 1567
assign 1 505 1568
has 1 505 1568
assign 1 506 1570
heldGet 0 506 1570
assign 1 506 1571
nameGet 0 506 1571
assign 1 506 1572
has 1 506 1572
assign 1 508 1574
new 0 508 1574
return 1 508 1575
assign 1 513 1580
containedGet 0 513 1580
assign 1 513 1581
firstGet 0 513 1581
assign 1 513 1582
heldGet 0 513 1582
assign 1 513 1583
namepathGet 0 513 1583
assign 1 513 1584
toString 0 513 1584
assign 1 513 1585
has 1 513 1585
assign 1 514 1587
heldGet 0 514 1587
assign 1 514 1588
nameGet 0 514 1588
assign 1 514 1589
has 1 514 1589
assign 1 516 1591
new 0 516 1591
return 1 516 1592
assign 1 522 1597
new 0 522 1597
return 1 522 1598
assign 1 533 1631
new 0 533 1631
assign 1 538 1632
CALLGet 0 538 1632
assign 1 538 1633
notEquals 1 538 1633
assign 1 538 1635
new 0 538 1635
return 1 538 1636
assign 1 539 1638
orgNameGet 0 539 1638
assign 1 539 1639
new 0 539 1639
assign 1 539 1640
equals 1 539 1640
assign 1 540 1642
firstGet 0 540 1642
assign 1 541 1643
secondGet 0 541 1643
assign 1 542 1644
def 1 542 1649
assign 1 542 1650
typenameGet 0 542 1650
assign 1 542 1651
CALLGet 0 542 1651
assign 1 542 1652
equals 1 542 1652
assign 1 0 1654
assign 1 0 1657
assign 1 0 1661
assign 1 543 1664
heldGet 0 543 1664
assign 1 543 1665
isLiteralGet 0 543 1665
assign 1 543 1667
heldGet 0 543 1667
assign 1 543 1668
isPropertyGet 0 543 1668
assign 1 543 1669
not 0 543 1669
assign 1 0 1671
assign 1 0 1674
assign 1 0 1678
assign 1 544 1681
new 0 544 1681
assign 1 545 1682
heldGet 0 545 1682
assign 1 545 1683
allCallsGet 0 545 1683
assign 1 545 1684
iteratorGet 0 0 1684
assign 1 545 1687
hasNextGet 0 545 1687
assign 1 545 1689
nextGet 0 545 1689
assign 1 546 1690
keyGet 0 546 1690
assign 1 547 1691
notEquals 1 547 1691
assign 1 548 1693
callIsSafe 1 548 1693
assign 1 548 1694
not 0 548 1694
assign 1 549 1696
new 0 549 1696
return 1 549 1697
return 1 560 1708
return 1 0 1711
assign 1 0 1714
return 1 0 1718
assign 1 0 1721
return 1 0 1725
assign 1 0 1728
return 1 0 1732
assign 1 0 1735
return 1 0 1739
assign 1 0 1742
return 1 0 1746
assign 1 0 1749
return 1 0 1753
assign 1 0 1756
return 1 0 1760
assign 1 0 1763
return 1 0 1767
assign 1 0 1770
return 1 0 1774
assign 1 0 1777
return 1 0 1781
assign 1 0 1784
return 1 0 1788
assign 1 0 1791
return 1 0 1795
assign 1 0 1798
return 1 0 1802
assign 1 0 1805
return 1 0 1809
assign 1 0 1812
return 1 0 1816
assign 1 0 1819
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case 1595262430: return bem_nlcGet_0();
case 786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1522157789: return bem_wideStringGet_0();
case 68392679: return bem_delayDeleteGet_0();
case 1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case 1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case 312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case 1014444004: return bem_typeDetailGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case 1692872440: return bem_toStringCompact_0();
case 1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case 576537281: return bem_delayDelete_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case 183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case 1471053772: return bem_initContained_0();
case 1866790687: return bem_isLiteralOnceGet_0();
case 819712668: return bem_delete_0();
case 978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case 1566845998: return bem_anchorGet_0();
case 213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case 1779180144: return bem_nextDescendGet_0();
case 644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case 1012494862: return bem_once_0();
case 493012039: return bem_buildGet_0();
case 314718434: return bem_print_0();
case 124944494: return bem_nextPeerGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1279784069: return bem_defined_1(bevd_0);
case 57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 205397975: return bem_syncVariable_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_5_4_BuildNode) bevd_0);
case 1671186230: return bem_beforeInsert_1((BEC_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_5_4_BuildNode) bevd_0);
case 1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case 1668215656: return bem_deleteAndAppend_1((BEC_5_4_BuildNode) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case 167727545: return bem_callIsSafe_1((BEC_5_4_BuildNode) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1584180177: return bem_nlcSet_1(bevd_0);
case 1007846464: return bem_prepend_1((BEC_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_4_BuildNode();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_4_BuildNode.bevs_inst = (BEC_5_4_BuildNode)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_4_BuildNode.bevs_inst;
}
}
}
