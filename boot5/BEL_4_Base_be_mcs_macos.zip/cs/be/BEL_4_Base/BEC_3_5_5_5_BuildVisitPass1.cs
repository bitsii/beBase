namespace be.BEL_4_Base {
/* IO:File: source/build/Pass1.be */
public sealed class BEC_3_5_5_5_BuildVisitPass1 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass1() { }
static BEC_3_5_5_5_BuildVisitPass1() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {};
private static byte[] bels_1 = {};
private static byte[] bels_2 = {0x2E};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x2E};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x2E};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 1));
public static new BEC_3_5_5_5_BuildVisitPass1 bevs_inst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_allAstElements;
public BEC_2_6_6_SystemObject bevp_f;
public BEC_2_4_6_TextString bevp_inClass;
public BEC_2_4_6_TextString bevp_inClassMethod;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass1 bem_new_2(BEC_2_9_3_ContainerSet beva__printAstElements, BEC_2_4_6_TextString beva__fname) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpvar_phold = null;
bevp_printAstElements = beva__printAstElements;
bevp_allAstElements = bevp_printAstElements.bem_isEmptyGet_0();
if (beva__fname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_3_tmpvar_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(beva__fname);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_writerGet_0();
bevp_f = bevt_1_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
} /* Line: 30 */
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_inLine = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_46_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_47_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_5_tmpvar_phold.bevi_int == bevt_6_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_0));
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_sameType_1(bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevp_inClass = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 41 */
 else  /* Line: 42 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_inClass = (BEC_2_4_6_TextString) bevt_10_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 43 */
bevp_inClassMethod = null;
bevl_inLine = null;
} /* Line: 46 */
bevt_13_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_13_tmpvar_phold.bevi_int == bevt_14_tmpvar_phold.bevi_int) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 48 */ {
if (bevp_inClass == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 48 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bels_1));
bevt_18_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_sameType_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 49 */ {
bevp_inClassMethod = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
} /* Line: 50 */
 else  /* Line: 49 */ {
bevt_21_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
if (bevt_20_tmpvar_phold == null) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_23_tmpvar_phold = bevo_0;
bevt_22_tmpvar_phold = bevp_inClass.bem_add_1(bevt_23_tmpvar_phold);
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevp_inClassMethod = bevt_22_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
} /* Line: 52 */
 else  /* Line: 49 */ {
bevt_28_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_30_tmpvar_phold = bevo_1;
bevt_29_tmpvar_phold = bevp_inClass.bem_add_1(bevt_30_tmpvar_phold);
bevt_32_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_inClassMethod = bevt_29_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
} /* Line: 54 */
} /* Line: 49 */
} /* Line: 49 */
} /* Line: 49 */
if (bevp_inClassMethod == null) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevt_35_tmpvar_phold = beva_node.bem_nlcGet_0();
if (bevt_35_tmpvar_phold == null) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 58 */ {
bevt_37_tmpvar_phold = bevo_2;
bevt_36_tmpvar_phold = bevp_inClassMethod.bem_add_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = beva_node.bem_nlcGet_0();
bevl_inLine = bevt_36_tmpvar_phold.bem_add_1(bevt_38_tmpvar_phold);
} /* Line: 59 */
if (bevp_allAstElements.bevi_bool) /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
if (bevp_inClassMethod == null) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_40_tmpvar_phold = bevp_printAstElements.bem_has_1(bevp_inClassMethod);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
if (bevl_inLine == null) {
bevt_41_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_42_tmpvar_phold = bevp_printAstElements.bem_has_1(bevl_inLine);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 61 */ {
if (bevp_f == null) {
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_44_tmpvar_phold = beva_node.bem_toString_0();
bevp_f.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_44_tmpvar_phold);
bevt_46_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_newlineGet_0();
bevp_f.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_45_tmpvar_phold);
} /* Line: 64 */
 else  /* Line: 65 */ {
beva_node.bem_print_0();
} /* Line: 66 */
} /* Line: 62 */
bevt_47_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_47_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAstElementsGet_0() {
return bevp_allAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_allAstElements = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fGet_0() {
return bevp_f;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_f = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClass = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inClassMethodGet_0() {
return bevp_inClassMethod;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassMethodSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inClassMethod = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {27, 28, 29, 29, 30, 30, 30, 30, 39, 39, 39, 39, 40, 40, 40, 41, 43, 43, 43, 45, 46, 48, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 49, 50, 51, 51, 51, 51, 52, 52, 52, 52, 52, 53, 53, 53, 53, 54, 54, 54, 54, 54, 58, 58, 58, 58, 58, 0, 0, 0, 59, 59, 59, 59, 0, 61, 61, 61, 0, 0, 0, 0, 0, 0, 61, 61, 61, 0, 0, 0, 0, 0, 62, 62, 63, 63, 64, 64, 64, 66, 69, 69, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {30, 31, 32, 37, 38, 39, 40, 41, 95, 96, 97, 102, 103, 104, 105, 107, 110, 111, 112, 114, 115, 117, 118, 119, 124, 125, 130, 131, 134, 138, 141, 142, 143, 145, 148, 149, 150, 155, 156, 157, 158, 159, 160, 163, 164, 165, 170, 171, 172, 173, 174, 175, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 206, 209, 212, 217, 218, 220, 223, 227, 230, 233, 237, 240, 245, 246, 248, 251, 255, 258, 261, 265, 270, 271, 272, 273, 274, 275, 278, 281, 282, 285, 288, 292, 295, 299, 302, 306, 309, 313, 316};
/* BEGIN LINEINFO 
assign 1 27 30
assign 1 28 31
isEmptyGet 0 28 31
assign 1 29 32
def 1 29 37
assign 1 30 38
new 1 30 38
assign 1 30 39
fileGet 0 30 39
assign 1 30 40
writerGet 0 30 40
assign 1 30 41
open 0 30 41
assign 1 39 95
typenameGet 0 39 95
assign 1 39 96
CLASSGet 0 39 96
assign 1 39 97
equals 1 39 102
assign 1 40 103
new 0 40 103
assign 1 40 104
heldGet 0 40 104
assign 1 40 105
sameType 1 40 105
assign 1 41 107
heldGet 0 41 107
assign 1 43 110
heldGet 0 43 110
assign 1 43 111
namepathGet 0 43 111
assign 1 43 112
toString 0 43 112
assign 1 45 114
assign 1 46 115
assign 1 48 117
typenameGet 0 48 117
assign 1 48 118
METHODGet 0 48 118
assign 1 48 119
equals 1 48 124
assign 1 48 125
def 1 48 130
assign 1 0 131
assign 1 0 134
assign 1 0 138
assign 1 49 141
new 0 49 141
assign 1 49 142
heldGet 0 49 142
assign 1 49 143
sameType 1 49 143
assign 1 50 145
heldGet 0 50 145
assign 1 51 148
heldGet 0 51 148
assign 1 51 149
orgNameGet 0 51 149
assign 1 51 150
def 1 51 155
assign 1 52 156
new 0 52 156
assign 1 52 157
add 1 52 157
assign 1 52 158
heldGet 0 52 158
assign 1 52 159
orgNameGet 0 52 159
assign 1 52 160
add 1 52 160
assign 1 53 163
heldGet 0 53 163
assign 1 53 164
nameGet 0 53 164
assign 1 53 165
def 1 53 170
assign 1 54 171
new 0 54 171
assign 1 54 172
add 1 54 172
assign 1 54 173
heldGet 0 54 173
assign 1 54 174
nameGet 0 54 174
assign 1 54 175
add 1 54 175
assign 1 58 180
def 1 58 185
assign 1 58 186
nlcGet 0 58 186
assign 1 58 187
def 1 58 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
assign 1 59 203
new 0 59 203
assign 1 59 204
add 1 59 204
assign 1 59 205
nlcGet 0 59 205
assign 1 59 206
add 1 59 206
assign 1 0 209
assign 1 61 212
def 1 61 217
assign 1 61 218
has 1 61 218
assign 1 0 220
assign 1 0 223
assign 1 0 227
assign 1 0 230
assign 1 0 233
assign 1 0 237
assign 1 61 240
def 1 61 245
assign 1 61 246
has 1 61 246
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 0 258
assign 1 0 261
assign 1 62 265
def 1 62 270
assign 1 63 271
toString 0 63 271
write 1 63 272
assign 1 64 273
new 0 64 273
assign 1 64 274
newlineGet 0 64 274
write 1 64 275
print 0 66 278
assign 1 69 281
nextDescendGet 0 69 281
return 1 69 282
return 1 0 285
assign 1 0 288
return 1 0 292
assign 1 0 295
return 1 0 299
assign 1 0 302
return 1 0 306
assign 1 0 309
return 1 0 313
assign 1 0 316
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 1810625581: return bem_inClassMethodGet_0();
case 185148207: return bem_allAstElementsGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 801883195: return bem_printAstElementsGet_0();
case 229958684: return bem_constGet_0();
case 1306100543: return bem_fGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 196230460: return bem_allAstElementsSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1799543328: return bem_inClassMethodSet_1(bevd_0);
case 1295018290: return bem_fSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_9_3_ContainerSet) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass1();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass1.bevs_inst = (BEC_3_5_5_5_BuildVisitPass1)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass1.bevs_inst;
}
}
}
