namespace be.BEL_4_Base {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
static BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
public static new BEC_2_6_8_SystemBasePath bevs_inst;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fromString_1(BEC_2_4_6_TextString beva_spath) {
bevp_path = beva_spath;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_firstStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lastStepGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevt_4_tmpvar_phold = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 385 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 387 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 388 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 392 */ {
bevt_8_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 392 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 394 */
 else  /* Line: 392 */ {
break;
} /* Line: 392 */
} /* Line: 392 */
bevt_9_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_2_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_2_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 410 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 410 */ {
bevt_2_tmpvar_phold = bevl_c.bem_lesser_1(bevl_rpl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 412 */
 else  /* Line: 413 */ {
bevl_i.bem_nextGet_0();
} /* Line: 414 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 416 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 419 */
return bevl_rpath;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 425 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 425 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 425 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 425 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 425 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_10_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 427 */
bevt_11_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 433 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 434 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 439 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 440 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_howMany.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 445 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 450 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_howMany);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 450 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 451 */ {
break;
} /* Line: 451 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 450 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 456 */
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 468 */ {
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 469 */
 else  /* Line: 470 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 471 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 477 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 477 */ {
bevt_1_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 478 */
 else  /* Line: 477 */ {
break;
} /* Line: 477 */
} /* Line: 477 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) {
BEC_2_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_8_SystemBasePath) this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 517 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 517 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 517 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 517 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 517 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 517 */ {
bevt_6_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 518 */
bevt_7_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 529 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 530 */
 else  /* Line: 531 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 532 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_2_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_pathGet_0() {
return bevp_path;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {345, 349, 350, 354, 358, 362, 366, 367, 368, 372, 376, 380, 384, 385, 387, 388, 390, 391, 392, 393, 394, 396, 397, 398, 400, 404, 405, 406, 407, 408, 409, 410, 411, 412, 414, 416, 418, 419, 421, 425, 0, 425, 0, 425, 426, 427, 429, 433, 434, 439, 440, 445, 446, 447, 449, 450, 451, 452, 453, 454, 450, 456, 461, 462, 463, 467, 468, 469, 471, 476, 477, 478, 480, 484, 488, 489, 490, 491, 495, 496, 497, 498, 502, 506, 510, 517, 0, 517, 0, 517, 0, 518, 520, 524, 528, 529, 530, 532, 534, 535, 536, 537, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24};
/* BEGIN LINEINFO 
assign 1 345 24
new 0 345 24
new 1 345 24
assign 1 349 24
new 0 349 24
fromString 1 350 24
assign 1 354 24
return 1 358 24
assign 1 362 24
toStringWithSeparator 1 362 24
return 1 362 24
assign 1 366 24
split 1 366 24
assign 1 367 24
new 0 367 24
assign 1 367 24
join 2 367 24
return 1 368 24
assign 1 372 24
split 1 372 24
return 1 372 24
assign 1 376 24
split 1 376 24
assign 1 376 24
firstGet 0 376 24
return 1 376 24
assign 1 380 24
split 1 380 24
assign 1 380 24
lastGet 0 380 24
return 1 380 24
assign 1 384 24
pathGet 0 384 24
assign 1 384 24
new 0 384 24
assign 1 384 24
emptyGet 0 384 24
assign 1 384 24
equals 1 384 24
assign 1 385 24
copy 0 385 24
return 1 385 24
assign 1 387 24
isAbsoluteGet 0 387 24
assign 1 388 24
copy 0 388 24
return 1 388 24
assign 1 390 24
split 1 390 24
assign 1 391 24
pathGet 0 391 24
assign 1 391 24
split 1 391 24
assign 1 392 24
linkedListIteratorGet 0 392 24
assign 1 392 24
hasNextGet 0 392 24
assign 1 393 24
nextGet 0 393 24
addValue 1 394 24
assign 1 396 24
new 0 396 24
assign 1 396 24
join 2 396 24
assign 1 397 24
copy 0 397 24
assign 1 398 24
fromString 1 398 24
return 1 400 24
assign 1 404 24
split 1 404 24
assign 1 405 24
copy 0 405 24
assign 1 406 24
new 0 406 24
pathSet 1 406 24
assign 1 407 24
lengthGet 0 407 24
assign 1 408 24
decrement 0 408 24
assign 1 409 24
new 0 409 24
assign 1 410 24
linkedListIteratorGet 0 410 24
assign 1 410 24
hasNextGet 0 410 24
assign 1 411 24
lesser 1 411 24
assign 1 412 24
nextGet 0 412 24
addStep 1 412 24
nextGet 0 414 24
assign 1 416 24
increment 0 416 24
assign 1 418 24
isAbsoluteGet 0 418 24
makeAbsolute 0 419 24
return 1 421 24
assign 1 425 24
undef 1 425 24
assign 1 0 24
assign 1 425 24
toString 0 425 24
assign 1 425 24
sizeGet 0 425 24
assign 1 425 24
new 0 425 24
assign 1 425 24
lesser 1 425 24
assign 1 0 24
assign 1 0 24
assign 1 425 24
new 0 425 24
return 1 425 24
assign 1 426 24
new 0 426 24
assign 1 426 24
getPoint 1 426 24
assign 1 426 24
equals 1 426 24
assign 1 427 24
new 0 427 24
return 1 427 24
assign 1 429 24
new 0 429 24
return 1 429 24
assign 1 433 24
isAbsoluteGet 0 433 24
assign 1 434 24
new 0 434 24
assign 1 434 24
sizeGet 0 434 24
assign 1 434 24
substring 2 434 24
assign 1 439 24
isAbsoluteGet 0 439 24
assign 1 439 24
not 0 439 24
assign 1 440 24
add 1 440 24
assign 1 445 24
new 0 445 24
assign 1 445 24
greater 1 445 24
makeNonAbsolute 0 446 24
assign 1 447 24
split 1 447 24
assign 1 449 24
firstNodeGet 0 449 24
assign 1 450 24
new 0 450 24
assign 1 450 24
lesser 1 450 24
assign 1 451 24
undef 1 451 24
assign 1 452 24
assign 1 453 24
nextGet 0 453 24
delete 0 454 24
assign 1 450 24
increment 0 450 24
assign 1 456 24
join 2 456 24
assign 1 461 24
split 1 461 24
addValue 1 462 24
assign 1 463 24
join 2 463 24
assign 1 467 24
find 1 467 24
assign 1 468 24
undef 1 468 24
assign 1 469 24
new 0 469 24
assign 1 469 24
emptyGet 0 469 24
assign 1 471 24
new 0 471 24
assign 1 471 24
add 1 471 24
assign 1 471 24
sizeGet 0 471 24
assign 1 471 24
substring 2 471 24
assign 1 476 24
split 1 476 24
assign 1 477 24
linkedListIteratorGet 0 477 24
assign 1 477 24
hasNextGet 0 477 24
assign 1 478 24
nextGet 0 478 24
addValue 1 478 24
assign 1 480 24
join 2 480 24
assign 1 484 24
addStep 1 484 24
return 1 484 24
assign 1 488 24
split 1 488 24
addValue 1 489 24
addValue 1 490 24
assign 1 491 24
join 2 491 24
assign 1 495 24
create 0 495 24
copyTo 1 496 24
assign 1 497 24
copy 0 497 24
pathSet 1 497 24
return 1 498 24
assign 1 502 24
split 1 502 24
return 1 502 24
assign 1 506 24
hashGet 0 506 24
return 1 506 24
assign 1 510 24
equals 1 510 24
assign 1 510 24
not 0 510 24
return 1 510 24
assign 1 517 24
undef 1 517 24
assign 1 0 24
assign 1 517 24
otherType 1 517 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 517 24
pathGet 0 517 24
assign 1 517 24
notEquals 1 517 24
assign 1 0 24
assign 1 0 24
assign 1 518 24
new 0 518 24
return 1 518 24
assign 1 520 24
new 0 520 24
return 1 520 24
assign 1 524 24
subPath 2 524 24
return 1 524 24
assign 1 528 24
stepsGet 0 528 24
assign 1 529 24
undef 1 529 24
assign 1 530 24
subList 1 530 24
assign 1 532 24
subList 2 532 24
assign 1 534 24
create 0 534 24
separatorSet 1 535 24
assign 1 536 24
new 0 536 24
assign 1 536 24
join 2 536 24
pathSet 1 536 24
return 1 537 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemBasePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemBasePath.bevs_inst = (BEC_2_6_8_SystemBasePath)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemBasePath.bevs_inst;
}
}
}
