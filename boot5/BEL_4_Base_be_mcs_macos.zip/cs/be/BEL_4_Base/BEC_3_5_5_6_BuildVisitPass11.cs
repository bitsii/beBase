namespace be.BEL_4_Base {
/* IO:File: source/build/Pass11.be */
public sealed class BEC_3_5_5_6_BuildVisitPass11 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
static BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 46));
private static byte[] bels_4 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bels_7 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_8 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bels_9 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitPass11 bevs_inst;
public BEC_2_5_4_BuildNode bevp_inMtd;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_87_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_5_tmpvar_phold.bevi_int == bevt_6_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevl_fnode = null;
bevt_11_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_firstGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_8_tmpvar_phold == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 28 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 29 */
bevt_14_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_firstGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_it = bevt_12_tmpvar_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 31 */ {
bevt_15_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 31 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_fnode == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 33 */ {
bevl_fnode = bevl_inode;
} /* Line: 34 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 36 */
 else  /* Line: 31 */ {
break;
} /* Line: 31 */
} /* Line: 31 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 39 */
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_18_tmpvar_phold.bevi_int == bevt_19_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 41 */ {
bevp_inMtd = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_23_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_23_tmpvar_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_20_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_24_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_24_tmpvar_phold);
bevt_27_tmpvar_phold = beva_node.bem_classGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_ts.bem_namepathSet_1(bevt_25_tmpvar_phold);
} /* Line: 45 */
bevt_29_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_30_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_29_tmpvar_phold.bevi_int == bevt_30_tmpvar_phold.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_33_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_34_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_34_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_37_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_2));
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_38_tmpvar_phold);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_lengthGet_0();
bevt_42_tmpvar_phold = bevo_0;
if (bevt_40_tmpvar_phold.bevi_int > bevt_42_tmpvar_phold.bevi_int) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 52 */ {
bevt_45_tmpvar_phold = bevo_1;
bevt_48_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_lengthGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_toString_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_add_1(bevt_46_tmpvar_phold);
bevt_43_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_44_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_43_tmpvar_phold);
} /* Line: 53 */
bevt_51_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(-1319292247, BEL_4_Base.bevn_boundGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_49_tmpvar_phold != null && bevt_49_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_49_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_53_tmpvar_phold = bevp_inMtd.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_54_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_4));
bevl_v = bevt_52_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_55_tmpvar_phold);
bevt_56_tmpvar_phold = bevl_v.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_56_tmpvar_phold);
bevt_57_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_57_tmpvar_phold.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_58_tmpvar_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd);
} /* Line: 62 */
bevt_61_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_5));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 65 */ {
bevt_63_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_63_tmpvar_phold;
} /* Line: 66 */
bevl_unwind = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 70 */ {
bevt_66_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bels_6));
bevt_65_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_66_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_65_tmpvar_phold);
} /* Line: 71 */
bevt_68_tmpvar_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevt_72_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_73_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_7));
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevt_74_tmpvar_phold = beva_node.bem_isSecondGet_0();
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 75 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 75 */
 else  /* Line: 75 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 75 */ {
bevl_unwind = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 76 */
 else  /* Line: 75 */ {
bevt_76_tmpvar_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_77_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_77_tmpvar_phold);
if (bevt_75_tmpvar_phold != null && bevt_75_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_75_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevl_unwind = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 78 */
} /* Line: 75 */
if (bevl_unwind != null && bevl_unwind is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_unwind).bevi_bool) /* Line: 80 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 85 */ {
bevt_79_tmpvar_phold = bevl_cnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_80_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_80_tmpvar_phold);
if (bevt_78_tmpvar_phold != null && bevt_78_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_78_tmpvar_phold).bevi_bool) /* Line: 85 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 88 */
 else  /* Line: 85 */ {
break;
} /* Line: 85 */
} /* Line: 85 */
bevt_81_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_8));
bevl_pholdv = bevl_lastStep.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_81_tmpvar_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_82_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_82_tmpvar_phold);
bevl_phold.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold);
bevl_phold.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_83_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_83_tmpvar_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_9));
bevl_prcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_84_tmpvar_phold);
bevl_prc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_85_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_85_tmpvar_phold);
bevl_phold2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_pholdv);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_phold2);
bevl_prc.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
bevl_lastStep.bemd_1(-1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_prc);
bevt_86_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpvar_phold;
} /* Line: 113 */
} /* Line: 80 */
bevt_87_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_87_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() {
return bevp_inMtd;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {26, 26, 26, 26, 27, 28, 28, 28, 28, 28, 28, 29, 31, 31, 31, 31, 31, 32, 33, 33, 34, 36, 38, 39, 41, 41, 41, 41, 42, 43, 43, 43, 43, 43, 44, 44, 45, 45, 45, 45, 50, 50, 50, 50, 52, 52, 52, 52, 0, 52, 52, 52, 52, 0, 0, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 53, 53, 53, 53, 53, 55, 55, 55, 56, 57, 58, 58, 58, 58, 59, 59, 60, 60, 61, 61, 61, 62, 65, 65, 65, 65, 66, 66, 68, 69, 70, 70, 71, 71, 71, 75, 75, 75, 75, 75, 75, 75, 0, 0, 0, 75, 0, 0, 0, 76, 77, 77, 77, 78, 81, 82, 85, 85, 85, 87, 88, 93, 93, 94, 95, 96, 96, 97, 98, 99, 100, 101, 102, 102, 103, 104, 104, 105, 106, 107, 108, 108, 109, 110, 111, 112, 113, 113, 116, 116, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {129, 130, 131, 136, 137, 138, 139, 140, 141, 142, 147, 148, 150, 151, 152, 153, 156, 158, 159, 164, 165, 167, 173, 174, 176, 177, 178, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 197, 198, 199, 204, 205, 206, 207, 208, 210, 213, 214, 215, 216, 218, 221, 225, 226, 227, 228, 233, 234, 237, 241, 244, 245, 246, 247, 248, 249, 250, 252, 253, 254, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 271, 272, 273, 274, 276, 277, 279, 280, 281, 286, 287, 288, 289, 291, 292, 293, 295, 296, 297, 298, 300, 303, 307, 310, 312, 315, 319, 322, 325, 326, 327, 329, 333, 334, 337, 338, 339, 341, 342, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 377, 378, 381, 384};
/* BEGIN LINEINFO 
assign 1 26 129
typenameGet 0 26 129
assign 1 26 130
EXPRGet 0 26 130
assign 1 26 131
equals 1 26 136
assign 1 27 137
assign 1 28 138
containedGet 0 28 138
assign 1 28 139
firstGet 0 28 139
assign 1 28 140
containedGet 0 28 140
assign 1 28 141
firstNodeGet 0 28 141
assign 1 28 142
undef 1 28 147
assign 1 29 148
nextDescendGet 0 29 148
assign 1 31 150
containedGet 0 31 150
assign 1 31 151
firstGet 0 31 151
assign 1 31 152
containedGet 0 31 152
assign 1 31 153
iteratorGet 0 31 153
assign 1 31 156
hasNextGet 0 31 156
assign 1 32 158
nextGet 0 32 158
assign 1 33 159
undef 1 33 164
assign 1 34 165
beforeInsert 1 36 167
delete 0 38 173
return 1 39 174
assign 1 41 176
typenameGet 0 41 176
assign 1 41 177
METHODGet 0 41 177
assign 1 41 178
equals 1 41 183
assign 1 42 184
assign 1 43 185
heldGet 0 43 185
assign 1 43 186
varMapGet 0 43 186
assign 1 43 187
new 0 43 187
assign 1 43 188
get 1 43 188
assign 1 43 189
heldGet 0 43 189
assign 1 44 190
new 0 44 190
isTypedSet 1 44 191
assign 1 45 192
classGet 0 45 192
assign 1 45 193
heldGet 0 45 193
assign 1 45 194
namepathGet 0 45 194
namepathSet 1 45 195
assign 1 50 197
typenameGet 0 50 197
assign 1 50 198
CALLGet 0 50 198
assign 1 50 199
equals 1 50 204
assign 1 52 205
heldGet 0 52 205
assign 1 52 206
nameGet 0 52 206
assign 1 52 207
new 0 52 207
assign 1 52 208
equals 1 52 208
assign 1 0 210
assign 1 52 213
heldGet 0 52 213
assign 1 52 214
nameGet 0 52 214
assign 1 52 215
new 0 52 215
assign 1 52 216
equals 1 52 216
assign 1 0 218
assign 1 0 221
assign 1 52 225
containedGet 0 52 225
assign 1 52 226
lengthGet 0 52 226
assign 1 52 227
new 0 52 227
assign 1 52 228
greater 1 52 233
assign 1 0 234
assign 1 0 237
assign 1 0 241
assign 1 53 244
new 0 53 244
assign 1 53 245
containedGet 0 53 245
assign 1 53 246
lengthGet 0 53 246
assign 1 53 247
toString 0 53 247
assign 1 53 248
add 1 53 248
assign 1 53 249
new 2 53 249
throw 1 53 250
assign 1 55 252
heldGet 0 55 252
assign 1 55 253
boundGet 0 55 253
assign 1 55 254
not 0 55 254
assign 1 56 256
new 1 56 256
copyLoc 1 57 257
assign 1 58 258
heldGet 0 58 258
assign 1 58 259
varMapGet 0 58 259
assign 1 58 260
new 0 58 260
assign 1 58 261
get 1 58 261
assign 1 59 262
VARGet 0 59 262
typenameSet 1 59 263
assign 1 60 264
heldGet 0 60 264
heldSet 1 60 265
assign 1 61 266
heldGet 0 61 266
assign 1 61 267
new 0 61 267
boundSet 1 61 268
prepend 1 62 269
assign 1 65 271
heldGet 0 65 271
assign 1 65 272
nameGet 0 65 272
assign 1 65 273
new 0 65 273
assign 1 65 274
equals 1 65 274
assign 1 66 276
nextDescendGet 0 66 276
return 1 66 277
assign 1 68 279
new 0 68 279
assign 1 69 280
containerGet 0 69 280
assign 1 70 281
undef 1 70 286
assign 1 71 287
new 0 71 287
assign 1 71 288
new 2 71 288
throw 1 71 289
assign 1 75 291
typenameGet 0 75 291
assign 1 75 292
CALLGet 0 75 292
assign 1 75 293
equals 1 75 293
assign 1 75 295
heldGet 0 75 295
assign 1 75 296
nameGet 0 75 296
assign 1 75 297
new 0 75 297
assign 1 75 298
equals 1 75 298
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 75 310
isSecondGet 0 75 310
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 76 322
new 0 76 322
assign 1 77 325
typenameGet 0 77 325
assign 1 77 326
BRACESGet 0 77 326
assign 1 77 327
equals 1 77 327
assign 1 78 329
new 0 78 329
assign 1 81 333
assign 1 82 334
assign 1 85 337
typenameGet 0 85 337
assign 1 85 338
BRACESGet 0 85 338
assign 1 85 339
notEquals 1 85 339
assign 1 87 341
assign 1 88 342
containerGet 0 88 342
assign 1 93 348
new 0 93 348
assign 1 93 349
tmpVar 2 93 349
assign 1 94 350
new 1 94 350
copyLoc 1 95 351
assign 1 96 352
VARGet 0 96 352
typenameSet 1 96 353
heldSet 1 97 354
replaceWith 1 98 355
addVariable 0 99 356
assign 1 100 357
new 1 100 357
copyLoc 1 101 358
assign 1 102 359
CALLGet 0 102 359
typenameSet 1 102 360
assign 1 103 361
new 0 103 361
assign 1 104 362
new 0 104 362
nameSet 1 104 363
heldSet 1 105 364
assign 1 106 365
new 1 106 365
copyLoc 1 107 366
assign 1 108 367
VARGet 0 108 367
typenameSet 1 108 368
heldSet 1 109 369
addValue 1 110 370
addValue 1 111 371
beforeInsert 1 112 372
assign 1 113 373
nextDescendGet 0 113 373
return 1 113 374
assign 1 116 377
nextDescendGet 0 116 377
return 1 116 378
return 1 0 381
assign 1 0 384
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -850314193: return bem_inMtdGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -839231940: return bem_inMtdSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass11.bevs_inst = (BEC_3_5_5_6_BuildVisitPass11)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass11.bevs_inst;
}
}
}
