namespace be.BEL_4_Base {
/* IO:File: source/build/Syns.be */
public class BEC_2_5_6_BuildPtySyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
static BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 8));
private static byte[] bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 4));
private static byte[] bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bels_4 = {0x76,0x61,0x72};
public static new BEC_2_5_6_BuildPtySyn bevs_inst;
public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public virtual BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_varNew_1(bevl_v);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevl_nl);
bevt_6_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_6_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevl_nl);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_name);
bevl_toRet = bevt_1_tmpvar_phold.bem_add_1(bevl_nl);
bevt_10_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_2));
bevt_9_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_10_tmpvar_phold);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_11_tmpvar_phold = bevp_origin.bem_toString_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_13_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_3));
bevt_12_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_13_tmpvar_phold);
bevl_toRet = bevt_12_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_14_tmpvar_phold = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 541 */ {
bevt_17_tmpvar_phold = bevp_memSyn.bem_namepathGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_toString_0();
bevt_15_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_16_tmpvar_phold);
bevl_toRet = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 542 */
 else  /* Line: 543 */ {
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevt_18_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_19_tmpvar_phold);
bevl_toRet = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 544 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_mposGet_0() {
return bevp_mpos;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_6_BuildVarSyn bem_memSynGet_0() {
return bevp_memSyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {526, 530, 531, 532, 537, 537, 538, 538, 538, 538, 538, 538, 538, 539, 539, 539, 539, 539, 539, 540, 540, 540, 541, 542, 542, 542, 542, 544, 544, 544, 546, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 72, 73, 74, 77, 78, 79, 81, 84, 87, 91, 94, 98, 101, 105, 108};
/* BEGIN LINEINFO 
assign 1 526 22
heldGet 0 526 22
assign 1 530 23
nameGet 0 530 23
assign 1 531 24
assign 1 532 25
varNew 1 532 25
assign 1 537 51
new 0 537 51
assign 1 537 52
newlineGet 0 537 52
assign 1 538 53
new 0 538 53
assign 1 538 54
add 1 538 54
assign 1 538 55
new 0 538 55
assign 1 538 56
add 1 538 56
assign 1 538 57
add 1 538 57
assign 1 538 58
add 1 538 58
assign 1 538 59
add 1 538 59
assign 1 539 60
new 0 539 60
assign 1 539 61
add 1 539 61
assign 1 539 62
add 1 539 62
assign 1 539 63
toString 0 539 63
assign 1 539 64
add 1 539 64
assign 1 539 65
add 1 539 65
assign 1 540 66
new 0 540 66
assign 1 540 67
add 1 540 67
assign 1 540 68
add 1 540 68
assign 1 541 69
isTypedGet 0 541 69
assign 1 542 71
namepathGet 0 542 71
assign 1 542 72
toString 0 542 72
assign 1 542 73
add 1 542 73
assign 1 542 74
add 1 542 74
assign 1 544 77
new 0 544 77
assign 1 544 78
add 1 544 78
assign 1 544 79
add 1 544 79
return 1 546 81
return 1 0 84
assign 1 0 87
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1707345409: return bem_originGet_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1271927552: return bem_mposGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1444794516: return bem_memSynGet_0();
case 1354714650: return bem_copy_0();
case 1211273660: return bem_nameGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1455876769: return bem_memSynSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1283009805: return bem_mposSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildPtySyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildPtySyn.bevs_inst = (BEC_2_5_6_BuildPtySyn)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildPtySyn.bevs_inst;
}
}
}
