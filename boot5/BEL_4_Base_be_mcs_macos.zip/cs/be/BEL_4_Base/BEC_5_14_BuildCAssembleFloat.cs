namespace be.BEL_4_Base {
/* File: source/build/CCallAssembler.be */
public class BEC_5_14_BuildCAssembleFloat : BEC_5_14_BuildCCallAssembler {
public BEC_5_14_BuildCAssembleFloat() { }
static BEC_5_14_BuildCAssembleFloat() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x61,0x6C,0x6C,0x41,0x73,0x73,0x65,0x6D,0x62,0x6C,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_3 = {0x3C};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_5 = {0x3E};
private static byte[] bels_6 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_7 = {0x3C,0x3D};
private static byte[] bels_8 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_9 = {0x3E,0x3D};
private static byte[] bels_10 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_11 = {0x2B};
private static byte[] bels_12 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_13 = {0x2D};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_15 = {0x2A};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_17 = {0x2F};
private static byte[] bels_18 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x30};
private static byte[] bels_19 = {0x2B};
private static byte[] bels_20 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x30};
private static byte[] bels_21 = {0x2D};
private static byte[] bels_22 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_22, 31));
private static byte[] bels_23 = {0x2C,0x20,0x30,0x29,0x3B};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_23, 5));
private static byte[] bels_24 = {0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_24, 15));
private static byte[] bels_25 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_25, 15));
private static byte[] bels_26 = {0x3B};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_26, 1));
private static byte[] bels_27 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_27, 4));
private static byte[] bels_28 = {0x20,0x3D,0x3D,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x7C,0x7C,0x20,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_28, 22));
private static byte[] bels_29 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_29, 13));
private static byte[] bels_30 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_31 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_32 = {0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_33 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_34 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_34, 39));
private static byte[] bels_35 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_35, 16));
private static byte[] bels_36 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_37 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_38 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D,0x20,0x7D};
private static byte[] bels_39 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_39, 4));
private static byte[] bels_40 = {0x20,0x3D,0x3D,0x20,0x4E,0x55,0x4C,0x4C,0x20,0x7C,0x7C,0x20,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_40, 22));
private static byte[] bels_41 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_41, 13));
private static byte[] bels_42 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_43 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_44 = {0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_45 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_46 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x21,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_46, 39));
private static byte[] bels_47 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_47, 16));
private static byte[] bels_48 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_49 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_50 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D,0x20,0x7D};
private static byte[] bels_51 = {0x69,0x66,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_51, 14));
private static byte[] bels_52 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_52, 13));
private static byte[] bels_53 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_54 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_55 = {0x69,0x66,0x20,0x28,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_56 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_57 = {0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_57, 25));
private static byte[] bels_58 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x29,0x20,0x7B,0x20};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_58, 16));
private static byte[] bels_59 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x54,0x72,0x75,0x65,0x3B,0x20,0x7D};
private static byte[] bels_60 = {0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_61 = {0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2D,0x3E,0x62,0x6F,0x6F,0x6C,0x5F,0x46,0x61,0x6C,0x73,0x65,0x3B,0x20,0x7D};
private static byte[] bels_62 = {0x7D};
private static byte[] bels_63 = {0x69,0x66,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_63, 14));
private static byte[] bels_64 = {0x29,0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x20,0x21,0x3D,0x20};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_64, 13));
private static byte[] bels_65 = {0x5B,0x62,0x65,0x72,0x64,0x65,0x66,0x5D,0x29,0x20,0x7B,0x20};
private static byte[] bels_66 = {0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B};
private static byte[] bels_67 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x42,0x45,0x55,0x56,0x5F,0x34,0x5F,0x35,0x5F,0x4D,0x61,0x74,0x68,0x46,0x6C,0x6F,0x61,0x74,0x5F,0x63,0x6C,0x44,0x65,0x66,0x2C,0x20,0x30,0x29,0x3B};
private static byte[] bels_68 = {0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28};
private static byte[] bels_69 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_70 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_71 = {0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28,0x28,0x76,0x6F,0x69,0x64,0x2A,0x2A,0x29,0x20};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 25));
private static byte[] bels_72 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x3B};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_72, 13));
private static byte[] bels_73 = {0x7D};
private static byte[] bels_74 = {0x42,0x45,0x52,0x46,0x5F,0x43,0x72,0x65,0x61,0x74,0x65,0x5F,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x62,0x65,0x72,0x76,0x5F,0x73,0x74,0x73,0x2C,0x20,0x42,0x45,0x55,0x56,0x5F,0x34,0x5F,0x35,0x5F,0x4D,0x61,0x74,0x68,0x46,0x6C,0x6F,0x61,0x74,0x5F,0x63,0x6C,0x44,0x65,0x66,0x2C,0x20,0x30,0x29,0x3B};
private static byte[] bels_75 = {0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28,0x28};
private static byte[] bels_76 = {0x29,0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20,0x3D,0x20,0x2A,0x28,0x28,0x42,0x45,0x46,0x4C,0x4F,0x41,0x54,0x2A,0x29,0x20,0x28};
private static byte[] bels_77 = {0x20,0x2B,0x20,0x62,0x65,0x72,0x63,0x70,0x73,0x29,0x29,0x20};
private static byte[] bels_78 = {0x20,0x31,0x2E,0x30,0x3B};
public static new BEC_5_14_BuildCAssembleFloat bevs_inst;
public override BEC_5_14_BuildCCallAssembler bem_new_1(BEC_6_6_SystemObject beva_build) {
this.bem_loadBuild_1(beva_build);
return this;
} /*method end*/
public override BEC_4_6_TextString bem_processCall_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevt_6_tmpvar_phold = beva_ca.bem_asnRGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 391 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 391 */
 else  /* Line: 391 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 391 */ {
bevt_9_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 391 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 391 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 391 */
 else  /* Line: 391 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 391 */ {
bevt_10_tmpvar_phold = this.bem_processLiteralConstruct_1(beva_ca);
return bevt_10_tmpvar_phold;
} /* Line: 392 */
bevt_14_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_0));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_15_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevt_16_tmpvar_phold = this.bem_processEquals_1(beva_ca);
return bevt_16_tmpvar_phold;
} /* Line: 395 */
 else  /* Line: 394 */ {
bevt_20_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevt_22_tmpvar_phold = this.bem_processNotEquals_1(beva_ca);
return bevt_22_tmpvar_phold;
} /* Line: 397 */
 else  /* Line: 394 */ {
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_heldGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 398 */ {
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_3));
bevt_28_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_29_tmpvar_phold);
return bevt_28_tmpvar_phold;
} /* Line: 399 */
 else  /* Line: 394 */ {
bevt_33_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_heldGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_4));
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_34_tmpvar_phold);
if (bevt_30_tmpvar_phold != null && bevt_30_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_30_tmpvar_phold).bevi_bool) /* Line: 400 */ {
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_5));
bevt_35_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_36_tmpvar_phold);
return bevt_35_tmpvar_phold;
} /* Line: 401 */
 else  /* Line: 394 */ {
bevt_40_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_6));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 402 */ {
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_7));
bevt_42_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_43_tmpvar_phold);
return bevt_42_tmpvar_phold;
} /* Line: 403 */
 else  /* Line: 394 */ {
bevt_47_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_heldGet_0();
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_8));
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_48_tmpvar_phold);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 404 */ {
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_9));
bevt_49_tmpvar_phold = this.bem_processCompare_2(beva_ca, bevt_50_tmpvar_phold);
return bevt_49_tmpvar_phold;
} /* Line: 405 */
 else  /* Line: 394 */ {
bevt_54_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_10));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_51_tmpvar_phold != null && bevt_51_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_51_tmpvar_phold).bevi_bool) /* Line: 406 */ {
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_11));
bevt_56_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_57_tmpvar_phold);
return bevt_56_tmpvar_phold;
} /* Line: 407 */
 else  /* Line: 394 */ {
bevt_61_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_heldGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_12));
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpvar_phold);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 408 */ {
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_13));
bevt_63_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_64_tmpvar_phold);
return bevt_63_tmpvar_phold;
} /* Line: 409 */
 else  /* Line: 394 */ {
bevt_68_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bem_heldGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_69_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_14));
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_65_tmpvar_phold != null && bevt_65_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_65_tmpvar_phold).bevi_bool) /* Line: 410 */ {
bevt_71_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_15));
bevt_70_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_71_tmpvar_phold);
return bevt_70_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 394 */ {
bevt_75_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_76_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_16));
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_72_tmpvar_phold != null && bevt_72_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_72_tmpvar_phold).bevi_bool) /* Line: 412 */ {
bevt_78_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_17));
bevt_77_tmpvar_phold = this.bem_processModify_2(beva_ca, bevt_78_tmpvar_phold);
return bevt_77_tmpvar_phold;
} /* Line: 413 */
 else  /* Line: 394 */ {
bevt_82_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_83_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_18));
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevt_85_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_19));
bevt_84_tmpvar_phold = this.bem_processIncDec_2(beva_ca, bevt_85_tmpvar_phold);
return bevt_84_tmpvar_phold;
} /* Line: 415 */
 else  /* Line: 394 */ {
bevt_89_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_heldGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_20));
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpvar_phold);
if (bevt_86_tmpvar_phold != null && bevt_86_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_86_tmpvar_phold).bevi_bool) /* Line: 416 */ {
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_21));
bevt_91_tmpvar_phold = this.bem_processIncDec_2(beva_ca, bevt_92_tmpvar_phold);
return bevt_91_tmpvar_phold;
} /* Line: 417 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
bevt_93_tmpvar_phold = this.bem_standardCall_1(beva_ca);
return bevt_93_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_processLiteralConstruct_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_4_6_TextString bevl_callRet = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_6_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_0;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_ca.bem_literalCdefGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_0_tmpvar_phold);
bevt_16_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevt_17_tmpvar_phold = bevo_2;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_3;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_24_tmpvar_phold = bevo_4;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_24_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_nl);
beva_ca.bem_tcallSet_1(bevt_10_tmpvar_phold);
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_25_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = beva_ca.bem_tcallGet_0();
bevl_callRet.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_28_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processEquals_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_18_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_5;
bevt_16_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_19_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_containedGet_0();
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_get_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_getBeavArg_1(bevt_17_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_6;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_containedGet_0();
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_get_1(bevt_27_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_getBeavArg_1(bevt_24_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_7;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_29_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_30));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(23, bels_31));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_32));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_33));
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_8;
bevt_46_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_49_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_containedGet_0();
bevt_50_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_get_1(bevt_50_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_getBeavArg_1(bevt_47_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_51_tmpvar_phold = bevo_9;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_51_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_52_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevt_37_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_36));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevt_36_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_35_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_37));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(25, bels_38));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_60_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_61_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_61_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processNotEquals_1(BEC_5_10_BuildCallCursor beva_ca) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_18_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_48_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_10;
bevt_16_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_19_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_containedGet_0();
bevt_20_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_get_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_getBeavArg_1(bevt_17_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_11;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_26_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_containedGet_0();
bevt_27_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_get_1(bevt_27_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_getBeavArg_1(bevt_24_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_12;
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_29_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_42));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_43));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_44));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_45));
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_13;
bevt_46_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_49_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bem_containedGet_0();
bevt_50_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_get_1(bevt_50_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_getBeavArg_1(bevt_47_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_51_tmpvar_phold = bevo_14;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_51_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) bevt_38_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_52_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevt_37_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_48));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevt_36_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_35_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_49));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevt_56_tmpvar_phold.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(25, bels_50));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevt_55_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_54_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_60_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_61_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_61_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processCompare_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_17_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevt_13_tmpvar_phold = bevo_15;
bevt_15_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_18_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_containedGet_0();
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_get_1(bevt_19_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_getBeavArg_1(bevt_16_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_16;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_21_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_53));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevl_nl);
this.bem_standardBlockAssign_2(beva_ca, bevl_callRet);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_54));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 478 */
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_55));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_56));
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevt_29_tmpvar_phold.bem_addValue_1(beva_action);
bevt_37_tmpvar_phold = bevo_17;
bevt_39_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_42_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_containedGet_0();
bevt_43_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_get_1(bevt_43_tmpvar_phold);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_getBeavArg_1(bevt_40_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevt_38_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_18;
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevt_28_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_45_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_59));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_46_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_60));
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_51_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(23, bels_61));
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_47_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_53_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_56_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_heldGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 483 */ {
bevt_58_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_62));
bevt_57_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_58_tmpvar_phold);
bevt_57_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 484 */
bevt_59_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_59_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processModify_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_17_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_47_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
beva_ca.bem_checkRetainTo_0();
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 498 */ {
bevt_13_tmpvar_phold = bevo_19;
bevt_15_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_18_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_containedGet_0();
bevt_19_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_get_1(bevt_19_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_getBeavArg_1(bevt_16_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_20;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_21_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_65));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevl_nl);
this.bem_standardBlockAssign_2(beva_ca, bevl_callRet);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_66));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_24_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 501 */
bevt_27_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(60, bels_67));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_68));
bevt_35_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_34_tmpvar_phold = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_addValue_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(29, bels_69));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevt_34_tmpvar_phold.bem_addValue_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_70));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(beva_action);
bevt_43_tmpvar_phold = bevo_21;
bevt_45_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_48_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_containedGet_0();
bevt_49_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_getBeavArg_1(bevt_46_tmpvar_phold);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_50_tmpvar_phold = bevo_22;
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_add_1(bevt_50_tmpvar_phold);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_51_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_54_tmpvar_phold = beva_ca.bem_nodeGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_heldGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 506 */ {
bevt_56_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_73));
bevt_55_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_55_tmpvar_phold.bem_addValue_1(bevl_nl);
} /* Line: 507 */
bevt_57_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_57_tmpvar_phold);
return bevl_callRet;
} /*method end*/
public virtual BEC_4_6_TextString bem_processIncDec_2(BEC_5_10_BuildCallCursor beva_ca, BEC_4_6_TextString beva_action) {
BEC_6_6_SystemObject bevl_nl = null;
BEC_4_6_TextString bevl_callRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_5_BuildBuild bevt_1_tmpvar_phold = null;
BEC_5_5_5_BuildVisitCEmit bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_ca.bem_isValidGet_0();
BEC_4_10_TestAssertions.bevs_inst.bem_assertTrue_1(bevt_0_tmpvar_phold);
beva_ca.bem_checkRetainTo_0();
bevt_2_tmpvar_phold = beva_ca.bem_emvisitGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_buildGet_0();
bevl_nl = bevt_1_tmpvar_phold.bem_nlGet_0();
bevl_callRet = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_3_tmpvar_phold = beva_ca.bem_preOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_ca.bem_callArgsGet_0();
bevl_callRet.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = beva_ca.bem_assignToVVGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(60, bels_74));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_5_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_75));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevl_callRet.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = beva_ca.bem_embedTargGet_0();
bevt_14_tmpvar_phold = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(29, bels_76));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevt_14_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = beva_ca.bem_targsGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_77));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(beva_action);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_78));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevl_nl);
bevt_22_tmpvar_phold = beva_ca.bem_assignToCheckGet_0();
bevl_callRet.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = beva_ca.bem_postOnceEvalGet_0();
bevl_callRet.bem_addValue_1(bevt_23_tmpvar_phold);
return bevl_callRet;
} /*method end*/
//int[] bevs_nlcs = {388, 391, 391, 391, 391, 391, 391, 0, 0, 0, 391, 391, 391, 0, 0, 0, 392, 392, 394, 394, 394, 394, 394, 395, 395, 396, 396, 396, 396, 396, 397, 397, 398, 398, 398, 398, 398, 399, 399, 399, 400, 400, 400, 400, 400, 401, 401, 401, 402, 402, 402, 402, 402, 403, 403, 403, 404, 404, 404, 404, 404, 405, 405, 405, 406, 406, 406, 406, 406, 407, 407, 407, 408, 408, 408, 408, 408, 409, 409, 409, 410, 410, 410, 410, 410, 411, 411, 411, 412, 412, 412, 412, 412, 413, 413, 413, 414, 414, 414, 414, 414, 415, 415, 415, 416, 416, 416, 416, 416, 417, 417, 417, 419, 419, 423, 423, 423, 423, 423, 423, 423, 423, 423, 423, 423, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 424, 425, 426, 426, 427, 427, 428, 428, 429, 429, 430, 435, 435, 437, 437, 437, 438, 439, 439, 440, 440, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 441, 442, 442, 442, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 444, 444, 444, 444, 444, 444, 444, 445, 445, 446, 446, 447, 452, 452, 454, 454, 454, 455, 456, 456, 457, 457, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 458, 459, 459, 459, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 460, 461, 461, 461, 461, 461, 461, 461, 462, 462, 463, 463, 464, 469, 469, 471, 471, 471, 472, 473, 473, 474, 474, 475, 475, 475, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 476, 477, 478, 478, 478, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 480, 481, 481, 481, 481, 481, 481, 481, 482, 482, 483, 483, 483, 484, 484, 484, 486, 486, 487, 492, 492, 493, 494, 494, 494, 495, 496, 496, 497, 497, 498, 498, 498, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 499, 500, 501, 501, 501, 503, 503, 503, 503, 503, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 504, 505, 505, 506, 506, 506, 507, 507, 507, 509, 509, 510, 515, 515, 516, 517, 517, 517, 518, 519, 519, 520, 520, 521, 521, 521, 521, 521, 522, 522, 522, 522, 522, 522, 522, 522, 522, 522, 522, 522, 522, 522, 523, 523, 524, 524, 525};
//int[] bevs_nlecs = {112, 210, 211, 212, 214, 215, 220, 221, 224, 228, 231, 232, 233, 235, 238, 242, 245, 246, 248, 249, 250, 251, 252, 254, 255, 258, 259, 260, 261, 262, 264, 265, 268, 269, 270, 271, 272, 274, 275, 276, 279, 280, 281, 282, 283, 285, 286, 287, 290, 291, 292, 293, 294, 296, 297, 298, 301, 302, 303, 304, 305, 307, 308, 309, 312, 313, 314, 315, 316, 318, 319, 320, 323, 324, 325, 326, 327, 329, 330, 331, 334, 335, 336, 337, 338, 340, 341, 342, 345, 346, 347, 348, 349, 351, 352, 353, 356, 357, 358, 359, 360, 362, 363, 364, 367, 368, 369, 370, 371, 373, 374, 375, 388, 389, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 874, 875, 876, 878, 879, 880, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1013, 1014, 1015, 1017, 1018, 1019, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082};
/* BEGIN LINEINFO 
loadBuild 1 388 112
assign 1 391 210
nodeGet 0 391 210
assign 1 391 211
heldGet 0 391 211
assign 1 391 212
isConstructGet 0 391 212
assign 1 391 214
asnRGet 0 391 214
assign 1 391 215
def 1 391 220
assign 1 0 221
assign 1 0 224
assign 1 0 228
assign 1 391 231
nodeGet 0 391 231
assign 1 391 232
heldGet 0 391 232
assign 1 391 233
isLiteralGet 0 391 233
assign 1 0 235
assign 1 0 238
assign 1 0 242
assign 1 392 245
processLiteralConstruct 1 392 245
return 1 392 246
assign 1 394 248
nodeGet 0 394 248
assign 1 394 249
heldGet 0 394 249
assign 1 394 250
nameGet 0 394 250
assign 1 394 251
new 0 394 251
assign 1 394 252
equals 1 394 252
assign 1 395 254
processEquals 1 395 254
return 1 395 255
assign 1 396 258
nodeGet 0 396 258
assign 1 396 259
heldGet 0 396 259
assign 1 396 260
nameGet 0 396 260
assign 1 396 261
new 0 396 261
assign 1 396 262
equals 1 396 262
assign 1 397 264
processNotEquals 1 397 264
return 1 397 265
assign 1 398 268
nodeGet 0 398 268
assign 1 398 269
heldGet 0 398 269
assign 1 398 270
nameGet 0 398 270
assign 1 398 271
new 0 398 271
assign 1 398 272
equals 1 398 272
assign 1 399 274
new 0 399 274
assign 1 399 275
processCompare 2 399 275
return 1 399 276
assign 1 400 279
nodeGet 0 400 279
assign 1 400 280
heldGet 0 400 280
assign 1 400 281
nameGet 0 400 281
assign 1 400 282
new 0 400 282
assign 1 400 283
equals 1 400 283
assign 1 401 285
new 0 401 285
assign 1 401 286
processCompare 2 401 286
return 1 401 287
assign 1 402 290
nodeGet 0 402 290
assign 1 402 291
heldGet 0 402 291
assign 1 402 292
nameGet 0 402 292
assign 1 402 293
new 0 402 293
assign 1 402 294
equals 1 402 294
assign 1 403 296
new 0 403 296
assign 1 403 297
processCompare 2 403 297
return 1 403 298
assign 1 404 301
nodeGet 0 404 301
assign 1 404 302
heldGet 0 404 302
assign 1 404 303
nameGet 0 404 303
assign 1 404 304
new 0 404 304
assign 1 404 305
equals 1 404 305
assign 1 405 307
new 0 405 307
assign 1 405 308
processCompare 2 405 308
return 1 405 309
assign 1 406 312
nodeGet 0 406 312
assign 1 406 313
heldGet 0 406 313
assign 1 406 314
nameGet 0 406 314
assign 1 406 315
new 0 406 315
assign 1 406 316
equals 1 406 316
assign 1 407 318
new 0 407 318
assign 1 407 319
processModify 2 407 319
return 1 407 320
assign 1 408 323
nodeGet 0 408 323
assign 1 408 324
heldGet 0 408 324
assign 1 408 325
nameGet 0 408 325
assign 1 408 326
new 0 408 326
assign 1 408 327
equals 1 408 327
assign 1 409 329
new 0 409 329
assign 1 409 330
processModify 2 409 330
return 1 409 331
assign 1 410 334
nodeGet 0 410 334
assign 1 410 335
heldGet 0 410 335
assign 1 410 336
nameGet 0 410 336
assign 1 410 337
new 0 410 337
assign 1 410 338
equals 1 410 338
assign 1 411 340
new 0 411 340
assign 1 411 341
processModify 2 411 341
return 1 411 342
assign 1 412 345
nodeGet 0 412 345
assign 1 412 346
heldGet 0 412 346
assign 1 412 347
nameGet 0 412 347
assign 1 412 348
new 0 412 348
assign 1 412 349
equals 1 412 349
assign 1 413 351
new 0 413 351
assign 1 413 352
processModify 2 413 352
return 1 413 353
assign 1 414 356
nodeGet 0 414 356
assign 1 414 357
heldGet 0 414 357
assign 1 414 358
nameGet 0 414 358
assign 1 414 359
new 0 414 359
assign 1 414 360
equals 1 414 360
assign 1 415 362
new 0 415 362
assign 1 415 363
processIncDec 2 415 363
return 1 415 364
assign 1 416 367
nodeGet 0 416 367
assign 1 416 368
heldGet 0 416 368
assign 1 416 369
nameGet 0 416 369
assign 1 416 370
new 0 416 370
assign 1 416 371
equals 1 416 371
assign 1 417 373
new 0 417 373
assign 1 417 374
processIncDec 2 417 374
return 1 417 375
assign 1 419 388
standardCall 1 419 388
return 1 419 389
assign 1 423 422
tcallGet 0 423 422
assign 1 423 423
assignToVVGet 0 423 423
assign 1 423 424
add 1 423 424
assign 1 423 425
new 0 423 425
assign 1 423 426
add 1 423 426
assign 1 423 427
literalCdefGet 0 423 427
assign 1 423 428
add 1 423 428
assign 1 423 429
new 0 423 429
assign 1 423 430
add 1 423 430
assign 1 423 431
add 1 423 431
tcallSet 1 423 432
assign 1 424 433
tcallGet 0 424 433
assign 1 424 434
new 0 424 434
assign 1 424 435
add 1 424 435
assign 1 424 436
embedTargGet 0 424 436
assign 1 424 437
add 1 424 437
assign 1 424 438
new 0 424 438
assign 1 424 439
add 1 424 439
assign 1 424 440
nodeGet 0 424 440
assign 1 424 441
heldGet 0 424 441
assign 1 424 442
literalValueGet 0 424 442
assign 1 424 443
toString 0 424 443
assign 1 424 444
add 1 424 444
assign 1 424 445
new 0 424 445
assign 1 424 446
add 1 424 446
assign 1 424 447
add 1 424 447
tcallSet 1 424 448
assign 1 425 449
new 0 425 449
assign 1 426 450
preOnceEvalGet 0 426 450
addValue 1 426 451
assign 1 427 452
tcallGet 0 427 452
addValue 1 427 453
assign 1 428 454
assignToCheckGet 0 428 454
addValue 1 428 455
assign 1 429 456
postOnceEvalGet 0 429 456
addValue 1 429 457
return 1 430 458
assign 1 435 525
isValidGet 0 435 525
assertTrue 1 435 526
assign 1 437 527
emvisitGet 0 437 527
assign 1 437 528
buildGet 0 437 528
assign 1 437 529
nlGet 0 437 529
assign 1 438 530
new 0 438 530
assign 1 439 531
preOnceEvalGet 0 439 531
addValue 1 439 532
assign 1 440 533
callArgsGet 0 440 533
addValue 1 440 534
assign 1 441 535
new 0 441 535
assign 1 441 536
emvisitGet 0 441 536
assign 1 441 537
nodeGet 0 441 537
assign 1 441 538
containedGet 0 441 538
assign 1 441 539
new 0 441 539
assign 1 441 540
get 1 441 540
assign 1 441 541
getBeavArg 1 441 541
assign 1 441 542
add 1 441 542
assign 1 441 543
new 0 441 543
assign 1 441 544
add 1 441 544
assign 1 441 545
emvisitGet 0 441 545
assign 1 441 546
nodeGet 0 441 546
assign 1 441 547
containedGet 0 441 547
assign 1 441 548
new 0 441 548
assign 1 441 549
get 1 441 549
assign 1 441 550
getBeavArg 1 441 550
assign 1 441 551
add 1 441 551
assign 1 441 552
new 0 441 552
assign 1 441 553
add 1 441 553
assign 1 441 554
addValue 1 441 554
assign 1 441 555
targsGet 0 441 555
assign 1 441 556
addValue 1 441 556
assign 1 441 557
new 0 441 557
assign 1 441 558
addValue 1 441 558
assign 1 441 559
assignToVVGet 0 441 559
assign 1 441 560
addValue 1 441 560
assign 1 441 561
new 0 441 561
assign 1 441 562
addValue 1 441 562
addValue 1 441 563
assign 1 442 564
new 0 442 564
assign 1 442 565
addValue 1 442 565
addValue 1 442 566
assign 1 443 567
new 0 443 567
assign 1 443 568
addValue 1 443 568
assign 1 443 569
targsGet 0 443 569
assign 1 443 570
addValue 1 443 570
assign 1 443 571
new 0 443 571
assign 1 443 572
emvisitGet 0 443 572
assign 1 443 573
nodeGet 0 443 573
assign 1 443 574
containedGet 0 443 574
assign 1 443 575
new 0 443 575
assign 1 443 576
get 1 443 576
assign 1 443 577
getBeavArg 1 443 577
assign 1 443 578
add 1 443 578
assign 1 443 579
new 0 443 579
assign 1 443 580
add 1 443 580
assign 1 443 581
addValue 1 443 581
assign 1 443 582
assignToVVGet 0 443 582
assign 1 443 583
addValue 1 443 583
assign 1 443 584
new 0 443 584
assign 1 443 585
addValue 1 443 585
addValue 1 443 586
assign 1 444 587
new 0 444 587
assign 1 444 588
addValue 1 444 588
assign 1 444 589
assignToVVGet 0 444 589
assign 1 444 590
addValue 1 444 590
assign 1 444 591
new 0 444 591
assign 1 444 592
addValue 1 444 592
addValue 1 444 593
assign 1 445 594
assignToCheckGet 0 445 594
addValue 1 445 595
assign 1 446 596
postOnceEvalGet 0 446 596
addValue 1 446 597
return 1 447 598
assign 1 452 665
isValidGet 0 452 665
assertTrue 1 452 666
assign 1 454 667
emvisitGet 0 454 667
assign 1 454 668
buildGet 0 454 668
assign 1 454 669
nlGet 0 454 669
assign 1 455 670
new 0 455 670
assign 1 456 671
preOnceEvalGet 0 456 671
addValue 1 456 672
assign 1 457 673
callArgsGet 0 457 673
addValue 1 457 674
assign 1 458 675
new 0 458 675
assign 1 458 676
emvisitGet 0 458 676
assign 1 458 677
nodeGet 0 458 677
assign 1 458 678
containedGet 0 458 678
assign 1 458 679
new 0 458 679
assign 1 458 680
get 1 458 680
assign 1 458 681
getBeavArg 1 458 681
assign 1 458 682
add 1 458 682
assign 1 458 683
new 0 458 683
assign 1 458 684
add 1 458 684
assign 1 458 685
emvisitGet 0 458 685
assign 1 458 686
nodeGet 0 458 686
assign 1 458 687
containedGet 0 458 687
assign 1 458 688
new 0 458 688
assign 1 458 689
get 1 458 689
assign 1 458 690
getBeavArg 1 458 690
assign 1 458 691
add 1 458 691
assign 1 458 692
new 0 458 692
assign 1 458 693
add 1 458 693
assign 1 458 694
addValue 1 458 694
assign 1 458 695
targsGet 0 458 695
assign 1 458 696
addValue 1 458 696
assign 1 458 697
new 0 458 697
assign 1 458 698
addValue 1 458 698
assign 1 458 699
assignToVVGet 0 458 699
assign 1 458 700
addValue 1 458 700
assign 1 458 701
new 0 458 701
assign 1 458 702
addValue 1 458 702
addValue 1 458 703
assign 1 459 704
new 0 459 704
assign 1 459 705
addValue 1 459 705
addValue 1 459 706
assign 1 460 707
new 0 460 707
assign 1 460 708
addValue 1 460 708
assign 1 460 709
targsGet 0 460 709
assign 1 460 710
addValue 1 460 710
assign 1 460 711
new 0 460 711
assign 1 460 712
emvisitGet 0 460 712
assign 1 460 713
nodeGet 0 460 713
assign 1 460 714
containedGet 0 460 714
assign 1 460 715
new 0 460 715
assign 1 460 716
get 1 460 716
assign 1 460 717
getBeavArg 1 460 717
assign 1 460 718
add 1 460 718
assign 1 460 719
new 0 460 719
assign 1 460 720
add 1 460 720
assign 1 460 721
addValue 1 460 721
assign 1 460 722
assignToVVGet 0 460 722
assign 1 460 723
addValue 1 460 723
assign 1 460 724
new 0 460 724
assign 1 460 725
addValue 1 460 725
addValue 1 460 726
assign 1 461 727
new 0 461 727
assign 1 461 728
addValue 1 461 728
assign 1 461 729
assignToVVGet 0 461 729
assign 1 461 730
addValue 1 461 730
assign 1 461 731
new 0 461 731
assign 1 461 732
addValue 1 461 732
addValue 1 461 733
assign 1 462 734
assignToCheckGet 0 462 734
addValue 1 462 735
assign 1 463 736
postOnceEvalGet 0 463 736
addValue 1 463 737
return 1 464 738
assign 1 469 803
isValidGet 0 469 803
assertTrue 1 469 804
assign 1 471 805
emvisitGet 0 471 805
assign 1 471 806
buildGet 0 471 806
assign 1 471 807
nlGet 0 471 807
assign 1 472 808
new 0 472 808
assign 1 473 809
preOnceEvalGet 0 473 809
addValue 1 473 810
assign 1 474 811
callArgsGet 0 474 811
addValue 1 474 812
assign 1 475 813
nodeGet 0 475 813
assign 1 475 814
heldGet 0 475 814
assign 1 475 815
checkTypesGet 0 475 815
assign 1 476 817
new 0 476 817
assign 1 476 818
emvisitGet 0 476 818
assign 1 476 819
nodeGet 0 476 819
assign 1 476 820
containedGet 0 476 820
assign 1 476 821
new 0 476 821
assign 1 476 822
get 1 476 822
assign 1 476 823
getBeavArg 1 476 823
assign 1 476 824
add 1 476 824
assign 1 476 825
new 0 476 825
assign 1 476 826
add 1 476 826
assign 1 476 827
addValue 1 476 827
assign 1 476 828
targsGet 0 476 828
assign 1 476 829
addValue 1 476 829
assign 1 476 830
new 0 476 830
assign 1 476 831
addValue 1 476 831
addValue 1 476 832
standardBlockAssign 2 477 833
assign 1 478 834
new 0 478 834
assign 1 478 835
addValue 1 478 835
addValue 1 478 836
assign 1 480 838
new 0 480 838
assign 1 480 839
addValue 1 480 839
assign 1 480 840
targsGet 0 480 840
assign 1 480 841
addValue 1 480 841
assign 1 480 842
new 0 480 842
assign 1 480 843
addValue 1 480 843
assign 1 480 844
addValue 1 480 844
assign 1 480 845
new 0 480 845
assign 1 480 846
emvisitGet 0 480 846
assign 1 480 847
nodeGet 0 480 847
assign 1 480 848
containedGet 0 480 848
assign 1 480 849
new 0 480 849
assign 1 480 850
get 1 480 850
assign 1 480 851
getBeavArg 1 480 851
assign 1 480 852
add 1 480 852
assign 1 480 853
new 0 480 853
assign 1 480 854
add 1 480 854
assign 1 480 855
addValue 1 480 855
assign 1 480 856
assignToVVGet 0 480 856
assign 1 480 857
addValue 1 480 857
assign 1 480 858
new 0 480 858
assign 1 480 859
addValue 1 480 859
addValue 1 480 860
assign 1 481 861
new 0 481 861
assign 1 481 862
addValue 1 481 862
assign 1 481 863
assignToVVGet 0 481 863
assign 1 481 864
addValue 1 481 864
assign 1 481 865
new 0 481 865
assign 1 481 866
addValue 1 481 866
addValue 1 481 867
assign 1 482 868
assignToCheckGet 0 482 868
addValue 1 482 869
assign 1 483 870
nodeGet 0 483 870
assign 1 483 871
heldGet 0 483 871
assign 1 483 872
checkTypesGet 0 483 872
assign 1 484 874
new 0 484 874
assign 1 484 875
addValue 1 484 875
addValue 1 484 876
assign 1 486 878
postOnceEvalGet 0 486 878
addValue 1 486 879
return 1 487 880
assign 1 492 943
isValidGet 0 492 943
assertTrue 1 492 944
checkRetainTo 0 493 945
assign 1 494 946
emvisitGet 0 494 946
assign 1 494 947
buildGet 0 494 947
assign 1 494 948
nlGet 0 494 948
assign 1 495 949
new 0 495 949
assign 1 496 950
preOnceEvalGet 0 496 950
addValue 1 496 951
assign 1 497 952
callArgsGet 0 497 952
addValue 1 497 953
assign 1 498 954
nodeGet 0 498 954
assign 1 498 955
heldGet 0 498 955
assign 1 498 956
checkTypesGet 0 498 956
assign 1 499 958
new 0 499 958
assign 1 499 959
emvisitGet 0 499 959
assign 1 499 960
nodeGet 0 499 960
assign 1 499 961
containedGet 0 499 961
assign 1 499 962
new 0 499 962
assign 1 499 963
get 1 499 963
assign 1 499 964
getBeavArg 1 499 964
assign 1 499 965
add 1 499 965
assign 1 499 966
new 0 499 966
assign 1 499 967
add 1 499 967
assign 1 499 968
addValue 1 499 968
assign 1 499 969
targsGet 0 499 969
assign 1 499 970
addValue 1 499 970
assign 1 499 971
new 0 499 971
assign 1 499 972
addValue 1 499 972
addValue 1 499 973
standardBlockAssign 2 500 974
assign 1 501 975
new 0 501 975
assign 1 501 976
addValue 1 501 976
addValue 1 501 977
assign 1 503 979
assignToVVGet 0 503 979
assign 1 503 980
addValue 1 503 980
assign 1 503 981
new 0 503 981
assign 1 503 982
addValue 1 503 982
addValue 1 503 983
assign 1 504 984
new 0 504 984
assign 1 504 985
addValue 1 504 985
assign 1 504 986
embedTargGet 0 504 986
assign 1 504 987
addValue 1 504 987
assign 1 504 988
new 0 504 988
assign 1 504 989
addValue 1 504 989
assign 1 504 990
targsGet 0 504 990
assign 1 504 991
addValue 1 504 991
assign 1 504 992
new 0 504 992
assign 1 504 993
addValue 1 504 993
assign 1 504 994
addValue 1 504 994
assign 1 504 995
new 0 504 995
assign 1 504 996
emvisitGet 0 504 996
assign 1 504 997
nodeGet 0 504 997
assign 1 504 998
containedGet 0 504 998
assign 1 504 999
new 0 504 999
assign 1 504 1000
get 1 504 1000
assign 1 504 1001
getBeavArg 1 504 1001
assign 1 504 1002
add 1 504 1002
assign 1 504 1003
new 0 504 1003
assign 1 504 1004
add 1 504 1004
assign 1 504 1005
addValue 1 504 1005
addValue 1 504 1006
assign 1 505 1007
assignToCheckGet 0 505 1007
addValue 1 505 1008
assign 1 506 1009
nodeGet 0 506 1009
assign 1 506 1010
heldGet 0 506 1010
assign 1 506 1011
checkTypesGet 0 506 1011
assign 1 507 1013
new 0 507 1013
assign 1 507 1014
addValue 1 507 1014
addValue 1 507 1015
assign 1 509 1017
postOnceEvalGet 0 509 1017
addValue 1 509 1018
return 1 510 1019
assign 1 515 1048
isValidGet 0 515 1048
assertTrue 1 515 1049
checkRetainTo 0 516 1050
assign 1 517 1051
emvisitGet 0 517 1051
assign 1 517 1052
buildGet 0 517 1052
assign 1 517 1053
nlGet 0 517 1053
assign 1 518 1054
new 0 518 1054
assign 1 519 1055
preOnceEvalGet 0 519 1055
addValue 1 519 1056
assign 1 520 1057
callArgsGet 0 520 1057
addValue 1 520 1058
assign 1 521 1059
assignToVVGet 0 521 1059
assign 1 521 1060
addValue 1 521 1060
assign 1 521 1061
new 0 521 1061
assign 1 521 1062
addValue 1 521 1062
addValue 1 521 1063
assign 1 522 1064
new 0 522 1064
assign 1 522 1065
addValue 1 522 1065
assign 1 522 1066
embedTargGet 0 522 1066
assign 1 522 1067
addValue 1 522 1067
assign 1 522 1068
new 0 522 1068
assign 1 522 1069
addValue 1 522 1069
assign 1 522 1070
targsGet 0 522 1070
assign 1 522 1071
addValue 1 522 1071
assign 1 522 1072
new 0 522 1072
assign 1 522 1073
addValue 1 522 1073
assign 1 522 1074
addValue 1 522 1074
assign 1 522 1075
new 0 522 1075
assign 1 522 1076
addValue 1 522 1076
addValue 1 522 1077
assign 1 523 1078
assignToCheckGet 0 523 1078
addValue 1 523 1079
assign 1 524 1080
postOnceEvalGet 0 524 1080
addValue 1 524 1081
return 1 525 1082
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 2001798761: return bem_nlGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1178476504: return bem_fromTypesGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 846242271: return bem_processCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 281832742: return bem_loadBuild_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1189558757: return bem_fromTypesSet_1(bevd_0);
case 224779883: return bem_processOptimizedGetter_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 77715863: return bem_processLiteralConstruct_1((BEC_5_10_BuildCallCursor) bevd_0);
case 2051196096: return bem_processEquals_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1292480624: return bem_processAssign_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1833349037: return bem_standardCall_1((BEC_5_10_BuildCallCursor) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1977543830: return bem_processNot_1((BEC_5_10_BuildCallCursor) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 825908811: return bem_processNotEquals_1((BEC_5_10_BuildCallCursor) bevd_0);
case 785892343: return bem_processOptimizedSetter_1((BEC_5_10_BuildCallCursor) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 429177731: return bem_standardBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 19297983: return bem_accessorCheckBlock_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1419087447: return bem_processCompare_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1046864252: return bem_processModify_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 436992814: return bem_standardBlockAssign_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1715203462: return bem_processIncDec_2((BEC_5_10_BuildCallCursor) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_14_BuildCAssembleFloat();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_14_BuildCAssembleFloat.bevs_inst = (BEC_5_14_BuildCAssembleFloat)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_14_BuildCAssembleFloat.bevs_inst;
}
}
}
