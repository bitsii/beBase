namespace be.BEL_4_Base {
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_6_BuildVisitPass12 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass12() { }
static BEC_3_5_5_6_BuildVisitPass12() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_4 = {0x47,0x45,0x54};
private static byte[] bels_5 = {0x5F,0x30};
private static byte[] bels_6 = {0x53,0x45,0x54};
private static byte[] bels_7 = {0x5F,0x31};
private static byte[] bels_8 = {0x53,0x45,0x54};
private static byte[] bels_9 = {0x43,0x61,0x6C,0x6C,0x20,0x68,0x65,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_11 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 64));
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x70,0x72,0x6F,0x62,0x61,0x62,0x6C,0x79,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x65,0x78,0x69,0x73,0x74,0x2C,0x20,0x76,0x65,0x72,0x69,0x66,0x79,0x20,0x6E,0x61,0x6D,0x65,0x20,0x61,0x6E,0x64,0x20,0x75,0x73,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 52));
private static byte[] bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74};
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_15 = {0x5F};
private static byte[] bels_16 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_17 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_18 = {0x6D,0x61,0x6E,0x79,0x5F,0x30};
public static new BEC_3_5_5_6_BuildVisitPass12 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_classnp;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAccessor_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_myselfn = null;
BEC_2_6_6_SystemObject bevl_myself = null;
BEC_2_6_6_SystemObject bevl_mtdmyn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_6_6_SystemObject bevl_myparn = null;
BEC_2_6_6_SystemObject bevl_mybr = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_myselfn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_myselfn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_myself = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_0));
bevl_myself.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_2_tmpvar_phold);
bevl_myself.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
bevt_3_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_3_tmpvar_phold);
bevl_myselfn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_myself);
bevl_mtdmyn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_4_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mtdmyn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_4_tmpvar_phold);
bevl_mtdmy = (new BEC_2_5_6_BuildMethod()).bem_new_0();
bevt_5_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_mtdmy.bemd_1(1725653351, BEL_4_Base.bevn_isGenAccessorSet_1, bevt_5_tmpvar_phold);
bevl_mtdmyn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_mtdmy);
bevl_myparn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_6_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_myparn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_6_tmpvar_phold);
bevl_myparn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myselfn);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myparn);
bevl_myselfn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_mybr = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_7_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_mybr.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_7_tmpvar_phold);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_mybr);
return bevl_mtdmyn;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getRetNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_retnoden = null;
BEC_2_6_6_SystemObject bevl_retnode = null;
BEC_2_6_6_SystemObject bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_retnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_retnoden.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_retnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_1));
bevl_retnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevl_retnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_retnode);
bevl_sn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_sn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_2));
bevl_sn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_3_tmpvar_phold);
bevl_retnoden.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_sn);
return bevl_retnoden;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAsNode_1(BEC_2_6_6_SystemObject beva_selfnode) {
BEC_2_6_6_SystemObject bevl_asnoden = null;
BEC_2_6_6_SystemObject bevl_asnode = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_asnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asnoden.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpvar_phold);
bevl_asnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_3));
bevl_asnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpvar_phold);
bevl_asnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asnode);
return bevl_asnoden;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_6_6_SystemObject bevl_tst = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ename = null;
BEC_2_6_6_SystemObject bevl_anode = null;
BEC_2_6_6_SystemObject bevl_rettnode = null;
BEC_2_6_6_SystemObject bevl_rin = null;
BEC_2_6_6_SystemObject bevl_sv = null;
BEC_2_6_6_SystemObject bevl_svn = null;
BEC_2_6_6_SystemObject bevl_svn2 = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_newNp = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_c1 = null;
BEC_2_6_6_SystemObject bevl_bn = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_102_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_165_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_182_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_183_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_186_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_192_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_193_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_195_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_198_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_200_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_201_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_204_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_205_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_206_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_13_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_firstGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ia = bevt_11_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpvar_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_14_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
} /* Line: 84 */
 else  /* Line: 81 */ {
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_20_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_tst = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_21_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 88 */ {
bevt_23_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 88 */ {
bevt_24_tmpvar_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_24_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_4));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_27_tmpvar_phold);
bevl_tst.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_30_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_5));
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_30_tmpvar_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_28_tmpvar_phold);
bevt_31_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 95 */ {
bevt_35_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_36_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_36_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 95 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 95 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_37_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold.bemd_1(1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_38_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_39_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_40_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_39_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_41_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_46_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_43_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_45_tmpvar_phold, bevl_anode);
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_47_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_50_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_lastGet_0();
bevt_49_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevl_rettnode = this.bem_getRetNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_51_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_51_tmpvar_phold);
bevt_53_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_52_tmpvar_phold);
bevl_rettnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevt_55_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_54_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rettnode);
bevt_57_tmpvar_phold = bevl_rettnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_56_tmpvar_phold.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevl_rin.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevt_58_tmpvar_phold = bevl_i.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_59_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_59_tmpvar_phold.bemd_1(419853240, BEL_4_Base.bevn_rtypeSet_1, bevl_i);
} /* Line: 115 */
} /* Line: 114 */
bevt_61_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_60_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_6));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_62_tmpvar_phold);
bevl_tst.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_7));
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_65_tmpvar_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_63_tmpvar_phold);
bevt_66_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_66_tmpvar_phold != null && bevt_66_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_66_tmpvar_phold).bevi_bool) /* Line: 125 */ {
bevt_70_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_71_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_71_tmpvar_phold);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 125 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
 else  /* Line: 125 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 125 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_72_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_72_tmpvar_phold.bemd_1(1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_73_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_73_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_74_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_75_tmpvar_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_74_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_75_tmpvar_phold);
bevt_76_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_77_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_76_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_77_tmpvar_phold);
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_78_tmpvar_phold = bevt_79_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_81_tmpvar_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_78_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_80_tmpvar_phold, bevl_anode);
bevt_83_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_82_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_85_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_84_tmpvar_phold = bevt_85_tmpvar_phold.bem_lastGet_0();
bevt_84_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_86_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bels_8));
bevl_sv = bevl_anode.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_86_tmpvar_phold, bevp_build);
bevt_87_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_sv.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_87_tmpvar_phold);
bevl_svn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_svn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_88_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_svn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevt_90_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_89_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn);
bevl_svn2 = (new BEC_2_5_4_BuildNode());
bevl_svn2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_91_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn2.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_91_tmpvar_phold);
bevl_svn2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevl_asn = this.bem_getAsNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_92_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_93_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn2);
bevt_96_tmpvar_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_95_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_asn);
bevl_svn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_rin.bemd_1(205397975, BEL_4_Base.bevn_syncVariable_1, this);
} /* Line: 159 */
} /* Line: 125 */
 else  /* Line: 88 */ {
break;
} /* Line: 88 */
} /* Line: 88 */
} /* Line: 88 */
 else  /* Line: 81 */ {
bevt_98_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_99_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_equals_1(bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_101_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_101_tmpvar_phold == null) {
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_100_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_100_tmpvar_phold.bevi_bool) /* Line: 166 */ {
bevt_103_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bels_9));
bevt_102_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_103_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_102_tmpvar_phold);
} /* Line: 167 */
bevt_105_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_107_tmpvar_phold == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 169 */ {
bevt_109_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_newNp = bevt_109_tmpvar_phold.bem_firstGet_0();
bevt_111_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_112_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_112_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 171 */ {
bevt_114_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_115_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_115_tmpvar_phold);
if (bevt_113_tmpvar_phold != null && bevt_113_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_113_tmpvar_phold).bevi_bool) /* Line: 172 */ {
bevt_118_tmpvar_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_119_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bels_10));
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_119_tmpvar_phold);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 172 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevl_newNp = beva_node.bem_secondGet_0();
bevt_121_tmpvar_phold = bevl_newNp.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_122_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_122_tmpvar_phold);
if (bevt_120_tmpvar_phold != null && bevt_120_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_120_tmpvar_phold).bevi_bool) /* Line: 174 */ {
bevt_124_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bem_add_1(bevt_125_tmpvar_phold);
bevt_123_tmpvar_phold.bem_print_0();
bevt_127_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(131, bels_12));
bevt_126_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 176 */
} /* Line: 174 */
 else  /* Line: 178 */ {
bevt_129_tmpvar_phold = bevo_1;
bevt_130_tmpvar_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_add_1(bevt_130_tmpvar_phold);
bevt_128_tmpvar_phold.bem_print_0();
bevt_132_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bels_14));
bevt_131_tmpvar_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 180 */
} /* Line: 172 */
bevt_133_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_133_tmpvar_phold.bemd_1(1572840142, BEL_4_Base.bevn_newNpSet_1, bevt_134_tmpvar_phold);
bevl_newNp.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 184 */
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_138_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_137_tmpvar_phold = bevt_138_tmpvar_phold.bem_lengthGet_0();
bevt_139_tmpvar_phold = bevo_2;
bevt_136_tmpvar_phold = bevt_137_tmpvar_phold.bem_subtract_1(bevt_139_tmpvar_phold);
bevt_135_tmpvar_phold.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_136_tmpvar_phold);
bevt_140_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_142_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_141_tmpvar_phold = bevt_142_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_140_tmpvar_phold.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_141_tmpvar_phold);
bevt_143_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_147_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_15));
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_148_tmpvar_phold);
bevt_151_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_149_tmpvar_phold);
bevt_143_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_144_tmpvar_phold);
bevt_154_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_155_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_16));
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpvar_phold);
if (bevt_152_tmpvar_phold != null && bevt_152_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_152_tmpvar_phold).bevi_bool) /* Line: 189 */ {
bevt_156_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_c0 = bevt_156_tmpvar_phold.bem_firstGet_0();
if (bevl_c0 == null) {
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_159_tmpvar_phold = bevl_c0.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_160_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_160_tmpvar_phold);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 191 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_161_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_164_tmpvar_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(389100841, BEL_4_Base.bevn_numAssignsGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_161_tmpvar_phold.bemd_1(400183094, BEL_4_Base.bevn_numAssignsSet_1, bevt_162_tmpvar_phold);
} /* Line: 192 */
bevt_165_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_c1 = bevt_165_tmpvar_phold.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_166_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_166_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_166_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_168_tmpvar_phold = bevl_c1.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_169_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_167_tmpvar_phold = bevt_168_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_169_tmpvar_phold);
if (bevt_167_tmpvar_phold != null && bevt_167_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_167_tmpvar_phold).bevi_bool) /* Line: 195 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 195 */ {
bevt_172_tmpvar_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_171_tmpvar_phold = bevt_172_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_173_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_17));
bevt_170_tmpvar_phold = bevt_171_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_173_tmpvar_phold);
if (bevt_170_tmpvar_phold != null && bevt_170_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_170_tmpvar_phold).bevi_bool) /* Line: 200 */ {
bevt_174_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_175_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_174_tmpvar_phold.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_175_tmpvar_phold);
} /* Line: 201 */
bevt_178_tmpvar_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_179_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_18));
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_179_tmpvar_phold);
if (bevt_176_tmpvar_phold != null && bevt_176_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_176_tmpvar_phold).bevi_bool) /* Line: 203 */ {
bevt_180_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_181_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_180_tmpvar_phold.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_181_tmpvar_phold);
} /* Line: 204 */
} /* Line: 203 */
} /* Line: 195 */
} /* Line: 189 */
 else  /* Line: 81 */ {
bevt_183_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_184_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_equals_1(bevt_184_tmpvar_phold);
if (bevt_182_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevl_bn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_186_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_186_tmpvar_phold == null) {
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_185_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_185_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_189_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bem_lastGet_0();
if (bevt_188_tmpvar_phold == null) {
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_187_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 210 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 210 */
 else  /* Line: 210 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 210 */ {
bevt_192_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bem_lastGet_0();
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_0(1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_bn.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_190_tmpvar_phold);
} /* Line: 211 */
 else  /* Line: 212 */ {
bevl_bn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 213 */
bevt_193_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevl_bn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_193_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_bn);
} /* Line: 216 */
 else  /* Line: 81 */ {
bevt_195_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_196_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bem_equals_1(bevt_196_tmpvar_phold);
if (bevt_194_tmpvar_phold.bevi_bool) /* Line: 217 */ {
bevl_pn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_198_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_198_tmpvar_phold == null) {
bevt_197_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_197_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_197_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevt_201_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_200_tmpvar_phold = bevt_201_tmpvar_phold.bem_lastGet_0();
if (bevt_200_tmpvar_phold == null) {
bevt_199_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_199_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_199_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 219 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 219 */
 else  /* Line: 219 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 219 */ {
bevt_204_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_lastGet_0();
bevt_202_tmpvar_phold = bevt_203_tmpvar_phold.bemd_0(1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_pn.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_202_tmpvar_phold);
} /* Line: 220 */
 else  /* Line: 221 */ {
bevl_pn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 222 */
bevt_205_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevl_pn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_205_tmpvar_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_pn);
} /* Line: 225 */
} /* Line: 81 */
} /* Line: 81 */
} /* Line: 81 */
} /* Line: 81 */
bevt_206_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_206_tmpvar_phold;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_classnpGet_0() {
return bevp_classnp;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_classnpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 68, 69, 70, 71, 72, 73, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 0, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 120, 121, 122, 123, 124, 125, 0, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139, 140, 141, 143, 144, 145, 146, 147, 149, 150, 151, 152, 153, 154, 155, 156, 158, 159, 165, 166, 167, 169, 0, 170, 171, 172, 0, 173, 174, 175, 176, 179, 180, 183, 184, 186, 187, 188, 189, 190, 191, 0, 192, 194, 195, 0, 200, 201, 203, 204, 208, 209, 210, 0, 211, 213, 215, 216, 217, 218, 219, 0, 220, 222, 224, 225, 227, 0};
public static new int[] bevs_smnlec
 = new int[] {33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33};
/* BEGIN LINEINFO 
assign 1 30 33
new 1 30 33
assign 1 31 33
VARGet 0 31 33
typenameSet 1 31 33
assign 1 32 33
new 0 32 33
assign 1 33 33
new 0 33 33
nameSet 1 33 33
assign 1 34 33
new 0 34 33
isTypedSet 1 34 33
namepathSet 1 35 33
assign 1 36 33
new 0 36 33
isArgSet 1 36 33
heldSet 1 37 33
assign 1 38 33
new 1 38 33
assign 1 39 33
METHODGet 0 39 33
typenameSet 1 39 33
assign 1 40 33
new 0 40 33
assign 1 41 33
new 0 41 33
isGenAccessorSet 1 41 33
heldSet 1 42 33
assign 1 43 33
new 1 43 33
assign 1 44 33
PARENSGet 0 44 33
typenameSet 1 44 33
addValue 1 45 33
addValue 1 46 33
addVariable 0 47 33
assign 1 48 33
new 1 48 33
assign 1 49 33
BRACESGet 0 49 33
typenameSet 1 49 33
addValue 1 50 33
return 1 51 33
assign 1 55 33
new 1 55 33
assign 1 56 33
CALLGet 0 56 33
typenameSet 1 56 33
assign 1 57 33
new 0 57 33
assign 1 58 33
new 0 58 33
nameSet 1 58 33
heldSet 1 59 33
assign 1 60 33
new 1 60 33
assign 1 61 33
VARGet 0 61 33
typenameSet 1 61 33
assign 1 62 33
new 0 62 33
heldSet 1 62 33
addValue 1 63 33
return 1 64 33
assign 1 68 33
new 1 68 33
assign 1 69 33
CALLGet 0 69 33
typenameSet 1 69 33
assign 1 70 33
new 0 70 33
assign 1 71 33
new 0 71 33
nameSet 1 71 33
heldSet 1 72 33
return 1 73 33
assign 1 81 33
typenameGet 0 81 33
assign 1 81 33
METHODGet 0 81 33
assign 1 81 33
equals 1 81 33
assign 1 82 33
containedGet 0 82 33
assign 1 82 33
firstGet 0 82 33
assign 1 82 33
containedGet 0 82 33
assign 1 82 33
firstGet 0 82 33
assign 1 83 33
heldGet 0 83 33
assign 1 83 33
new 0 83 33
isTypedSet 1 83 33
assign 1 84 33
heldGet 0 84 33
namepathSet 1 84 33
assign 1 85 33
typenameGet 0 85 33
assign 1 85 33
CLASSGet 0 85 33
assign 1 85 33
equals 1 85 33
assign 1 86 33
heldGet 0 86 33
assign 1 86 33
namepathGet 0 86 33
assign 1 87 33
new 0 87 33
assign 1 88 33
heldGet 0 88 33
assign 1 88 33
orderedVarsGet 0 88 33
assign 1 88 33
iteratorGet 0 88 33
assign 1 88 33
hasNextGet 0 88 33
assign 1 89 33
nextGet 0 89 33
assign 1 89 33
heldGet 0 89 33
assign 1 90 33
nameGet 0 90 33
assign 1 90 33
copy 0 90 33
nameSet 1 90 33
assign 1 91 33
new 0 91 33
accessorTypeSet 1 91 33
toAccessorName 0 92 33
assign 1 93 33
nameGet 0 93 33
assign 1 94 33
nameGet 0 94 33
assign 1 94 33
new 0 94 33
assign 1 94 33
add 1 94 33
nameSet 1 94 33
assign 1 95 33
isDeclaredGet 0 95 33
assign 1 95 33
heldGet 0 95 33
assign 1 95 33
methodsGet 0 95 33
assign 1 95 33
nameGet 0 95 33
assign 1 95 33
has 1 95 33
assign 1 95 33
not 0 95 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 97 33
getAccessor 1 97 33
assign 1 98 33
heldGet 0 98 33
propertySet 1 98 33
assign 1 99 33
heldGet 0 99 33
orgNameSet 1 99 33
assign 1 100 33
heldGet 0 100 33
assign 1 100 33
nameGet 0 100 33
nameSet 1 100 33
assign 1 101 33
heldGet 0 101 33
assign 1 101 33
new 0 101 33
numargsSet 1 101 33
assign 1 102 33
heldGet 0 102 33
assign 1 102 33
methodsGet 0 102 33
assign 1 102 33
heldGet 0 102 33
assign 1 102 33
nameGet 0 102 33
put 2 102 33
assign 1 103 33
heldGet 0 103 33
assign 1 103 33
orderedMethodsGet 0 103 33
addValue 1 103 33
assign 1 104 33
containedGet 0 104 33
assign 1 104 33
lastGet 0 104 33
addValue 1 104 33
assign 1 105 33
getRetNode 1 105 33
assign 1 106 33
new 1 106 33
copyLoc 1 107 33
assign 1 108 33
VARGet 0 108 33
typenameSet 1 108 33
assign 1 109 33
nameGet 0 109 33
assign 1 109 33
copy 0 109 33
heldSet 1 109 33
addValue 1 110 33
assign 1 111 33
containedGet 0 111 33
assign 1 111 33
lastGet 0 111 33
addValue 1 111 33
assign 1 112 33
containedGet 0 112 33
assign 1 112 33
firstGet 0 112 33
syncVariable 1 112 33
syncVariable 1 113 33
assign 1 114 33
isTypedGet 0 114 33
assign 1 115 33
heldGet 0 115 33
rtypeSet 1 115 33
assign 1 120 33
nameGet 0 120 33
assign 1 120 33
copy 0 120 33
nameSet 1 120 33
assign 1 121 33
new 0 121 33
accessorTypeSet 1 121 33
toAccessorName 0 122 33
assign 1 123 33
nameGet 0 123 33
assign 1 124 33
nameGet 0 124 33
assign 1 124 33
new 0 124 33
assign 1 124 33
add 1 124 33
nameSet 1 124 33
assign 1 125 33
isDeclaredGet 0 125 33
assign 1 125 33
heldGet 0 125 33
assign 1 125 33
methodsGet 0 125 33
assign 1 125 33
nameGet 0 125 33
assign 1 125 33
has 1 125 33
assign 1 125 33
not 0 125 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 127 33
getAccessor 1 127 33
assign 1 128 33
heldGet 0 128 33
propertySet 1 128 33
assign 1 129 33
heldGet 0 129 33
orgNameSet 1 129 33
assign 1 130 33
heldGet 0 130 33
assign 1 130 33
nameGet 0 130 33
nameSet 1 130 33
assign 1 131 33
heldGet 0 131 33
assign 1 131 33
new 0 131 33
numargsSet 1 131 33
assign 1 132 33
heldGet 0 132 33
assign 1 132 33
methodsGet 0 132 33
assign 1 132 33
heldGet 0 132 33
assign 1 132 33
nameGet 0 132 33
put 2 132 33
assign 1 133 33
heldGet 0 133 33
assign 1 133 33
orderedMethodsGet 0 133 33
addValue 1 133 33
assign 1 134 33
containedGet 0 134 33
assign 1 134 33
lastGet 0 134 33
addValue 1 134 33
assign 1 136 33
new 0 136 33
assign 1 136 33
tmpVar 2 136 33
assign 1 137 33
new 0 137 33
isArgSet 1 137 33
assign 1 138 33
new 1 138 33
copyLoc 1 139 33
assign 1 140 33
VARGet 0 140 33
typenameSet 1 140 33
heldSet 1 141 33
assign 1 143 33
containedGet 0 143 33
assign 1 143 33
firstGet 0 143 33
addValue 1 143 33
assign 1 144 33
new 0 144 33
copyLoc 1 145 33
assign 1 146 33
VARGet 0 146 33
typenameSet 1 146 33
heldSet 1 147 33
assign 1 149 33
getAsNode 1 149 33
assign 1 150 33
new 1 150 33
copyLoc 1 151 33
assign 1 152 33
VARGet 0 152 33
typenameSet 1 152 33
assign 1 153 33
nameGet 0 153 33
assign 1 153 33
copy 0 153 33
heldSet 1 153 33
addValue 1 154 33
addValue 1 155 33
assign 1 156 33
containedGet 0 156 33
assign 1 156 33
lastGet 0 156 33
addValue 1 156 33
addVariable 0 158 33
syncVariable 1 159 33
assign 1 165 33
typenameGet 0 165 33
assign 1 165 33
CALLGet 0 165 33
assign 1 165 33
equals 1 165 33
assign 1 166 33
heldGet 0 166 33
assign 1 166 33
undef 1 166 33
assign 1 167 33
new 0 167 33
assign 1 167 33
new 2 167 33
throw 1 167 33
assign 1 169 33
heldGet 0 169 33
assign 1 169 33
isConstructGet 0 169 33
assign 1 169 33
heldGet 0 169 33
assign 1 169 33
newNpGet 0 169 33
assign 1 169 33
undef 1 169 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 170 33
containedGet 0 170 33
assign 1 170 33
firstGet 0 170 33
assign 1 171 33
typenameGet 0 171 33
assign 1 171 33
NAMEPATHGet 0 171 33
assign 1 171 33
notEquals 1 171 33
assign 1 172 33
typenameGet 0 172 33
assign 1 172 33
VARGet 0 172 33
assign 1 172 33
equals 1 172 33
assign 1 172 33
heldGet 0 172 33
assign 1 172 33
nameGet 0 172 33
assign 1 172 33
new 0 172 33
assign 1 172 33
equals 1 172 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 173 33
secondGet 0 173 33
assign 1 174 33
typenameGet 0 174 33
assign 1 174 33
NAMEPATHGet 0 174 33
assign 1 174 33
notEquals 1 174 33
assign 1 175 33
new 0 175 33
assign 1 175 33
toString 0 175 33
assign 1 175 33
add 1 175 33
print 0 175 33
assign 1 176 33
new 0 176 33
assign 1 176 33
new 2 176 33
throw 1 176 33
assign 1 179 33
new 0 179 33
assign 1 179 33
toString 0 179 33
assign 1 179 33
add 1 179 33
print 0 179 33
assign 1 180 33
new 0 180 33
assign 1 180 33
new 2 180 33
throw 1 180 33
assign 1 183 33
heldGet 0 183 33
assign 1 183 33
heldGet 0 183 33
newNpSet 1 183 33
delete 0 184 33
assign 1 186 33
heldGet 0 186 33
assign 1 186 33
containedGet 0 186 33
assign 1 186 33
lengthGet 0 186 33
assign 1 186 33
new 0 186 33
assign 1 186 33
subtract 1 186 33
numargsSet 1 186 33
assign 1 187 33
heldGet 0 187 33
assign 1 187 33
heldGet 0 187 33
assign 1 187 33
nameGet 0 187 33
orgNameSet 1 187 33
assign 1 188 33
heldGet 0 188 33
assign 1 188 33
heldGet 0 188 33
assign 1 188 33
nameGet 0 188 33
assign 1 188 33
new 0 188 33
assign 1 188 33
add 1 188 33
assign 1 188 33
heldGet 0 188 33
assign 1 188 33
numargsGet 0 188 33
assign 1 188 33
toString 0 188 33
assign 1 188 33
add 1 188 33
nameSet 1 188 33
assign 1 189 33
heldGet 0 189 33
assign 1 189 33
orgNameGet 0 189 33
assign 1 189 33
new 0 189 33
assign 1 189 33
equals 1 189 33
assign 1 190 33
containedGet 0 190 33
assign 1 190 33
firstGet 0 190 33
assign 1 191 33
def 1 191 33
assign 1 191 33
typenameGet 0 191 33
assign 1 191 33
VARGet 0 191 33
assign 1 191 33
equals 1 191 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 192 33
heldGet 0 192 33
assign 1 192 33
heldGet 0 192 33
assign 1 192 33
numAssignsGet 0 192 33
assign 1 192 33
increment 0 192 33
numAssignsSet 1 192 33
assign 1 194 33
containedGet 0 194 33
assign 1 194 33
secondGet 0 194 33
assign 1 195 33
def 1 195 33
assign 1 195 33
typenameGet 0 195 33
assign 1 195 33
CALLGet 0 195 33
assign 1 195 33
equals 1 195 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 200 33
heldGet 0 200 33
assign 1 200 33
nameGet 0 200 33
assign 1 200 33
new 0 200 33
assign 1 200 33
equals 1 200 33
assign 1 201 33
heldGet 0 201 33
assign 1 201 33
new 0 201 33
isOnceSet 1 201 33
assign 1 203 33
heldGet 0 203 33
assign 1 203 33
nameGet 0 203 33
assign 1 203 33
new 0 203 33
assign 1 203 33
equals 1 203 33
assign 1 204 33
heldGet 0 204 33
assign 1 204 33
new 0 204 33
isManySet 1 204 33
assign 1 208 33
typenameGet 0 208 33
assign 1 208 33
BRACESGet 0 208 33
assign 1 208 33
equals 1 208 33
assign 1 209 33
new 1 209 33
assign 1 210 33
containedGet 0 210 33
assign 1 210 33
def 1 210 33
assign 1 210 33
containedGet 0 210 33
assign 1 210 33
lastGet 0 210 33
assign 1 210 33
def 1 210 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 211 33
containedGet 0 211 33
assign 1 211 33
lastGet 0 211 33
assign 1 211 33
nlcGet 0 211 33
nlcSet 1 211 33
copyLoc 1 213 33
assign 1 215 33
RBRACESGet 0 215 33
typenameSet 1 215 33
addValue 1 216 33
assign 1 217 33
typenameGet 0 217 33
assign 1 217 33
PARENSGet 0 217 33
assign 1 217 33
equals 1 217 33
assign 1 218 33
new 1 218 33
assign 1 219 33
containedGet 0 219 33
assign 1 219 33
def 1 219 33
assign 1 219 33
containedGet 0 219 33
assign 1 219 33
lastGet 0 219 33
assign 1 219 33
def 1 219 33
assign 1 0 33
assign 1 0 33
assign 1 0 33
assign 1 220 33
containedGet 0 220 33
assign 1 220 33
lastGet 0 220 33
assign 1 220 33
nlcGet 0 220 33
nlcSet 1 220 33
copyLoc 1 222 33
assign 1 224 33
RPARENSGet 0 224 33
typenameSet 1 224 33
addValue 1 225 33
assign 1 227 33
nextDescendGet 0 227 33
return 1 227 33
return 1 0 33
assign 1 0 33
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 487303277: return bem_classnpGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 2055890305: return bem_getRetNode_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 498385530: return bem_classnpSet_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 654182780: return bem_getAsNode_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1438955473: return bem_getAccessor_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass12();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass12.bevs_inst = (BEC_3_5_5_6_BuildVisitPass12)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass12.bevs_inst;
}
}
}
