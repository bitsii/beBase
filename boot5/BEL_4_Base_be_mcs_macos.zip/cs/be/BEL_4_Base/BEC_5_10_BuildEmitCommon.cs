namespace be.BEL_4_Base {
/* File: source/build/EmitCommon.be */
public class BEC_5_10_BuildEmitCommon : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_10_BuildEmitCommon() { }
static BEC_5_10_BuildEmitCommon() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_4 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_5 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_6 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_7 = {0x20,0x3D,0x3D,0x20};
private static byte[] bels_8 = {0x20,0x21,0x3D,0x20};
private static byte[] bels_9 = {0x62,0x65};
private static byte[] bels_10 = {0x63,0x73};
private static byte[] bels_11 = {0x20,0x69,0x73,0x20};
private static byte[] bels_12 = {0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x6F,0x66,0x20};
private static byte[] bels_13 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 33));
private static byte[] bels_14 = {0x42,0x45,0x4C,0x5F};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 4));
private static byte[] bels_15 = {0x5F};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_15, 1));
private static byte[] bels_16 = {0x2E};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 1));
private static byte[] bels_17 = {0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x69,0x6E,0x67,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 17));
private static byte[] bels_18 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_18, 2));
private static byte[] bels_19 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_19, 3));
private static byte[] bels_20 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_20, 4));
private static byte[] bels_21 = {0x20};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_21, 1));
private static byte[] bels_22 = {0x2F,0x2A,0x20,0x42,0x45,0x47,0x49,0x4E,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20};
private static byte[] bels_23 = {0x2C,0x20};
private static byte[] bels_24 = {0x2C,0x20};
private static byte[] bels_25 = {0x20};
private static byte[] bels_26 = {0x20};
private static byte[] bels_27 = {0x20};
private static byte[] bels_28 = {0x45,0x4E,0x44,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20,0x2A,0x2F};
private static byte[] bels_29 = {0x6A,0x73};
private static byte[] bels_30 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_30, 11));
private static byte[] bels_31 = {0x2E,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_31, 11));
private static byte[] bels_32 = {0x2E,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_32, 12));
private static byte[] bels_33 = {0x63,0x73};
private static byte[] bels_34 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_36 = {0x6A,0x76};
private static byte[] bels_37 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_38 = {0x6A,0x73};
private static byte[] bels_39 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_40 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_41 = {0x5D,0x3B};
private static byte[] bels_42 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_43 = {0x7D,0x3B};
private static byte[] bels_44 = {0x63,0x73};
private static byte[] bels_45 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_46 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_47 = {0x6A,0x76};
private static byte[] bels_48 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_49 = {0x6A,0x73};
private static byte[] bels_50 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_51 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_52 = {0x5D,0x3B};
private static byte[] bels_53 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_54 = {0x7D,0x3B};
private static byte[] bels_55 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_56 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_59 = {};
private static byte[] bels_60 = {};
private static byte[] bels_61 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_62 = {};
private static byte[] bels_63 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_64 = {0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_65 = {0x28,0x29,0x3B};
private static byte[] bels_66 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_67 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_68 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62};
private static byte[] bels_69 = {0x20,0x20,0x7B};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_69, 3));
private static byte[] bels_70 = {0x20,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x66,0x61,0x6C,0x73,0x65,0x3B};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 19));
private static byte[] bels_71 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_72 = {0x6A,0x76};
private static byte[] bels_73 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x2E,0x70,0x75,0x74,0x28};
private static byte[] bels_74 = {0x2C,0x20,0x43,0x6C,0x61,0x73,0x73,0x2E,0x66,0x6F,0x72,0x4E,0x61,0x6D,0x65,0x28};
private static byte[] bels_75 = {0x29,0x29,0x3B};
private static byte[] bels_76 = {0x63,0x73};
private static byte[] bels_77 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_78 = {0x5D,0x20,0x3D,0x20,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_79 = {0x29,0x3B};
private static byte[] bels_80 = {0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_81 = {0x29};
private static byte[] bels_82 = {0x2E,0x47,0x65,0x74,0x46,0x69,0x65,0x6C,0x64,0x28};
private static byte[] bels_83 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_84 = {0x29,0x2E,0x47,0x65,0x74,0x56,0x61,0x6C,0x75,0x65,0x28,0x6E,0x75,0x6C,0x6C,0x29,0x3B};
private static byte[] bels_85 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_85, 4));
private static byte[] bels_86 = {0x28,0x29};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_86, 2));
private static byte[] bels_87 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_88 = {0x29,0x3B};
private static byte[] bels_89 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_90 = {0x29,0x3B};
private static byte[] bels_91 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_91, 9));
private static byte[] bels_92 = {0x3B};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_92, 1));
private static byte[] bels_93 = {0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_94 = {0x20,0x3D,0x20,0x67,0x65,0x74,0x43,0x61,0x6C,0x6C,0x49,0x64,0x28};
private static byte[] bels_95 = {0x29,0x3B};
private static byte[] bels_96 = {0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_97 = {0x2C,0x20};
private static byte[] bels_98 = {0x29,0x3B};
private static byte[] bels_99 = {0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_100 = {0x2C,0x20};
private static byte[] bels_101 = {0x29,0x3B};
private static byte[] bels_102 = {0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_102, 11));
private static byte[] bels_103 = {0x20,0x7B};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_103, 2));
private static byte[] bels_104 = {0x6A,0x76};
private static byte[] bels_105 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_105, 14));
private static byte[] bels_106 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_106, 9));
private static byte[] bels_107 = {0x63,0x73};
private static byte[] bels_108 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_108, 13));
private static byte[] bels_109 = {0x29,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_109, 4));
private static byte[] bels_110 = {0x69,0x66,0x20,0x28,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x29,0x20,0x7B,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x3B,0x20,0x7D};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_110, 26));
private static byte[] bels_111 = {0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x74,0x72,0x75,0x65,0x3B};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_111, 17));
private static byte[] bels_112 = {0x6A,0x76};
private static byte[] bels_113 = {0x63,0x73};
private static byte[] bels_114 = {0x7D};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_114, 1));
private static byte[] bels_115 = {0x7D};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_115, 1));
private static byte[] bels_116 = {0x7D};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_116, 1));
private static byte[] bels_117 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_117, 60));
private static byte[] bels_118 = {};
private static byte[] bels_119 = {0x6A,0x76};
private static byte[] bels_120 = {0x63,0x73};
private static byte[] bels_121 = {0x7D,0x20,0x7D};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_121, 3));
private static byte[] bels_122 = {0x7D};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_122, 1));
private static byte[] bels_123 = {};
private static byte[] bels_124 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bels_125 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_126 = {0x62,0x65,0x76,0x61,0x5F};
private static byte[] bels_127 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bels_128 = {0x20};
private static byte[] bels_129 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_129, 4));
private static byte[] bels_130 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_130, 4));
private static byte[] bels_131 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_132 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_133 = {0x2C,0x20};
private static byte[] bels_134 = {0x4E,0x75,0x6C,0x6C,0x20,0x61,0x72,0x67,0x20,0x68,0x65,0x6C,0x64,0x20};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_134, 14));
private static byte[] bels_135 = {0x6A,0x73};
private static byte[] bels_136 = {0x3B};
private static byte[] bels_137 = {0x20,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x3B};
private static byte[] bels_138 = {0x20};
private static byte[] bels_139 = {0x28};
private static byte[] bels_140 = {0x29};
private static byte[] bels_141 = {0x20,0x7B};
private static byte[] bels_142 = {0x2F};
private static BEC_4_3_MathInt bevo_35 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_36 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_143 = {0x3B};
private static byte[] bels_144 = {0x62,0x65,0x6D,0x64,0x5F};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_144, 5));
private static byte[] bels_145 = {0x62,0x65,0x6D,0x64,0x5F,0x78};
private static byte[] bels_146 = {0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static byte[] bels_147 = {0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static BEC_4_3_MathInt bevo_38 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_148 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_148, 2));
private static byte[] bels_149 = {0x20,0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_149, 6));
private static BEC_4_3_MathInt bevo_41 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_150 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_150, 2));
private static byte[] bels_151 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_43 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_151, 5));
private static BEC_4_3_MathInt bevo_44 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_152 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_45 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_152, 2));
private static byte[] bels_153 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_6_TextString bevo_46 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_153, 9));
private static byte[] bels_154 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_6_TextString bevo_47 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_154, 8));
private static byte[] bels_155 = {0x20};
private static byte[] bels_156 = {0x28};
private static byte[] bels_157 = {0x29};
private static byte[] bels_158 = {0x20,0x7B};
private static byte[] bels_159 = {0x73,0x77,0x69,0x74,0x63,0x68,0x20,0x28,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x29,0x20,0x7B};
private static byte[] bels_160 = {0x63,0x61,0x73,0x65,0x20};
private static byte[] bels_161 = {0x3A,0x20};
private static BEC_4_3_MathInt bevo_48 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_162 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_4_6_TextString bevo_49 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_162, 6));
private static byte[] bels_163 = {0x69,0x66,0x20,0x28,0x63,0x61,0x6C,0x6C,0x49,0x64,0x20,0x3D,0x3D,0x20};
private static byte[] bels_164 = {0x29,0x20,0x7B};
private static byte[] bels_165 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x6D,0x5F};
private static byte[] bels_166 = {0x28};
private static BEC_4_3_MathInt bevo_50 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_167 = {0x20};
private static BEC_4_6_TextString bevo_51 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_167, 1));
private static byte[] bels_168 = {};
private static BEC_4_3_MathInt bevo_52 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_169 = {0x2C,0x20};
private static byte[] bels_170 = {};
private static byte[] bels_171 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_53 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_171, 5));
private static BEC_4_3_MathInt bevo_54 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_172 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static BEC_4_6_TextString bevo_55 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_172, 7));
private static byte[] bels_173 = {0x5D};
private static BEC_4_6_TextString bevo_56 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_173, 1));
private static byte[] bels_174 = {0x29,0x3B};
private static byte[] bels_175 = {0x7D};
private static byte[] bels_176 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_177 = {0x7D};
private static byte[] bels_178 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static BEC_4_6_TextString bevo_57 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_178, 7));
private static byte[] bels_179 = {0x2E};
private static BEC_4_6_TextString bevo_58 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_179, 1));
private static byte[] bels_180 = {0x28};
private static byte[] bels_181 = {0x29,0x3B};
private static byte[] bels_182 = {0x7D};
private static byte[] bels_183 = {0x2F};
private static byte[] bels_184 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x66,0x69,0x72,0x73,0x74,0x53,0x6C,0x6F,0x74,0x4E,0x61,0x74,0x69,0x76,0x65,0x2D,0x2A};
private static byte[] bels_185 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x6E,0x61,0x74,0x69,0x76,0x65,0x53,0x6C,0x6F,0x74,0x73};
private static BEC_4_3_MathInt bevo_59 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_186 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bels_187 = {0x20,0x7B};
private static byte[] bels_188 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_189 = {0x28,0x29,0x3B};
private static byte[] bels_190 = {0x7D};
private static byte[] bels_191 = {0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bels_192 = {0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bels_193 = {0x20,0x7B};
private static byte[] bels_194 = {};
private static byte[] bels_195 = {0x20,0x3D,0x20};
private static byte[] bels_196 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_197 = {0x7D};
private static byte[] bels_198 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bels_199 = {0x20,0x7B};
private static byte[] bels_200 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_201 = {0x3B};
private static byte[] bels_202 = {0x7D};
private static byte[] bels_203 = {0x63,0x6C,0x6E,0x61,0x6D,0x65};
private static byte[] bels_204 = {0x63,0x6C,0x66,0x69,0x6C,0x65};
private static byte[] bels_205 = {0x62,0x65,0x63,0x63,0x5F};
private static BEC_4_6_TextString bevo_60 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_205, 5));
private static BEC_4_3_MathInt bevo_61 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_206 = {0x2C};
private static BEC_4_6_TextString bevo_62 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_206, 1));
private static byte[] bels_207 = {0x62,0x79,0x74,0x65,0x5B,0x5D,0x20,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bels_208 = {0x28,0x29};
private static byte[] bels_209 = {0x20,0x7B};
private static byte[] bels_210 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bels_211 = {0x3B};
private static byte[] bels_212 = {0x7D};
private static byte[] bels_213 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_214 = {0x3B};
private static byte[] bels_215 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_216 = {0x3B};
private static byte[] bels_217 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_218 = {0x2F,0x2A,0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_219 = {0x20,0x2A,0x2F};
private static byte[] bels_220 = {0x20,0x7B};
private static byte[] bels_221 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_222 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_223 = {0x20,0x7D};
private static byte[] bels_224 = {0x63,0x73};
private static byte[] bels_225 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_226 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_227 = {0x20,0x7D};
private static byte[] bels_228 = {0x7D};
private static byte[] bels_229 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_63 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_229, 14));
private static byte[] bels_230 = {0x20};
private static BEC_4_6_TextString bevo_64 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_230, 1));
private static byte[] bels_231 = {};
private static byte[] bels_232 = {};
private static byte[] bels_233 = {0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_234 = {0x20,0x2F,0x2A,0x20};
private static byte[] bels_235 = {0x20,0x2A,0x2F,0x20,0x7B};
private static byte[] bels_236 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_237 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x68,0x69,0x73,0x3B};
private static BEC_4_3_MathInt bevo_65 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_238 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_239 = {0x5B};
private static byte[] bels_240 = {0x5D,0x3B};
private static byte[] bels_241 = {0x7D,0x20,0x2F,0x2A,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x65,0x6E,0x64,0x2A,0x2F};
private static byte[] bels_242 = {0x7D,0x20,0x2F,0x2A,0x20};
private static byte[] bels_243 = {0x20,0x2A,0x2F};
private static byte[] bels_244 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_245 = {};
private static byte[] bels_246 = {0x21,0x28};
private static byte[] bels_247 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_248 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x26,0x26,0x20};
private static byte[] bels_249 = {0x20,0x26,0x26,0x20};
private static byte[] bels_250 = {0x6A,0x73};
private static byte[] bels_251 = {0x28};
private static byte[] bels_252 = {0x6A,0x73};
private static byte[] bels_253 = {0x29};
private static byte[] bels_254 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_255 = {0x29};
private static byte[] bels_256 = {0x69,0x66,0x20,0x28};
private static byte[] bels_257 = {0x29};
private static byte[] bels_258 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_259 = {0x69,0x66,0x20,0x28};
private static byte[] bels_260 = {0x29};
private static byte[] bels_261 = {0x3B};
private static BEC_4_6_TextString bevo_66 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_261, 1));
private static byte[] bels_262 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x6C,0x69,0x74,0x65,0x72,0x61,0x6C,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_263 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_264 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66};
private static byte[] bels_265 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_266 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_267 = {};
private static byte[] bels_268 = {0x20};
private static BEC_4_6_TextString bevo_67 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_268, 1));
private static byte[] bels_269 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_68 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_269, 3));
private static byte[] bels_270 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_271 = {0x28};
private static BEC_4_6_TextString bevo_69 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_271, 1));
private static byte[] bels_272 = {0x29};
private static BEC_4_6_TextString bevo_70 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_272, 1));
private static byte[] bels_273 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_274 = {0x29,0x3B};
private static byte[] bels_275 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_4_6_TextString bevo_71 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_275, 5));
private static byte[] bels_276 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_4_3_MathInt bevo_72 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static byte[] bels_277 = {0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20};
private static BEC_4_6_TextString bevo_73 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_277, 51));
private static byte[] bels_278 = {0x20,0x21,0x21,0x21};
private static byte[] bels_279 = {0x21,0x21,0x20};
private static byte[] bels_280 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_281 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_282 = {0x73,0x65,0x6C,0x66,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x74,0x6F};
private static byte[] bels_283 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_284 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_285 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_286 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_287 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_288 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_289 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_290 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_291 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x75,0x6E,0x64,0x65,0x66,0x2F,0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] bels_292 = {0x75};
private static byte[] bels_293 = {0x69,0x66,0x20,0x28};
private static byte[] bels_294 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static byte[] bels_295 = {0x20,0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_296 = {0x7D};
private static byte[] bels_297 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_298 = {};
private static byte[] bels_299 = {0x20};
private static BEC_4_6_TextString bevo_74 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_299, 1));
private static byte[] bels_300 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_301 = {0x3B};
private static byte[] bels_302 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_303 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_304 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_305 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_306 = {0x5F};
private static byte[] bels_307 = {0x42,0x61,0x64,0x20,0x6E,0x61,0x6D,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_75 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_307, 18));
private static byte[] bels_308 = {0x20};
private static BEC_4_6_TextString bevo_76 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_308, 1));
private static byte[] bels_309 = {0x20};
private static BEC_4_6_TextString bevo_77 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_309, 1));
private static byte[] bels_310 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_311 = {0x73,0x75,0x70,0x65,0x72};
private static BEC_4_3_MathInt bevo_78 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_79 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_312 = {0x2C,0x20};
private static byte[] bels_313 = {0x20};
private static byte[] bels_314 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static byte[] bels_315 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_316 = {0x3B};
private static byte[] bels_317 = {0x69,0x73,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x69,0x73,0x54,0x79,0x70,0x65,0x64};
private static byte[] bels_318 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_319 = {};
private static byte[] bels_320 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_80 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_320, 3));
private static byte[] bels_321 = {0x3B};
private static BEC_4_6_TextString bevo_81 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_321, 1));
private static byte[] bels_322 = {0x20};
private static BEC_4_6_TextString bevo_82 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_322, 1));
private static byte[] bels_323 = {};
private static byte[] bels_324 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_83 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_324, 3));
private static byte[] bels_325 = {0x6A,0x76};
private static byte[] bels_326 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bels_327 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bels_328 = {0x63,0x73};
private static byte[] bels_329 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_330 = {0x29,0x29,0x20,0x7B};
private static byte[] bels_331 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_84 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_331, 4));
private static byte[] bels_332 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_85 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_332, 11));
private static byte[] bels_333 = {0x62,0x65,0x6C,0x73,0x5F};
private static BEC_4_6_TextString bevo_86 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_333, 5));
private static byte[] bels_334 = {0x5B};
private static BEC_4_6_TextString bevo_87 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_334, 1));
private static byte[] bels_335 = {0x5D};
private static BEC_4_6_TextString bevo_88 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_335, 1));
private static BEC_4_3_MathInt bevo_89 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_336 = {0x2C};
private static BEC_4_6_TextString bevo_90 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_336, 1));
private static byte[] bels_337 = {0x74,0x72,0x75,0x65};
private static byte[] bels_338 = {0x55,0x4E,0x48,0x41,0x4E,0x44,0x4C,0x45,0x44,0x20,0x4C,0x49,0x54,0x45,0x52,0x41,0x4C,0x20,0x54,0x59,0x50,0x45,0x20};
private static BEC_4_6_TextString bevo_91 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_338, 23));
private static byte[] bels_339 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_92 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_339, 4));
private static byte[] bels_340 = {0x28,0x29};
private static BEC_4_6_TextString bevo_93 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_340, 2));
private static byte[] bels_341 = {0x28};
private static BEC_4_6_TextString bevo_94 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_341, 1));
private static byte[] bels_342 = {0x29};
private static BEC_4_6_TextString bevo_95 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_342, 1));
private static byte[] bels_343 = {0x20};
private static byte[] bels_344 = {0x6F,0x68,0x20,0x6E,0x6F,0x65,0x73,0x20,0x6F,0x6E,0x63,0x65,0x20,0x64,0x65,0x63,0x65,0x64,0x20};
private static BEC_4_6_TextString bevo_96 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_344, 19));
private static byte[] bels_345 = {0x74,0x72,0x75,0x65};
private static byte[] bels_346 = {0x3B};
private static byte[] bels_347 = {0x3B};
private static byte[] bels_348 = {0x2E};
private static byte[] bels_349 = {0x28};
private static byte[] bels_350 = {0x29,0x3B};
private static byte[] bels_351 = {0x2E};
private static byte[] bels_352 = {0x28};
private static byte[] bels_353 = {0x29,0x3B};
private static byte[] bels_354 = {0x2E};
private static byte[] bels_355 = {0x28};
private static byte[] bels_356 = {0x29,0x3B};
private static byte[] bels_357 = {0x2E};
private static byte[] bels_358 = {0x28};
private static byte[] bels_359 = {0x29,0x3B};
private static byte[] bels_360 = {};
private static byte[] bels_361 = {0x78};
private static BEC_4_3_MathInt bevo_97 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_362 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_3_MathInt bevo_98 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_363 = {0x2C,0x20};
private static byte[] bels_364 = {};
private static byte[] bels_365 = {0x2E,0x62,0x65,0x6D,0x64,0x5F};
private static byte[] bels_366 = {0x28};
private static byte[] bels_367 = {0x2C,0x20};
private static byte[] bels_368 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_369 = {0x29,0x3B};
private static byte[] bels_370 = {0x7D};
private static byte[] bels_371 = {0x6A,0x76};
private static byte[] bels_372 = {0x63,0x73};
private static byte[] bels_373 = {0x7D};
private static byte[] bels_374 = {0x3B};
private static byte[] bels_375 = {0x28};
private static byte[] bels_376 = {0x6A,0x73};
private static byte[] bels_377 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_378 = {0x29};
private static byte[] bels_379 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_380 = {0x29};
private static byte[] bels_381 = {0x29};
private static byte[] bels_382 = {0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_383 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_99 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_383, 4));
private static byte[] bels_384 = {0x28};
private static BEC_4_6_TextString bevo_100 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_384, 1));
private static byte[] bels_385 = {0x29};
private static BEC_4_6_TextString bevo_101 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_385, 1));
private static byte[] bels_386 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_102 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_386, 4));
private static byte[] bels_387 = {0x28};
private static BEC_4_6_TextString bevo_103 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_387, 1));
private static byte[] bels_388 = {0x66,0x29};
private static BEC_4_6_TextString bevo_104 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_388, 2));
private static byte[] bels_389 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_105 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_389, 4));
private static byte[] bels_390 = {0x28};
private static BEC_4_6_TextString bevo_106 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_390, 1));
private static byte[] bels_391 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_107 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_391, 2));
private static byte[] bels_392 = {0x29};
private static BEC_4_6_TextString bevo_108 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_392, 1));
private static byte[] bels_393 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_109 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_393, 4));
private static byte[] bels_394 = {0x28};
private static BEC_4_6_TextString bevo_110 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_394, 1));
private static byte[] bels_395 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_111 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_395, 2));
private static byte[] bels_396 = {0x29};
private static BEC_4_6_TextString bevo_112 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_396, 1));
private static byte[] bels_397 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x62,0x79,0x74,0x65,0x5B,0x5D,0x20};
private static byte[] bels_398 = {0x20,0x3D,0x20,0x7B};
private static byte[] bels_399 = {0x7D,0x3B};
private static byte[] bels_400 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_401 = {0x77,0x68,0x69,0x6C,0x65,0x20,0x28,0x74,0x72,0x75,0x65,0x29};
private static byte[] bels_402 = {0x20,0x65,0x6C,0x73,0x65,0x20};
private static byte[] bels_403 = {0x74,0x72,0x79,0x20};
private static byte[] bels_404 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_405 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_406 = {0x74,0x68,0x69,0x73};
private static byte[] bels_407 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_408 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_409 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_410 = {0x74,0x68,0x69,0x73};
private static byte[] bels_411 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_412 = {};
private static byte[] bels_413 = {};
private static byte[] bels_414 = {};
private static byte[] bels_415 = {};
private static byte[] bels_416 = {};
private static byte[] bels_417 = {};
private static byte[] bels_418 = {};
private static byte[] bels_419 = {};
private static BEC_4_6_TextString bevo_113 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_419, 0));
private static byte[] bels_420 = {0x5F};
private static BEC_4_6_TextString bevo_114 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_420, 1));
private static byte[] bels_421 = {0x5F};
private static byte[] bels_422 = {0x42,0x45,0x43,0x5F};
private static BEC_4_6_TextString bevo_115 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_422, 4));
private static byte[] bels_423 = {0x2E};
private static BEC_4_6_TextString bevo_116 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_423, 1));
private static byte[] bels_424 = {0x62,0x65,0x2E};
private static BEC_4_6_TextString bevo_117 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_424, 3));
public static new BEC_5_10_BuildEmitCommon bevs_inst;
public BEC_5_11_BuildClassConfig bevp_classConf;
public BEC_5_11_BuildClassConfig bevp_parentConf;
public BEC_4_6_TextString bevp_emitLang;
public BEC_4_6_TextString bevp_fileExt;
public BEC_4_6_TextString bevp_exceptDec;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_q;
public BEC_9_3_ContainerMap bevp_ccCache;
public BEC_5_8_BuildNamePath bevp_objectNp;
public BEC_5_8_BuildNamePath bevp_boolNp;
public BEC_5_8_BuildNamePath bevp_intNp;
public BEC_5_8_BuildNamePath bevp_floatNp;
public BEC_5_8_BuildNamePath bevp_stringNp;
public BEC_4_6_TextString bevp_trueValue;
public BEC_4_6_TextString bevp_falseValue;
public BEC_4_6_TextString bevp_instanceEqual;
public BEC_4_6_TextString bevp_instanceNotEqual;
public BEC_4_6_TextString bevp_libEmitName;
public BEC_4_6_TextString bevp_fullLibEmitName;
public BEC_2_4_4_IOFilePath bevp_libEmitPath;
public BEC_4_6_TextString bevp_methodBody;
public BEC_4_3_MathInt bevp_lastMethodBodySize;
public BEC_4_3_MathInt bevp_lastMethodBodyLines;
public BEC_9_5_ContainerArray bevp_methodCalls;
public BEC_4_3_MathInt bevp_methodCatch;
public BEC_4_3_MathInt bevp_maxDynArgs;
public BEC_4_3_MathInt bevp_maxSpillArgsLen;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_BuildNode bevp_lastCall;
public BEC_9_3_ContainerSet bevp_callNames;
public BEC_5_11_BuildClassConfig bevp_objectCc;
public BEC_5_11_BuildClassConfig bevp_boolCc;
public BEC_4_6_TextString bevp_instOf;
public BEC_9_3_ContainerMap bevp_smnlcs;
public BEC_9_3_ContainerMap bevp_smnlecs;
public BEC_9_5_ContainerArray bevp_classesInDepthOrder;
public BEC_4_3_MathInt bevp_lineCount;
public BEC_4_6_TextString bevp_methods;
public BEC_9_5_ContainerArray bevp_classCalls;
public BEC_4_3_MathInt bevp_lastMethodsSize;
public BEC_4_3_MathInt bevp_lastMethodsLines;
public BEC_5_4_BuildNode bevp_mnode;
public BEC_5_11_BuildClassConfig bevp_returnType;
public BEC_5_6_BuildMtdSyn bevp_msyn;
public BEC_4_6_TextString bevp_preClass;
public BEC_4_6_TextString bevp_classEmits;
public BEC_4_6_TextString bevp_onceDecs;
public BEC_4_3_MathInt bevp_onceCount;
public BEC_4_6_TextString bevp_propertyDecs;
public BEC_5_4_BuildNode bevp_cnode;
public BEC_5_8_BuildClassSyn bevp_csyn;
public BEC_4_6_TextString bevp_dynMethods;
public BEC_4_6_TextString bevp_ccMethods;
public BEC_9_5_ContainerArray bevp_superCalls;
public BEC_4_3_MathInt bevp_nativeCSlots;
public BEC_4_6_TextString bevp_inFilePathed;
public virtual BEC_6_6_SystemObject bem_new_1(BEC_5_5_BuildBuild beva__build) {
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
bevp_build = beva__build;
bevp_nl = bevp_build.bem_nlGet_0();
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_q = bevt_0_tmpvar_phold.bem_quoteGet_0();
bevp_ccCache = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_0));
bevp_objectNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_1));
bevp_boolNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevp_intNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_3));
bevp_floatNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_4));
bevp_stringNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_5_tmpvar_phold);
bevp_trueValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(34, bels_5));
bevp_falseValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_6));
bevp_instanceEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_7));
bevp_instanceNotEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_8));
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_libEmitName = (BEC_4_6_TextString) this.bem_libEmitName_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_fullLibEmitName = (BEC_4_6_TextString) this.bem_fullLibEmitName_1(bevt_7_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_copy_0();
bevt_13_tmpvar_phold = this.bem_emitLangGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_9));
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = this.bem_libEmitName_1(bevt_16_tmpvar_phold);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevp_libEmitName.bem_add_1(bevp_fileExt);
bevp_libEmitPath = (BEC_2_4_4_IOFilePath) bevt_8_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_17_tmpvar_phold);
bevp_methodBody = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_lastMethodBodySize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_methodCatch = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_maxDynArgs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_callNames = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_objectCc = this.bem_getClassConfig_1(bevp_objectNp);
bevp_boolCc = this.bem_getClassConfig_1(bevp_boolNp);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_10));
bevt_18_tmpvar_phold = this.bem_emitting_1(bevt_19_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevp_instOf = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_11));
} /* Line: 141 */
 else  /* Line: 142 */ {
bevp_instOf = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_12));
} /* Line: 143 */
bevp_smnlcs = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_smnlecs = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_runtimeInitGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitName_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_libName.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_libName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullLibEmitName_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_libNs_1(beva_libName);
bevt_3_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_getClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_dname = null;
BEC_5_11_BuildClassConfig bevl_toRet = null;
BEC_5_7_BuildLibrary bevl_pack = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_8_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_2_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 170 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevl_pack = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_pack.bem_emitPathGet_0();
bevt_5_tmpvar_phold = bevl_pack.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_toRet.bem_synPathGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_existsGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
return bevl_toRet;
} /* Line: 174 */
} /* Line: 172 */
 else  /* Line: 170 */ {
break;
} /* Line: 170 */
} /* Line: 170 */
bevt_9_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_9_tmpvar_phold, bevt_10_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 178 */
return bevl_toRet;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_dname = null;
BEC_5_11_BuildClassConfig bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_1_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 188 */
return bevl_toRet;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_complete_1(BEC_5_4_BuildNode beva_clgen) {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_emvisit = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_2_tmpvar_phold = bevp_build.bem_printPlacesGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 194 */ {
bevt_4_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_clgen.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 195 */
bevt_7_tmpvar_phold = beva_clgen.bem_transUnitGet_0();
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_2(bevp_build, (BEC_5_4_BuildNode) bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_9_tmpvar_phold = bevo_5;
bevt_9_tmpvar_phold.bem_echo_0();
} /* Line: 203 */
bevl_emvisit = (new BEC_5_5_6_BuildVisitRewind()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_10_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_11_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 211 */
bevl_emvisit = (new BEC_5_5_9_BuildVisitTypeCheck()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_12_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_13_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold.bem_echo_0();
bevt_14_tmpvar_phold = bevo_8;
bevt_14_tmpvar_phold.bem_print_0();
} /* Line: 220 */
bevt_15_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, this);
bevt_16_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 226 */ {
} /* Line: 226 */
bevt_17_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 230 */ {
} /* Line: 230 */
this.bem_buildStackLines_1(beva_clgen);
bevt_18_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 234 */ {
} /* Line: 234 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doEmit_0() {
BEC_9_3_ContainerMap bevl_depthClasses = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_4_6_TextString bevl_clName = null;
BEC_5_4_BuildNode bevl_clnode = null;
BEC_4_3_MathInt bevl_depth = null;
BEC_9_5_ContainerArray bevl_classes = null;
BEC_9_5_ContainerArray bevl_depths = null;
BEC_2_4_6_IOFileWriter bevl_cle = null;
BEC_4_6_TextString bevl_bns = null;
BEC_4_6_TextString bevl_cb = null;
BEC_4_6_TextString bevl_idec = null;
BEC_4_6_TextString bevl_nlcs = null;
BEC_4_6_TextString bevl_nlecs = null;
BEC_5_4_LogicBool bevl_firstNlc = null;
BEC_4_3_MathInt bevl_lastNlc = null;
BEC_4_3_MathInt bevl_lastNlec = null;
BEC_4_6_TextString bevl_lineInfo = null;
BEC_5_4_BuildNode bevl_cc = null;
BEC_4_6_TextString bevl_smpref = null;
BEC_4_6_TextString bevl_nlcNName = null;
BEC_4_6_TextString bevl_ce = null;
BEC_4_6_TextString bevl_en = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_8_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_4_3_MathInt bevt_131_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_132_tmpvar_phold = null;
BEC_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_4_3_MathInt bevt_136_tmpvar_phold = null;
bevl_depthClasses = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_6_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_parseOrderClassNamesGet_0();
bevl_ci = bevt_5_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 245 */ {
bevt_7_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevl_clName = (BEC_4_6_TextString) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_classesGet_0();
bevl_clnode = (BEC_5_4_BuildNode) bevt_8_tmpvar_phold.bem_get_1(bevl_clName);
bevt_11_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_depth = (BEC_4_3_MathInt) bevt_10_tmpvar_phold.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevl_classes = (BEC_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
if (bevl_classes == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevl_classes = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_depthClasses.bem_put_2(bevl_depth, bevl_classes);
} /* Line: 254 */
bevl_classes.bem_addValue_1(bevl_clnode);
} /* Line: 256 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
bevl_depths = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_ci = bevl_depthClasses.bem_keyIteratorGet_0();
while (true)
 /* Line: 260 */ {
bevt_13_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevl_depth = (BEC_4_3_MathInt) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_depths.bem_addValue_1(bevl_depth);
} /* Line: 262 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevl_depths = (BEC_9_5_ContainerArray) bevl_depths.bem_sort_0();
bevp_classesInDepthOrder = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevt_0_tmpvar_loop = bevl_depths.bem_iteratorGet_0();
while (true)
 /* Line: 269 */ {
bevt_14_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevl_depth = (BEC_4_3_MathInt) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_classes = (BEC_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
bevt_1_tmpvar_loop = bevl_classes.bem_iteratorGet_0();
while (true)
 /* Line: 271 */ {
bevt_15_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevl_clnode = (BEC_5_4_BuildNode) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_classesInDepthOrder.bem_addValue_1(bevl_clnode);
} /* Line: 272 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
} /* Line: 271 */
 else  /* Line: 269 */ {
break;
} /* Line: 269 */
} /* Line: 269 */
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 276 */ {
bevt_16_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 276 */ {
bevl_clnode = (BEC_5_4_BuildNode) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_18_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_classConf = this.bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 281 */ {
} /* Line: 281 */
this.bem_complete_1(bevl_clnode);
bevl_cle = this.bem_getClassOutput_0();
bevl_bns = this.bem_beginNs_0();
bevt_20_tmpvar_phold = this.bem_countLines_1(bevl_bns);
bevp_lineCount.bem_addValue_1(bevt_20_tmpvar_phold);
bevl_cle.bem_write_1(bevl_bns);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevp_preClass);
bevp_lineCount.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_cle.bem_write_1(bevp_preClass);
bevl_cb = this.bem_classBeginGet_0();
bevt_22_tmpvar_phold = this.bem_countLines_1(bevl_cb);
bevp_lineCount.bem_addValue_1(bevt_22_tmpvar_phold);
bevl_cle.bem_write_1(bevl_cb);
bevt_23_tmpvar_phold = this.bem_countLines_1(bevp_classEmits);
bevp_lineCount.bem_addValue_1(bevt_23_tmpvar_phold);
bevl_cle.bem_write_1(bevp_classEmits);
bevt_24_tmpvar_phold = this.bem_writeOnceDecs_2(bevl_cle, bevp_onceDecs);
bevp_lineCount.bem_addValue_1((BEC_4_3_MathInt) bevt_24_tmpvar_phold);
bevl_idec = this.bem_initialDecGet_0();
bevt_25_tmpvar_phold = this.bem_countLines_1(bevl_idec);
bevp_lineCount.bem_addValue_1(bevt_25_tmpvar_phold);
bevl_cle.bem_write_1(bevl_idec);
bevt_26_tmpvar_phold = this.bem_countLines_1(bevp_propertyDecs);
bevp_lineCount.bem_addValue_1(bevt_26_tmpvar_phold);
bevl_cle.bem_write_1(bevp_propertyDecs);
bevl_nlcs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_nlecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_firstNlc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_22));
bevl_lineInfo = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_2_tmpvar_loop = bevp_classCalls.bem_iteratorGet_0();
while (true)
 /* Line: 335 */ {
bevt_28_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevl_cc = (BEC_5_4_BuildNode) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_29_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_29_tmpvar_phold.bem_addValue_1(bevp_lineCount);
bevt_30_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_30_tmpvar_phold.bem_incrementValue_0();
if (bevl_lastNlc == null) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_33_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_32_tmpvar_phold = bevl_lastNlc.bem_notEquals_1(bevt_33_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_35_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_34_tmpvar_phold = bevl_lastNlec.bem_notEquals_1(bevt_35_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 338 */ {
if (bevl_firstNlc.bevi_bool) /* Line: 340 */ {
bevl_firstNlc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_23));
bevl_nlcs.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_24));
bevl_nlecs.bem_addValue_1(bevt_37_tmpvar_phold);
} /* Line: 344 */
bevt_38_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevl_nlcs.bem_addValue_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevl_nlecs.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 347 */
bevl_lastNlc = bevl_cc.bem_nlcGet_0();
bevl_lastNlec = bevl_cc.bem_nlecGet_0();
bevt_48_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_46_tmpvar_phold = (BEC_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_47_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_25));
bevt_45_tmpvar_phold = (BEC_4_6_TextString) bevt_46_tmpvar_phold.bem_addValue_1(bevt_49_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_44_tmpvar_phold = (BEC_4_6_TextString) bevt_45_tmpvar_phold.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_26));
bevt_43_tmpvar_phold = (BEC_4_6_TextString) bevt_44_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_42_tmpvar_phold = (BEC_4_6_TextString) bevt_43_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_27));
bevt_41_tmpvar_phold = (BEC_4_6_TextString) bevt_42_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevt_41_tmpvar_phold.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 352 */
 else  /* Line: 335 */ {
break;
} /* Line: 335 */
} /* Line: 335 */
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_28));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_56_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_29));
bevt_58_tmpvar_phold = this.bem_emitting_1(bevt_59_tmpvar_phold);
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_63_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_61_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_emitNameGet_0();
bevt_64_tmpvar_phold = bevo_9;
bevl_smpref = bevt_60_tmpvar_phold.bem_add_1(bevt_64_tmpvar_phold);
} /* Line: 357 */
bevt_67_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_nlcNName = (BEC_4_6_TextString) bevt_65_tmpvar_phold.bem_relEmitName_1(bevt_68_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_73_tmpvar_phold = bevo_10;
bevt_72_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_73_tmpvar_phold);
bevp_smnlcs.bem_put_2(bevt_69_tmpvar_phold, bevt_72_tmpvar_phold);
bevt_76_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_78_tmpvar_phold = bevo_11;
bevt_77_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_78_tmpvar_phold);
bevp_smnlecs.bem_put_2(bevt_74_tmpvar_phold, bevt_77_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_33));
bevt_79_tmpvar_phold = this.bem_emitting_1(bevt_80_tmpvar_phold);
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_82_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevt_84_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_34));
bevt_83_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_84_tmpvar_phold);
bevt_83_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 368 */
 else  /* Line: 369 */ {
bevt_86_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(34, bels_35));
bevt_85_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_86_tmpvar_phold);
bevt_85_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 370 */
} /* Line: 367 */
bevt_88_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_36));
bevt_87_tmpvar_phold = this.bem_emitting_1(bevt_88_tmpvar_phold);
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 373 */ {
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_37));
bevt_89_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_90_tmpvar_phold);
bevt_89_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 374 */
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_38));
bevt_91_tmpvar_phold = this.bem_emitting_1(bevt_92_tmpvar_phold);
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevt_93_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_94_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_39));
bevt_93_tmpvar_phold.bem_addValue_1(bevt_94_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_40));
bevt_97_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_98_tmpvar_phold);
bevt_96_tmpvar_phold = (BEC_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_41));
bevt_95_tmpvar_phold = (BEC_4_6_TextString) bevt_96_tmpvar_phold.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_95_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 378 */
 else  /* Line: 379 */ {
bevt_103_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_42));
bevt_102_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_103_tmpvar_phold);
bevt_101_tmpvar_phold = (BEC_4_6_TextString) bevt_102_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_104_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_43));
bevt_100_tmpvar_phold = (BEC_4_6_TextString) bevt_101_tmpvar_phold.bem_addValue_1(bevt_104_tmpvar_phold);
bevt_100_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 380 */
bevt_106_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_44));
bevt_105_tmpvar_phold = this.bem_emitting_1(bevt_106_tmpvar_phold);
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevt_108_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_110_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_45));
bevt_109_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_110_tmpvar_phold);
bevt_109_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 384 */
 else  /* Line: 385 */ {
bevt_112_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_46));
bevt_111_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_112_tmpvar_phold);
bevt_111_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 386 */
} /* Line: 383 */
bevt_114_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_47));
bevt_113_tmpvar_phold = this.bem_emitting_1(bevt_114_tmpvar_phold);
if (bevt_113_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_48));
bevt_115_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_115_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 390 */
bevt_118_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_49));
bevt_117_tmpvar_phold = this.bem_emitting_1(bevt_118_tmpvar_phold);
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_119_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_120_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_50));
bevt_119_tmpvar_phold.bem_addValue_1(bevt_120_tmpvar_phold);
bevt_124_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_51));
bevt_123_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_124_tmpvar_phold);
bevt_122_tmpvar_phold = (BEC_4_6_TextString) bevt_123_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_125_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_52));
bevt_121_tmpvar_phold = (BEC_4_6_TextString) bevt_122_tmpvar_phold.bem_addValue_1(bevt_125_tmpvar_phold);
bevt_121_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 394 */
 else  /* Line: 395 */ {
bevt_129_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_53));
bevt_128_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_129_tmpvar_phold);
bevt_127_tmpvar_phold = (BEC_4_6_TextString) bevt_128_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_130_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_54));
bevt_126_tmpvar_phold = (BEC_4_6_TextString) bevt_127_tmpvar_phold.bem_addValue_1(bevt_130_tmpvar_phold);
bevt_126_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 396 */
bevp_methods.bem_addValue_1(bevl_lineInfo);
bevt_131_tmpvar_phold = this.bem_countLines_1(bevp_methods);
bevp_lineCount.bem_addValue_1(bevt_131_tmpvar_phold);
bevl_cle.bem_write_1(bevp_methods);
bevt_132_tmpvar_phold = this.bem_useDynMethodsGet_0();
if (bevt_132_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_133_tmpvar_phold = this.bem_countLines_1(bevp_dynMethods);
bevp_lineCount.bem_addValue_1(bevt_133_tmpvar_phold);
bevl_cle.bem_write_1(bevp_dynMethods);
} /* Line: 408 */
bevt_134_tmpvar_phold = this.bem_countLines_1(bevp_ccMethods);
bevp_lineCount.bem_addValue_1(bevt_134_tmpvar_phold);
bevl_cle.bem_write_1(bevp_ccMethods);
bevl_ce = this.bem_classEndGet_0();
bevt_135_tmpvar_phold = this.bem_countLines_1(bevl_ce);
bevp_lineCount.bem_addValue_1(bevt_135_tmpvar_phold);
bevl_cle.bem_write_1(bevl_ce);
bevl_en = this.bem_endNs_0();
bevt_136_tmpvar_phold = this.bem_countLines_1(bevl_en);
bevp_lineCount.bem_addValue_1(bevt_136_tmpvar_phold);
bevl_cle.bem_write_1(bevl_en);
this.bem_finishClassOutput_1(bevl_cle);
} /* Line: 426 */
 else  /* Line: 276 */ {
break;
} /* Line: 276 */
} /* Line: 276 */
this.bem_emitLib_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_writeOnceDecs_2(BEC_6_6_SystemObject beva_cle, BEC_6_6_SystemObject beva_onceDecs) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
beva_cle.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_onceDecs);
bevt_0_tmpvar_phold = this.bem_countLines_1((BEC_4_6_TextString) beva_onceDecs);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_IOFile bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_4_IOFile bevt_5_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lineCount = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_4_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_fileGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_existsGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 445 */ {
bevt_6_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_fileGet_0();
bevt_5_tmpvar_phold.bem_makeDirs_0();
} /* Line: 446 */
bevt_10_tmpvar_phold = bevp_classConf.bem_classPathGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_2_4_6_IOFileWriter) bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_finishClassOutput_1(BEC_2_4_6_IOFileWriter beva_cle) {
beva_cle.bem_close_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_IOFile bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_writerGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_2_4_6_IOFileWriter) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_finishLibOutput_1(BEC_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_klassDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_55));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_spropDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_56));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_overrideSmtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_57));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_baseSmtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_58));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_baseMtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_59));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_overrideMtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_60));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_propDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_61));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_emitting_1(BEC_4_6_TextString beva_lang) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(beva_lang);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 492 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 493 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLib_0() {
BEC_4_6_TextString bevl_getNames = null;
BEC_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_5_11_BuildClassConfig bevl_maincc = null;
BEC_4_6_TextString bevl_main = null;
BEC_2_4_6_IOFileWriter bevl_libe = null;
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_initLibs = null;
BEC_5_7_BuildLibrary bevl_bl = null;
BEC_4_6_TextString bevl_typeInstances = null;
BEC_4_6_TextString bevl_notNullInitConstruct = null;
BEC_4_6_TextString bevl_notNullInitDefault = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_4_6_TextString bevl_nc = null;
BEC_4_6_TextString bevl_callName = null;
BEC_4_6_TextString bevl_smap = null;
BEC_4_6_TextString bevl_smk = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_9_3_11_ContainerSetKeyIterator bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_4_6_TextString bevt_147_tmpvar_phold = null;
BEC_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_152_tmpvar_phold = null;
BEC_4_6_TextString bevt_153_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_4_6_TextString bevt_157_tmpvar_phold = null;
BEC_4_6_TextString bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_4_6_TextString bevt_160_tmpvar_phold = null;
BEC_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_169_tmpvar_phold = null;
BEC_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_4_6_TextString bevt_189_tmpvar_phold = null;
BEC_4_6_TextString bevt_190_tmpvar_phold = null;
BEC_4_6_TextString bevt_191_tmpvar_phold = null;
BEC_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_4_6_TextString bevt_193_tmpvar_phold = null;
BEC_4_6_TextString bevt_194_tmpvar_phold = null;
BEC_4_6_TextString bevt_195_tmpvar_phold = null;
BEC_4_6_TextString bevt_196_tmpvar_phold = null;
BEC_4_6_TextString bevt_197_tmpvar_phold = null;
BEC_4_6_TextString bevt_198_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_4_6_TextString bevt_205_tmpvar_phold = null;
BEC_4_6_TextString bevt_206_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_4_6_TextString bevt_208_tmpvar_phold = null;
BEC_4_6_TextString bevt_209_tmpvar_phold = null;
BEC_4_6_TextString bevt_210_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_211_tmpvar_phold = null;
bevl_getNames = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_mainClassNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_4_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_4_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_62));
bevt_5_tmpvar_phold = this.bem_mainStartGet_0();
bevl_main.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevp_fullLibEmitName);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_63));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_64));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_65));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_66));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_67));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = this.bem_mainEndGet_0();
bevl_main.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_libe = this.bem_getLibOutput_0();
bevt_22_tmpvar_phold = this.bem_beginNs_0();
bevl_libe.bem_write_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_68));
bevl_extends = this.bem_extend_1(bevt_23_tmpvar_phold);
bevt_28_tmpvar_phold = this.bem_klassDecGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevl_extends);
bevt_29_tmpvar_phold = bevo_12;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_24_tmpvar_phold);
bevt_33_tmpvar_phold = this.bem_spropDecGet_0();
bevt_34_tmpvar_phold = this.bem_boolTypeGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevo_13;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevt_35_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_30_tmpvar_phold);
bevl_initLibs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_36_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_36_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 522 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 522 */ {
bevl_bl = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = bevl_bl.bem_libNameGet_0();
bevt_40_tmpvar_phold = this.bem_fullLibEmitName_1(bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_initLibs.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_71));
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_38_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 524 */
 else  /* Line: 522 */ {
break;
} /* Line: 522 */
} /* Line: 522 */
bevl_typeInstances = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 530 */ {
bevt_43_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 530 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_72));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 534 */ {
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(44, bels_73));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) bevt_54_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_58_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) bevt_53_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_51_tmpvar_phold = (BEC_4_6_TextString) bevt_52_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_74));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_63_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_61_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_fullEmitNameGet_0();
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_75));
bevt_46_tmpvar_phold = (BEC_4_6_TextString) bevt_47_tmpvar_phold.bem_addValue_1(bevt_64_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 535 */
bevt_66_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_76));
bevt_65_tmpvar_phold = this.bem_emitting_1(bevt_66_tmpvar_phold);
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 537 */ {
bevt_74_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(40, bels_77));
bevt_73_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_4_6_TextString) bevt_73_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_77_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_71_tmpvar_phold = (BEC_4_6_TextString) bevt_72_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_4_6_TextString) bevt_71_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_78_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_78));
bevt_69_tmpvar_phold = (BEC_4_6_TextString) bevt_70_tmpvar_phold.bem_addValue_1(bevt_78_tmpvar_phold);
bevt_82_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_80_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_81_tmpvar_phold);
bevt_83_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_relEmitName_1(bevt_83_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_4_6_TextString) bevt_69_tmpvar_phold.bem_addValue_1(bevt_79_tmpvar_phold);
bevt_84_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_79));
bevt_67_tmpvar_phold = (BEC_4_6_TextString) bevt_68_tmpvar_phold.bem_addValue_1(bevt_84_tmpvar_phold);
bevt_67_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_80));
bevt_86_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_87_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_89_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_90_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_relEmitName_1(bevt_92_tmpvar_phold);
bevt_85_tmpvar_phold = (BEC_4_6_TextString) bevt_86_tmpvar_phold.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_81));
bevt_85_tmpvar_phold.bem_addValue_1(bevt_93_tmpvar_phold);
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_82));
bevt_98_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_97_tmpvar_phold = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_100_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_83));
bevt_96_tmpvar_phold = (BEC_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_95_tmpvar_phold = (BEC_4_6_TextString) bevt_96_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_101_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(17, bels_84));
bevt_94_tmpvar_phold = (BEC_4_6_TextString) bevt_95_tmpvar_phold.bem_addValue_1(bevt_101_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 540 */
bevt_104_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_106_tmpvar_phold = bevo_14;
bevt_110_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_108_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_109_tmpvar_phold);
bevt_111_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bem_relEmitName_1(bevt_111_tmpvar_phold);
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevt_112_tmpvar_phold = bevo_15;
bevl_nc = bevt_105_tmpvar_phold.bem_add_1(bevt_112_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(65, bels_87));
bevt_115_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_114_tmpvar_phold = (BEC_4_6_TextString) bevt_115_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_88));
bevt_113_tmpvar_phold = (BEC_4_6_TextString) bevt_114_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_113_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(63, bels_89));
bevt_120_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_119_tmpvar_phold = (BEC_4_6_TextString) bevt_120_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_122_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_90));
bevt_118_tmpvar_phold = (BEC_4_6_TextString) bevt_119_tmpvar_phold.bem_addValue_1(bevt_122_tmpvar_phold);
bevt_118_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 546 */
} /* Line: 543 */
 else  /* Line: 530 */ {
break;
} /* Line: 530 */
} /* Line: 530 */
bevt_1_tmpvar_loop = bevp_callNames.bem_iteratorGet_0();
while (true)
 /* Line: 550 */ {
bevt_123_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 550 */ {
bevl_callName = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_128_tmpvar_phold = this.bem_spropDecGet_0();
bevt_129_tmpvar_phold = bevo_16;
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bem_add_1(bevt_129_tmpvar_phold);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bem_add_1(bevl_callName);
bevt_130_tmpvar_phold = bevo_17;
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bem_add_1(bevt_130_tmpvar_phold);
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_124_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_93));
bevt_137_tmpvar_phold = (BEC_4_6_TextString) bevl_getNames.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_94));
bevt_135_tmpvar_phold = (BEC_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_134_tmpvar_phold = (BEC_4_6_TextString) bevt_135_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_133_tmpvar_phold = (BEC_4_6_TextString) bevt_134_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_132_tmpvar_phold = (BEC_4_6_TextString) bevt_133_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_140_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_95));
bevt_131_tmpvar_phold = (BEC_4_6_TextString) bevt_132_tmpvar_phold.bem_addValue_1(bevt_140_tmpvar_phold);
bevt_131_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 552 */
 else  /* Line: 550 */ {
break;
} /* Line: 550 */
} /* Line: 550 */
bevl_smap = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_141_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_2_tmpvar_loop = bevt_141_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 557 */ {
bevt_142_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_142_tmpvar_phold != null && bevt_142_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_142_tmpvar_phold).bevi_bool) /* Line: 557 */ {
bevl_smk = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_150_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_96));
bevt_149_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_150_tmpvar_phold);
bevt_152_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_151_tmpvar_phold = bevt_152_tmpvar_phold.bem_quoteGet_0();
bevt_148_tmpvar_phold = (BEC_4_6_TextString) bevt_149_tmpvar_phold.bem_addValue_1(bevt_151_tmpvar_phold);
bevt_147_tmpvar_phold = (BEC_4_6_TextString) bevt_148_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_154_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bem_quoteGet_0();
bevt_146_tmpvar_phold = (BEC_4_6_TextString) bevt_147_tmpvar_phold.bem_addValue_1(bevt_153_tmpvar_phold);
bevt_155_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_97));
bevt_145_tmpvar_phold = (BEC_4_6_TextString) bevt_146_tmpvar_phold.bem_addValue_1(bevt_155_tmpvar_phold);
bevt_156_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_144_tmpvar_phold = (BEC_4_6_TextString) bevt_145_tmpvar_phold.bem_addValue_1(bevt_156_tmpvar_phold);
bevt_157_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_98));
bevt_143_tmpvar_phold = (BEC_4_6_TextString) bevt_144_tmpvar_phold.bem_addValue_1(bevt_157_tmpvar_phold);
bevt_143_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_165_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(17, bels_99));
bevt_164_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_165_tmpvar_phold);
bevt_167_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_quoteGet_0();
bevt_163_tmpvar_phold = (BEC_4_6_TextString) bevt_164_tmpvar_phold.bem_addValue_1(bevt_166_tmpvar_phold);
bevt_162_tmpvar_phold = (BEC_4_6_TextString) bevt_163_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_169_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bem_quoteGet_0();
bevt_161_tmpvar_phold = (BEC_4_6_TextString) bevt_162_tmpvar_phold.bem_addValue_1(bevt_168_tmpvar_phold);
bevt_170_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_100));
bevt_160_tmpvar_phold = (BEC_4_6_TextString) bevt_161_tmpvar_phold.bem_addValue_1(bevt_170_tmpvar_phold);
bevt_171_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_159_tmpvar_phold = (BEC_4_6_TextString) bevt_160_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_172_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_101));
bevt_158_tmpvar_phold = (BEC_4_6_TextString) bevt_159_tmpvar_phold.bem_addValue_1(bevt_172_tmpvar_phold);
bevt_158_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 560 */
 else  /* Line: 557 */ {
break;
} /* Line: 557 */
} /* Line: 557 */
bevt_176_tmpvar_phold = this.bem_baseSmtdDecGet_0();
bevt_177_tmpvar_phold = bevo_18;
bevt_175_tmpvar_phold = bevt_176_tmpvar_phold.bem_add_1(bevt_177_tmpvar_phold);
bevt_174_tmpvar_phold = (BEC_4_6_TextString) bevt_175_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_179_tmpvar_phold = bevo_19;
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevp_nl);
bevt_173_tmpvar_phold = (BEC_4_6_TextString) bevt_174_tmpvar_phold.bem_addValue_1(bevt_178_tmpvar_phold);
bevl_libe.bem_write_1(bevt_173_tmpvar_phold);
bevt_181_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_104));
bevt_180_tmpvar_phold = this.bem_emitting_1(bevt_181_tmpvar_phold);
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 565 */ {
bevt_185_tmpvar_phold = bevo_20;
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_186_tmpvar_phold = bevo_21;
bevt_183_tmpvar_phold = bevt_184_tmpvar_phold.bem_add_1(bevt_186_tmpvar_phold);
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_182_tmpvar_phold);
} /* Line: 566 */
 else  /* Line: 565 */ {
bevt_188_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_107));
bevt_187_tmpvar_phold = this.bem_emitting_1(bevt_188_tmpvar_phold);
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 567 */ {
bevt_192_tmpvar_phold = bevo_22;
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_193_tmpvar_phold = bevo_23;
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bem_add_1(bevt_193_tmpvar_phold);
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_189_tmpvar_phold);
} /* Line: 568 */
} /* Line: 565 */
bevt_195_tmpvar_phold = bevo_24;
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_194_tmpvar_phold);
bevt_197_tmpvar_phold = bevo_25;
bevt_196_tmpvar_phold = bevt_197_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_196_tmpvar_phold);
bevt_198_tmpvar_phold = this.bem_runtimeInitGet_0();
bevl_libe.bem_write_1(bevt_198_tmpvar_phold);
bevl_libe.bem_write_1(bevl_getNames);
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_initLibs);
bevl_libe.bem_write_1(bevl_typeInstances);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_200_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_112));
bevt_199_tmpvar_phold = this.bem_emitting_1(bevt_200_tmpvar_phold);
if (bevt_199_tmpvar_phold.bevi_bool) /* Line: 579 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 579 */ {
bevt_202_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_113));
bevt_201_tmpvar_phold = this.bem_emitting_1(bevt_202_tmpvar_phold);
if (bevt_201_tmpvar_phold.bevi_bool) /* Line: 579 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 579 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 579 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 579 */ {
bevt_204_tmpvar_phold = bevo_26;
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_203_tmpvar_phold);
} /* Line: 581 */
bevt_206_tmpvar_phold = bevo_27;
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_205_tmpvar_phold);
bevt_207_tmpvar_phold = this.bem_mainInClassGet_0();
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 585 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 586 */
bevt_209_tmpvar_phold = bevo_28;
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_208_tmpvar_phold);
bevt_210_tmpvar_phold = this.bem_endNs_0();
bevl_libe.bem_write_1(bevt_210_tmpvar_phold);
bevt_211_tmpvar_phold = this.bem_mainOutsideNsGet_0();
if (bevt_211_tmpvar_phold.bevi_bool) /* Line: 592 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 593 */
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_procStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_29;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_mainInClassGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_118));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainEndGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_119));
bevt_1_tmpvar_phold = this.bem_emitting_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 619 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 619 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_120));
bevt_3_tmpvar_phold = this.bem_emitting_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 619 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 619 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 619 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 619 */ {
bevt_6_tmpvar_phold = bevo_30;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_5_tmpvar_phold;
} /* Line: 621 */
bevt_8_tmpvar_phold = bevo_31;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_boolTypeGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_123));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bevp_methods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_classCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_lastMethodsSize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodsLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nameForVar_1(BEC_5_3_BuildVar beva_v) {
BEC_4_6_TextString bevl_prefix = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isTmpVarGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 645 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_124));
} /* Line: 646 */
 else  /* Line: 645 */ {
bevt_1_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 647 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_125));
} /* Line: 648 */
 else  /* Line: 645 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 649 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_126));
} /* Line: 650 */
 else  /* Line: 651 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_127));
} /* Line: 652 */
} /* Line: 645 */
} /* Line: 645 */
bevt_4_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_3_tmpvar_phold = bevl_prefix.bem_add_1(bevt_4_tmpvar_phold);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDecForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_5_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_v.bem_isTypedGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 659 */ {
bevt_3_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_2_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_3_tmpvar_phold);
beva_b.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 660 */
 else  /* Line: 661 */ {
bevt_6_tmpvar_phold = beva_v.bem_namepathGet_0();
bevt_5_tmpvar_phold = this.bem_getClassConfig_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_relEmitName_1(bevt_7_tmpvar_phold);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 662 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_decForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
this.bem_typeDecForVar_2(beva_b, beva_v);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_128));
beva_b.bem_addValue_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitNameForMethod_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_32;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitNameForCall_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_33;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptMethod_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_argDecs = null;
BEC_4_6_TextString bevl_varDecs = null;
BEC_5_4_LogicBool bevl_isFirstArg = null;
BEC_5_4_BuildNode bevl_ov = null;
BEC_5_8_BuildNamePath bevl_ertype = null;
BEC_4_6_TextString bevl_mtdDec = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_40_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
bevp_mnode = beva_node;
bevp_returnType = null;
bevt_2_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_4_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_msyn = (BEC_5_6_BuildMtdSyn) bevt_2_tmpvar_phold.bem_get_1(bevt_3_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_5_tmpvar_phold);
bevl_argDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_varDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_isFirstArg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_0_tmpvar_loop = bevt_7_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 694 */ {
bevt_9_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 694 */ {
bevl_ov = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_131));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_13_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 695 */ {
bevt_16_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_132));
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_17_tmpvar_phold);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 695 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 695 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 695 */
 else  /* Line: 695 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 695 */ {
bevt_19_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 696 */ {
if (!(bevl_isFirstArg.bevi_bool)) /* Line: 697 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_133));
bevl_argDecs.bem_addValue_1(bevt_20_tmpvar_phold);
} /* Line: 698 */
bevl_isFirstArg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_22_tmpvar_phold = bevl_ov.bem_heldGet_0();
if (bevt_22_tmpvar_phold == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 701 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_26_tmpvar_phold = bevl_ov.bem_toString_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_24_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_23_tmpvar_phold);
} /* Line: 702 */
bevt_27_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_argDecs, (BEC_5_3_BuildVar) bevt_27_tmpvar_phold);
} /* Line: 704 */
 else  /* Line: 705 */ {
bevt_28_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_varDecs, (BEC_5_3_BuildVar) bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_135));
bevt_29_tmpvar_phold = this.bem_emitting_1(bevt_30_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 707 */ {
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_136));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 708 */
 else  /* Line: 709 */ {
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_137));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 710 */
} /* Line: 707 */
bevt_35_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_37_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_36_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_37_tmpvar_phold);
bevt_35_tmpvar_phold.bemd_1(792634738, BEL_4_Base.bevn_nativeNameSet_1, bevt_36_tmpvar_phold);
} /* Line: 713 */
} /* Line: 695 */
 else  /* Line: 694 */ {
break;
} /* Line: 694 */
} /* Line: 694 */
bevl_ertype = bevp_msyn.bem_getEmitReturnType_2(bevp_csyn, bevp_build);
if (bevl_ertype == null) {
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 719 */ {
bevp_returnType = this.bem_getClassConfig_1(bevl_ertype);
} /* Line: 720 */
 else  /* Line: 721 */ {
bevp_returnType = bevp_objectCc;
} /* Line: 722 */
bevt_40_tmpvar_phold = bevp_msyn.bem_declarationGet_0();
bevt_41_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 726 */ {
bevl_mtdDec = this.bem_baseMtdDecGet_0();
} /* Line: 727 */
 else  /* Line: 728 */ {
bevl_mtdDec = this.bem_overrideMtdDecGet_0();
} /* Line: 729 */
bevt_42_tmpvar_phold = this.bem_emitNameForMethod_1(beva_node);
this.bem_startMethod_5(bevl_mtdDec, bevp_returnType, bevt_42_tmpvar_phold, bevl_argDecs, bevp_exceptDec);
bevp_methods.bem_addValue_1(bevl_varDecs);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_startMethod_5(BEC_4_6_TextString beva_mtdDec, BEC_5_11_BuildClassConfig beva_returnType, BEC_4_6_TextString beva_mtdName, BEC_4_6_TextString beva_argDecs, BEC_6_6_SystemObject beva_exceptDec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_5_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = beva_returnType.bem_relEmitName_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_138));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_139));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_140));
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(beva_exceptDec);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_141));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isClose_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_8_BuildClassSyn bevl_orgsyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_orgsyn = bevp_build.bem_getSynNp_1(beva_np);
bevt_1_tmpvar_phold = bevp_build.bem_closeLibrariesGet_0();
bevt_2_tmpvar_phold = bevl_orgsyn.bem_libNameGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_has_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 750 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 751 */
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptClass_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_te = null;
BEC_6_6_SystemObject bevl_jn = null;
BEC_5_8_BuildClassSyn bevl_psyn = null;
BEC_4_6_TextString bevl_inlang = null;
BEC_5_4_BuildNode bevl_innode = null;
BEC_4_3_MathInt bevl_ovcount = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_9_3_ContainerMap bevl_dynGen = null;
BEC_9_3_ContainerSet bevl_mq = null;
BEC_5_6_BuildMtdSyn bevl_msyn = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_9_3_ContainerMap bevl_dgm = null;
BEC_4_3_MathInt bevl_msh = null;
BEC_9_5_ContainerArray bevl_dgv = null;
BEC_9_3_7_ContainerMapMapNode bevl_dnode = null;
BEC_4_3_MathInt bevl_dnumargs = null;
BEC_4_6_TextString bevl_dmname = null;
BEC_4_6_TextString bevl_superArgs = null;
BEC_4_6_TextString bevl_args = null;
BEC_4_3_MathInt bevl_j = null;
BEC_9_3_7_ContainerMapMapNode bevl_msnode = null;
BEC_4_3_MathInt bevl_thisHash = null;
BEC_5_4_LogicBool bevl_dynConditions = null;
BEC_4_6_TextString bevl_mcall = null;
BEC_4_6_TextString bevl_constName = null;
BEC_4_3_MathInt bevl_vnumargs = null;
BEC_5_6_BuildVarSyn bevl_vsyn = null;
BEC_4_6_TextString bevl_vcast = null;
BEC_4_6_TextString bevl_vcma = null;
BEC_4_6_TextString bevl_varg = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_3_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_4_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_5_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_67_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_128_tmpvar_phold = null;
BEC_4_3_MathInt bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_151_tmpvar_phold = null;
BEC_4_6_TextString bevt_152_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_153_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_156_tmpvar_phold = null;
BEC_4_3_MathInt bevt_157_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_4_3_MathInt bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_3_MathInt bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_4_6_TextString bevt_187_tmpvar_phold = null;
BEC_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_4_6_TextString bevt_189_tmpvar_phold = null;
bevp_preClass = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_classEmits = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_onceDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_onceCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_propertyDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_cnode = beva_node;
bevt_10_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_csyn = (BEC_5_8_BuildClassSyn) bevt_10_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevp_dynMethods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_ccMethods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_superCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_nativeCSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_142));
bevp_inFilePathed = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bemd_1(450717861, BEL_4_Base.bevn_toStringWithSeparator_1, bevt_13_tmpvar_phold);
bevt_15_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_te = bevt_14_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevl_te == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 773 */ {
bevl_te = bevl_te.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 774 */ {
bevt_17_tmpvar_phold = bevl_te.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 774 */ {
bevl_jn = bevl_te.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_20_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_21_tmpvar_phold = this.bem_emitLangGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_21_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 776 */ {
bevt_23_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_preClass.bem_addValue_1(bevt_22_tmpvar_phold);
} /* Line: 777 */
} /* Line: 776 */
 else  /* Line: 774 */ {
break;
} /* Line: 774 */
} /* Line: 774 */
} /* Line: 774 */
bevt_26_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 782 */ {
bevt_28_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevp_parentConf = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = bevp_build.bem_getSynNp_1(bevt_29_tmpvar_phold);
} /* Line: 784 */
 else  /* Line: 785 */ {
bevp_parentConf = null;
} /* Line: 786 */
bevt_33_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevt_32_tmpvar_phold == null) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 790 */ {
bevl_inlang = this.bem_emitLangGet_0();
bevt_35_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevt_0_tmpvar_loop = bevt_34_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 792 */ {
bevt_36_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 792 */ {
bevl_innode = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_38_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_nativeCSlots = this.bem_getNativeCSlots_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_41_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_inlang);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 795 */ {
bevt_43_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_classEmits.bem_addValue_1(bevt_42_tmpvar_phold);
} /* Line: 796 */
} /* Line: 795 */
 else  /* Line: 792 */ {
break;
} /* Line: 792 */
} /* Line: 792 */
} /* Line: 792 */
if (bevl_psyn == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 801 */ {
bevt_46_tmpvar_phold = bevo_35;
bevt_45_tmpvar_phold = bevp_nativeCSlots.bem_greater_1(bevt_46_tmpvar_phold);
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 801 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 801 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 801 */
 else  /* Line: 801 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 801 */ {
bevt_48_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_sizeGet_0();
bevp_nativeCSlots = bevp_nativeCSlots.bem_subtract_1(bevt_47_tmpvar_phold);
bevt_50_tmpvar_phold = bevo_36;
bevt_49_tmpvar_phold = bevp_nativeCSlots.bem_lesser_1(bevt_50_tmpvar_phold);
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 803 */ {
bevp_nativeCSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 804 */
} /* Line: 803 */
bevl_ovcount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_52_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_51_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 811 */ {
bevt_53_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 811 */ {
bevt_54_tmpvar_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 813 */ {
bevt_56_tmpvar_phold = bevl_ovcount.bem_greaterEquals_1(bevp_nativeCSlots);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 814 */ {
bevt_57_tmpvar_phold = this.bem_propDecGet_0();
bevp_propertyDecs.bem_addValue_1(bevt_57_tmpvar_phold);
this.bem_decForVar_2(bevp_propertyDecs, (BEC_5_3_BuildVar) bevl_i);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_143));
bevt_58_tmpvar_phold = (BEC_4_6_TextString) bevp_propertyDecs.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_58_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 817 */
bevl_ovcount = bevl_ovcount.bem_increment_0();
} /* Line: 819 */
} /* Line: 813 */
 else  /* Line: 811 */ {
break;
} /* Line: 811 */
} /* Line: 811 */
bevl_dynGen = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_mq = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_60_tmpvar_phold = bevp_csyn.bem_mtdListGet_0();
bevt_1_tmpvar_loop = bevt_60_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 826 */ {
bevt_61_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 826 */ {
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_63_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_62_tmpvar_phold = bevl_mq.bem_has_1(bevt_63_tmpvar_phold);
if (!(bevt_62_tmpvar_phold.bevi_bool)) /* Line: 827 */ {
bevt_64_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_mq.bem_put_1(bevt_64_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_66_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_65_tmpvar_phold.bem_get_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_msyn.bem_originGet_0();
bevt_67_tmpvar_phold = this.bem_isClose_1(bevt_68_tmpvar_phold);
if (bevt_67_tmpvar_phold.bevi_bool) /* Line: 830 */ {
bevl_numargs = bevl_msyn.bem_numargsGet_0();
bevt_69_tmpvar_phold = bevl_numargs.bem_greater_1(bevp_maxDynArgs);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 832 */ {
bevl_numargs = bevp_maxDynArgs;
} /* Line: 833 */
bevl_dgm = (BEC_9_3_ContainerMap) bevl_dynGen.bem_get_1(bevl_numargs);
if (bevl_dgm == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 836 */ {
bevl_dgm = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_dynGen.bem_put_2(bevl_numargs, bevl_dgm);
} /* Line: 838 */
bevt_71_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msh = bevt_71_tmpvar_phold.bem_hashGet_0();
bevl_dgv = (BEC_9_5_ContainerArray) bevl_dgm.bem_get_1(bevl_msh);
if (bevl_dgv == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 842 */ {
bevl_dgv = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_dgm.bem_put_2(bevl_msh, bevl_dgv);
} /* Line: 844 */
bevl_dgv.bem_addValue_1(bevl_msyn);
} /* Line: 846 */
} /* Line: 830 */
} /* Line: 827 */
 else  /* Line: 826 */ {
break;
} /* Line: 826 */
} /* Line: 826 */
bevt_2_tmpvar_loop = bevl_dynGen.bem_iteratorGet_0();
while (true)
 /* Line: 852 */ {
bevt_73_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 852 */ {
bevl_dnode = (BEC_9_3_7_ContainerMapMapNode) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_dnumargs = (BEC_4_3_MathInt) bevl_dnode.bem_keyGet_0();
bevt_74_tmpvar_phold = bevl_dnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 855 */ {
bevt_75_tmpvar_phold = bevo_37;
bevt_76_tmpvar_phold = bevl_dnumargs.bem_toString_0();
bevl_dmname = bevt_75_tmpvar_phold.bem_add_1(bevt_76_tmpvar_phold);
} /* Line: 856 */
 else  /* Line: 857 */ {
bevl_dmname = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_145));
} /* Line: 858 */
bevl_superArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_146));
bevl_args = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_147));
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 863 */ {
bevt_79_tmpvar_phold = bevo_38;
bevt_78_tmpvar_phold = bevl_dnumargs.bem_add_1(bevt_79_tmpvar_phold);
bevt_77_tmpvar_phold = bevl_j.bem_lesser_1(bevt_78_tmpvar_phold);
if (bevt_77_tmpvar_phold.bevi_bool) /* Line: 863 */ {
bevt_80_tmpvar_phold = bevl_j.bem_lesser_1(bevp_maxDynArgs);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 863 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 863 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 863 */
 else  /* Line: 863 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 863 */ {
bevt_84_tmpvar_phold = bevo_39;
bevt_83_tmpvar_phold = bevl_args.bem_add_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_85_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_86_tmpvar_phold);
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevt_85_tmpvar_phold);
bevt_87_tmpvar_phold = bevo_40;
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_add_1(bevt_87_tmpvar_phold);
bevt_89_tmpvar_phold = bevo_41;
bevt_88_tmpvar_phold = bevl_j.bem_subtract_1(bevt_89_tmpvar_phold);
bevl_args = bevt_81_tmpvar_phold.bem_add_1(bevt_88_tmpvar_phold);
bevt_92_tmpvar_phold = bevo_42;
bevt_91_tmpvar_phold = bevl_superArgs.bem_add_1(bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = bevo_43;
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bem_add_1(bevt_93_tmpvar_phold);
bevt_95_tmpvar_phold = bevo_44;
bevt_94_tmpvar_phold = bevl_j.bem_subtract_1(bevt_95_tmpvar_phold);
bevl_superArgs = bevt_90_tmpvar_phold.bem_add_1(bevt_94_tmpvar_phold);
bevl_j = bevl_j.bem_increment_0();
} /* Line: 866 */
 else  /* Line: 863 */ {
break;
} /* Line: 863 */
} /* Line: 863 */
bevt_96_tmpvar_phold = bevl_dnumargs.bem_greaterEquals_1(bevp_maxDynArgs);
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 868 */ {
bevt_99_tmpvar_phold = bevo_45;
bevt_98_tmpvar_phold = bevl_args.bem_add_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_100_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_101_tmpvar_phold);
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_add_1(bevt_100_tmpvar_phold);
bevt_102_tmpvar_phold = bevo_46;
bevl_args = bevt_97_tmpvar_phold.bem_add_1(bevt_102_tmpvar_phold);
bevt_103_tmpvar_phold = bevo_47;
bevl_superArgs = bevl_superArgs.bem_add_1(bevt_103_tmpvar_phold);
} /* Line: 870 */
bevt_113_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_112_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_113_tmpvar_phold);
bevt_115_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_114_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_115_tmpvar_phold);
bevt_111_tmpvar_phold = (BEC_4_6_TextString) bevt_112_tmpvar_phold.bem_addValue_1(bevt_114_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_155));
bevt_110_tmpvar_phold = (BEC_4_6_TextString) bevt_111_tmpvar_phold.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_109_tmpvar_phold = (BEC_4_6_TextString) bevt_110_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_156));
bevt_108_tmpvar_phold = (BEC_4_6_TextString) bevt_109_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_107_tmpvar_phold = (BEC_4_6_TextString) bevt_108_tmpvar_phold.bem_addValue_1(bevl_args);
bevt_118_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_157));
bevt_106_tmpvar_phold = (BEC_4_6_TextString) bevt_107_tmpvar_phold.bem_addValue_1(bevt_118_tmpvar_phold);
bevt_105_tmpvar_phold = (BEC_4_6_TextString) bevt_106_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_119_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_158));
bevt_104_tmpvar_phold = (BEC_4_6_TextString) bevt_105_tmpvar_phold.bem_addValue_1(bevt_119_tmpvar_phold);
bevt_104_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(19, bels_159));
bevt_120_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_120_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_dgm = (BEC_9_3_ContainerMap) bevl_dnode.bem_valueGet_0();
bevt_3_tmpvar_loop = bevl_dgm.bem_iteratorGet_0();
while (true)
 /* Line: 876 */ {
bevt_122_tmpvar_phold = bevt_3_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 876 */ {
bevl_msnode = (BEC_9_3_7_ContainerMapMapNode) bevt_3_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_thisHash = (BEC_4_3_MathInt) bevl_msnode.bem_keyGet_0();
bevl_dgv = (BEC_9_5_ContainerArray) bevl_msnode.bem_valueGet_0();
bevt_125_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_160));
bevt_124_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_125_tmpvar_phold);
bevt_126_tmpvar_phold = bevl_thisHash.bem_toString_0();
bevt_123_tmpvar_phold = (BEC_4_6_TextString) bevt_124_tmpvar_phold.bem_addValue_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_161));
bevt_123_tmpvar_phold.bem_addValue_1(bevt_127_tmpvar_phold);
if (bevp_dynConditionsAll.bevi_bool) /* Line: 883 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 883 */ {
bevt_129_tmpvar_phold = bevl_dgv.bem_sizeGet_0();
bevt_130_tmpvar_phold = bevo_48;
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_greater_1(bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold.bevi_bool) /* Line: 883 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 883 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 883 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 883 */ {
bevl_dynConditions = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 884 */
 else  /* Line: 885 */ {
bevl_dynConditions = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 886 */
bevt_4_tmpvar_loop = bevl_dgv.bem_iteratorGet_0();
while (true)
 /* Line: 888 */ {
bevt_131_tmpvar_phold = bevt_4_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_131_tmpvar_phold != null && bevt_131_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_131_tmpvar_phold).bevi_bool) /* Line: 888 */ {
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_4_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_mcall = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
if (bevl_dynConditions.bevi_bool) /* Line: 890 */ {
bevt_133_tmpvar_phold = bevo_49;
bevt_132_tmpvar_phold = bevp_libEmitName.bem_add_1(bevt_133_tmpvar_phold);
bevt_134_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_constName = bevt_132_tmpvar_phold.bem_add_1(bevt_134_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_163));
bevt_137_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_constName);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_164));
bevt_135_tmpvar_phold = (BEC_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_135_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 892 */
bevt_142_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_165));
bevt_141_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_142_tmpvar_phold);
bevt_143_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_140_tmpvar_phold = (BEC_4_6_TextString) bevt_141_tmpvar_phold.bem_addValue_1(bevt_143_tmpvar_phold);
bevt_144_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_166));
bevt_140_tmpvar_phold.bem_addValue_1(bevt_144_tmpvar_phold);
bevl_vnumargs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_145_tmpvar_phold = bevl_msyn.bem_argSynsGet_0();
bevt_5_tmpvar_loop = bevt_145_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 896 */ {
bevt_146_tmpvar_phold = bevt_5_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 896 */ {
bevl_vsyn = (BEC_5_6_BuildVarSyn) bevt_5_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_148_tmpvar_phold = bevo_50;
bevt_147_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_148_tmpvar_phold);
if (bevt_147_tmpvar_phold.bevi_bool) /* Line: 897 */ {
bevt_149_tmpvar_phold = bevl_vsyn.bem_isTypedGet_0();
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 898 */ {
bevt_151_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bem_notEquals_1(bevp_objectNp);
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 898 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 898 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 898 */
 else  /* Line: 898 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 898 */ {
bevt_154_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_153_tmpvar_phold = this.bem_getClassConfig_1(bevt_154_tmpvar_phold);
bevt_152_tmpvar_phold = this.bem_formCast_1(bevt_153_tmpvar_phold);
bevt_155_tmpvar_phold = bevo_51;
bevl_vcast = bevt_152_tmpvar_phold.bem_add_1(bevt_155_tmpvar_phold);
} /* Line: 899 */
 else  /* Line: 900 */ {
bevl_vcast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_168));
} /* Line: 901 */
bevt_157_tmpvar_phold = bevo_52;
bevt_156_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_157_tmpvar_phold);
if (bevt_156_tmpvar_phold.bevi_bool) /* Line: 903 */ {
bevl_vcma = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_169));
} /* Line: 904 */
 else  /* Line: 905 */ {
bevl_vcma = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_170));
} /* Line: 906 */
bevt_158_tmpvar_phold = bevl_vnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_158_tmpvar_phold.bevi_bool) /* Line: 908 */ {
bevt_159_tmpvar_phold = bevo_53;
bevt_161_tmpvar_phold = bevo_54;
bevt_160_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevt_161_tmpvar_phold);
bevl_varg = bevt_159_tmpvar_phold.bem_add_1(bevt_160_tmpvar_phold);
} /* Line: 909 */
 else  /* Line: 910 */ {
bevt_163_tmpvar_phold = bevo_55;
bevt_164_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevp_maxDynArgs);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bem_add_1(bevt_164_tmpvar_phold);
bevt_165_tmpvar_phold = bevo_56;
bevl_varg = bevt_162_tmpvar_phold.bem_add_1(bevt_165_tmpvar_phold);
} /* Line: 911 */
bevt_167_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevl_vcma);
bevt_166_tmpvar_phold = (BEC_4_6_TextString) bevt_167_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_166_tmpvar_phold.bem_addValue_1(bevl_varg);
} /* Line: 913 */
bevl_vnumargs = bevl_vnumargs.bem_increment_0();
} /* Line: 915 */
 else  /* Line: 896 */ {
break;
} /* Line: 896 */
} /* Line: 896 */
bevt_169_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_174));
bevt_168_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_169_tmpvar_phold);
bevt_168_tmpvar_phold.bem_addValue_1(bevp_nl);
if (bevl_dynConditions.bevi_bool) /* Line: 918 */ {
bevt_171_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_175));
bevt_170_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_170_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 920 */
bevp_dynMethods.bem_addValue_1(bevl_mcall);
} /* Line: 923 */
 else  /* Line: 888 */ {
break;
} /* Line: 888 */
} /* Line: 888 */
if (bevl_dynConditions.bevi_bool) /* Line: 925 */ {
bevt_173_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_176));
bevt_172_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_173_tmpvar_phold);
bevt_172_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 926 */
} /* Line: 925 */
 else  /* Line: 876 */ {
break;
} /* Line: 876 */
} /* Line: 876 */
bevt_175_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_177));
bevt_174_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_175_tmpvar_phold);
bevt_174_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_183_tmpvar_phold = bevo_57;
bevt_184_tmpvar_phold = this.bem_superNameGet_0();
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_185_tmpvar_phold = bevo_58;
bevt_181_tmpvar_phold = bevt_182_tmpvar_phold.bem_add_1(bevt_185_tmpvar_phold);
bevt_180_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_181_tmpvar_phold);
bevt_179_tmpvar_phold = (BEC_4_6_TextString) bevt_180_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_186_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_180));
bevt_178_tmpvar_phold = (BEC_4_6_TextString) bevt_179_tmpvar_phold.bem_addValue_1(bevt_186_tmpvar_phold);
bevt_177_tmpvar_phold = (BEC_4_6_TextString) bevt_178_tmpvar_phold.bem_addValue_1(bevl_superArgs);
bevt_187_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_181));
bevt_176_tmpvar_phold = (BEC_4_6_TextString) bevt_177_tmpvar_phold.bem_addValue_1(bevt_187_tmpvar_phold);
bevt_176_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_189_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_182));
bevt_188_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_189_tmpvar_phold);
bevt_188_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 931 */
 else  /* Line: 852 */ {
break;
} /* Line: 852 */
} /* Line: 852 */
this.bem_buildClassInfo_0();
this.bem_buildCreate_0();
this.bem_buildInitial_0();
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getNativeCSlots_1(BEC_4_6_TextString beva_text) {
BEC_4_3_MathInt bevl_nativeSlots = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_isfn = null;
BEC_6_6_SystemObject bevl_nextIsNativeSlots = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_183));
bevl_ll = beva_text.bem_split_1(bevt_1_tmpvar_phold);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 950 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 950 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_nextIsNativeSlots != null && bevl_nextIsNativeSlots is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_nextIsNativeSlots).bevi_bool) /* Line: 951 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevl_i);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 954 */
 else  /* Line: 951 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_184));
bevt_3_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 955 */ {
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 957 */
 else  /* Line: 951 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(20, bels_185));
bevt_5_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 958 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 959 */
} /* Line: 951 */
} /* Line: 951 */
} /* Line: 951 */
 else  /* Line: 950 */ {
break;
} /* Line: 950 */
} /* Line: 950 */
bevt_8_tmpvar_phold = bevo_59;
bevt_7_tmpvar_phold = bevl_nativeSlots.bem_greater_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 962 */ {
} /* Line: 962 */
return bevl_nativeSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildCreate_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_186));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_187));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_188));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_16_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_relEmitName_1(bevt_19_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_189));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_190));
bevt_21_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildInitial_0() {
BEC_4_6_TextString bevl_oname = null;
BEC_4_6_TextString bevl_mname = null;
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_4_6_TextString bevl_vcast = null;
BEC_5_11_BuildClassConfig bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_oname = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bem_relEmitName_1(bevt_1_tmpvar_phold);
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_2_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_10_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_191));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_192));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_193));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 983 */ {
bevl_vcast = this.bem_formCast_1(bevp_classConf);
} /* Line: 984 */
 else  /* Line: 985 */ {
bevl_vcast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_194));
} /* Line: 986 */
bevt_18_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_195));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_196));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_197));
bevt_21_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_198));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_199));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_200));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_201));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_202));
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpvar_phold);
bevt_36_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_buildClassInfo_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_203));
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_buildClassInfo_2(bevt_0_tmpvar_phold, (BEC_4_6_TextString) bevt_1_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_204));
this.bem_buildClassInfo_2(bevt_4_tmpvar_phold, bevp_inFilePathed);
return this;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_buildClassInfo_2(BEC_4_6_TextString beva_belsBase, BEC_4_6_TextString beva_lival) {
BEC_4_6_TextString bevl_belsName = null;
BEC_4_6_TextString bevl_sdec = null;
BEC_4_3_MathInt bevl_lisz = null;
BEC_4_3_MathInt bevl_lipos = null;
BEC_4_3_MathInt bevl_bcode = null;
BEC_4_6_TextString bevl_hs = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_60;
bevl_belsName = bevt_0_tmpvar_phold.bem_add_1(beva_belsBase);
bevl_sdec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevl_lisz = beva_lival.bem_sizeGet_0();
bevl_lipos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_bcode = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_hs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
while (true)
 /* Line: 1018 */ {
bevt_2_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1018 */ {
bevt_4_tmpvar_phold = bevo_61;
bevt_3_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1019 */ {
bevt_6_tmpvar_phold = bevo_62;
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1020 */
this.bem_lstringByte_5(bevl_sdec, beva_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1023 */
 else  /* Line: 1018 */ {
break;
} /* Line: 1018 */
} /* Line: 1018 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
this.bem_buildClassInfoMethod_1(beva_belsBase);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_4_6_TextString beva_belsBase) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_207));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_208));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_209));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_210));
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_211));
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_10_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_212));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_initialDecGet_0() {
BEC_4_6_TextString bevl_initialDec = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevl_initialDec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_1_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1044 */ {
bevt_5_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_213));
bevt_4_tmpvar_phold = this.bem_baseSpropDec_2(bevt_5_tmpvar_phold, bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_214));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1045 */
 else  /* Line: 1046 */ {
bevt_11_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_215));
bevt_10_tmpvar_phold = this.bem_overrideSpropDec_2(bevt_11_tmpvar_phold, bevt_12_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_216));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1047 */
return bevl_initialDec;
} /*method end*/
public virtual BEC_4_6_TextString bem_classBeginGet_0() {
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_clb = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1054 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 1055 */
 else  /* Line: 1056 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_217));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 1057 */
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_218));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_219));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevl_clb = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpvar_phold = this.bem_klassDecGet_0();
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevl_extends);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_220));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_221));
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_222));
bevt_15_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_223));
bevt_20_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_224));
bevt_22_tmpvar_phold = this.bem_emitting_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1063 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_225));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_226));
bevt_24_tmpvar_phold.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_227));
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1065 */
return bevl_clb;
} /*method end*/
public virtual BEC_4_6_TextString bem_classEndGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_228));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_baseSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_63;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_typeName);
bevt_4_tmpvar_phold = bevo_64;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_varName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_231));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_overrideSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_232));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getTraceInfo_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_trInfo = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_trInfo = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
if (beva_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1090 */ {
bevt_3_tmpvar_phold = beva_node.bem_nlcGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1090 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1090 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1090 */
 else  /* Line: 1090 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1090 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_233));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevl_trInfo.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = beva_node.bem_nlcGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_toString_0();
bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 1091 */
return bevl_trInfo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptBraces_1(BEC_5_4_BuildNode beva_node) {
BEC_4_3_MathInt bevl_typename = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 1097 */ {
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_typename = bevt_6_tmpvar_phold.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1099 */ {
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_9_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1099 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1099 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1099 */
 else  /* Line: 1099 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1099 */ {
bevt_12_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_11_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 1099 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1099 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1099 */
 else  /* Line: 1099 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1099 */ {
bevt_14_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_13_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1099 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1099 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1099 */
 else  /* Line: 1099 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1099 */ {
bevt_16_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_15_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 1099 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1099 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1099 */
 else  /* Line: 1099 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1099 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_234));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_235));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1101 */
} /* Line: 1099 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptRbraces_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_nct = null;
BEC_6_6_SystemObject bevl_typename = null;
BEC_4_3_MathInt bevl_methodsOffset = null;
BEC_5_4_BuildNode bevl_mc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1110 */ {
bevt_9_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_containerGet_0();
if (bevt_8_tmpvar_phold == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1110 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1110 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1110 */
 else  /* Line: 1110 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1110 */ {
bevt_10_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_nct = bevt_10_tmpvar_phold.bem_containerGet_0();
bevl_typename = bevl_nct.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_11_tmpvar_phold = bevl_typename.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1113 */ {
if (bevp_mnode == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1114 */ {
if (bevp_lastCall == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 1115 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1115 */ {
bevt_17_tmpvar_phold = bevp_lastCall.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_236));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_18_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 1115 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1115 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1115 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1115 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_237));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1118 */
bevt_22_tmpvar_phold = bevo_65;
bevt_21_tmpvar_phold = bevp_maxSpillArgsLen.bem_greater_1(bevt_22_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 1121 */ {
bevt_30_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_29_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_30_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_238));
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevt_28_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_33_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_32_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_33_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_239));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevp_maxSpillArgsLen.bem_toString_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_240));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1122 */
bevl_methodsOffset = this.bem_countLines_2(bevp_methods, bevp_lastMethodsSize);
bevl_methodsOffset.bem_addValue_1(bevp_lastMethodsLines);
bevp_lastMethodsLines = bevl_methodsOffset;
bevp_lastMethodsSize = bevp_methods.bem_sizeGet_0();
bevt_0_tmpvar_loop = bevp_methodCalls.bem_iteratorGet_0();
while (true)
 /* Line: 1132 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 1132 */ {
bevl_mc = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_38_tmpvar_phold = bevl_mc.bem_nlecGet_0();
bevt_38_tmpvar_phold.bem_addValue_1(bevl_methodsOffset);
} /* Line: 1133 */
 else  /* Line: 1132 */ {
break;
} /* Line: 1132 */
} /* Line: 1132 */
bevp_classCalls.bem_addValue_1(bevp_methodCalls);
bevt_39_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCalls.bem_lengthSet_1(bevt_39_tmpvar_phold);
bevp_methods.bem_addValue_1(bevp_methodBody);
bevp_methodBody.bem_clear_0();
bevp_lastMethodBodySize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCatch = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastCall = null;
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_241));
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
bevp_msyn = null;
bevp_mnode = null;
} /* Line: 1151 */
} /* Line: 1114 */
 else  /* Line: 1113 */ {
bevt_43_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_42_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 1153 */ {
bevt_45_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_44_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 1153 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1153 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1153 */
 else  /* Line: 1153 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1153 */ {
bevt_47_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_46_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 1153 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1153 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1153 */
 else  /* Line: 1153 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1153 */ {
bevt_51_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_242));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_243));
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_48_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1155 */
} /* Line: 1113 */
} /* Line: 1113 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_countLines_1(BEC_4_6_TextString beva_text) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_countLines_2(beva_text, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_countLines_2(BEC_4_6_TextString beva_text, BEC_4_3_MathInt beva_start) {
BEC_4_3_MathInt bevl_found = null;
BEC_4_3_MathInt bevl_nlval = null;
BEC_4_3_MathInt bevl_cursor = null;
BEC_4_3_MathInt bevl_slen = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_found = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_nlval = bevp_nl.bem_getInt_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl_cursor = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_slen = beva_text.bem_sizeGet_0();
bevl_i = beva_start;
while (true)
 /* Line: 1169 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_slen);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1169 */ {
beva_text.bem_getInt_2(bevl_i, bevl_cursor);
bevt_3_tmpvar_phold = bevl_cursor.bem_equals_1(bevl_nlval);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1171 */ {
bevl_found.bem_incrementValue_0();
} /* Line: 1172 */
bevl_i.bem_incrementValue_0();
} /* Line: 1169 */
 else  /* Line: 1169 */ {
break;
} /* Line: 1169 */
} /* Line: 1169 */
return bevl_found;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptIf_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_targs = null;
BEC_5_4_LogicBool bevl_isBool = null;
BEC_5_4_LogicBool bevl_isUnless = null;
BEC_4_6_TextString bevl_ev = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_firstGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_5_4_BuildNode) bevt_2_tmpvar_phold);
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_firstGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 1180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1180 */ {
bevt_19_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_firstGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevp_boolNp);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 1180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1180 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1180 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1180 */ {
bevl_isBool = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1181 */
 else  /* Line: 1182 */ {
bevl_isBool = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1183 */
bevt_21_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 1185 */ {
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_244));
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 1185 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1185 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1185 */
 else  /* Line: 1185 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1185 */ {
bevl_isUnless = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1186 */
 else  /* Line: 1187 */ {
bevl_isUnless = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1188 */
bevl_ev = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_245));
if (bevl_isUnless.bevi_bool) /* Line: 1191 */ {
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_246));
bevl_ev.bem_addValue_1(bevt_25_tmpvar_phold);
} /* Line: 1192 */
if (bevl_isBool.bevi_bool) /* Line: 1194 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_247));
bevt_26_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
} /* Line: 1196 */
 else  /* Line: 1197 */ {
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_248));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevp_instOf);
bevt_35_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_34_tmpvar_phold = bevp_boolCc.bem_relEmitName_1(bevt_35_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevt_29_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_249));
bevt_28_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_250));
bevt_38_tmpvar_phold = this.bem_emitting_1(bevt_39_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_not_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 1202 */ {
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_251));
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = this.bem_formCast_1(bevp_boolCc);
bevt_40_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
} /* Line: 1203 */
bevl_ev.bem_addValue_1(bevl_targs);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_252));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1206 */ {
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_253));
bevl_ev.bem_addValue_1(bevt_46_tmpvar_phold);
} /* Line: 1207 */
bevt_47_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_254));
bevl_ev.bem_addValue_1(bevt_47_tmpvar_phold);
} /* Line: 1209 */
if (bevl_isUnless.bevi_bool) /* Line: 1211 */ {
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_255));
bevl_ev.bem_addValue_1(bevt_48_tmpvar_phold);
} /* Line: 1212 */
bevt_51_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_256));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevl_ev);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_257));
bevt_49_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_oldacceptIf_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_targs = null;
BEC_4_6_TextString bevl_cexpr = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_firstGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_5_4_BuildNode) bevt_1_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1220 */ {
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_258));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1220 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1220 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1220 */
 else  /* Line: 1220 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1220 */ {
bevl_cexpr = bevp_instanceNotEqual;
} /* Line: 1221 */
 else  /* Line: 1222 */ {
bevl_cexpr = bevp_instanceEqual;
} /* Line: 1223 */
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_259));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevp_trueValue);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevl_cexpr);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_260));
bevt_10_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptCatch_1(BEC_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_finalAssign_3(BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_sFrom, BEC_5_8_BuildNamePath beva_castTo) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_finalAssignTo_2(beva_node, beva_castTo);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_sFrom);
bevt_4_tmpvar_phold = bevo_66;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_finalAssignTo_2(BEC_5_4_BuildNode beva_node, BEC_5_8_BuildNamePath beva_castTo) {
BEC_4_6_TextString bevl_cast = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1237 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(29, bels_262));
bevt_3_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 1238 */
bevt_7_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_263));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 1240 */ {
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_264));
bevt_9_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_10_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_9_tmpvar_phold);
} /* Line: 1241 */
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_265));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1243 */ {
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_266));
bevt_15_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_16_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_15_tmpvar_phold);
} /* Line: 1244 */
bevl_cast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_267));
if (beva_castTo == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 1247 */ {
bevt_19_tmpvar_phold = this.bem_getClassConfig_1(beva_castTo);
bevt_18_tmpvar_phold = this.bem_formCast_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_67;
bevl_cast = bevt_18_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
} /* Line: 1248 */
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevo_68;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevl_cast);
return bevt_21_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_superNameGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_270));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_formCast_1(BEC_5_11_BuildClassConfig beva_cc) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_69;
bevt_4_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpvar_phold = beva_cc.bem_relEmitName_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_70;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptThrow_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(38, bels_273));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_274));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_onceVarDec_1(BEC_4_6_TextString beva_count) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_71;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptCall_1(BEC_5_4_BuildNode beva_node) {
BEC_4_3_MathInt bevl_moreLines = null;
BEC_6_6_SystemObject bevl_errmsg = null;
BEC_4_3_MathInt bevl_ei = null;
BEC_5_8_BuildNamePath bevl_castTo = null;
BEC_4_6_TextString bevl_nullRes = null;
BEC_4_6_TextString bevl_notNullRes = null;
BEC_4_6_TextString bevl_returnCast = null;
BEC_5_4_LogicBool bevl_selfCall = null;
BEC_5_4_LogicBool bevl_superCall = null;
BEC_5_4_LogicBool bevl_isConstruct = null;
BEC_5_4_LogicBool bevl_isTyped = null;
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_callArgs = null;
BEC_4_6_TextString bevl_spillArgs = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_9_5_ContainerArray bevl_argCasts = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevl_target = null;
BEC_5_4_BuildNode bevl_targetNode = null;
BEC_4_3_MathInt bevl_spillArgPos = null;
BEC_5_4_LogicBool bevl_isOnce = null;
BEC_5_4_LogicBool bevl_onceDeced = null;
BEC_4_6_TextString bevl_ovar = null;
BEC_4_6_TextString bevl_odec = null;
BEC_4_6_TextString bevl_callAssign = null;
BEC_4_6_TextString bevl_postOnceCallAssign = null;
BEC_4_6_TextString bevl_cast = null;
BEC_4_6_TextString bevl_belsName = null;
BEC_4_6_TextString bevl_sdec = null;
BEC_4_6_TextString bevl_liorg = null;
BEC_4_6_TextString bevl_lival = null;
BEC_4_3_MathInt bevl_lisz = null;
BEC_4_3_MathInt bevl_lipos = null;
BEC_4_3_MathInt bevl_bcode = null;
BEC_4_6_TextString bevl_hs = null;
BEC_4_6_TextString bevl_newCall = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_4_6_TextString bevl_odinfo = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_8_BuildClassSyn bevl_asyn = null;
BEC_4_6_TextString bevl_dm = null;
BEC_4_6_TextString bevl_callArgSpill = null;
BEC_4_3_MathInt bevl_spillArgsLen = null;
BEC_4_6_TextString bevl_fc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_44_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_90_tmpvar_phold = null;
BEC_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_94_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_143_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_144_tmpvar_phold = null;
BEC_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_148_tmpvar_phold = null;
BEC_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_153_tmpvar_phold = null;
BEC_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_181_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_4_6_TextString bevt_187_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_4_6_TextString bevt_195_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_198_tmpvar_phold = null;
BEC_4_6_TextString bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_4_6_TextString bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_205_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_4_6_TextString bevt_207_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_4_6_TextString bevt_210_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_221_tmpvar_phold = null;
BEC_4_6_TextString bevt_222_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_227_tmpvar_phold = null;
BEC_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_230_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_231_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_234_tmpvar_phold = null;
BEC_4_3_MathInt bevt_235_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_239_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_4_6_TextString bevt_243_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_4_3_MathInt bevt_245_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_246_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_247_tmpvar_phold = null;
BEC_4_6_TextString bevt_248_tmpvar_phold = null;
BEC_4_6_TextString bevt_249_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_250_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_251_tmpvar_phold = null;
BEC_4_6_TextString bevt_252_tmpvar_phold = null;
BEC_4_6_TextString bevt_253_tmpvar_phold = null;
BEC_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_4_6_TextString bevt_257_tmpvar_phold = null;
BEC_4_6_TextString bevt_258_tmpvar_phold = null;
BEC_4_6_TextString bevt_259_tmpvar_phold = null;
BEC_4_6_TextString bevt_260_tmpvar_phold = null;
BEC_4_6_TextString bevt_261_tmpvar_phold = null;
BEC_4_6_TextString bevt_262_tmpvar_phold = null;
BEC_4_6_TextString bevt_263_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_265_tmpvar_phold = null;
BEC_4_6_TextString bevt_266_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_269_tmpvar_phold = null;
BEC_4_3_MathInt bevt_270_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_271_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_272_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_273_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_274_tmpvar_phold = null;
BEC_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_276_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_277_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_278_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_279_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_280_tmpvar_phold = null;
BEC_4_6_TextString bevt_281_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_282_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_283_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_284_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_285_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_286_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_287_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_288_tmpvar_phold = null;
BEC_4_6_TextString bevt_289_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_290_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_291_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_292_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_293_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_294_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_295_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_296_tmpvar_phold = null;
BEC_4_6_TextString bevt_297_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_298_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_299_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_300_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_301_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_302_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_303_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_304_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_305_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_306_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_307_tmpvar_phold = null;
BEC_4_6_TextString bevt_308_tmpvar_phold = null;
BEC_4_6_TextString bevt_309_tmpvar_phold = null;
BEC_4_6_TextString bevt_310_tmpvar_phold = null;
BEC_4_6_TextString bevt_311_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_312_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_313_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_314_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_315_tmpvar_phold = null;
BEC_4_6_TextString bevt_316_tmpvar_phold = null;
BEC_4_6_TextString bevt_317_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_318_tmpvar_phold = null;
BEC_4_6_TextString bevt_319_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_320_tmpvar_phold = null;
BEC_4_6_TextString bevt_321_tmpvar_phold = null;
BEC_4_6_TextString bevt_322_tmpvar_phold = null;
BEC_4_6_TextString bevt_323_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_324_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_325_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_326_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_327_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_328_tmpvar_phold = null;
BEC_4_6_TextString bevt_329_tmpvar_phold = null;
BEC_4_6_TextString bevt_330_tmpvar_phold = null;
BEC_4_6_TextString bevt_331_tmpvar_phold = null;
BEC_4_6_TextString bevt_332_tmpvar_phold = null;
BEC_4_6_TextString bevt_333_tmpvar_phold = null;
BEC_4_6_TextString bevt_334_tmpvar_phold = null;
BEC_4_6_TextString bevt_335_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_336_tmpvar_phold = null;
BEC_4_6_TextString bevt_337_tmpvar_phold = null;
BEC_4_6_TextString bevt_338_tmpvar_phold = null;
BEC_4_6_TextString bevt_339_tmpvar_phold = null;
BEC_4_6_TextString bevt_340_tmpvar_phold = null;
BEC_4_6_TextString bevt_341_tmpvar_phold = null;
BEC_4_6_TextString bevt_342_tmpvar_phold = null;
BEC_4_6_TextString bevt_343_tmpvar_phold = null;
BEC_4_6_TextString bevt_344_tmpvar_phold = null;
BEC_4_6_TextString bevt_345_tmpvar_phold = null;
BEC_4_6_TextString bevt_346_tmpvar_phold = null;
BEC_4_6_TextString bevt_347_tmpvar_phold = null;
BEC_4_6_TextString bevt_348_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_349_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_350_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_351_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_352_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_353_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_354_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_355_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_356_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_357_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_358_tmpvar_phold = null;
BEC_4_6_TextString bevt_359_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_360_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_361_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_362_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_363_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_364_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_365_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_366_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_367_tmpvar_phold = null;
BEC_4_12_JsonUnmarshaller bevt_368_tmpvar_phold = null;
BEC_4_6_TextString bevt_369_tmpvar_phold = null;
BEC_4_6_TextString bevt_370_tmpvar_phold = null;
BEC_4_6_TextString bevt_371_tmpvar_phold = null;
BEC_4_6_TextString bevt_372_tmpvar_phold = null;
BEC_4_6_TextString bevt_373_tmpvar_phold = null;
BEC_4_6_TextString bevt_374_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_375_tmpvar_phold = null;
BEC_4_6_TextString bevt_376_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_377_tmpvar_phold = null;
BEC_4_6_TextString bevt_378_tmpvar_phold = null;
BEC_4_3_MathInt bevt_379_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_380_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_381_tmpvar_phold = null;
BEC_4_3_MathInt bevt_382_tmpvar_phold = null;
BEC_4_6_TextString bevt_383_tmpvar_phold = null;
BEC_4_6_TextString bevt_384_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_385_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_386_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_387_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_388_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_389_tmpvar_phold = null;
BEC_4_6_TextString bevt_390_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_391_tmpvar_phold = null;
BEC_4_6_TextString bevt_392_tmpvar_phold = null;
BEC_4_6_TextString bevt_393_tmpvar_phold = null;
BEC_4_6_TextString bevt_394_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_395_tmpvar_phold = null;
BEC_4_6_TextString bevt_396_tmpvar_phold = null;
BEC_4_6_TextString bevt_397_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_398_tmpvar_phold = null;
BEC_4_6_TextString bevt_399_tmpvar_phold = null;
BEC_4_6_TextString bevt_400_tmpvar_phold = null;
BEC_4_6_TextString bevt_401_tmpvar_phold = null;
BEC_4_6_TextString bevt_402_tmpvar_phold = null;
BEC_4_6_TextString bevt_403_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_404_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_405_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_406_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_407_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_408_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_409_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_410_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_411_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_412_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_413_tmpvar_phold = null;
BEC_4_6_TextString bevt_414_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_415_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_416_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_417_tmpvar_phold = null;
BEC_4_6_TextString bevt_418_tmpvar_phold = null;
BEC_6_9_SystemException bevt_419_tmpvar_phold = null;
BEC_4_6_TextString bevt_420_tmpvar_phold = null;
BEC_4_6_TextString bevt_421_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_422_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_423_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_424_tmpvar_phold = null;
BEC_4_6_TextString bevt_425_tmpvar_phold = null;
BEC_4_6_TextString bevt_426_tmpvar_phold = null;
BEC_4_6_TextString bevt_427_tmpvar_phold = null;
BEC_4_6_TextString bevt_428_tmpvar_phold = null;
BEC_4_6_TextString bevt_429_tmpvar_phold = null;
BEC_4_6_TextString bevt_430_tmpvar_phold = null;
BEC_4_6_TextString bevt_431_tmpvar_phold = null;
BEC_4_6_TextString bevt_432_tmpvar_phold = null;
BEC_4_6_TextString bevt_433_tmpvar_phold = null;
BEC_4_6_TextString bevt_434_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_435_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_436_tmpvar_phold = null;
BEC_4_6_TextString bevt_437_tmpvar_phold = null;
BEC_4_6_TextString bevt_438_tmpvar_phold = null;
BEC_4_6_TextString bevt_439_tmpvar_phold = null;
BEC_4_6_TextString bevt_440_tmpvar_phold = null;
BEC_4_6_TextString bevt_441_tmpvar_phold = null;
BEC_4_6_TextString bevt_442_tmpvar_phold = null;
BEC_4_6_TextString bevt_443_tmpvar_phold = null;
BEC_4_6_TextString bevt_444_tmpvar_phold = null;
BEC_4_6_TextString bevt_445_tmpvar_phold = null;
BEC_4_6_TextString bevt_446_tmpvar_phold = null;
BEC_4_6_TextString bevt_447_tmpvar_phold = null;
BEC_4_6_TextString bevt_448_tmpvar_phold = null;
BEC_4_6_TextString bevt_449_tmpvar_phold = null;
BEC_4_6_TextString bevt_450_tmpvar_phold = null;
BEC_4_6_TextString bevt_451_tmpvar_phold = null;
BEC_4_6_TextString bevt_452_tmpvar_phold = null;
BEC_4_6_TextString bevt_453_tmpvar_phold = null;
BEC_4_6_TextString bevt_454_tmpvar_phold = null;
BEC_4_6_TextString bevt_455_tmpvar_phold = null;
BEC_4_6_TextString bevt_456_tmpvar_phold = null;
BEC_4_6_TextString bevt_457_tmpvar_phold = null;
BEC_4_6_TextString bevt_458_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_459_tmpvar_phold = null;
BEC_4_6_TextString bevt_460_tmpvar_phold = null;
BEC_4_6_TextString bevt_461_tmpvar_phold = null;
BEC_4_6_TextString bevt_462_tmpvar_phold = null;
BEC_4_6_TextString bevt_463_tmpvar_phold = null;
BEC_4_6_TextString bevt_464_tmpvar_phold = null;
BEC_4_6_TextString bevt_465_tmpvar_phold = null;
BEC_4_6_TextString bevt_466_tmpvar_phold = null;
BEC_4_6_TextString bevt_467_tmpvar_phold = null;
BEC_4_6_TextString bevt_468_tmpvar_phold = null;
BEC_4_6_TextString bevt_469_tmpvar_phold = null;
BEC_4_6_TextString bevt_470_tmpvar_phold = null;
BEC_4_6_TextString bevt_471_tmpvar_phold = null;
BEC_4_6_TextString bevt_472_tmpvar_phold = null;
BEC_4_6_TextString bevt_473_tmpvar_phold = null;
BEC_4_6_TextString bevt_474_tmpvar_phold = null;
BEC_4_6_TextString bevt_475_tmpvar_phold = null;
BEC_4_6_TextString bevt_476_tmpvar_phold = null;
BEC_4_6_TextString bevt_477_tmpvar_phold = null;
BEC_4_6_TextString bevt_478_tmpvar_phold = null;
BEC_4_6_TextString bevt_479_tmpvar_phold = null;
BEC_4_6_TextString bevt_480_tmpvar_phold = null;
BEC_4_6_TextString bevt_481_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_482_tmpvar_phold = null;
BEC_4_3_MathInt bevt_483_tmpvar_phold = null;
BEC_4_3_MathInt bevt_484_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_485_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_486_tmpvar_phold = null;
BEC_4_3_MathInt bevt_487_tmpvar_phold = null;
BEC_4_6_TextString bevt_488_tmpvar_phold = null;
BEC_4_6_TextString bevt_489_tmpvar_phold = null;
BEC_4_6_TextString bevt_490_tmpvar_phold = null;
BEC_4_6_TextString bevt_491_tmpvar_phold = null;
BEC_4_6_TextString bevt_492_tmpvar_phold = null;
BEC_4_6_TextString bevt_493_tmpvar_phold = null;
BEC_4_6_TextString bevt_494_tmpvar_phold = null;
BEC_4_6_TextString bevt_495_tmpvar_phold = null;
BEC_4_6_TextString bevt_496_tmpvar_phold = null;
BEC_4_6_TextString bevt_497_tmpvar_phold = null;
BEC_4_6_TextString bevt_498_tmpvar_phold = null;
BEC_4_6_TextString bevt_499_tmpvar_phold = null;
BEC_4_6_TextString bevt_500_tmpvar_phold = null;
BEC_4_6_TextString bevt_501_tmpvar_phold = null;
BEC_4_6_TextString bevt_502_tmpvar_phold = null;
BEC_4_6_TextString bevt_503_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_504_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_505_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_506_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_507_tmpvar_phold = null;
BEC_4_6_TextString bevt_508_tmpvar_phold = null;
BEC_4_6_TextString bevt_509_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_510_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_511_tmpvar_phold = null;
BEC_4_6_TextString bevt_512_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_513_tmpvar_phold = null;
BEC_4_6_TextString bevt_514_tmpvar_phold = null;
BEC_4_6_TextString bevt_515_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_516_tmpvar_phold = null;
BEC_4_6_TextString bevt_517_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_518_tmpvar_phold = null;
BEC_4_6_TextString bevt_519_tmpvar_phold = null;
BEC_4_6_TextString bevt_520_tmpvar_phold = null;
BEC_4_6_TextString bevt_521_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_522_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_523_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_524_tmpvar_phold = null;
BEC_4_6_TextString bevt_525_tmpvar_phold = null;
BEC_4_6_TextString bevt_526_tmpvar_phold = null;
BEC_4_6_TextString bevt_527_tmpvar_phold = null;
BEC_4_6_TextString bevt_528_tmpvar_phold = null;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_21_tmpvar_phold);
bevp_lastCall = beva_node;
bevp_methodCalls.bem_addValue_1(beva_node);
bevl_moreLines = this.bem_countLines_2(bevp_methodBody, bevp_lastMethodBodySize);
bevp_lastMethodBodyLines = bevp_lastMethodBodyLines.bem_add_1(bevl_moreLines);
bevp_lastMethodBodySize = bevp_methodBody.bem_sizeGet_0();
beva_node.bem_nlecSet_1(bevp_lastMethodBodyLines);
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_276));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 1286 */ {
bevt_29_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_lengthGet_0();
bevt_30_tmpvar_phold = bevo_72;
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_notEquals_1(bevt_30_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 1286 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1286 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1286 */
 else  /* Line: 1286 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1286 */ {
bevt_31_tmpvar_phold = bevo_73;
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_lengthGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_toString_0();
bevl_errmsg = bevt_31_tmpvar_phold.bem_add_1(bevt_32_tmpvar_phold);
bevl_ei = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 1288 */ {
bevt_37_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_lengthGet_0();
bevt_35_tmpvar_phold = bevl_ei.bem_lesser_1(bevt_36_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 1288 */ {
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_278));
bevt_40_tmpvar_phold = bevl_errmsg.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_ei);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_279));
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_get_1(bevl_ei);
bevl_errmsg = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpvar_phold);
bevl_ei = bevl_ei.bem_increment_0();
} /* Line: 1288 */
 else  /* Line: 1288 */ {
break;
} /* Line: 1288 */
} /* Line: 1288 */
bevt_45_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevl_errmsg, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_45_tmpvar_phold);
} /* Line: 1291 */
 else  /* Line: 1286 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_280));
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpvar_phold);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 1292 */ {
bevt_54_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_281));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 1292 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1292 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1292 */
 else  /* Line: 1292 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1292 */ {
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_282));
bevt_56_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_57_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_56_tmpvar_phold);
} /* Line: 1293 */
 else  /* Line: 1286 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_283));
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 1294 */ {
this.bem_acceptThrow_1(beva_node);
return this;
} /* Line: 1296 */
 else  /* Line: 1286 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_284));
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpvar_phold);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 1297 */ {
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_66_tmpvar_phold != null && bevt_66_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_66_tmpvar_phold).bevi_bool) /* Line: 1301 */ {
bevt_70_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_firstGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_5_8_BuildNamePath) bevt_68_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1302 */
bevt_73_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_typenameGet_0();
bevt_74_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_equals_1(bevt_74_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 1304 */ {
bevt_77_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_firstGet_0();
bevt_79_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_78_tmpvar_phold = this.bem_formTarg_1(bevt_79_tmpvar_phold);
bevt_75_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_76_tmpvar_phold, bevt_78_tmpvar_phold, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_75_tmpvar_phold);
} /* Line: 1306 */
 else  /* Line: 1304 */ {
bevt_82_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_typenameGet_0();
bevt_83_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_equals_1(bevt_83_tmpvar_phold);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 1307 */ {
bevt_86_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_firstGet_0();
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_285));
bevt_84_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_85_tmpvar_phold, bevt_87_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_84_tmpvar_phold);
} /* Line: 1308 */
 else  /* Line: 1304 */ {
bevt_90_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_typenameGet_0();
bevt_91_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_equals_1(bevt_91_tmpvar_phold);
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 1309 */ {
bevt_94_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bem_firstGet_0();
bevt_92_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_93_tmpvar_phold, bevp_trueValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_92_tmpvar_phold);
} /* Line: 1310 */
 else  /* Line: 1304 */ {
bevt_97_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_typenameGet_0();
bevt_98_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_equals_1(bevt_98_tmpvar_phold);
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 1311 */ {
bevt_101_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_firstGet_0();
bevt_99_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_100_tmpvar_phold, bevp_falseValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_99_tmpvar_phold);
} /* Line: 1312 */
 else  /* Line: 1304 */ {
bevt_105_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_heldGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_106_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_286));
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpvar_phold);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 1313 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1313 */ {
bevt_110_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_heldGet_0();
bevt_108_tmpvar_phold = bevt_109_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_111_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_287));
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_111_tmpvar_phold);
if (bevt_107_tmpvar_phold != null && bevt_107_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_107_tmpvar_phold).bevi_bool) /* Line: 1313 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1313 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1313 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 1313 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1313 */ {
bevt_115_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bem_heldGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_288));
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpvar_phold);
if (bevt_112_tmpvar_phold != null && bevt_112_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_112_tmpvar_phold).bevi_bool) /* Line: 1313 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1313 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1313 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1314 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_120_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bem_heldGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_289));
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_117_tmpvar_phold != null && bevt_117_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_117_tmpvar_phold).bevi_bool) /* Line: 1314 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1314 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1314 */ {
bevt_123_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 1321 */ {
bevt_129_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_firstGet_0();
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_130_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_290));
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_130_tmpvar_phold);
if (bevt_124_tmpvar_phold != null && bevt_124_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_124_tmpvar_phold).bevi_bool) /* Line: 1322 */ {
bevt_132_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(48, bels_291));
bevt_131_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 1323 */
} /* Line: 1322 */
bevt_136_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_137_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_292));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_137_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 1326 */ {
bevl_nullRes = bevp_trueValue;
bevl_notNullRes = bevp_falseValue;
} /* Line: 1328 */
 else  /* Line: 1329 */ {
bevl_nullRes = bevp_falseValue;
bevl_notNullRes = bevp_trueValue;
} /* Line: 1331 */
bevt_141_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_293));
bevt_140_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_141_tmpvar_phold);
bevt_144_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_143_tmpvar_phold = bevt_144_tmpvar_phold.bem_secondGet_0();
bevt_142_tmpvar_phold = this.bem_formTarg_1(bevt_143_tmpvar_phold);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) bevt_140_tmpvar_phold.bem_addValue_1(bevt_142_tmpvar_phold);
bevt_145_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_294));
bevt_138_tmpvar_phold = (BEC_4_6_TextString) bevt_139_tmpvar_phold.bem_addValue_1(bevt_145_tmpvar_phold);
bevt_138_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_148_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_147_tmpvar_phold = bevt_148_tmpvar_phold.bem_firstGet_0();
bevt_146_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_147_tmpvar_phold, bevl_nullRes, null);
bevp_methodBody.bem_addValue_1(bevt_146_tmpvar_phold);
bevt_150_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_295));
bevt_149_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_150_tmpvar_phold);
bevt_149_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_153_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bem_firstGet_0();
bevt_151_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_152_tmpvar_phold, bevl_notNullRes, null);
bevp_methodBody.bem_addValue_1(bevt_151_tmpvar_phold);
bevt_155_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_296));
bevt_154_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_155_tmpvar_phold);
bevt_154_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1337 */
} /* Line: 1304 */
} /* Line: 1304 */
} /* Line: 1304 */
} /* Line: 1304 */
return this;
} /* Line: 1339 */
 else  /* Line: 1286 */ {
bevt_158_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_157_tmpvar_phold = bevt_158_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_159_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_297));
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_159_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 1340 */ {
bevl_returnCast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_298));
bevt_161_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_160_tmpvar_phold != null && bevt_160_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_160_tmpvar_phold).bevi_bool) /* Line: 1343 */ {
bevt_162_tmpvar_phold = this.bem_formCast_1(bevp_returnType);
bevt_163_tmpvar_phold = bevo_74;
bevl_returnCast = bevt_162_tmpvar_phold.bem_add_1(bevt_163_tmpvar_phold);
} /* Line: 1344 */
bevt_168_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_300));
bevt_167_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_168_tmpvar_phold);
bevt_166_tmpvar_phold = (BEC_4_6_TextString) bevt_167_tmpvar_phold.bem_addValue_1(bevl_returnCast);
bevt_170_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_169_tmpvar_phold = this.bem_formTarg_1(bevt_170_tmpvar_phold);
bevt_165_tmpvar_phold = (BEC_4_6_TextString) bevt_166_tmpvar_phold.bem_addValue_1(bevt_169_tmpvar_phold);
bevt_171_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_301));
bevt_164_tmpvar_phold = (BEC_4_6_TextString) bevt_165_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_164_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /* Line: 1347 */
 else  /* Line: 1286 */ {
bevt_174_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_173_tmpvar_phold = bevt_174_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_175_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_302));
bevt_172_tmpvar_phold = bevt_173_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_175_tmpvar_phold);
if (bevt_172_tmpvar_phold != null && bevt_172_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_172_tmpvar_phold).bevi_bool) /* Line: 1348 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_178_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_179_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_303));
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_179_tmpvar_phold);
if (bevt_176_tmpvar_phold != null && bevt_176_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_176_tmpvar_phold).bevi_bool) /* Line: 1348 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1348 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 1348 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_182_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_181_tmpvar_phold = bevt_182_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_183_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_304));
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_183_tmpvar_phold);
if (bevt_180_tmpvar_phold != null && bevt_180_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_180_tmpvar_phold).bevi_bool) /* Line: 1348 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1348 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 1348 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_186_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_185_tmpvar_phold = bevt_186_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_187_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_305));
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_187_tmpvar_phold);
if (bevt_184_tmpvar_phold != null && bevt_184_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_184_tmpvar_phold).bevi_bool) /* Line: 1348 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1348 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1348 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 1348 */ {
return this;
} /* Line: 1350 */
} /* Line: 1286 */
} /* Line: 1286 */
} /* Line: 1286 */
} /* Line: 1286 */
} /* Line: 1286 */
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_194_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_195_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_306));
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_195_tmpvar_phold);
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_196_tmpvar_phold = bevt_197_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_196_tmpvar_phold);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_191_tmpvar_phold);
if (bevt_188_tmpvar_phold != null && bevt_188_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_188_tmpvar_phold).bevi_bool) /* Line: 1353 */ {
bevt_204_tmpvar_phold = bevo_75;
bevt_206_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevt_205_tmpvar_phold);
bevt_207_tmpvar_phold = bevo_76;
bevt_202_tmpvar_phold = bevt_203_tmpvar_phold.bem_add_1(bevt_207_tmpvar_phold);
bevt_209_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bem_add_1(bevt_208_tmpvar_phold);
bevt_210_tmpvar_phold = bevo_77;
bevt_200_tmpvar_phold = bevt_201_tmpvar_phold.bem_add_1(bevt_210_tmpvar_phold);
bevt_212_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_211_tmpvar_phold = bevt_212_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_199_tmpvar_phold = bevt_200_tmpvar_phold.bem_add_1(bevt_211_tmpvar_phold);
bevt_198_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_199_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_198_tmpvar_phold);
} /* Line: 1354 */
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_superCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isConstruct = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_214_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_213_tmpvar_phold != null && bevt_213_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_213_tmpvar_phold).bevi_bool) /* Line: 1362 */ {
bevl_isConstruct = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_215_tmpvar_phold);
} /* Line: 1364 */
 else  /* Line: 1362 */ {
bevt_221_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_220_tmpvar_phold = bevt_221_tmpvar_phold.bem_firstGet_0();
bevt_219_tmpvar_phold = bevt_220_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_218_tmpvar_phold = bevt_219_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_222_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_310));
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_222_tmpvar_phold);
if (bevt_217_tmpvar_phold != null && bevt_217_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_217_tmpvar_phold).bevi_bool) /* Line: 1365 */ {
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1366 */
 else  /* Line: 1362 */ {
bevt_227_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_226_tmpvar_phold = bevt_227_tmpvar_phold.bem_firstGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_228_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_311));
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_228_tmpvar_phold);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 1367 */ {
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_superCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_superCalls.bem_addValue_1(beva_node);
bevt_229_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_230_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_229_tmpvar_phold.bemd_1(1785494885, BEL_4_Base.bevn_superCallSet_1, bevt_230_tmpvar_phold);
} /* Line: 1371 */
} /* Line: 1362 */
} /* Line: 1362 */
bevl_callArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_spillArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_numargs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_231_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_231_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1380 */ {
bevt_232_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_232_tmpvar_phold != null && bevt_232_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_232_tmpvar_phold).bevi_bool) /* Line: 1380 */ {
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_argCasts = (BEC_9_5_ContainerArray) bevt_233_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_235_tmpvar_phold = bevo_78;
bevt_234_tmpvar_phold = bevl_numargs.bem_equals_1(bevt_235_tmpvar_phold);
if (bevt_234_tmpvar_phold.bevi_bool) /* Line: 1383 */ {
bevl_target = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevl_targetNode = (BEC_5_4_BuildNode) bevl_i;
bevt_237_tmpvar_phold = bevl_targetNode.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_236_tmpvar_phold != null && bevt_236_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_236_tmpvar_phold).bevi_bool) /* Line: 1387 */ {
bevl_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1388 */
} /* Line: 1387 */
 else  /* Line: 1390 */ {
if (bevl_isTyped.bevi_bool) /* Line: 1391 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1391 */ {
bevt_238_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 1391 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1391 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1391 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 1391 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1391 */ {
bevt_240_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_239_tmpvar_phold = bevt_240_tmpvar_phold.bem_not_0();
if (bevt_239_tmpvar_phold.bevi_bool) /* Line: 1391 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1391 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1391 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 1391 */ {
bevt_242_tmpvar_phold = bevo_79;
bevt_241_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_242_tmpvar_phold);
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 1392 */ {
bevt_243_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_312));
bevl_callArgs.bem_addValue_1(bevt_243_tmpvar_phold);
} /* Line: 1393 */
bevt_245_tmpvar_phold = bevl_argCasts.bem_lengthGet_0();
bevt_244_tmpvar_phold = bevt_245_tmpvar_phold.bem_greater_1(bevl_numargs);
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 1395 */ {
bevt_247_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
if (bevt_247_tmpvar_phold == null) {
bevt_246_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_246_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_246_tmpvar_phold.bevi_bool) /* Line: 1395 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1395 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1395 */
 else  /* Line: 1395 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 1395 */ {
bevt_251_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
bevt_250_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_251_tmpvar_phold);
bevt_249_tmpvar_phold = this.bem_formCast_1(bevt_250_tmpvar_phold);
bevt_248_tmpvar_phold = (BEC_4_6_TextString) bevl_callArgs.bem_addValue_1(bevt_249_tmpvar_phold);
bevt_252_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_313));
bevt_248_tmpvar_phold.bem_addValue_1(bevt_252_tmpvar_phold);
} /* Line: 1396 */
bevt_253_tmpvar_phold = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevl_callArgs.bem_addValue_1(bevt_253_tmpvar_phold);
} /* Line: 1398 */
 else  /* Line: 1399 */ {
bevl_spillArgPos = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_259_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_314));
bevt_258_tmpvar_phold = (BEC_4_6_TextString) bevl_spillArgs.bem_addValue_1(bevt_259_tmpvar_phold);
bevt_260_tmpvar_phold = bevl_spillArgPos.bem_toString_0();
bevt_257_tmpvar_phold = (BEC_4_6_TextString) bevt_258_tmpvar_phold.bem_addValue_1(bevt_260_tmpvar_phold);
bevt_261_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_315));
bevt_256_tmpvar_phold = (BEC_4_6_TextString) bevt_257_tmpvar_phold.bem_addValue_1(bevt_261_tmpvar_phold);
bevt_262_tmpvar_phold = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevt_255_tmpvar_phold = (BEC_4_6_TextString) bevt_256_tmpvar_phold.bem_addValue_1(bevt_262_tmpvar_phold);
bevt_263_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_316));
bevt_254_tmpvar_phold = (BEC_4_6_TextString) bevt_255_tmpvar_phold.bem_addValue_1(bevt_263_tmpvar_phold);
bevt_254_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1402 */
} /* Line: 1391 */
bevl_numargs = bevl_numargs.bem_increment_0();
} /* Line: 1405 */
 else  /* Line: 1380 */ {
break;
} /* Line: 1380 */
} /* Line: 1380 */
bevl_numargs = bevl_numargs.bem_decrement_0();
if (bevl_isConstruct.bevi_bool) /* Line: 1411 */ {
bevt_264_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_264_tmpvar_phold.bevi_bool) /* Line: 1411 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1411 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1411 */
 else  /* Line: 1411 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 1411 */ {
bevt_266_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(27, bels_317));
bevt_265_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_266_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_265_tmpvar_phold);
} /* Line: 1412 */
bevl_isOnce = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_onceDeced = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_269_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_268_tmpvar_phold = bevt_269_tmpvar_phold.bem_typenameGet_0();
bevt_270_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_267_tmpvar_phold = bevt_268_tmpvar_phold.bem_equals_1(bevt_270_tmpvar_phold);
if (bevt_267_tmpvar_phold.bevi_bool) /* Line: 1419 */ {
bevt_274_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_heldGet_0();
bevt_272_tmpvar_phold = bevt_273_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_275_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_318));
bevt_271_tmpvar_phold = bevt_272_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_275_tmpvar_phold);
if (bevt_271_tmpvar_phold != null && bevt_271_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_271_tmpvar_phold).bevi_bool) /* Line: 1419 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1419 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1419 */
 else  /* Line: 1419 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 1419 */ {
bevt_277_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_276_tmpvar_phold = this.bem_isOnceAssign_1(bevt_277_tmpvar_phold);
if (bevt_276_tmpvar_phold.bevi_bool) /* Line: 1420 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1420 */ {
bevt_279_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_278_tmpvar_phold = bevt_279_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_278_tmpvar_phold.bevi_bool) /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1420 */
 else  /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
bevt_280_tmpvar_phold = bevt_14_tmpvar_anchor.bem_not_0();
if (bevt_280_tmpvar_phold.bevi_bool) /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1420 */
 else  /* Line: 1420 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 1420 */ {
bevl_isOnce = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_281_tmpvar_phold = bevp_onceCount.bem_toString_0();
bevl_ovar = this.bem_onceVarDec_1(bevt_281_tmpvar_phold);
bevp_onceCount = bevp_onceCount.bem_increment_0();
bevt_287_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_286_tmpvar_phold = bevt_287_tmpvar_phold.bem_containedGet_0();
bevt_285_tmpvar_phold = bevt_286_tmpvar_phold.bem_firstGet_0();
bevt_284_tmpvar_phold = bevt_285_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_283_tmpvar_phold = bevt_284_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_282_tmpvar_phold = bevt_283_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_282_tmpvar_phold != null && bevt_282_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_282_tmpvar_phold).bevi_bool) /* Line: 1425 */ {
bevt_289_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_288_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_289_tmpvar_phold);
bevl_odec = (BEC_4_6_TextString) this.bem_onceDec_2((BEC_4_6_TextString) bevt_288_tmpvar_phold, bevl_ovar);
} /* Line: 1426 */
 else  /* Line: 1427 */ {
bevt_296_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_295_tmpvar_phold = bevt_296_tmpvar_phold.bem_containedGet_0();
bevt_294_tmpvar_phold = bevt_295_tmpvar_phold.bem_firstGet_0();
bevt_293_tmpvar_phold = bevt_294_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_292_tmpvar_phold = bevt_293_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_291_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_292_tmpvar_phold);
bevt_297_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_290_tmpvar_phold = bevt_291_tmpvar_phold.bem_relEmitName_1(bevt_297_tmpvar_phold);
bevl_odec = (BEC_4_6_TextString) this.bem_onceDec_2((BEC_4_6_TextString) bevt_290_tmpvar_phold, bevl_ovar);
} /* Line: 1428 */
} /* Line: 1425 */
bevt_300_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_299_tmpvar_phold = bevt_300_tmpvar_phold.bem_heldGet_0();
bevt_298_tmpvar_phold = bevt_299_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_298_tmpvar_phold != null && bevt_298_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_298_tmpvar_phold).bevi_bool) /* Line: 1433 */ {
bevt_304_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bem_containedGet_0();
bevt_302_tmpvar_phold = bevt_303_tmpvar_phold.bem_firstGet_0();
bevt_301_tmpvar_phold = bevt_302_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_5_8_BuildNamePath) bevt_301_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1435 */
bevt_307_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_306_tmpvar_phold = bevt_307_tmpvar_phold.bem_containedGet_0();
bevt_305_tmpvar_phold = bevt_306_tmpvar_phold.bem_firstGet_0();
bevl_callAssign = this.bem_finalAssignTo_2((BEC_5_4_BuildNode) bevt_305_tmpvar_phold, bevl_castTo);
} /* Line: 1437 */
 else  /* Line: 1438 */ {
bevl_callAssign = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_319));
} /* Line: 1439 */
if (bevl_isOnce.bevi_bool) /* Line: 1442 */ {
bevt_315_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_314_tmpvar_phold = bevt_315_tmpvar_phold.bem_containedGet_0();
bevt_313_tmpvar_phold = bevt_314_tmpvar_phold.bem_firstGet_0();
bevt_312_tmpvar_phold = bevt_313_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_311_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_312_tmpvar_phold);
bevt_316_tmpvar_phold = bevo_80;
bevt_310_tmpvar_phold = bevt_311_tmpvar_phold.bem_add_1(bevt_316_tmpvar_phold);
bevt_309_tmpvar_phold = bevt_310_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_317_tmpvar_phold = bevo_81;
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bem_add_1(bevt_317_tmpvar_phold);
bevl_postOnceCallAssign = bevt_308_tmpvar_phold.bem_add_1(bevp_nl);
if (bevl_castTo == null) {
bevt_318_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_318_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_318_tmpvar_phold.bevi_bool) /* Line: 1446 */ {
bevt_320_tmpvar_phold = this.bem_getClassConfig_1(bevl_castTo);
bevt_319_tmpvar_phold = this.bem_formCast_1(bevt_320_tmpvar_phold);
bevt_321_tmpvar_phold = bevo_82;
bevl_cast = bevt_319_tmpvar_phold.bem_add_1(bevt_321_tmpvar_phold);
} /* Line: 1447 */
 else  /* Line: 1448 */ {
bevl_cast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_323));
} /* Line: 1449 */
bevt_323_tmpvar_phold = bevo_83;
bevt_322_tmpvar_phold = bevl_ovar.bem_add_1(bevt_323_tmpvar_phold);
bevl_callAssign = bevt_322_tmpvar_phold.bem_add_1(bevl_cast);
} /* Line: 1451 */
if (bevl_isTyped.bevi_bool) /* Line: 1455 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1455 */ {
bevt_325_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_324_tmpvar_phold = bevt_325_tmpvar_phold.bem_not_0();
if (bevt_324_tmpvar_phold.bevi_bool) /* Line: 1455 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1455 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1455 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 1455 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1455 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1455 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1455 */
 else  /* Line: 1455 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 1455 */ {
bevt_327_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_326_tmpvar_phold = bevt_327_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_326_tmpvar_phold != null && bevt_326_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_326_tmpvar_phold).bevi_bool) /* Line: 1455 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1455 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1455 */
 else  /* Line: 1455 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 1455 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1455 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1455 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1455 */
 else  /* Line: 1455 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 1455 */ {
bevl_onceDeced = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1456 */
 else  /* Line: 1455 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1457 */ {
bevt_329_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_325));
bevt_328_tmpvar_phold = this.bem_emitting_1(bevt_329_tmpvar_phold);
if (bevt_328_tmpvar_phold.bevi_bool) /* Line: 1460 */ {
bevt_333_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_326));
bevt_332_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_333_tmpvar_phold);
bevt_334_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_331_tmpvar_phold = (BEC_4_6_TextString) bevt_332_tmpvar_phold.bem_addValue_1(bevt_334_tmpvar_phold);
bevt_335_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_327));
bevt_330_tmpvar_phold = (BEC_4_6_TextString) bevt_331_tmpvar_phold.bem_addValue_1(bevt_335_tmpvar_phold);
bevt_330_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1461 */
 else  /* Line: 1460 */ {
bevt_337_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_328));
bevt_336_tmpvar_phold = this.bem_emitting_1(bevt_337_tmpvar_phold);
if (bevt_336_tmpvar_phold.bevi_bool) /* Line: 1462 */ {
bevt_341_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_329));
bevt_340_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_341_tmpvar_phold);
bevt_342_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_339_tmpvar_phold = (BEC_4_6_TextString) bevt_340_tmpvar_phold.bem_addValue_1(bevt_342_tmpvar_phold);
bevt_343_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_330));
bevt_338_tmpvar_phold = (BEC_4_6_TextString) bevt_339_tmpvar_phold.bem_addValue_1(bevt_343_tmpvar_phold);
bevt_338_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1463 */
} /* Line: 1460 */
bevt_347_tmpvar_phold = bevo_84;
bevt_346_tmpvar_phold = bevt_347_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_348_tmpvar_phold = bevo_85;
bevt_345_tmpvar_phold = bevt_346_tmpvar_phold.bem_add_1(bevt_348_tmpvar_phold);
bevt_344_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_345_tmpvar_phold);
bevt_344_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1465 */
} /* Line: 1455 */
if (bevl_isTyped.bevi_bool) /* Line: 1470 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1470 */ {
bevt_350_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_349_tmpvar_phold = bevt_350_tmpvar_phold.bem_not_0();
if (bevt_349_tmpvar_phold.bevi_bool) /* Line: 1470 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1470 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1470 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 1470 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1471 */ {
bevt_352_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_351_tmpvar_phold = bevt_352_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_351_tmpvar_phold != null && bevt_351_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_351_tmpvar_phold).bevi_bool) /* Line: 1472 */ {
bevt_354_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_353_tmpvar_phold = bevt_354_tmpvar_phold.bem_equals_1(bevp_intNp);
if (bevt_353_tmpvar_phold.bevi_bool) /* Line: 1473 */ {
bevl_newCall = this.bem_lintConstruct_2(bevl_newcc, beva_node);
} /* Line: 1474 */
 else  /* Line: 1473 */ {
bevt_356_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_355_tmpvar_phold = bevt_356_tmpvar_phold.bem_equals_1(bevp_floatNp);
if (bevt_355_tmpvar_phold.bevi_bool) /* Line: 1475 */ {
bevl_newCall = this.bem_lfloatConstruct_2(bevl_newcc, beva_node);
} /* Line: 1476 */
 else  /* Line: 1473 */ {
bevt_358_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_357_tmpvar_phold = bevt_358_tmpvar_phold.bem_equals_1(bevp_stringNp);
if (bevt_357_tmpvar_phold.bevi_bool) /* Line: 1477 */ {
bevt_359_tmpvar_phold = bevo_86;
bevt_362_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_361_tmpvar_phold = bevt_362_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_360_tmpvar_phold = bevt_361_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_belsName = bevt_359_tmpvar_phold.bem_add_1(bevt_360_tmpvar_phold);
bevt_364_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_363_tmpvar_phold = bevt_364_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_363_tmpvar_phold.bemd_0(1205852557, BEL_4_Base.bevn_incrementValue_0);
bevl_sdec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevt_365_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_liorg = (BEC_4_6_TextString) bevt_365_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_366_tmpvar_phold = beva_node.bem_wideStringGet_0();
if (bevt_366_tmpvar_phold.bevi_bool) /* Line: 1486 */ {
bevl_lival = bevl_liorg;
} /* Line: 1487 */
 else  /* Line: 1488 */ {
bevt_368_tmpvar_phold = (BEC_4_12_JsonUnmarshaller) (new BEC_4_12_JsonUnmarshaller()).bem_new_0();
bevt_373_tmpvar_phold = bevo_87;
bevt_375_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_374_tmpvar_phold = bevt_375_tmpvar_phold.bem_quoteGet_0();
bevt_372_tmpvar_phold = bevt_373_tmpvar_phold.bem_add_1(bevt_374_tmpvar_phold);
bevt_371_tmpvar_phold = bevt_372_tmpvar_phold.bem_add_1(bevl_liorg);
bevt_377_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_376_tmpvar_phold = bevt_377_tmpvar_phold.bem_quoteGet_0();
bevt_370_tmpvar_phold = bevt_371_tmpvar_phold.bem_add_1(bevt_376_tmpvar_phold);
bevt_378_tmpvar_phold = bevo_88;
bevt_369_tmpvar_phold = bevt_370_tmpvar_phold.bem_add_1(bevt_378_tmpvar_phold);
bevt_367_tmpvar_phold = bevt_368_tmpvar_phold.bem_unmarshall_1(bevt_369_tmpvar_phold);
bevl_lival = (BEC_4_6_TextString) bevt_367_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 1489 */
bevl_lisz = bevl_lival.bem_sizeGet_0();
bevl_lipos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_bcode = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_379_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_hs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_379_tmpvar_phold);
while (true)
 /* Line: 1496 */ {
bevt_380_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_380_tmpvar_phold.bevi_bool) /* Line: 1496 */ {
bevt_382_tmpvar_phold = bevo_89;
bevt_381_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_382_tmpvar_phold);
if (bevt_381_tmpvar_phold.bevi_bool) /* Line: 1497 */ {
bevt_384_tmpvar_phold = bevo_90;
bevt_383_tmpvar_phold = (BEC_4_6_TextString) bevt_384_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_383_tmpvar_phold);
} /* Line: 1498 */
this.bem_lstringByte_5(bevl_sdec, bevl_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1501 */
 else  /* Line: 1496 */ {
break;
} /* Line: 1496 */
} /* Line: 1496 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
bevl_newCall = this.bem_lstringConstruct_5(bevl_newcc, beva_node, bevl_belsName, bevl_lisz, bevl_isOnce);
} /* Line: 1506 */
 else  /* Line: 1473 */ {
bevt_386_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_385_tmpvar_phold = bevt_386_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_385_tmpvar_phold.bevi_bool) /* Line: 1507 */ {
bevt_389_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_388_tmpvar_phold = bevt_389_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_390_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_337));
bevt_387_tmpvar_phold = bevt_388_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_390_tmpvar_phold);
if (bevt_387_tmpvar_phold != null && bevt_387_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_387_tmpvar_phold).bevi_bool) /* Line: 1508 */ {
bevl_newCall = bevp_trueValue;
} /* Line: 1509 */
 else  /* Line: 1510 */ {
bevl_newCall = bevp_falseValue;
} /* Line: 1511 */
} /* Line: 1508 */
 else  /* Line: 1513 */ {
bevt_393_tmpvar_phold = bevo_91;
bevt_395_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_394_tmpvar_phold = bevt_395_tmpvar_phold.bem_toString_0();
bevt_392_tmpvar_phold = bevt_393_tmpvar_phold.bem_add_1(bevt_394_tmpvar_phold);
bevt_391_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_392_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_391_tmpvar_phold);
} /* Line: 1515 */
} /* Line: 1473 */
} /* Line: 1473 */
} /* Line: 1473 */
} /* Line: 1473 */
 else  /* Line: 1517 */ {
bevt_397_tmpvar_phold = bevo_92;
bevt_399_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_398_tmpvar_phold = bevl_newcc.bem_relEmitName_1(bevt_399_tmpvar_phold);
bevt_396_tmpvar_phold = bevt_397_tmpvar_phold.bem_add_1(bevt_398_tmpvar_phold);
bevt_400_tmpvar_phold = bevo_93;
bevl_newCall = bevt_396_tmpvar_phold.bem_add_1(bevt_400_tmpvar_phold);
} /* Line: 1518 */
bevt_402_tmpvar_phold = bevo_94;
bevt_401_tmpvar_phold = bevt_402_tmpvar_phold.bem_add_1(bevl_newCall);
bevt_403_tmpvar_phold = bevo_95;
bevl_target = bevt_401_tmpvar_phold.bem_add_1(bevt_403_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_405_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_404_tmpvar_phold = bevt_405_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_404_tmpvar_phold != null && bevt_404_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_404_tmpvar_phold).bevi_bool) /* Line: 1524 */ {
bevt_407_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_406_tmpvar_phold = bevt_407_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_406_tmpvar_phold.bevi_bool) /* Line: 1525 */ {
if (bevl_onceDeced.bevi_bool) /* Line: 1526 */ {
bevl_odinfo = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_412_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_411_tmpvar_phold = bevt_412_tmpvar_phold.bem_containedGet_0();
bevt_410_tmpvar_phold = bevt_411_tmpvar_phold.bem_firstGet_0();
bevt_409_tmpvar_phold = bevt_410_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_408_tmpvar_phold = bevt_409_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_408_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1528 */ {
bevt_413_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_413_tmpvar_phold != null && bevt_413_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_413_tmpvar_phold).bevi_bool) /* Line: 1528 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_417_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_416_tmpvar_phold = bevt_417_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_415_tmpvar_phold = bevt_416_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_414_tmpvar_phold = (BEC_4_6_TextString) bevl_odinfo.bem_addValue_1(bevt_415_tmpvar_phold);
bevt_418_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_343));
bevt_414_tmpvar_phold.bem_addValue_1(bevt_418_tmpvar_phold);
} /* Line: 1529 */
 else  /* Line: 1528 */ {
break;
} /* Line: 1528 */
} /* Line: 1528 */
bevt_421_tmpvar_phold = bevo_96;
bevt_420_tmpvar_phold = bevt_421_tmpvar_phold.bem_add_1(bevl_odinfo);
bevt_419_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_420_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_419_tmpvar_phold);
} /* Line: 1531 */
bevt_424_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_423_tmpvar_phold = bevt_424_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_425_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_345));
bevt_422_tmpvar_phold = bevt_423_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_425_tmpvar_phold);
if (bevt_422_tmpvar_phold != null && bevt_422_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_422_tmpvar_phold).bevi_bool) /* Line: 1534 */ {
bevl_target = bevp_trueValue;
} /* Line: 1535 */
 else  /* Line: 1536 */ {
bevl_target = bevp_falseValue;
} /* Line: 1537 */
} /* Line: 1534 */
if (bevl_onceDeced.bevi_bool) /* Line: 1540 */ {
bevt_429_tmpvar_phold = (BEC_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_428_tmpvar_phold = (BEC_4_6_TextString) bevt_429_tmpvar_phold.bem_addValue_1(bevl_callAssign);
bevt_427_tmpvar_phold = (BEC_4_6_TextString) bevt_428_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_430_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_346));
bevt_426_tmpvar_phold = (BEC_4_6_TextString) bevt_427_tmpvar_phold.bem_addValue_1(bevt_430_tmpvar_phold);
bevt_426_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1541 */
 else  /* Line: 1542 */ {
bevt_433_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_432_tmpvar_phold = (BEC_4_6_TextString) bevt_433_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_434_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_347));
bevt_431_tmpvar_phold = (BEC_4_6_TextString) bevt_432_tmpvar_phold.bem_addValue_1(bevt_434_tmpvar_phold);
bevt_431_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1543 */
} /* Line: 1540 */
 else  /* Line: 1545 */ {
bevt_435_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevl_asyn = bevp_build.bem_getSynNp_1(bevt_435_tmpvar_phold);
bevt_436_tmpvar_phold = bevl_asyn.bem_hasDefaultGet_0();
if (bevt_436_tmpvar_phold.bevi_bool) /* Line: 1547 */ {
bevt_443_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_442_tmpvar_phold = (BEC_4_6_TextString) bevt_443_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_444_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_348));
bevt_441_tmpvar_phold = (BEC_4_6_TextString) bevt_442_tmpvar_phold.bem_addValue_1(bevt_444_tmpvar_phold);
bevt_445_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_440_tmpvar_phold = (BEC_4_6_TextString) bevt_441_tmpvar_phold.bem_addValue_1(bevt_445_tmpvar_phold);
bevt_446_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_349));
bevt_439_tmpvar_phold = (BEC_4_6_TextString) bevt_440_tmpvar_phold.bem_addValue_1(bevt_446_tmpvar_phold);
bevt_438_tmpvar_phold = (BEC_4_6_TextString) bevt_439_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_447_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_350));
bevt_437_tmpvar_phold = (BEC_4_6_TextString) bevt_438_tmpvar_phold.bem_addValue_1(bevt_447_tmpvar_phold);
bevt_437_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1548 */
 else  /* Line: 1549 */ {
bevt_454_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_453_tmpvar_phold = (BEC_4_6_TextString) bevt_454_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_455_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_351));
bevt_452_tmpvar_phold = (BEC_4_6_TextString) bevt_453_tmpvar_phold.bem_addValue_1(bevt_455_tmpvar_phold);
bevt_456_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_451_tmpvar_phold = (BEC_4_6_TextString) bevt_452_tmpvar_phold.bem_addValue_1(bevt_456_tmpvar_phold);
bevt_457_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_352));
bevt_450_tmpvar_phold = (BEC_4_6_TextString) bevt_451_tmpvar_phold.bem_addValue_1(bevt_457_tmpvar_phold);
bevt_449_tmpvar_phold = (BEC_4_6_TextString) bevt_450_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_458_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_353));
bevt_448_tmpvar_phold = (BEC_4_6_TextString) bevt_449_tmpvar_phold.bem_addValue_1(bevt_458_tmpvar_phold);
bevt_448_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1550 */
} /* Line: 1547 */
} /* Line: 1524 */
 else  /* Line: 1553 */ {
bevt_459_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_459_tmpvar_phold.bevi_bool) /* Line: 1554 */ {
bevt_466_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_465_tmpvar_phold = (BEC_4_6_TextString) bevt_466_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_467_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_354));
bevt_464_tmpvar_phold = (BEC_4_6_TextString) bevt_465_tmpvar_phold.bem_addValue_1(bevt_467_tmpvar_phold);
bevt_468_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_463_tmpvar_phold = (BEC_4_6_TextString) bevt_464_tmpvar_phold.bem_addValue_1(bevt_468_tmpvar_phold);
bevt_469_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_355));
bevt_462_tmpvar_phold = (BEC_4_6_TextString) bevt_463_tmpvar_phold.bem_addValue_1(bevt_469_tmpvar_phold);
bevt_461_tmpvar_phold = (BEC_4_6_TextString) bevt_462_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_470_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_356));
bevt_460_tmpvar_phold = (BEC_4_6_TextString) bevt_461_tmpvar_phold.bem_addValue_1(bevt_470_tmpvar_phold);
bevt_460_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1555 */
 else  /* Line: 1556 */ {
bevt_477_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_476_tmpvar_phold = (BEC_4_6_TextString) bevt_477_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_478_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_357));
bevt_475_tmpvar_phold = (BEC_4_6_TextString) bevt_476_tmpvar_phold.bem_addValue_1(bevt_478_tmpvar_phold);
bevt_479_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_474_tmpvar_phold = (BEC_4_6_TextString) bevt_475_tmpvar_phold.bem_addValue_1(bevt_479_tmpvar_phold);
bevt_480_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_358));
bevt_473_tmpvar_phold = (BEC_4_6_TextString) bevt_474_tmpvar_phold.bem_addValue_1(bevt_480_tmpvar_phold);
bevt_472_tmpvar_phold = (BEC_4_6_TextString) bevt_473_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_481_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_359));
bevt_471_tmpvar_phold = (BEC_4_6_TextString) bevt_472_tmpvar_phold.bem_addValue_1(bevt_481_tmpvar_phold);
bevt_471_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1557 */
} /* Line: 1554 */
} /* Line: 1471 */
 else  /* Line: 1560 */ {
bevt_482_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_482_tmpvar_phold.bevi_bool) /* Line: 1561 */ {
bevl_dm = bevl_numargs.bem_toString_0();
bevl_callArgSpill = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_360));
} /* Line: 1563 */
 else  /* Line: 1564 */ {
bevl_dm = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_361));
bevt_483_tmpvar_phold = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_484_tmpvar_phold = bevo_97;
bevl_spillArgsLen = bevt_483_tmpvar_phold.bem_add_1(bevt_484_tmpvar_phold);
bevt_485_tmpvar_phold = bevl_spillArgsLen.bem_greater_1(bevp_maxSpillArgsLen);
if (bevt_485_tmpvar_phold.bevi_bool) /* Line: 1567 */ {
bevp_maxSpillArgsLen = bevl_spillArgsLen;
} /* Line: 1568 */
bevp_methodBody.bem_addValue_1(bevl_spillArgs);
bevl_callArgSpill = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_362));
} /* Line: 1571 */
bevt_487_tmpvar_phold = bevo_98;
bevt_486_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_487_tmpvar_phold);
if (bevt_486_tmpvar_phold.bevi_bool) /* Line: 1573 */ {
bevl_fc = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_363));
} /* Line: 1574 */
 else  /* Line: 1575 */ {
bevl_fc = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_364));
} /* Line: 1576 */
bevt_501_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_500_tmpvar_phold = (BEC_4_6_TextString) bevt_501_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_502_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_365));
bevt_499_tmpvar_phold = (BEC_4_6_TextString) bevt_500_tmpvar_phold.bem_addValue_1(bevt_502_tmpvar_phold);
bevt_498_tmpvar_phold = (BEC_4_6_TextString) bevt_499_tmpvar_phold.bem_addValue_1(bevl_dm);
bevt_503_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_366));
bevt_497_tmpvar_phold = (BEC_4_6_TextString) bevt_498_tmpvar_phold.bem_addValue_1(bevt_503_tmpvar_phold);
bevt_507_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_506_tmpvar_phold = bevt_507_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_505_tmpvar_phold = bevt_506_tmpvar_phold.bemd_0(287040793, BEL_4_Base.bevn_hashGet_0);
bevt_504_tmpvar_phold = bevt_505_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_496_tmpvar_phold = (BEC_4_6_TextString) bevt_497_tmpvar_phold.bem_addValue_1(bevt_504_tmpvar_phold);
bevt_508_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_367));
bevt_495_tmpvar_phold = (BEC_4_6_TextString) bevt_496_tmpvar_phold.bem_addValue_1(bevt_508_tmpvar_phold);
bevt_494_tmpvar_phold = (BEC_4_6_TextString) bevt_495_tmpvar_phold.bem_addValue_1(bevp_libEmitName);
bevt_509_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_368));
bevt_493_tmpvar_phold = (BEC_4_6_TextString) bevt_494_tmpvar_phold.bem_addValue_1(bevt_509_tmpvar_phold);
bevt_511_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_510_tmpvar_phold = bevt_511_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_492_tmpvar_phold = (BEC_4_6_TextString) bevt_493_tmpvar_phold.bem_addValue_1(bevt_510_tmpvar_phold);
bevt_491_tmpvar_phold = (BEC_4_6_TextString) bevt_492_tmpvar_phold.bem_addValue_1(bevl_fc);
bevt_490_tmpvar_phold = (BEC_4_6_TextString) bevt_491_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_489_tmpvar_phold = (BEC_4_6_TextString) bevt_490_tmpvar_phold.bem_addValue_1(bevl_callArgSpill);
bevt_512_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_369));
bevt_488_tmpvar_phold = (BEC_4_6_TextString) bevt_489_tmpvar_phold.bem_addValue_1(bevt_512_tmpvar_phold);
bevt_488_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1578 */
if (bevl_isOnce.bevi_bool) /* Line: 1581 */ {
bevt_513_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_513_tmpvar_phold.bevi_bool) /* Line: 1582 */ {
bevt_515_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_370));
bevt_514_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_515_tmpvar_phold);
bevt_514_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_517_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_371));
bevt_516_tmpvar_phold = this.bem_emitting_1(bevt_517_tmpvar_phold);
if (bevt_516_tmpvar_phold.bevi_bool) /* Line: 1585 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1585 */ {
bevt_519_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_372));
bevt_518_tmpvar_phold = this.bem_emitting_1(bevt_519_tmpvar_phold);
if (bevt_518_tmpvar_phold.bevi_bool) /* Line: 1585 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1585 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1585 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 1585 */ {
bevt_521_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_373));
bevt_520_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_521_tmpvar_phold);
bevt_520_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1587 */
} /* Line: 1585 */
bevp_methodBody.bem_addValue_1(bevl_postOnceCallAssign);
bevt_522_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_522_tmpvar_phold.bevi_bool) /* Line: 1591 */ {
bevt_524_tmpvar_phold = bevl_odec.bem_isEmptyGet_0();
bevt_523_tmpvar_phold = bevt_524_tmpvar_phold.bem_not_0();
if (bevt_523_tmpvar_phold.bevi_bool) /* Line: 1592 */ {
bevt_527_tmpvar_phold = (BEC_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_526_tmpvar_phold = (BEC_4_6_TextString) bevt_527_tmpvar_phold.bem_addValue_1(bevl_ovar);
bevt_528_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_374));
bevt_525_tmpvar_phold = (BEC_4_6_TextString) bevt_526_tmpvar_phold.bem_addValue_1(bevt_528_tmpvar_phold);
bevt_525_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1593 */
} /* Line: 1592 */
} /* Line: 1591 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_doInitializeIt_1(BEC_4_6_TextString beva_nc) {
BEC_4_6_TextString bevl_ii = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_ii = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_375));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_376));
bevt_0_tmpvar_phold = this.bem_emitting_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1602 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(67, bels_377));
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevl_ii.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_378));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1603 */
 else  /* Line: 1604 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(57, bels_379));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_ii.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_380));
bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
} /* Line: 1605 */
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_381));
bevl_ii.bem_addValue_1(bevt_10_tmpvar_phold);
return bevl_ii;
} /*method end*/
public virtual BEC_4_6_TextString bem_getInitialInst_1(BEC_5_11_BuildClassConfig beva_newcc) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_382));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lintConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_99;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_100;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_101;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lfloatConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_102;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_103;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_104;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lstringConstruct_5(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_belsName, BEC_4_3_MathInt beva_lisz, BEC_5_4_LogicBool beva_isOnce) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 1624 */ {
bevt_6_tmpvar_phold = bevo_105;
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_106;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_10_tmpvar_phold = bevo_107;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_11_tmpvar_phold = bevo_108;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 1625 */
bevt_18_tmpvar_phold = bevo_109;
bevt_20_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_110;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(beva_lisz);
bevt_22_tmpvar_phold = bevo_111;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(beva_belsName);
bevt_23_tmpvar_phold = bevo_112;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringStart_2(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_belsName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_397));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_398));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringByte_5(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_lival, BEC_4_3_MathInt beva_lipos, BEC_4_3_MathInt beva_bcode, BEC_4_6_TextString beva_hs) {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringEnd_1(BEC_4_6_TextString beva_sdec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_399));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isOnceAssign_1(BEC_5_4_BuildNode beva_asnCall) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1362267230, BEL_4_Base.bevn_isManyGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1646 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 1647 */
bevt_5_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1478834556, BEL_4_Base.bevn_isOnceGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1649 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1649 */ {
bevt_6_tmpvar_phold = beva_asnCall.bem_isLiteralOnceGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1649 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1649 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1649 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1649 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 1650 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptEmit_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_3_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_3_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1656 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_methodBody.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 1657 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptIfEmit_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_4_tmpvar_phold = this.bem_emitLangGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1662 */ {
bevt_5_tmpvar_phold = beva_node.bem_nextPeerGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 1663 */
bevt_6_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_46_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1669 */ {
this.bem_acceptClass_1(beva_node);
} /* Line: 1670 */
 else  /* Line: 1669 */ {
bevt_4_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1671 */ {
this.bem_acceptMethod_1(beva_node);
} /* Line: 1672 */
 else  /* Line: 1669 */ {
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1673 */ {
this.bem_acceptRbraces_1(beva_node);
} /* Line: 1674 */
 else  /* Line: 1669 */ {
bevt_10_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_11_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1675 */ {
this.bem_acceptEmit_1(beva_node);
} /* Line: 1676 */
 else  /* Line: 1669 */ {
bevt_13_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 1677 */ {
this.bem_addStackLines_1(beva_node);
bevt_15_tmpvar_phold = this.bem_acceptIfEmit_1(beva_node);
return (BEC_5_4_BuildNode) bevt_15_tmpvar_phold;
} /* Line: 1679 */
 else  /* Line: 1669 */ {
bevt_17_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_18_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 1680 */ {
this.bem_acceptCall_1(beva_node);
} /* Line: 1681 */
 else  /* Line: 1669 */ {
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 1682 */ {
this.bem_acceptBraces_1(beva_node);
} /* Line: 1683 */
 else  /* Line: 1669 */ {
bevt_23_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_24_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1684 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_400));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1685 */
 else  /* Line: 1669 */ {
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 1686 */ {
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_401));
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1687 */
 else  /* Line: 1669 */ {
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 1688 */ {
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_402));
bevp_methodBody.bem_addValue_1(bevt_35_tmpvar_phold);
} /* Line: 1689 */
 else  /* Line: 1669 */ {
bevt_37_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 1690 */ {
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_403));
bevp_methodBody.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 1691 */
 else  /* Line: 1669 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 1692 */ {
this.bem_acceptCatch_1(beva_node);
} /* Line: 1693 */
 else  /* Line: 1669 */ {
bevt_44_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1694 */ {
this.bem_acceptIf_1(beva_node);
} /* Line: 1695 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
} /* Line: 1669 */
this.bem_addStackLines_1(beva_node);
bevt_46_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_46_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addStackLines_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_cnode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1702 */ {
} /* Line: 1702 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildStackLines_1(BEC_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_formTarg_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_tcall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1711 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_404));
} /* Line: 1712 */
 else  /* Line: 1711 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_405));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1713 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_406));
} /* Line: 1714 */
 else  /* Line: 1711 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_407));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1715 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1716 */
 else  /* Line: 1717 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1718 */
} /* Line: 1711 */
} /* Line: 1711 */
return bevl_tcall;
} /*method end*/
public virtual BEC_4_6_TextString bem_formRTarg_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_tcall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1725 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_408));
} /* Line: 1726 */
 else  /* Line: 1725 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_409));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1727 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_410));
} /* Line: 1728 */
 else  /* Line: 1725 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_411));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1729 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1730 */
 else  /* Line: 1731 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1732 */
} /* Line: 1725 */
} /* Line: 1725 */
return bevl_tcall;
} /*method end*/
public override BEC_6_6_SystemObject bem_end_1(BEC_6_6_SystemObject beva_transi) {
base.bem_end_1(beva_transi);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_beginNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_412));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_beginNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_413));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_414));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_endNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_415));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_extend_1(BEC_4_6_TextString beva_parent) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_416));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mangleName_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_pref = null;
BEC_4_6_TextString bevl_suf = null;
BEC_4_6_TextString bevl_step = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_pref = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_417));
bevl_suf = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_418));
bevt_1_tmpvar_phold = beva_np.bem_stepsGet_0();
bevt_0_tmpvar_loop = bevt_1_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1769 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 1769 */ {
bevl_step = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevo_113;
bevt_3_tmpvar_phold = bevl_pref.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1770 */ {
bevt_5_tmpvar_phold = bevo_114;
bevl_pref = bevl_pref.bem_add_1(bevt_5_tmpvar_phold);
} /* Line: 1770 */
 else  /* Line: 1771 */ {
bevl_suf = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_421));
} /* Line: 1771 */
bevt_6_tmpvar_phold = bevl_step.bem_sizeGet_0();
bevl_pref = bevl_pref.bem_add_1(bevt_6_tmpvar_phold);
bevl_suf = bevl_suf.bem_add_1(bevl_step);
} /* Line: 1773 */
 else  /* Line: 1769 */ {
break;
} /* Line: 1769 */
} /* Line: 1769 */
bevt_7_tmpvar_phold = bevl_pref.bem_add_1(bevl_suf);
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getEmitName_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_115;
bevt_2_tmpvar_phold = this.bem_mangleName_1(beva_np);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getFullEmitName_2(BEC_4_6_TextString beva_nameSpace, BEC_4_6_TextString beva_emitName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_116;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getNameSpace_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_117;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_classConfGet_0() {
return bevp_classConf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classConfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classConf = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_parentConfGet_0() {
return bevp_parentConf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parentConfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parentConf = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLangSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_fileExtGet_0() {
return bevp_fileExt;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fileExtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileExt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_exceptDecGet_0() {
return bevp_exceptDec;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exceptDecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exceptDec = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_qGet_0() {
return bevp_q;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_qSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_q = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_ccCacheGet_0() {
return bevp_ccCache;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccCacheSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccCache = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_objectNpGet_0() {
return bevp_objectNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_objectNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_boolNpGet_0() {
return bevp_boolNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_boolNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_intNpGet_0() {
return bevp_intNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_intNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_intNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_floatNpGet_0() {
return bevp_floatNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_floatNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_floatNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_stringNpGet_0() {
return bevp_stringNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_stringNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_stringNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_trueValueGet_0() {
return bevp_trueValue;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_trueValueSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_trueValue = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_falseValueGet_0() {
return bevp_falseValue;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_falseValueSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_falseValue = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instanceEqualGet_0() {
return bevp_instanceEqual;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instanceEqualSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceEqual = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instanceNotEqualGet_0() {
return bevp_instanceNotEqual;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instanceNotEqualSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceNotEqual = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libEmitNameGet_0() {
return bevp_libEmitName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_fullLibEmitNameGet_0() {
return bevp_fullLibEmitName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullLibEmitNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fullLibEmitName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_libEmitPathGet_0() {
return bevp_libEmitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_methodBodyGet_0() {
return bevp_methodBody;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodBodySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodBody = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodBodySizeGet_0() {
return bevp_lastMethodBodySize;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodBodySizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodySize = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodBodyLinesGet_0() {
return bevp_lastMethodBodyLines;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodBodyLinesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_methodCallsGet_0() {
return bevp_methodCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_methodCatchGet_0() {
return bevp_methodCatch;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodCatchSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCatch = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxDynArgsGet_0() {
return bevp_maxDynArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxDynArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxDynArgs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxSpillArgsLenGet_0() {
return bevp_maxSpillArgsLen;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxSpillArgsLenSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_lastCallGet_0() {
return bevp_lastCall;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastCallSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastCall = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_callNamesGet_0() {
return bevp_callNames;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_callNamesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_callNames = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_objectCcGet_0() {
return bevp_objectCc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_objectCcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectCc = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_boolCcGet_0() {
return bevp_boolCc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_boolCcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolCc = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instOfGet_0() {
return bevp_instOf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instOfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instOf = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_smnlcsGet_0() {
return bevp_smnlcs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_smnlcsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlcs = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_smnlecsGet_0() {
return bevp_smnlecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_smnlecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlecs = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_classesInDepthOrderGet_0() {
return bevp_classesInDepthOrder;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classesInDepthOrderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classesInDepthOrder = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lineCountGet_0() {
return bevp_lineCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lineCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_classCallsGet_0() {
return bevp_classCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodsSizeGet_0() {
return bevp_lastMethodsSize;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodsSizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsSize = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodsLinesGet_0() {
return bevp_lastMethodsLines;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodsLinesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsLines = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_mnodeGet_0() {
return bevp_mnode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mnodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mnode = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_returnTypeGet_0() {
return bevp_returnType;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_returnTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_returnType = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_6_BuildMtdSyn bem_msynGet_0() {
return bevp_msyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_msynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_msyn = (BEC_5_6_BuildMtdSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_preClassGet_0() {
return bevp_preClass;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_preClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_preClass = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_classEmitsGet_0() {
return bevp_classEmits;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classEmitsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classEmits = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_onceDecsGet_0() {
return bevp_onceDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_onceCountGet_0() {
return bevp_onceCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_propertyDecsGet_0() {
return bevp_propertyDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_propertyDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_propertyDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_cnodeGet_0() {
return bevp_cnode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cnodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cnode = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_csynGet_0() {
return bevp_csyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_csynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_csyn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_dynMethodsGet_0() {
return bevp_dynMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynMethods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_ccMethodsGet_0() {
return bevp_ccMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccMethods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_superCallsGet_0() {
return bevp_superCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_superCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nativeCSlotsGet_0() {
return bevp_nativeCSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nativeCSlotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nativeCSlots = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_inFilePathedGet_0() {
return bevp_inFilePathed;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inFilePathedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFilePathed = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {78, 93, 95, 95, 98, 101, 101, 102, 102, 103, 103, 104, 104, 105, 105, 109, 110, 112, 113, 116, 116, 117, 117, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 120, 121, 122, 123, 124, 126, 127, 133, 136, 137, 140, 140, 141, 143, 148, 149, 155, 155, 155, 159, 159, 159, 159, 159, 159, 159, 163, 163, 163, 163, 163, 163, 167, 168, 169, 169, 170, 170, 0, 170, 170, 171, 171, 171, 172, 172, 172, 173, 174, 177, 177, 177, 178, 180, 184, 185, 186, 186, 187, 187, 187, 188, 190, 194, 0, 194, 0, 0, 195, 195, 195, 195, 195, 197, 197, 202, 203, 203, 205, 206, 207, 208, 210, 211, 211, 213, 214, 215, 216, 218, 219, 219, 220, 220, 222, 225, 226, 230, 233, 234, 244, 245, 245, 245, 245, 246, 248, 248, 248, 250, 250, 250, 251, 252, 252, 253, 254, 256, 259, 260, 260, 261, 262, 265, 267, 269, 0, 269, 269, 270, 271, 0, 271, 271, 272, 276, 276, 278, 280, 280, 280, 281, 285, 288, 292, 293, 293, 294, 297, 297, 298, 301, 302, 302, 303, 306, 306, 307, 311, 311, 314, 315, 315, 316, 319, 319, 320, 326, 327, 329, 334, 334, 335, 0, 335, 335, 336, 336, 337, 337, 338, 338, 0, 338, 338, 0, 0, 0, 338, 338, 0, 0, 341, 343, 343, 344, 344, 346, 346, 347, 347, 350, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 354, 354, 354, 356, 356, 358, 358, 358, 358, 358, 357, 358, 361, 361, 361, 361, 361, 363, 363, 363, 363, 363, 363, 364, 364, 364, 364, 364, 364, 366, 366, 367, 367, 368, 368, 368, 370, 370, 370, 373, 373, 374, 374, 374, 376, 376, 377, 377, 377, 378, 378, 378, 378, 378, 378, 380, 380, 380, 380, 380, 380, 382, 382, 383, 383, 384, 384, 384, 386, 386, 386, 389, 389, 390, 390, 390, 392, 392, 393, 393, 393, 394, 394, 394, 394, 394, 394, 396, 396, 396, 396, 396, 396, 399, 402, 402, 403, 406, 407, 407, 408, 411, 411, 412, 415, 416, 416, 417, 420, 421, 421, 422, 426, 429, 433, 434, 434, 438, 438, 443, 443, 445, 445, 445, 445, 446, 446, 446, 448, 448, 448, 448, 448, 452, 456, 456, 456, 456, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 484, 488, 488, 492, 492, 493, 493, 495, 495, 500, 502, 503, 503, 504, 506, 507, 507, 508, 508, 508, 508, 510, 510, 510, 510, 510, 510, 510, 510, 510, 511, 511, 511, 512, 512, 512, 513, 513, 515, 516, 516, 517, 517, 518, 518, 518, 518, 518, 518, 518, 519, 519, 519, 519, 519, 519, 519, 521, 522, 522, 0, 522, 522, 524, 524, 524, 524, 524, 524, 527, 528, 529, 530, 530, 532, 534, 534, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 535, 537, 537, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 538, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 540, 540, 540, 540, 540, 540, 540, 540, 540, 543, 543, 543, 544, 544, 544, 544, 544, 544, 544, 544, 544, 545, 545, 545, 545, 545, 545, 546, 546, 546, 546, 546, 546, 550, 0, 550, 550, 551, 551, 551, 551, 551, 551, 551, 551, 552, 552, 552, 552, 552, 552, 552, 552, 552, 552, 552, 555, 557, 557, 0, 557, 557, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 559, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 564, 564, 564, 564, 564, 564, 564, 564, 565, 565, 566, 566, 566, 566, 566, 566, 567, 567, 568, 568, 568, 568, 568, 568, 570, 570, 570, 571, 571, 571, 572, 572, 573, 574, 575, 576, 577, 578, 579, 579, 0, 579, 579, 0, 0, 581, 581, 581, 583, 583, 583, 585, 586, 589, 589, 589, 590, 590, 592, 593, 596, 601, 601, 601, 605, 605, 609, 609, 613, 613, 619, 619, 0, 619, 619, 0, 0, 621, 621, 621, 624, 624, 624, 628, 628, 633, 635, 636, 637, 638, 645, 646, 647, 648, 649, 650, 652, 654, 654, 654, 659, 659, 660, 660, 660, 662, 662, 662, 662, 662, 667, 668, 668, 669, 669, 673, 673, 673, 673, 673, 677, 677, 677, 677, 677, 682, 683, 686, 686, 686, 686, 688, 688, 688, 690, 691, 693, 694, 694, 694, 0, 694, 694, 695, 695, 695, 695, 695, 695, 695, 695, 0, 0, 0, 696, 696, 698, 698, 700, 701, 701, 701, 702, 702, 702, 702, 702, 704, 704, 706, 706, 707, 707, 708, 708, 708, 710, 710, 710, 713, 713, 713, 713, 717, 719, 719, 720, 722, 726, 726, 726, 727, 729, 732, 732, 734, 740, 740, 740, 740, 740, 740, 740, 740, 740, 742, 744, 744, 744, 744, 744, 744, 749, 750, 750, 750, 751, 751, 753, 753, 758, 759, 760, 761, 762, 763, 764, 764, 765, 766, 767, 768, 769, 769, 769, 769, 772, 772, 772, 773, 773, 774, 774, 775, 776, 776, 776, 776, 777, 777, 777, 782, 782, 782, 782, 783, 783, 783, 784, 784, 784, 786, 790, 790, 790, 790, 791, 792, 792, 792, 0, 792, 792, 794, 794, 794, 795, 795, 795, 796, 796, 796, 801, 801, 801, 801, 0, 0, 0, 802, 802, 802, 803, 803, 804, 810, 811, 811, 811, 811, 812, 812, 813, 814, 815, 815, 816, 817, 817, 817, 819, 824, 825, 826, 826, 0, 826, 826, 827, 827, 828, 828, 829, 829, 829, 830, 830, 831, 832, 833, 835, 836, 836, 837, 838, 840, 840, 841, 842, 842, 843, 844, 846, 852, 0, 852, 852, 853, 855, 856, 856, 856, 858, 860, 861, 862, 863, 863, 863, 863, 0, 0, 0, 864, 864, 864, 864, 864, 864, 864, 864, 864, 864, 865, 865, 865, 865, 865, 865, 865, 866, 868, 869, 869, 869, 869, 869, 869, 869, 870, 870, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 872, 873, 873, 873, 875, 876, 0, 876, 876, 877, 878, 879, 879, 879, 879, 879, 879, 0, 883, 883, 883, 0, 0, 884, 886, 888, 0, 888, 888, 889, 891, 891, 891, 891, 892, 892, 892, 892, 892, 892, 894, 894, 894, 894, 894, 894, 895, 896, 896, 0, 896, 896, 897, 897, 898, 898, 898, 0, 0, 0, 899, 899, 899, 899, 899, 901, 903, 903, 904, 906, 908, 909, 909, 909, 909, 911, 911, 911, 911, 911, 913, 913, 913, 915, 917, 917, 917, 920, 920, 920, 923, 926, 926, 926, 929, 929, 929, 930, 930, 930, 930, 930, 930, 930, 930, 930, 930, 930, 930, 930, 931, 931, 931, 934, 936, 938, 946, 947, 947, 948, 949, 950, 0, 950, 950, 952, 953, 954, 955, 955, 956, 957, 958, 958, 959, 962, 962, 965, 969, 969, 969, 969, 969, 969, 969, 969, 969, 969, 969, 969, 970, 970, 970, 970, 970, 970, 970, 970, 970, 970, 970, 972, 972, 972, 976, 976, 976, 977, 978, 978, 978, 979, 981, 981, 981, 981, 981, 981, 981, 981, 981, 981, 981, 983, 984, 986, 989, 989, 989, 989, 989, 989, 989, 991, 991, 991, 994, 994, 994, 994, 994, 994, 994, 994, 994, 996, 996, 996, 996, 996, 996, 998, 998, 998, 1003, 1003, 1003, 1003, 1003, 1004, 1004, 1009, 1009, 1011, 1012, 1014, 1015, 1016, 1017, 1017, 1018, 1019, 1019, 1020, 1020, 1020, 1022, 1023, 1025, 1027, 1029, 1034, 1034, 1034, 1034, 1034, 1034, 1034, 1034, 1034, 1034, 1034, 1035, 1035, 1035, 1035, 1035, 1035, 1037, 1037, 1037, 1042, 1044, 1044, 1045, 1045, 1045, 1045, 1045, 1045, 1045, 1047, 1047, 1047, 1047, 1047, 1047, 1047, 1050, 1054, 1054, 1055, 1055, 1055, 1057, 1057, 1059, 1059, 1059, 1059, 1059, 1060, 1060, 1060, 1060, 1060, 1060, 1060, 1060, 1061, 1061, 1061, 1061, 1061, 1061, 1062, 1062, 1062, 1063, 1063, 1064, 1064, 1064, 1064, 1064, 1064, 1065, 1065, 1065, 1067, 1072, 1072, 1072, 1076, 1076, 1076, 1076, 1076, 1076, 1080, 1080, 1085, 1085, 1089, 1090, 1090, 1090, 1090, 1090, 0, 0, 0, 1091, 1091, 1091, 1091, 1091, 1093, 1097, 1097, 1097, 1098, 1098, 1099, 1099, 1099, 1099, 0, 0, 0, 1099, 1099, 0, 0, 0, 1099, 1099, 0, 0, 0, 1099, 1099, 0, 0, 0, 1101, 1101, 1101, 1101, 1101, 1101, 1101, 1110, 1110, 1110, 1110, 1110, 1110, 1110, 0, 0, 0, 1111, 1111, 1112, 1113, 1113, 1114, 1114, 1115, 1115, 0, 1115, 1115, 1115, 1115, 0, 0, 1118, 1118, 1118, 1121, 1121, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1122, 1125, 1126, 1127, 1128, 1132, 0, 1132, 1132, 1133, 1133, 1135, 1136, 1136, 1138, 1139, 1140, 1141, 1144, 1145, 1146, 1149, 1149, 1149, 1150, 1151, 1153, 1153, 1153, 1153, 0, 0, 0, 1153, 1153, 0, 0, 0, 1155, 1155, 1155, 1155, 1155, 1155, 1155, 1161, 1161, 1161, 1165, 1166, 1166, 1166, 1167, 1168, 1169, 1169, 1170, 1171, 1172, 1169, 1175, 1179, 1179, 1179, 1179, 1179, 1180, 1180, 1180, 1180, 1180, 1180, 1180, 0, 1180, 1180, 1180, 1180, 1180, 1180, 1180, 0, 0, 1181, 1183, 1185, 1185, 1185, 1185, 1185, 1185, 0, 0, 0, 1186, 1188, 1190, 1192, 1192, 1196, 1196, 1196, 1201, 1201, 1201, 1201, 1201, 1201, 1201, 1201, 1201, 1201, 1202, 1202, 1202, 1203, 1203, 1203, 1203, 1205, 1206, 1206, 1206, 1207, 1207, 1209, 1209, 1212, 1212, 1214, 1214, 1214, 1214, 1214, 1219, 1219, 1219, 1219, 1219, 1220, 1220, 1220, 1220, 1220, 1220, 0, 0, 0, 1221, 1223, 1225, 1225, 1225, 1225, 1225, 1225, 1225, 1232, 1232, 1232, 1232, 1232, 1232, 1237, 1237, 1237, 1238, 1238, 1238, 1240, 1240, 1240, 1240, 1241, 1241, 1241, 1243, 1243, 1243, 1243, 1244, 1244, 1244, 1246, 1247, 1247, 1248, 1248, 1248, 1248, 1250, 1250, 1250, 1250, 1250, 1250, 1254, 1254, 1258, 1258, 1258, 1258, 1258, 1258, 1258, 1262, 1262, 1262, 1262, 1262, 1262, 1262, 1262, 1266, 1266, 1266, 1271, 1271, 1271, 1273, 1275, 1279, 1280, 1281, 1283, 1286, 1286, 1286, 1286, 1286, 1286, 1286, 1286, 0, 0, 0, 1287, 1287, 1287, 1287, 1287, 1288, 1288, 1288, 1288, 1289, 1289, 1289, 1289, 1289, 1289, 1289, 1289, 1288, 1291, 1291, 1292, 1292, 1292, 1292, 1292, 1292, 1292, 1292, 1292, 1292, 0, 0, 0, 1293, 1293, 1293, 1294, 1294, 1294, 1294, 1295, 1296, 1297, 1297, 1297, 1297, 1301, 1301, 1302, 1302, 1302, 1302, 1304, 1304, 1304, 1304, 1306, 1306, 1306, 1306, 1306, 1306, 1307, 1307, 1307, 1307, 1308, 1308, 1308, 1308, 1308, 1309, 1309, 1309, 1309, 1310, 1310, 1310, 1310, 1311, 1311, 1311, 1311, 1312, 1312, 1312, 1312, 1313, 1313, 1313, 1313, 1313, 0, 1313, 1313, 1313, 1313, 1313, 0, 0, 0, 1314, 1314, 1314, 1314, 1314, 0, 0, 0, 1314, 1314, 1314, 1314, 1314, 0, 0, 1321, 1321, 1322, 1322, 1322, 1322, 1322, 1322, 1322, 1323, 1323, 1323, 1326, 1326, 1326, 1326, 1326, 1327, 1328, 1330, 1331, 1333, 1333, 1333, 1333, 1333, 1333, 1333, 1333, 1333, 1334, 1334, 1334, 1334, 1335, 1335, 1335, 1336, 1336, 1336, 1336, 1337, 1337, 1337, 1339, 1340, 1340, 1340, 1340, 1342, 1343, 1343, 1344, 1344, 1344, 1346, 1346, 1346, 1346, 1346, 1346, 1346, 1346, 1346, 1347, 1348, 1348, 1348, 1348, 0, 1348, 1348, 1348, 1348, 0, 0, 0, 1348, 1348, 1348, 1348, 0, 0, 0, 1348, 1348, 1348, 1348, 0, 0, 1350, 1353, 1353, 1353, 1353, 1353, 1353, 1353, 1353, 1353, 1353, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1357, 1358, 1359, 1360, 1362, 1362, 1363, 1364, 1364, 1364, 1365, 1365, 1365, 1365, 1365, 1365, 1366, 1367, 1367, 1367, 1367, 1367, 1367, 1368, 1369, 1370, 1371, 1371, 1371, 1376, 1377, 1379, 1380, 1380, 1380, 1381, 1381, 1382, 1383, 1383, 1385, 1386, 1387, 1387, 1388, 0, 1391, 0, 0, 0, 1391, 1391, 0, 0, 1392, 1392, 1393, 1393, 1395, 1395, 1395, 1395, 1395, 0, 0, 0, 1396, 1396, 1396, 1396, 1396, 1396, 1398, 1398, 1401, 1402, 1402, 1402, 1402, 1402, 1402, 1402, 1402, 1402, 1402, 1402, 1405, 1409, 1411, 0, 0, 0, 1412, 1412, 1412, 1415, 1416, 1419, 1419, 1419, 1419, 1419, 1419, 1419, 1419, 1419, 0, 0, 0, 1420, 1420, 1420, 1420, 0, 0, 0, 1420, 0, 0, 0, 1421, 1422, 1422, 1423, 1425, 1425, 1425, 1425, 1425, 1425, 1426, 1426, 1426, 1428, 1428, 1428, 1428, 1428, 1428, 1428, 1428, 1428, 1433, 1433, 1433, 1435, 1435, 1435, 1435, 1435, 1437, 1437, 1437, 1437, 1439, 1445, 1445, 1445, 1445, 1445, 1445, 1445, 1445, 1445, 1445, 1445, 1446, 1446, 1447, 1447, 1447, 1447, 1449, 1451, 1451, 1451, 0, 1455, 1455, 0, 0, 0, 0, 0, 1455, 1455, 0, 0, 0, 0, 0, 0, 1456, 1460, 1460, 1461, 1461, 1461, 1461, 1461, 1461, 1461, 1462, 1462, 1463, 1463, 1463, 1463, 1463, 1463, 1463, 1465, 1465, 1465, 1465, 1465, 1465, 0, 1470, 1470, 0, 0, 1472, 1472, 1473, 1473, 1474, 1475, 1475, 1476, 1477, 1477, 1479, 1479, 1479, 1479, 1479, 1480, 1480, 1480, 1481, 1482, 1484, 1484, 1486, 1487, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1489, 1492, 1493, 1494, 1495, 1495, 1496, 1497, 1497, 1498, 1498, 1498, 1500, 1501, 1503, 1505, 1506, 1507, 1507, 1508, 1508, 1508, 1508, 1509, 1511, 1515, 1515, 1515, 1515, 1515, 1515, 1518, 1518, 1518, 1518, 1518, 1518, 1520, 1520, 1520, 1520, 1522, 1524, 1524, 1525, 1525, 1527, 1528, 1528, 1528, 1528, 1528, 1528, 0, 1528, 1528, 1529, 1529, 1529, 1529, 1529, 1529, 1531, 1531, 1531, 1531, 1534, 1534, 1534, 1534, 1535, 1537, 1541, 1541, 1541, 1541, 1541, 1541, 1543, 1543, 1543, 1543, 1543, 1546, 1546, 1547, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1548, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1550, 1554, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1555, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1557, 1561, 1562, 1563, 1565, 1566, 1566, 1566, 1567, 1568, 1570, 1571, 1573, 1573, 1574, 1576, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1578, 1582, 1584, 1584, 1584, 1585, 1585, 0, 1585, 1585, 0, 0, 1587, 1587, 1587, 1590, 1591, 1592, 1592, 1593, 1593, 1593, 1593, 1593, 1601, 1602, 1602, 1603, 1603, 1603, 1603, 1603, 1605, 1605, 1605, 1605, 1605, 1607, 1607, 1608, 1612, 1612, 1612, 1612, 1612, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1616, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1620, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1625, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1627, 1631, 1631, 1631, 1631, 1631, 1642, 1642, 1642, 1646, 1646, 1647, 1647, 1649, 1649, 0, 1649, 0, 0, 1650, 1650, 1652, 1652, 1656, 1656, 1656, 1656, 1657, 1657, 1657, 1662, 1662, 1662, 1662, 1662, 1663, 1663, 1665, 1665, 1669, 1669, 1669, 1670, 1671, 1671, 1671, 1672, 1673, 1673, 1673, 1674, 1675, 1675, 1675, 1676, 1677, 1677, 1677, 1678, 1679, 1679, 1680, 1680, 1680, 1681, 1682, 1682, 1682, 1683, 1684, 1684, 1684, 1685, 1685, 1685, 1686, 1686, 1686, 1687, 1687, 1687, 1688, 1688, 1688, 1689, 1689, 1690, 1690, 1690, 1691, 1691, 1692, 1692, 1692, 1693, 1694, 1694, 1694, 1695, 1697, 1698, 1698, 1702, 1702, 1711, 1711, 1711, 1712, 1713, 1713, 1713, 1713, 1714, 1715, 1715, 1715, 1715, 1716, 1718, 1718, 1720, 1725, 1725, 1725, 1726, 1727, 1727, 1727, 1727, 1728, 1729, 1729, 1729, 1729, 1730, 1732, 1732, 1734, 1738, 1742, 1742, 1746, 1746, 1750, 1750, 1754, 1754, 1758, 1758, 1763, 1763, 1767, 1768, 1769, 1769, 0, 1769, 1769, 1770, 1770, 1770, 1770, 1771, 1772, 1772, 1773, 1775, 1775, 1779, 1779, 1779, 1779, 1783, 1783, 1783, 1783, 1787, 1787, 1787, 1787, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 676, 679, 681, 682, 688, 689, 690, 699, 700, 701, 702, 703, 704, 705, 713, 714, 715, 716, 717, 718, 735, 736, 737, 742, 743, 744, 744, 747, 749, 750, 751, 752, 753, 754, 755, 757, 758, 765, 766, 767, 768, 770, 778, 779, 780, 785, 786, 787, 788, 789, 791, 815, 817, 820, 822, 825, 829, 830, 831, 832, 833, 835, 836, 837, 839, 840, 842, 843, 844, 845, 846, 848, 849, 851, 852, 853, 854, 855, 857, 858, 859, 860, 862, 865, 866, 869, 872, 873, 1038, 1039, 1040, 1041, 1044, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1059, 1060, 1061, 1063, 1069, 1070, 1073, 1075, 1076, 1082, 1083, 1084, 1084, 1087, 1089, 1090, 1091, 1091, 1094, 1096, 1097, 1108, 1111, 1113, 1114, 1115, 1116, 1117, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1150, 1153, 1155, 1156, 1157, 1158, 1159, 1160, 1165, 1166, 1169, 1170, 1172, 1175, 1179, 1182, 1183, 1185, 1188, 1193, 1196, 1197, 1198, 1199, 1201, 1202, 1203, 1204, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1230, 1231, 1232, 1233, 1234, 1236, 1237, 1238, 1239, 1240, 1241, 1241, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1263, 1264, 1266, 1267, 1268, 1271, 1272, 1273, 1276, 1277, 1279, 1280, 1281, 1283, 1284, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1297, 1298, 1299, 1300, 1301, 1302, 1304, 1305, 1307, 1308, 1310, 1311, 1312, 1315, 1316, 1317, 1320, 1321, 1323, 1324, 1325, 1327, 1328, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1341, 1342, 1343, 1344, 1345, 1346, 1348, 1349, 1350, 1351, 1352, 1354, 1355, 1356, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1375, 1380, 1381, 1382, 1386, 1387, 1401, 1402, 1403, 1404, 1405, 1406, 1408, 1409, 1410, 1412, 1413, 1414, 1415, 1416, 1419, 1426, 1427, 1428, 1429, 1432, 1437, 1438, 1442, 1443, 1447, 1448, 1452, 1453, 1457, 1458, 1462, 1463, 1467, 1468, 1475, 1476, 1478, 1479, 1481, 1482, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1764, 1767, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1781, 1782, 1783, 1784, 1787, 1789, 1790, 1791, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1814, 1815, 1817, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1852, 1853, 1854, 1856, 1857, 1858, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1887, 1887, 1890, 1892, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1917, 1918, 1919, 1919, 1922, 1924, 1925, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1970, 1971, 1973, 1974, 1975, 1976, 1977, 1978, 1981, 1982, 1984, 1985, 1986, 1987, 1988, 1989, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2009, 2012, 2013, 2015, 2018, 2022, 2023, 2024, 2026, 2027, 2028, 2029, 2031, 2033, 2034, 2035, 2036, 2037, 2038, 2040, 2042, 2048, 2049, 2050, 2054, 2055, 2059, 2060, 2064, 2065, 2077, 2078, 2080, 2083, 2084, 2086, 2089, 2093, 2094, 2095, 2097, 2098, 2099, 2103, 2104, 2107, 2108, 2109, 2110, 2111, 2121, 2123, 2126, 2128, 2131, 2133, 2136, 2140, 2141, 2142, 2153, 2154, 2156, 2157, 2158, 2161, 2162, 2163, 2164, 2165, 2172, 2173, 2174, 2175, 2176, 2184, 2185, 2186, 2187, 2188, 2195, 2196, 2197, 2198, 2199, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2265, 2268, 2270, 2271, 2272, 2273, 2274, 2276, 2277, 2278, 2279, 2281, 2284, 2288, 2291, 2292, 2295, 2296, 2298, 2299, 2300, 2305, 2306, 2307, 2308, 2309, 2310, 2312, 2313, 2316, 2317, 2318, 2319, 2321, 2322, 2323, 2326, 2327, 2328, 2331, 2332, 2333, 2334, 2341, 2342, 2347, 2348, 2351, 2353, 2354, 2355, 2357, 2360, 2362, 2363, 2364, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2406, 2407, 2408, 2409, 2411, 2412, 2414, 2415, 2639, 2640, 2641, 2642, 2643, 2644, 2645, 2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658, 2663, 2664, 2667, 2669, 2670, 2671, 2672, 2673, 2675, 2676, 2677, 2685, 2686, 2687, 2692, 2693, 2694, 2695, 2696, 2697, 2698, 2701, 2703, 2704, 2705, 2710, 2711, 2712, 2713, 2714, 2714, 2717, 2719, 2720, 2721, 2722, 2723, 2724, 2725, 2727, 2728, 2729, 2737, 2742, 2743, 2744, 2746, 2749, 2753, 2756, 2757, 2758, 2759, 2760, 2762, 2765, 2766, 2767, 2768, 2771, 2773, 2774, 2775, 2777, 2779, 2780, 2781, 2782, 2783, 2784, 2786, 2793, 2794, 2795, 2796, 2796, 2799, 2801, 2802, 2803, 2805, 2806, 2807, 2808, 2809, 2810, 2811, 2813, 2814, 2816, 2818, 2819, 2824, 2825, 2826, 2828, 2829, 2830, 2831, 2836, 2837, 2838, 2840, 2848, 2848, 2851, 2853, 2854, 2855, 2857, 2858, 2859, 2862, 2864, 2865, 2866, 2869, 2870, 2871, 2873, 2875, 2878, 2882, 2885, 2886, 2887, 2888, 2889, 2890, 2891, 2892, 2893, 2894, 2895, 2896, 2897, 2898, 2899, 2900, 2901, 2902, 2908, 2910, 2911, 2912, 2913, 2914, 2915, 2916, 2917, 2918, 2920, 2921, 2922, 2923, 2924, 2925, 2926, 2927, 2928, 2929, 2930, 2931, 2932, 2933, 2934, 2935, 2936, 2937, 2938, 2939, 2940, 2941, 2941, 2944, 2946, 2947, 2948, 2949, 2950, 2951, 2952, 2953, 2954, 2956, 2959, 2960, 2961, 2963, 2966, 2970, 2973, 2975, 2975, 2978, 2980, 2981, 2983, 2984, 2985, 2986, 2987, 2988, 2989, 2990, 2991, 2992, 2994, 2995, 2996, 2997, 2998, 2999, 3000, 3001, 3002, 3002, 3005, 3007, 3008, 3009, 3011, 3013, 3014, 3016, 3019, 3023, 3026, 3027, 3028, 3029, 3030, 3033, 3035, 3036, 3038, 3041, 3043, 3045, 3046, 3047, 3048, 3051, 3052, 3053, 3054, 3055, 3057, 3058, 3059, 3061, 3067, 3068, 3069, 3071, 3072, 3073, 3075, 3082, 3083, 3084, 3091, 3092, 3093, 3094, 3095, 3096, 3097, 3098, 3099, 3100, 3101, 3102, 3103, 3104, 3105, 3106, 3107, 3108, 3109, 3115, 3116, 3117, 3135, 3136, 3137, 3138, 3139, 3140, 3140, 3143, 3145, 3147, 3148, 3149, 3152, 3153, 3155, 3156, 3159, 3160, 3162, 3171, 3172, 3175, 3201, 3202, 3203, 3204, 3205, 3206, 3207, 3208, 3209, 3210, 3211, 3212, 3213, 3214, 3215, 3216, 3217, 3218, 3219, 3220, 3221, 3222, 3223, 3224, 3225, 3226, 3273, 3274, 3275, 3276, 3277, 3278, 3279, 3280, 3281, 3282, 3283, 3284, 3285, 3286, 3287, 3288, 3289, 3290, 3291, 3292, 3294, 3297, 3299, 3300, 3301, 3302, 3303, 3304, 3305, 3306, 3307, 3308, 3309, 3310, 3311, 3312, 3313, 3314, 3315, 3316, 3317, 3318, 3319, 3320, 3321, 3322, 3323, 3324, 3325, 3326, 3335, 3336, 3337, 3338, 3339, 3340, 3341, 3358, 3359, 3360, 3361, 3362, 3363, 3364, 3365, 3366, 3369, 3371, 3372, 3374, 3375, 3376, 3378, 3379, 3385, 3386, 3387, 3408, 3409, 3410, 3411, 3412, 3413, 3414, 3415, 3416, 3417, 3418, 3419, 3420, 3421, 3422, 3423, 3424, 3425, 3426, 3427, 3446, 3447, 3448, 3450, 3451, 3452, 3453, 3454, 3455, 3456, 3459, 3460, 3461, 3462, 3463, 3464, 3465, 3467, 3503, 3508, 3509, 3510, 3511, 3514, 3515, 3517, 3518, 3519, 3520, 3521, 3522, 3523, 3524, 3525, 3526, 3527, 3528, 3529, 3530, 3531, 3532, 3533, 3534, 3535, 3536, 3537, 3538, 3539, 3540, 3542, 3543, 3544, 3545, 3546, 3547, 3548, 3549, 3550, 3552, 3557, 3558, 3559, 3567, 3568, 3569, 3570, 3571, 3572, 3576, 3577, 3581, 3582, 3594, 3595, 3600, 3601, 3602, 3607, 3608, 3611, 3615, 3618, 3619, 3620, 3621, 3622, 3624, 3651, 3652, 3657, 3658, 3659, 3660, 3661, 3663, 3664, 3666, 3669, 3673, 3676, 3677, 3679, 3682, 3686, 3689, 3690, 3692, 3695, 3699, 3702, 3703, 3705, 3708, 3712, 3715, 3716, 3717, 3718, 3719, 3720, 3721, 3785, 3786, 3791, 3792, 3793, 3794, 3799, 3800, 3803, 3807, 3810, 3811, 3812, 3813, 3814, 3816, 3821, 3822, 3827, 3828, 3831, 3832, 3833, 3834, 3836, 3839, 3843, 3844, 3845, 3847, 3848, 3850, 3851, 3852, 3853, 3854, 3855, 3856, 3857, 3858, 3859, 3860, 3861, 3862, 3863, 3864, 3866, 3867, 3868, 3869, 3870, 3870, 3873, 3875, 3876, 3877, 3883, 3884, 3885, 3886, 3887, 3888, 3889, 3890, 3891, 3892, 3893, 3894, 3895, 3896, 3897, 3901, 3902, 3904, 3905, 3907, 3910, 3914, 3917, 3918, 3920, 3923, 3927, 3930, 3931, 3932, 3933, 3934, 3935, 3936, 3945, 3946, 3947, 3959, 3960, 3961, 3962, 3963, 3964, 3965, 3968, 3970, 3971, 3973, 3975, 3981, 4041, 4042, 4043, 4044, 4045, 4046, 4047, 4048, 4049, 4050, 4051, 4052, 4054, 4057, 4058, 4059, 4060, 4061, 4062, 4063, 4065, 4068, 4072, 4075, 4077, 4078, 4083, 4084, 4085, 4086, 4088, 4091, 4095, 4098, 4101, 4103, 4105, 4106, 4109, 4110, 4111, 4114, 4115, 4116, 4117, 4118, 4119, 4120, 4121, 4122, 4123, 4124, 4125, 4126, 4128, 4129, 4130, 4131, 4133, 4134, 4135, 4136, 4138, 4139, 4141, 4142, 4145, 4146, 4148, 4149, 4150, 4151, 4152, 4174, 4175, 4176, 4177, 4178, 4179, 4180, 4185, 4186, 4187, 4188, 4190, 4193, 4197, 4200, 4203, 4205, 4206, 4207, 4208, 4209, 4210, 4211, 4223, 4224, 4225, 4226, 4227, 4228, 4258, 4259, 4260, 4262, 4263, 4264, 4266, 4267, 4268, 4269, 4271, 4272, 4273, 4275, 4276, 4277, 4278, 4280, 4281, 4282, 4284, 4285, 4290, 4291, 4292, 4293, 4294, 4296, 4297, 4298, 4299, 4300, 4301, 4305, 4306, 4315, 4316, 4317, 4318, 4319, 4320, 4321, 4331, 4332, 4333, 4334, 4335, 4336, 4337, 4338, 4344, 4345, 4346, 4923, 4924, 4925, 4926, 4927, 4928, 4929, 4930, 4931, 4932, 4933, 4934, 4935, 4937, 4938, 4939, 4940, 4942, 4945, 4949, 4952, 4953, 4954, 4955, 4956, 4957, 4960, 4961, 4962, 4964, 4965, 4966, 4967, 4968, 4969, 4970, 4971, 4972, 4978, 4979, 4982, 4983, 4984, 4985, 4987, 4988, 4989, 4990, 4991, 4992, 4994, 4997, 5001, 5004, 5005, 5006, 5009, 5010, 5011, 5012, 5014, 5015, 5018, 5019, 5020, 5021, 5023, 5024, 5026, 5027, 5028, 5029, 5031, 5032, 5033, 5034, 5036, 5037, 5038, 5039, 5040, 5041, 5044, 5045, 5046, 5047, 5049, 5050, 5051, 5052, 5053, 5056, 5057, 5058, 5059, 5061, 5062, 5063, 5064, 5067, 5068, 5069, 5070, 5072, 5073, 5074, 5075, 5078, 5079, 5080, 5081, 5082, 5084, 5087, 5088, 5089, 5090, 5091, 5093, 5096, 5100, 5103, 5104, 5105, 5106, 5107, 5109, 5112, 5116, 5119, 5120, 5121, 5122, 5123, 5125, 5128, 5132, 5133, 5135, 5136, 5137, 5138, 5139, 5140, 5141, 5143, 5144, 5145, 5148, 5149, 5150, 5151, 5152, 5154, 5155, 5158, 5159, 5161, 5162, 5163, 5164, 5165, 5166, 5167, 5168, 5169, 5170, 5171, 5172, 5173, 5174, 5175, 5176, 5177, 5178, 5179, 5180, 5181, 5182, 5183, 5189, 5192, 5193, 5194, 5195, 5197, 5198, 5199, 5201, 5202, 5203, 5205, 5206, 5207, 5208, 5209, 5210, 5211, 5212, 5213, 5214, 5217, 5218, 5219, 5220, 5222, 5225, 5226, 5227, 5228, 5230, 5233, 5237, 5240, 5241, 5242, 5243, 5245, 5248, 5252, 5255, 5256, 5257, 5258, 5260, 5263, 5267, 5274, 5275, 5276, 5277, 5278, 5279, 5280, 5281, 5282, 5283, 5285, 5286, 5287, 5288, 5289, 5290, 5291, 5292, 5293, 5294, 5295, 5296, 5297, 5298, 5299, 5300, 5302, 5303, 5304, 5305, 5306, 5307, 5309, 5310, 5311, 5312, 5315, 5316, 5317, 5318, 5319, 5320, 5322, 5325, 5326, 5327, 5328, 5329, 5330, 5332, 5333, 5334, 5335, 5336, 5337, 5341, 5342, 5343, 5344, 5345, 5348, 5350, 5351, 5352, 5353, 5354, 5356, 5357, 5358, 5359, 5361, 5366, 5369, 5371, 5374, 5378, 5381, 5382, 5384, 5387, 5391, 5392, 5394, 5395, 5397, 5398, 5400, 5401, 5406, 5407, 5410, 5414, 5417, 5418, 5419, 5420, 5421, 5422, 5424, 5425, 5428, 5429, 5430, 5431, 5432, 5433, 5434, 5435, 5436, 5437, 5438, 5439, 5442, 5448, 5450, 5452, 5455, 5459, 5462, 5463, 5464, 5466, 5467, 5468, 5469, 5470, 5471, 5473, 5474, 5475, 5476, 5477, 5479, 5482, 5486, 5489, 5490, 5493, 5494, 5496, 5499, 5503, 5505, 5507, 5510, 5514, 5517, 5518, 5519, 5520, 5521, 5522, 5523, 5524, 5525, 5526, 5528, 5529, 5530, 5533, 5534, 5535, 5536, 5537, 5538, 5539, 5540, 5541, 5544, 5545, 5546, 5548, 5549, 5550, 5551, 5552, 5554, 5555, 5556, 5557, 5560, 5563, 5564, 5565, 5566, 5567, 5568, 5569, 5570, 5571, 5572, 5573, 5574, 5579, 5580, 5581, 5582, 5583, 5586, 5588, 5589, 5590, 5593, 5596, 5597, 5599, 5602, 5607, 5610, 5614, 5617, 5618, 5620, 5623, 5627, 5631, 5634, 5638, 5641, 5645, 5646, 5648, 5649, 5650, 5651, 5652, 5653, 5654, 5657, 5658, 5660, 5661, 5662, 5663, 5664, 5665, 5666, 5669, 5670, 5671, 5672, 5673, 5674, 5678, 5681, 5682, 5684, 5687, 5692, 5693, 5695, 5696, 5698, 5701, 5702, 5704, 5707, 5708, 5710, 5711, 5712, 5713, 5714, 5715, 5716, 5717, 5718, 5719, 5720, 5721, 5722, 5724, 5727, 5728, 5729, 5730, 5731, 5732, 5733, 5734, 5735, 5736, 5737, 5738, 5739, 5741, 5742, 5743, 5744, 5745, 5748, 5750, 5751, 5753, 5754, 5755, 5757, 5758, 5764, 5765, 5766, 5769, 5770, 5772, 5773, 5774, 5775, 5777, 5780, 5784, 5785, 5786, 5787, 5788, 5789, 5796, 5797, 5798, 5799, 5800, 5801, 5803, 5804, 5805, 5806, 5807, 5808, 5809, 5811, 5812, 5815, 5816, 5817, 5818, 5819, 5820, 5821, 5821, 5824, 5826, 5827, 5828, 5829, 5830, 5831, 5832, 5838, 5839, 5840, 5841, 5843, 5844, 5845, 5846, 5848, 5851, 5855, 5856, 5857, 5858, 5859, 5860, 5863, 5864, 5865, 5866, 5867, 5871, 5872, 5873, 5875, 5876, 5877, 5878, 5879, 5880, 5881, 5882, 5883, 5884, 5885, 5886, 5889, 5890, 5891, 5892, 5893, 5894, 5895, 5896, 5897, 5898, 5899, 5900, 5905, 5907, 5908, 5909, 5910, 5911, 5912, 5913, 5914, 5915, 5916, 5917, 5918, 5921, 5922, 5923, 5924, 5925, 5926, 5927, 5928, 5929, 5930, 5931, 5932, 5937, 5939, 5940, 5943, 5944, 5945, 5946, 5947, 5949, 5951, 5952, 5954, 5955, 5957, 5960, 5962, 5963, 5964, 5965, 5966, 5967, 5968, 5969, 5970, 5971, 5972, 5973, 5974, 5975, 5976, 5977, 5978, 5979, 5980, 5981, 5982, 5983, 5984, 5985, 5986, 5987, 5990, 5992, 5993, 5994, 5995, 5996, 5998, 6001, 6002, 6004, 6007, 6011, 6012, 6013, 6016, 6017, 6019, 6020, 6022, 6023, 6024, 6025, 6026, 6045, 6046, 6047, 6049, 6050, 6051, 6052, 6053, 6056, 6057, 6058, 6059, 6060, 6062, 6063, 6064, 6071, 6072, 6073, 6074, 6075, 6089, 6090, 6091, 6092, 6093, 6094, 6095, 6096, 6097, 6098, 6099, 6100, 6114, 6115, 6116, 6117, 6118, 6119, 6120, 6121, 6122, 6123, 6124, 6125, 6153, 6154, 6155, 6156, 6157, 6158, 6159, 6160, 6161, 6162, 6163, 6164, 6165, 6167, 6168, 6169, 6170, 6171, 6172, 6173, 6174, 6175, 6176, 6177, 6178, 6179, 6186, 6187, 6188, 6189, 6190, 6199, 6200, 6201, 6214, 6215, 6217, 6218, 6220, 6221, 6223, 6226, 6228, 6231, 6235, 6236, 6238, 6239, 6248, 6249, 6250, 6251, 6253, 6254, 6255, 6267, 6268, 6269, 6270, 6271, 6273, 6274, 6276, 6277, 6327, 6328, 6329, 6331, 6334, 6335, 6336, 6338, 6341, 6342, 6343, 6345, 6348, 6349, 6350, 6352, 6355, 6356, 6357, 6359, 6360, 6361, 6364, 6365, 6366, 6368, 6371, 6372, 6373, 6375, 6378, 6379, 6380, 6382, 6383, 6384, 6387, 6388, 6389, 6391, 6392, 6393, 6396, 6397, 6398, 6400, 6401, 6404, 6405, 6406, 6408, 6409, 6412, 6413, 6414, 6416, 6419, 6420, 6421, 6423, 6437, 6438, 6439, 6443, 6448, 6469, 6470, 6471, 6473, 6476, 6477, 6478, 6479, 6481, 6484, 6485, 6486, 6487, 6489, 6492, 6493, 6497, 6513, 6514, 6515, 6517, 6520, 6521, 6522, 6523, 6525, 6528, 6529, 6530, 6531, 6533, 6536, 6537, 6541, 6544, 6549, 6550, 6554, 6555, 6559, 6560, 6564, 6565, 6569, 6570, 6574, 6575, 6589, 6590, 6591, 6592, 6592, 6595, 6597, 6598, 6599, 6601, 6602, 6605, 6607, 6608, 6609, 6615, 6616, 6622, 6623, 6624, 6625, 6631, 6632, 6633, 6634, 6640, 6641, 6642, 6643, 6646, 6649, 6653, 6656, 6660, 6663, 6667, 6670, 6674, 6677, 6681, 6684, 6688, 6691, 6695, 6698, 6702, 6705, 6709, 6712, 6716, 6719, 6723, 6726, 6730, 6733, 6737, 6740, 6744, 6747, 6751, 6754, 6758, 6761, 6765, 6768, 6772, 6775, 6779, 6782, 6786, 6789, 6793, 6796, 6800, 6803, 6807, 6810, 6814, 6817, 6821, 6824, 6828, 6831, 6835, 6838, 6842, 6845, 6849, 6852, 6856, 6859, 6863, 6866, 6870, 6873, 6877, 6880, 6884, 6887, 6891, 6894, 6898, 6901, 6905, 6908, 6912, 6915, 6919, 6922, 6926, 6929, 6933, 6936, 6940, 6943, 6947, 6950, 6954, 6957, 6961, 6964, 6968, 6971, 6975, 6978, 6982, 6985, 6989, 6992, 6996, 6999, 7003, 7006, 7010, 7013, 7017, 7020, 7024, 7027, 7031, 7034};
/* BEGIN LINEINFO 
assign 1 78 629
assign 1 93 630
nlGet 0 93 630
assign 1 95 631
new 0 95 631
assign 1 95 632
quoteGet 0 95 632
assign 1 98 633
new 0 98 633
assign 1 101 634
new 0 101 634
assign 1 101 635
new 1 101 635
assign 1 102 636
new 0 102 636
assign 1 102 637
new 1 102 637
assign 1 103 638
new 0 103 638
assign 1 103 639
new 1 103 639
assign 1 104 640
new 0 104 640
assign 1 104 641
new 1 104 641
assign 1 105 642
new 0 105 642
assign 1 105 643
new 1 105 643
assign 1 109 644
new 0 109 644
assign 1 110 645
new 0 110 645
assign 1 112 646
new 0 112 646
assign 1 113 647
new 0 113 647
assign 1 116 648
libNameGet 0 116 648
assign 1 116 649
libEmitName 1 116 649
assign 1 117 650
libNameGet 0 117 650
assign 1 117 651
fullLibEmitName 1 117 651
assign 1 118 652
emitPathGet 0 118 652
assign 1 118 653
copy 0 118 653
assign 1 118 654
emitLangGet 0 118 654
assign 1 118 655
addStep 1 118 655
assign 1 118 656
new 0 118 656
assign 1 118 657
addStep 1 118 657
assign 1 118 658
libNameGet 0 118 658
assign 1 118 659
libEmitName 1 118 659
assign 1 118 660
addStep 1 118 660
assign 1 118 661
add 1 118 661
assign 1 118 662
addStep 1 118 662
assign 1 120 663
new 0 120 663
assign 1 121 664
new 0 121 664
assign 1 122 665
new 0 122 665
assign 1 123 666
new 0 123 666
assign 1 124 667
new 0 124 667
assign 1 126 668
new 0 126 668
assign 1 127 669
new 0 127 669
assign 1 133 670
new 0 133 670
assign 1 136 671
getClassConfig 1 136 671
assign 1 137 672
getClassConfig 1 137 672
assign 1 140 673
new 0 140 673
assign 1 140 674
emitting 1 140 674
assign 1 141 676
new 0 141 676
assign 1 143 679
new 0 143 679
assign 1 148 681
new 0 148 681
assign 1 149 682
new 0 149 682
assign 1 155 688
new 0 155 688
assign 1 155 689
add 1 155 689
return 1 155 690
assign 1 159 699
new 0 159 699
assign 1 159 700
sizeGet 0 159 700
assign 1 159 701
add 1 159 701
assign 1 159 702
new 0 159 702
assign 1 159 703
add 1 159 703
assign 1 159 704
add 1 159 704
return 1 159 705
assign 1 163 713
libNs 1 163 713
assign 1 163 714
new 0 163 714
assign 1 163 715
add 1 163 715
assign 1 163 716
libEmitName 1 163 716
assign 1 163 717
add 1 163 717
return 1 163 718
assign 1 167 735
toString 0 167 735
assign 1 168 736
get 1 168 736
assign 1 169 737
undef 1 169 742
assign 1 170 743
usedLibrarysGet 0 170 743
assign 1 170 744
iteratorGet 0 0 744
assign 1 170 747
hasNextGet 0 170 747
assign 1 170 749
nextGet 0 170 749
assign 1 171 750
emitPathGet 0 171 750
assign 1 171 751
libNameGet 0 171 751
assign 1 171 752
new 4 171 752
assign 1 172 753
synPathGet 0 172 753
assign 1 172 754
fileGet 0 172 754
assign 1 172 755
existsGet 0 172 755
put 2 173 757
return 1 174 758
assign 1 177 765
emitPathGet 0 177 765
assign 1 177 766
libNameGet 0 177 766
assign 1 177 767
new 4 177 767
put 2 178 768
return 1 180 770
assign 1 184 778
toString 0 184 778
assign 1 185 779
get 1 185 779
assign 1 186 780
undef 1 186 785
assign 1 187 786
emitPathGet 0 187 786
assign 1 187 787
libNameGet 0 187 787
assign 1 187 788
new 4 187 788
put 2 188 789
return 1 190 791
assign 1 194 815
printStepsGet 0 194 815
assign 1 0 817
assign 1 194 820
printPlacesGet 0 194 820
assign 1 0 822
assign 1 0 825
assign 1 195 829
new 0 195 829
assign 1 195 830
heldGet 0 195 830
assign 1 195 831
nameGet 0 195 831
assign 1 195 832
add 1 195 832
print 0 195 833
assign 1 197 835
transUnitGet 0 197 835
assign 1 197 836
new 2 197 836
assign 1 202 837
printStepsGet 0 202 837
assign 1 203 839
new 0 203 839
echo 0 203 840
assign 1 205 842
new 0 205 842
emitterSet 1 206 843
buildSet 1 207 844
traverse 1 208 845
assign 1 210 846
printStepsGet 0 210 846
assign 1 211 848
new 0 211 848
echo 0 211 849
assign 1 213 851
new 0 213 851
emitterSet 1 214 852
buildSet 1 215 853
traverse 1 216 854
assign 1 218 855
printStepsGet 0 218 855
assign 1 219 857
new 0 219 857
echo 0 219 858
assign 1 220 859
new 0 220 859
print 0 220 860
assign 1 222 862
printStepsGet 0 222 862
traverse 1 225 865
assign 1 226 866
printStepsGet 0 226 866
assign 1 230 869
printStepsGet 0 230 869
buildStackLines 1 233 872
assign 1 234 873
printStepsGet 0 234 873
assign 1 244 1038
new 0 244 1038
assign 1 245 1039
emitDataGet 0 245 1039
assign 1 245 1040
parseOrderClassNamesGet 0 245 1040
assign 1 245 1041
iteratorGet 0 245 1041
assign 1 245 1044
hasNextGet 0 245 1044
assign 1 246 1046
nextGet 0 246 1046
assign 1 248 1047
emitDataGet 0 248 1047
assign 1 248 1048
classesGet 0 248 1048
assign 1 248 1049
get 1 248 1049
assign 1 250 1050
heldGet 0 250 1050
assign 1 250 1051
synGet 0 250 1051
assign 1 250 1052
depthGet 0 250 1052
assign 1 251 1053
get 1 251 1053
assign 1 252 1054
undef 1 252 1059
assign 1 253 1060
new 0 253 1060
put 2 254 1061
addValue 1 256 1063
assign 1 259 1069
new 0 259 1069
assign 1 260 1070
keyIteratorGet 0 260 1070
assign 1 260 1073
hasNextGet 0 260 1073
assign 1 261 1075
nextGet 0 261 1075
addValue 1 262 1076
assign 1 265 1082
sort 0 265 1082
assign 1 267 1083
new 0 267 1083
assign 1 269 1084
iteratorGet 0 0 1084
assign 1 269 1087
hasNextGet 0 269 1087
assign 1 269 1089
nextGet 0 269 1089
assign 1 270 1090
get 1 270 1090
assign 1 271 1091
iteratorGet 0 0 1091
assign 1 271 1094
hasNextGet 0 271 1094
assign 1 271 1096
nextGet 0 271 1096
addValue 1 272 1097
assign 1 276 1108
iteratorGet 0 276 1108
assign 1 276 1111
hasNextGet 0 276 1111
assign 1 278 1113
nextGet 0 278 1113
assign 1 280 1114
heldGet 0 280 1114
assign 1 280 1115
namepathGet 0 280 1115
assign 1 280 1116
getLocalClassConfig 1 280 1116
assign 1 281 1117
printStepsGet 0 281 1117
complete 1 285 1120
assign 1 288 1121
getClassOutput 0 288 1121
assign 1 292 1122
beginNs 0 292 1122
assign 1 293 1123
countLines 1 293 1123
addValue 1 293 1124
write 1 294 1125
assign 1 297 1126
countLines 1 297 1126
addValue 1 297 1127
write 1 298 1128
assign 1 301 1129
classBeginGet 0 301 1129
assign 1 302 1130
countLines 1 302 1130
addValue 1 302 1131
write 1 303 1132
assign 1 306 1133
countLines 1 306 1133
addValue 1 306 1134
write 1 307 1135
assign 1 311 1136
writeOnceDecs 2 311 1136
addValue 1 311 1137
assign 1 314 1138
initialDecGet 0 314 1138
assign 1 315 1139
countLines 1 315 1139
addValue 1 315 1140
write 1 316 1141
assign 1 319 1142
countLines 1 319 1142
addValue 1 319 1143
write 1 320 1144
assign 1 326 1145
new 0 326 1145
assign 1 327 1146
new 0 327 1146
assign 1 329 1147
new 0 329 1147
assign 1 334 1148
new 0 334 1148
assign 1 334 1149
addValue 1 334 1149
assign 1 335 1150
iteratorGet 0 0 1150
assign 1 335 1153
hasNextGet 0 335 1153
assign 1 335 1155
nextGet 0 335 1155
assign 1 336 1156
nlecGet 0 336 1156
addValue 1 336 1157
assign 1 337 1158
nlecGet 0 337 1158
incrementValue 0 337 1159
assign 1 338 1160
undef 1 338 1165
assign 1 0 1166
assign 1 338 1169
nlcGet 0 338 1169
assign 1 338 1170
notEquals 1 338 1170
assign 1 0 1172
assign 1 0 1175
assign 1 0 1179
assign 1 338 1182
nlecGet 0 338 1182
assign 1 338 1183
notEquals 1 338 1183
assign 1 0 1185
assign 1 0 1188
assign 1 341 1193
new 0 341 1193
assign 1 343 1196
new 0 343 1196
addValue 1 343 1197
assign 1 344 1198
new 0 344 1198
addValue 1 344 1199
assign 1 346 1201
nlcGet 0 346 1201
addValue 1 346 1202
assign 1 347 1203
nlecGet 0 347 1203
addValue 1 347 1204
assign 1 350 1206
nlcGet 0 350 1206
assign 1 351 1207
nlecGet 0 351 1207
assign 1 352 1208
heldGet 0 352 1208
assign 1 352 1209
orgNameGet 0 352 1209
assign 1 352 1210
addValue 1 352 1210
assign 1 352 1211
new 0 352 1211
assign 1 352 1212
addValue 1 352 1212
assign 1 352 1213
heldGet 0 352 1213
assign 1 352 1214
numargsGet 0 352 1214
assign 1 352 1215
addValue 1 352 1215
assign 1 352 1216
new 0 352 1216
assign 1 352 1217
addValue 1 352 1217
assign 1 352 1218
nlcGet 0 352 1218
assign 1 352 1219
addValue 1 352 1219
assign 1 352 1220
new 0 352 1220
assign 1 352 1221
addValue 1 352 1221
assign 1 352 1222
nlecGet 0 352 1222
assign 1 352 1223
addValue 1 352 1223
addValue 1 352 1224
assign 1 354 1230
new 0 354 1230
assign 1 354 1231
addValue 1 354 1231
addValue 1 354 1232
assign 1 356 1233
new 0 356 1233
assign 1 356 1234
emitting 1 356 1234
assign 1 358 1236
heldGet 0 358 1236
assign 1 358 1237
namepathGet 0 358 1237
assign 1 358 1238
getClassConfig 1 358 1238
assign 1 358 1239
emitNameGet 0 358 1239
assign 1 358 1240
new 0 358 1240
assign 1 357 1241
add 1 358 1241
assign 1 361 1243
heldGet 0 361 1243
assign 1 361 1244
namepathGet 0 361 1244
assign 1 361 1245
getClassConfig 1 361 1245
assign 1 361 1246
libNameGet 0 361 1246
assign 1 361 1247
relEmitName 1 361 1247
assign 1 363 1248
heldGet 0 363 1248
assign 1 363 1249
namepathGet 0 363 1249
assign 1 363 1250
toString 0 363 1250
assign 1 363 1251
new 0 363 1251
assign 1 363 1252
add 1 363 1252
put 2 363 1253
assign 1 364 1254
heldGet 0 364 1254
assign 1 364 1255
namepathGet 0 364 1255
assign 1 364 1256
toString 0 364 1256
assign 1 364 1257
new 0 364 1257
assign 1 364 1258
add 1 364 1258
put 2 364 1259
assign 1 366 1260
new 0 366 1260
assign 1 366 1261
emitting 1 366 1261
assign 1 367 1263
namepathGet 0 367 1263
assign 1 367 1264
equals 1 367 1264
assign 1 368 1266
new 0 368 1266
assign 1 368 1267
addValue 1 368 1267
addValue 1 368 1268
assign 1 370 1271
new 0 370 1271
assign 1 370 1272
addValue 1 370 1272
addValue 1 370 1273
assign 1 373 1276
new 0 373 1276
assign 1 373 1277
emitting 1 373 1277
assign 1 374 1279
new 0 374 1279
assign 1 374 1280
addValue 1 374 1280
addValue 1 374 1281
assign 1 376 1283
new 0 376 1283
assign 1 376 1284
emitting 1 376 1284
assign 1 377 1286
addValue 1 377 1286
assign 1 377 1287
new 0 377 1287
addValue 1 377 1288
assign 1 378 1289
new 0 378 1289
assign 1 378 1290
addValue 1 378 1290
assign 1 378 1291
addValue 1 378 1291
assign 1 378 1292
new 0 378 1292
assign 1 378 1293
addValue 1 378 1293
addValue 1 378 1294
assign 1 380 1297
new 0 380 1297
assign 1 380 1298
addValue 1 380 1298
assign 1 380 1299
addValue 1 380 1299
assign 1 380 1300
new 0 380 1300
assign 1 380 1301
addValue 1 380 1301
addValue 1 380 1302
assign 1 382 1304
new 0 382 1304
assign 1 382 1305
emitting 1 382 1305
assign 1 383 1307
namepathGet 0 383 1307
assign 1 383 1308
equals 1 383 1308
assign 1 384 1310
new 0 384 1310
assign 1 384 1311
addValue 1 384 1311
addValue 1 384 1312
assign 1 386 1315
new 0 386 1315
assign 1 386 1316
addValue 1 386 1316
addValue 1 386 1317
assign 1 389 1320
new 0 389 1320
assign 1 389 1321
emitting 1 389 1321
assign 1 390 1323
new 0 390 1323
assign 1 390 1324
addValue 1 390 1324
addValue 1 390 1325
assign 1 392 1327
new 0 392 1327
assign 1 392 1328
emitting 1 392 1328
assign 1 393 1330
addValue 1 393 1330
assign 1 393 1331
new 0 393 1331
addValue 1 393 1332
assign 1 394 1333
new 0 394 1333
assign 1 394 1334
addValue 1 394 1334
assign 1 394 1335
addValue 1 394 1335
assign 1 394 1336
new 0 394 1336
assign 1 394 1337
addValue 1 394 1337
addValue 1 394 1338
assign 1 396 1341
new 0 396 1341
assign 1 396 1342
addValue 1 396 1342
assign 1 396 1343
addValue 1 396 1343
assign 1 396 1344
new 0 396 1344
assign 1 396 1345
addValue 1 396 1345
addValue 1 396 1346
addValue 1 399 1348
assign 1 402 1349
countLines 1 402 1349
addValue 1 402 1350
write 1 403 1351
assign 1 406 1352
useDynMethodsGet 0 406 1352
assign 1 407 1354
countLines 1 407 1354
addValue 1 407 1355
write 1 408 1356
assign 1 411 1358
countLines 1 411 1358
addValue 1 411 1359
write 1 412 1360
assign 1 415 1361
classEndGet 0 415 1361
assign 1 416 1362
countLines 1 416 1362
addValue 1 416 1363
write 1 417 1364
assign 1 420 1365
endNs 0 420 1365
assign 1 421 1366
countLines 1 421 1366
addValue 1 421 1367
write 1 422 1368
finishClassOutput 1 426 1369
emitLib 0 429 1375
write 1 433 1380
assign 1 434 1381
countLines 1 434 1381
return 1 434 1382
assign 1 438 1386
new 0 438 1386
return 1 438 1387
assign 1 443 1401
new 0 443 1401
assign 1 443 1402
copy 0 443 1402
assign 1 445 1403
classDirGet 0 445 1403
assign 1 445 1404
fileGet 0 445 1404
assign 1 445 1405
existsGet 0 445 1405
assign 1 445 1406
not 0 445 1406
assign 1 446 1408
classDirGet 0 446 1408
assign 1 446 1409
fileGet 0 446 1409
makeDirs 0 446 1410
assign 1 448 1412
classPathGet 0 448 1412
assign 1 448 1413
fileGet 0 448 1413
assign 1 448 1414
writerGet 0 448 1414
assign 1 448 1415
open 0 448 1415
return 1 448 1416
close 0 452 1419
assign 1 456 1426
fileGet 0 456 1426
assign 1 456 1427
writerGet 0 456 1427
assign 1 456 1428
open 0 456 1428
return 1 456 1429
close 0 460 1432
assign 1 464 1437
new 0 464 1437
return 1 464 1438
assign 1 468 1442
new 0 468 1442
return 1 468 1443
assign 1 472 1447
new 0 472 1447
return 1 472 1448
assign 1 476 1452
new 0 476 1452
return 1 476 1453
assign 1 480 1457
new 0 480 1457
return 1 480 1458
assign 1 484 1462
new 0 484 1462
return 1 484 1463
assign 1 488 1467
new 0 488 1467
return 1 488 1468
assign 1 492 1475
emitLangGet 0 492 1475
assign 1 492 1476
equals 1 492 1476
assign 1 493 1478
new 0 493 1478
return 1 493 1479
assign 1 495 1481
new 0 495 1481
return 1 495 1482
assign 1 500 1714
new 0 500 1714
assign 1 502 1715
new 0 502 1715
assign 1 503 1716
mainNameGet 0 503 1716
fromString 1 503 1717
assign 1 504 1718
getClassConfig 1 504 1718
assign 1 506 1719
new 0 506 1719
assign 1 507 1720
mainStartGet 0 507 1720
addValue 1 507 1721
assign 1 508 1722
addValue 1 508 1722
assign 1 508 1723
new 0 508 1723
assign 1 508 1724
addValue 1 508 1724
addValue 1 508 1725
assign 1 510 1726
fullEmitNameGet 0 510 1726
assign 1 510 1727
addValue 1 510 1727
assign 1 510 1728
new 0 510 1728
assign 1 510 1729
addValue 1 510 1729
assign 1 510 1730
fullEmitNameGet 0 510 1730
assign 1 510 1731
addValue 1 510 1731
assign 1 510 1732
new 0 510 1732
assign 1 510 1733
addValue 1 510 1733
addValue 1 510 1734
assign 1 511 1735
new 0 511 1735
assign 1 511 1736
addValue 1 511 1736
addValue 1 511 1737
assign 1 512 1738
new 0 512 1738
assign 1 512 1739
addValue 1 512 1739
addValue 1 512 1740
assign 1 513 1741
mainEndGet 0 513 1741
addValue 1 513 1742
assign 1 515 1743
getLibOutput 0 515 1743
assign 1 516 1744
beginNs 0 516 1744
write 1 516 1745
assign 1 517 1746
new 0 517 1746
assign 1 517 1747
extend 1 517 1747
assign 1 518 1748
klassDecGet 0 518 1748
assign 1 518 1749
add 1 518 1749
assign 1 518 1750
add 1 518 1750
assign 1 518 1751
new 0 518 1751
assign 1 518 1752
add 1 518 1752
assign 1 518 1753
add 1 518 1753
write 1 518 1754
assign 1 519 1755
spropDecGet 0 519 1755
assign 1 519 1756
boolTypeGet 0 519 1756
assign 1 519 1757
add 1 519 1757
assign 1 519 1758
new 0 519 1758
assign 1 519 1759
add 1 519 1759
assign 1 519 1760
add 1 519 1760
write 1 519 1761
assign 1 521 1762
new 0 521 1762
assign 1 522 1763
usedLibrarysGet 0 522 1763
assign 1 522 1764
iteratorGet 0 0 1764
assign 1 522 1767
hasNextGet 0 522 1767
assign 1 522 1769
nextGet 0 522 1769
assign 1 524 1770
libNameGet 0 524 1770
assign 1 524 1771
fullLibEmitName 1 524 1771
assign 1 524 1772
addValue 1 524 1772
assign 1 524 1773
new 0 524 1773
assign 1 524 1774
addValue 1 524 1774
addValue 1 524 1775
assign 1 527 1781
new 0 527 1781
assign 1 528 1782
new 0 528 1782
assign 1 529 1783
new 0 529 1783
assign 1 530 1784
iteratorGet 0 530 1784
assign 1 530 1787
hasNextGet 0 530 1787
assign 1 532 1789
nextGet 0 532 1789
assign 1 534 1790
new 0 534 1790
assign 1 534 1791
emitting 1 534 1791
assign 1 535 1793
new 0 535 1793
assign 1 535 1794
addValue 1 535 1794
assign 1 535 1795
addValue 1 535 1795
assign 1 535 1796
heldGet 0 535 1796
assign 1 535 1797
namepathGet 0 535 1797
assign 1 535 1798
toString 0 535 1798
assign 1 535 1799
addValue 1 535 1799
assign 1 535 1800
addValue 1 535 1800
assign 1 535 1801
new 0 535 1801
assign 1 535 1802
addValue 1 535 1802
assign 1 535 1803
addValue 1 535 1803
assign 1 535 1804
heldGet 0 535 1804
assign 1 535 1805
namepathGet 0 535 1805
assign 1 535 1806
getClassConfig 1 535 1806
assign 1 535 1807
fullEmitNameGet 0 535 1807
assign 1 535 1808
addValue 1 535 1808
assign 1 535 1809
addValue 1 535 1809
assign 1 535 1810
new 0 535 1810
assign 1 535 1811
addValue 1 535 1811
addValue 1 535 1812
assign 1 537 1814
new 0 537 1814
assign 1 537 1815
emitting 1 537 1815
assign 1 538 1817
new 0 538 1817
assign 1 538 1818
addValue 1 538 1818
assign 1 538 1819
addValue 1 538 1819
assign 1 538 1820
heldGet 0 538 1820
assign 1 538 1821
namepathGet 0 538 1821
assign 1 538 1822
toString 0 538 1822
assign 1 538 1823
addValue 1 538 1823
assign 1 538 1824
addValue 1 538 1824
assign 1 538 1825
new 0 538 1825
assign 1 538 1826
addValue 1 538 1826
assign 1 538 1827
heldGet 0 538 1827
assign 1 538 1828
namepathGet 0 538 1828
assign 1 538 1829
getClassConfig 1 538 1829
assign 1 538 1830
libNameGet 0 538 1830
assign 1 538 1831
relEmitName 1 538 1831
assign 1 538 1832
addValue 1 538 1832
assign 1 538 1833
new 0 538 1833
assign 1 538 1834
addValue 1 538 1834
addValue 1 538 1835
assign 1 539 1836
new 0 539 1836
assign 1 539 1837
addValue 1 539 1837
assign 1 539 1838
heldGet 0 539 1838
assign 1 539 1839
namepathGet 0 539 1839
assign 1 539 1840
getClassConfig 1 539 1840
assign 1 539 1841
libNameGet 0 539 1841
assign 1 539 1842
relEmitName 1 539 1842
assign 1 539 1843
addValue 1 539 1843
assign 1 539 1844
new 0 539 1844
addValue 1 539 1845
assign 1 540 1846
new 0 540 1846
assign 1 540 1847
addValue 1 540 1847
assign 1 540 1848
addValue 1 540 1848
assign 1 540 1849
new 0 540 1849
assign 1 540 1850
addValue 1 540 1850
assign 1 540 1851
addValue 1 540 1851
assign 1 540 1852
new 0 540 1852
assign 1 540 1853
addValue 1 540 1853
addValue 1 540 1854
assign 1 543 1856
heldGet 0 543 1856
assign 1 543 1857
synGet 0 543 1857
assign 1 543 1858
hasDefaultGet 0 543 1858
assign 1 544 1860
new 0 544 1860
assign 1 544 1861
heldGet 0 544 1861
assign 1 544 1862
namepathGet 0 544 1862
assign 1 544 1863
getClassConfig 1 544 1863
assign 1 544 1864
libNameGet 0 544 1864
assign 1 544 1865
relEmitName 1 544 1865
assign 1 544 1866
add 1 544 1866
assign 1 544 1867
new 0 544 1867
assign 1 544 1868
add 1 544 1868
assign 1 545 1869
new 0 545 1869
assign 1 545 1870
addValue 1 545 1870
assign 1 545 1871
addValue 1 545 1871
assign 1 545 1872
new 0 545 1872
assign 1 545 1873
addValue 1 545 1873
addValue 1 545 1874
assign 1 546 1875
new 0 546 1875
assign 1 546 1876
addValue 1 546 1876
assign 1 546 1877
addValue 1 546 1877
assign 1 546 1878
new 0 546 1878
assign 1 546 1879
addValue 1 546 1879
addValue 1 546 1880
assign 1 550 1887
iteratorGet 0 0 1887
assign 1 550 1890
hasNextGet 0 550 1890
assign 1 550 1892
nextGet 0 550 1892
assign 1 551 1893
spropDecGet 0 551 1893
assign 1 551 1894
new 0 551 1894
assign 1 551 1895
add 1 551 1895
assign 1 551 1896
add 1 551 1896
assign 1 551 1897
new 0 551 1897
assign 1 551 1898
add 1 551 1898
assign 1 551 1899
add 1 551 1899
write 1 551 1900
assign 1 552 1901
new 0 552 1901
assign 1 552 1902
addValue 1 552 1902
assign 1 552 1903
addValue 1 552 1903
assign 1 552 1904
new 0 552 1904
assign 1 552 1905
addValue 1 552 1905
assign 1 552 1906
addValue 1 552 1906
assign 1 552 1907
addValue 1 552 1907
assign 1 552 1908
addValue 1 552 1908
assign 1 552 1909
new 0 552 1909
assign 1 552 1910
addValue 1 552 1910
addValue 1 552 1911
assign 1 555 1917
new 0 555 1917
assign 1 557 1918
keysGet 0 557 1918
assign 1 557 1919
iteratorGet 0 0 1919
assign 1 557 1922
hasNextGet 0 557 1922
assign 1 557 1924
nextGet 0 557 1924
assign 1 559 1925
new 0 559 1925
assign 1 559 1926
addValue 1 559 1926
assign 1 559 1927
new 0 559 1927
assign 1 559 1928
quoteGet 0 559 1928
assign 1 559 1929
addValue 1 559 1929
assign 1 559 1930
addValue 1 559 1930
assign 1 559 1931
new 0 559 1931
assign 1 559 1932
quoteGet 0 559 1932
assign 1 559 1933
addValue 1 559 1933
assign 1 559 1934
new 0 559 1934
assign 1 559 1935
addValue 1 559 1935
assign 1 559 1936
get 1 559 1936
assign 1 559 1937
addValue 1 559 1937
assign 1 559 1938
new 0 559 1938
assign 1 559 1939
addValue 1 559 1939
addValue 1 559 1940
assign 1 560 1941
new 0 560 1941
assign 1 560 1942
addValue 1 560 1942
assign 1 560 1943
new 0 560 1943
assign 1 560 1944
quoteGet 0 560 1944
assign 1 560 1945
addValue 1 560 1945
assign 1 560 1946
addValue 1 560 1946
assign 1 560 1947
new 0 560 1947
assign 1 560 1948
quoteGet 0 560 1948
assign 1 560 1949
addValue 1 560 1949
assign 1 560 1950
new 0 560 1950
assign 1 560 1951
addValue 1 560 1951
assign 1 560 1952
get 1 560 1952
assign 1 560 1953
addValue 1 560 1953
assign 1 560 1954
new 0 560 1954
assign 1 560 1955
addValue 1 560 1955
addValue 1 560 1956
assign 1 564 1962
baseSmtdDecGet 0 564 1962
assign 1 564 1963
new 0 564 1963
assign 1 564 1964
add 1 564 1964
assign 1 564 1965
addValue 1 564 1965
assign 1 564 1966
new 0 564 1966
assign 1 564 1967
add 1 564 1967
assign 1 564 1968
addValue 1 564 1968
write 1 564 1969
assign 1 565 1970
new 0 565 1970
assign 1 565 1971
emitting 1 565 1971
assign 1 566 1973
new 0 566 1973
assign 1 566 1974
add 1 566 1974
assign 1 566 1975
new 0 566 1975
assign 1 566 1976
add 1 566 1976
assign 1 566 1977
add 1 566 1977
write 1 566 1978
assign 1 567 1981
new 0 567 1981
assign 1 567 1982
emitting 1 567 1982
assign 1 568 1984
new 0 568 1984
assign 1 568 1985
add 1 568 1985
assign 1 568 1986
new 0 568 1986
assign 1 568 1987
add 1 568 1987
assign 1 568 1988
add 1 568 1988
write 1 568 1989
assign 1 570 1992
new 0 570 1992
assign 1 570 1993
add 1 570 1993
write 1 570 1994
assign 1 571 1995
new 0 571 1995
assign 1 571 1996
add 1 571 1996
write 1 571 1997
assign 1 572 1998
runtimeInitGet 0 572 1998
write 1 572 1999
write 1 573 2000
write 1 574 2001
write 1 575 2002
write 1 576 2003
write 1 577 2004
write 1 578 2005
assign 1 579 2006
new 0 579 2006
assign 1 579 2007
emitting 1 579 2007
assign 1 0 2009
assign 1 579 2012
new 0 579 2012
assign 1 579 2013
emitting 1 579 2013
assign 1 0 2015
assign 1 0 2018
assign 1 581 2022
new 0 581 2022
assign 1 581 2023
add 1 581 2023
write 1 581 2024
assign 1 583 2026
new 0 583 2026
assign 1 583 2027
add 1 583 2027
write 1 583 2028
assign 1 585 2029
mainInClassGet 0 585 2029
write 1 586 2031
assign 1 589 2033
new 0 589 2033
assign 1 589 2034
add 1 589 2034
write 1 589 2035
assign 1 590 2036
endNs 0 590 2036
write 1 590 2037
assign 1 592 2038
mainOutsideNsGet 0 592 2038
write 1 593 2040
finishLibOutput 1 596 2042
assign 1 601 2048
new 0 601 2048
assign 1 601 2049
add 1 601 2049
return 1 601 2050
assign 1 605 2054
new 0 605 2054
return 1 605 2055
assign 1 609 2059
new 0 609 2059
return 1 609 2060
assign 1 613 2064
new 0 613 2064
return 1 613 2065
assign 1 619 2077
new 0 619 2077
assign 1 619 2078
emitting 1 619 2078
assign 1 0 2080
assign 1 619 2083
new 0 619 2083
assign 1 619 2084
emitting 1 619 2084
assign 1 0 2086
assign 1 0 2089
assign 1 621 2093
new 0 621 2093
assign 1 621 2094
add 1 621 2094
return 1 621 2095
assign 1 624 2097
new 0 624 2097
assign 1 624 2098
add 1 624 2098
return 1 624 2099
assign 1 628 2103
new 0 628 2103
return 1 628 2104
begin 1 633 2107
assign 1 635 2108
new 0 635 2108
assign 1 636 2109
new 0 636 2109
assign 1 637 2110
new 0 637 2110
assign 1 638 2111
new 0 638 2111
assign 1 645 2121
isTmpVarGet 0 645 2121
assign 1 646 2123
new 0 646 2123
assign 1 647 2126
isPropertyGet 0 647 2126
assign 1 648 2128
new 0 648 2128
assign 1 649 2131
isArgGet 0 649 2131
assign 1 650 2133
new 0 650 2133
assign 1 652 2136
new 0 652 2136
assign 1 654 2140
nameGet 0 654 2140
assign 1 654 2141
add 1 654 2141
return 1 654 2142
assign 1 659 2153
isTypedGet 0 659 2153
assign 1 659 2154
not 0 659 2154
assign 1 660 2156
libNameGet 0 660 2156
assign 1 660 2157
relEmitName 1 660 2157
addValue 1 660 2158
assign 1 662 2161
namepathGet 0 662 2161
assign 1 662 2162
getClassConfig 1 662 2162
assign 1 662 2163
libNameGet 0 662 2163
assign 1 662 2164
relEmitName 1 662 2164
addValue 1 662 2165
typeDecForVar 2 667 2172
assign 1 668 2173
new 0 668 2173
addValue 1 668 2174
assign 1 669 2175
nameForVar 1 669 2175
addValue 1 669 2176
assign 1 673 2184
new 0 673 2184
assign 1 673 2185
heldGet 0 673 2185
assign 1 673 2186
nameGet 0 673 2186
assign 1 673 2187
add 1 673 2187
return 1 673 2188
assign 1 677 2195
new 0 677 2195
assign 1 677 2196
heldGet 0 677 2196
assign 1 677 2197
nameGet 0 677 2197
assign 1 677 2198
add 1 677 2198
return 1 677 2199
assign 1 682 2251
assign 1 683 2252
assign 1 686 2253
mtdMapGet 0 686 2253
assign 1 686 2254
heldGet 0 686 2254
assign 1 686 2255
nameGet 0 686 2255
assign 1 686 2256
get 1 686 2256
assign 1 688 2257
heldGet 0 688 2257
assign 1 688 2258
nameGet 0 688 2258
put 1 688 2259
assign 1 690 2260
new 0 690 2260
assign 1 691 2261
new 0 691 2261
assign 1 693 2262
new 0 693 2262
assign 1 694 2263
heldGet 0 694 2263
assign 1 694 2264
orderedVarsGet 0 694 2264
assign 1 694 2265
iteratorGet 0 0 2265
assign 1 694 2268
hasNextGet 0 694 2268
assign 1 694 2270
nextGet 0 694 2270
assign 1 695 2271
heldGet 0 695 2271
assign 1 695 2272
nameGet 0 695 2272
assign 1 695 2273
new 0 695 2273
assign 1 695 2274
notEquals 1 695 2274
assign 1 695 2276
heldGet 0 695 2276
assign 1 695 2277
nameGet 0 695 2277
assign 1 695 2278
new 0 695 2278
assign 1 695 2279
notEquals 1 695 2279
assign 1 0 2281
assign 1 0 2284
assign 1 0 2288
assign 1 696 2291
heldGet 0 696 2291
assign 1 696 2292
isArgGet 0 696 2292
assign 1 698 2295
new 0 698 2295
addValue 1 698 2296
assign 1 700 2298
new 0 700 2298
assign 1 701 2299
heldGet 0 701 2299
assign 1 701 2300
undef 1 701 2305
assign 1 702 2306
new 0 702 2306
assign 1 702 2307
toString 0 702 2307
assign 1 702 2308
add 1 702 2308
assign 1 702 2309
new 2 702 2309
throw 1 702 2310
assign 1 704 2312
heldGet 0 704 2312
decForVar 2 704 2313
assign 1 706 2316
heldGet 0 706 2316
decForVar 2 706 2317
assign 1 707 2318
new 0 707 2318
assign 1 707 2319
emitting 1 707 2319
assign 1 708 2321
new 0 708 2321
assign 1 708 2322
addValue 1 708 2322
addValue 1 708 2323
assign 1 710 2326
new 0 710 2326
assign 1 710 2327
addValue 1 710 2327
addValue 1 710 2328
assign 1 713 2331
heldGet 0 713 2331
assign 1 713 2332
heldGet 0 713 2332
assign 1 713 2333
nameForVar 1 713 2333
nativeNameSet 1 713 2334
assign 1 717 2341
getEmitReturnType 2 717 2341
assign 1 719 2342
def 1 719 2347
assign 1 720 2348
getClassConfig 1 720 2348
assign 1 722 2351
assign 1 726 2353
declarationGet 0 726 2353
assign 1 726 2354
namepathGet 0 726 2354
assign 1 726 2355
equals 1 726 2355
assign 1 727 2357
baseMtdDecGet 0 727 2357
assign 1 729 2360
overrideMtdDecGet 0 729 2360
assign 1 732 2362
emitNameForMethod 1 732 2362
startMethod 5 732 2363
addValue 1 734 2364
assign 1 740 2381
addValue 1 740 2381
assign 1 740 2382
libNameGet 0 740 2382
assign 1 740 2383
relEmitName 1 740 2383
assign 1 740 2384
addValue 1 740 2384
assign 1 740 2385
new 0 740 2385
assign 1 740 2386
addValue 1 740 2386
assign 1 740 2387
addValue 1 740 2387
assign 1 740 2388
new 0 740 2388
addValue 1 740 2389
addValue 1 742 2390
assign 1 744 2391
new 0 744 2391
assign 1 744 2392
addValue 1 744 2392
assign 1 744 2393
addValue 1 744 2393
assign 1 744 2394
new 0 744 2394
assign 1 744 2395
addValue 1 744 2395
addValue 1 744 2396
assign 1 749 2406
getSynNp 1 749 2406
assign 1 750 2407
closeLibrariesGet 0 750 2407
assign 1 750 2408
libNameGet 0 750 2408
assign 1 750 2409
has 1 750 2409
assign 1 751 2411
new 0 751 2411
return 1 751 2412
assign 1 753 2414
new 0 753 2414
return 1 753 2415
assign 1 758 2639
new 0 758 2639
assign 1 759 2640
new 0 759 2640
assign 1 760 2641
new 0 760 2641
assign 1 761 2642
new 0 761 2642
assign 1 762 2643
new 0 762 2643
assign 1 763 2644
assign 1 764 2645
heldGet 0 764 2645
assign 1 764 2646
synGet 0 764 2646
assign 1 765 2647
new 0 765 2647
assign 1 766 2648
new 0 766 2648
assign 1 767 2649
new 0 767 2649
assign 1 768 2650
new 0 768 2650
assign 1 769 2651
heldGet 0 769 2651
assign 1 769 2652
fromFileGet 0 769 2652
assign 1 769 2653
new 0 769 2653
assign 1 769 2654
toStringWithSeparator 1 769 2654
assign 1 772 2655
transUnitGet 0 772 2655
assign 1 772 2656
heldGet 0 772 2656
assign 1 772 2657
emitsGet 0 772 2657
assign 1 773 2658
def 1 773 2663
assign 1 774 2664
iteratorGet 0 774 2664
assign 1 774 2667
hasNextGet 0 774 2667
assign 1 775 2669
nextGet 0 775 2669
assign 1 776 2670
heldGet 0 776 2670
assign 1 776 2671
langsGet 0 776 2671
assign 1 776 2672
emitLangGet 0 776 2672
assign 1 776 2673
has 1 776 2673
assign 1 777 2675
heldGet 0 777 2675
assign 1 777 2676
textGet 0 777 2676
addValue 1 777 2677
assign 1 782 2685
heldGet 0 782 2685
assign 1 782 2686
extendsGet 0 782 2686
assign 1 782 2687
def 1 782 2692
assign 1 783 2693
heldGet 0 783 2693
assign 1 783 2694
extendsGet 0 783 2694
assign 1 783 2695
getClassConfig 1 783 2695
assign 1 784 2696
heldGet 0 784 2696
assign 1 784 2697
extendsGet 0 784 2697
assign 1 784 2698
getSynNp 1 784 2698
assign 1 786 2701
assign 1 790 2703
heldGet 0 790 2703
assign 1 790 2704
emitsGet 0 790 2704
assign 1 790 2705
def 1 790 2710
assign 1 791 2711
emitLangGet 0 791 2711
assign 1 792 2712
heldGet 0 792 2712
assign 1 792 2713
emitsGet 0 792 2713
assign 1 792 2714
iteratorGet 0 0 2714
assign 1 792 2717
hasNextGet 0 792 2717
assign 1 792 2719
nextGet 0 792 2719
assign 1 794 2720
heldGet 0 794 2720
assign 1 794 2721
textGet 0 794 2721
assign 1 794 2722
getNativeCSlots 1 794 2722
assign 1 795 2723
heldGet 0 795 2723
assign 1 795 2724
langsGet 0 795 2724
assign 1 795 2725
has 1 795 2725
assign 1 796 2727
heldGet 0 796 2727
assign 1 796 2728
textGet 0 796 2728
addValue 1 796 2729
assign 1 801 2737
def 1 801 2742
assign 1 801 2743
new 0 801 2743
assign 1 801 2744
greater 1 801 2744
assign 1 0 2746
assign 1 0 2749
assign 1 0 2753
assign 1 802 2756
ptyListGet 0 802 2756
assign 1 802 2757
sizeGet 0 802 2757
assign 1 802 2758
subtract 1 802 2758
assign 1 803 2759
new 0 803 2759
assign 1 803 2760
lesser 1 803 2760
assign 1 804 2762
new 0 804 2762
assign 1 810 2765
new 0 810 2765
assign 1 811 2766
heldGet 0 811 2766
assign 1 811 2767
orderedVarsGet 0 811 2767
assign 1 811 2768
iteratorGet 0 811 2768
assign 1 811 2771
hasNextGet 0 811 2771
assign 1 812 2773
nextGet 0 812 2773
assign 1 812 2774
heldGet 0 812 2774
assign 1 813 2775
isDeclaredGet 0 813 2775
assign 1 814 2777
greaterEquals 1 814 2777
assign 1 815 2779
propDecGet 0 815 2779
addValue 1 815 2780
decForVar 2 816 2781
assign 1 817 2782
new 0 817 2782
assign 1 817 2783
addValue 1 817 2783
addValue 1 817 2784
assign 1 819 2786
increment 0 819 2786
assign 1 824 2793
new 0 824 2793
assign 1 825 2794
new 0 825 2794
assign 1 826 2795
mtdListGet 0 826 2795
assign 1 826 2796
iteratorGet 0 0 2796
assign 1 826 2799
hasNextGet 0 826 2799
assign 1 826 2801
nextGet 0 826 2801
assign 1 827 2802
nameGet 0 827 2802
assign 1 827 2803
has 1 827 2803
assign 1 828 2805
nameGet 0 828 2805
put 1 828 2806
assign 1 829 2807
mtdMapGet 0 829 2807
assign 1 829 2808
nameGet 0 829 2808
assign 1 829 2809
get 1 829 2809
assign 1 830 2810
originGet 0 830 2810
assign 1 830 2811
isClose 1 830 2811
assign 1 831 2813
numargsGet 0 831 2813
assign 1 832 2814
greater 1 832 2814
assign 1 833 2816
assign 1 835 2818
get 1 835 2818
assign 1 836 2819
undef 1 836 2824
assign 1 837 2825
new 0 837 2825
put 2 838 2826
assign 1 840 2828
nameGet 0 840 2828
assign 1 840 2829
hashGet 0 840 2829
assign 1 841 2830
get 1 841 2830
assign 1 842 2831
undef 1 842 2836
assign 1 843 2837
new 0 843 2837
put 2 844 2838
addValue 1 846 2840
assign 1 852 2848
iteratorGet 0 0 2848
assign 1 852 2851
hasNextGet 0 852 2851
assign 1 852 2853
nextGet 0 852 2853
assign 1 853 2854
keyGet 0 853 2854
assign 1 855 2855
lesser 1 855 2855
assign 1 856 2857
new 0 856 2857
assign 1 856 2858
toString 0 856 2858
assign 1 856 2859
add 1 856 2859
assign 1 858 2862
new 0 858 2862
assign 1 860 2864
new 0 860 2864
assign 1 861 2865
new 0 861 2865
assign 1 862 2866
new 0 862 2866
assign 1 863 2869
new 0 863 2869
assign 1 863 2870
add 1 863 2870
assign 1 863 2871
lesser 1 863 2871
assign 1 863 2873
lesser 1 863 2873
assign 1 0 2875
assign 1 0 2878
assign 1 0 2882
assign 1 864 2885
new 0 864 2885
assign 1 864 2886
add 1 864 2886
assign 1 864 2887
libNameGet 0 864 2887
assign 1 864 2888
relEmitName 1 864 2888
assign 1 864 2889
add 1 864 2889
assign 1 864 2890
new 0 864 2890
assign 1 864 2891
add 1 864 2891
assign 1 864 2892
new 0 864 2892
assign 1 864 2893
subtract 1 864 2893
assign 1 864 2894
add 1 864 2894
assign 1 865 2895
new 0 865 2895
assign 1 865 2896
add 1 865 2896
assign 1 865 2897
new 0 865 2897
assign 1 865 2898
add 1 865 2898
assign 1 865 2899
new 0 865 2899
assign 1 865 2900
subtract 1 865 2900
assign 1 865 2901
add 1 865 2901
assign 1 866 2902
increment 0 866 2902
assign 1 868 2908
greaterEquals 1 868 2908
assign 1 869 2910
new 0 869 2910
assign 1 869 2911
add 1 869 2911
assign 1 869 2912
libNameGet 0 869 2912
assign 1 869 2913
relEmitName 1 869 2913
assign 1 869 2914
add 1 869 2914
assign 1 869 2915
new 0 869 2915
assign 1 869 2916
add 1 869 2916
assign 1 870 2917
new 0 870 2917
assign 1 870 2918
add 1 870 2918
assign 1 872 2920
overrideMtdDecGet 0 872 2920
assign 1 872 2921
addValue 1 872 2921
assign 1 872 2922
libNameGet 0 872 2922
assign 1 872 2923
relEmitName 1 872 2923
assign 1 872 2924
addValue 1 872 2924
assign 1 872 2925
new 0 872 2925
assign 1 872 2926
addValue 1 872 2926
assign 1 872 2927
addValue 1 872 2927
assign 1 872 2928
new 0 872 2928
assign 1 872 2929
addValue 1 872 2929
assign 1 872 2930
addValue 1 872 2930
assign 1 872 2931
new 0 872 2931
assign 1 872 2932
addValue 1 872 2932
assign 1 872 2933
addValue 1 872 2933
assign 1 872 2934
new 0 872 2934
assign 1 872 2935
addValue 1 872 2935
addValue 1 872 2936
assign 1 873 2937
new 0 873 2937
assign 1 873 2938
addValue 1 873 2938
addValue 1 873 2939
assign 1 875 2940
valueGet 0 875 2940
assign 1 876 2941
iteratorGet 0 0 2941
assign 1 876 2944
hasNextGet 0 876 2944
assign 1 876 2946
nextGet 0 876 2946
assign 1 877 2947
keyGet 0 877 2947
assign 1 878 2948
valueGet 0 878 2948
assign 1 879 2949
new 0 879 2949
assign 1 879 2950
addValue 1 879 2950
assign 1 879 2951
toString 0 879 2951
assign 1 879 2952
addValue 1 879 2952
assign 1 879 2953
new 0 879 2953
addValue 1 879 2954
assign 1 0 2956
assign 1 883 2959
sizeGet 0 883 2959
assign 1 883 2960
new 0 883 2960
assign 1 883 2961
greater 1 883 2961
assign 1 0 2963
assign 1 0 2966
assign 1 884 2970
new 0 884 2970
assign 1 886 2973
new 0 886 2973
assign 1 888 2975
iteratorGet 0 0 2975
assign 1 888 2978
hasNextGet 0 888 2978
assign 1 888 2980
nextGet 0 888 2980
assign 1 889 2981
new 0 889 2981
assign 1 891 2983
new 0 891 2983
assign 1 891 2984
add 1 891 2984
assign 1 891 2985
nameGet 0 891 2985
assign 1 891 2986
add 1 891 2986
assign 1 892 2987
new 0 892 2987
assign 1 892 2988
addValue 1 892 2988
assign 1 892 2989
addValue 1 892 2989
assign 1 892 2990
new 0 892 2990
assign 1 892 2991
addValue 1 892 2991
addValue 1 892 2992
assign 1 894 2994
new 0 894 2994
assign 1 894 2995
addValue 1 894 2995
assign 1 894 2996
nameGet 0 894 2996
assign 1 894 2997
addValue 1 894 2997
assign 1 894 2998
new 0 894 2998
addValue 1 894 2999
assign 1 895 3000
new 0 895 3000
assign 1 896 3001
argSynsGet 0 896 3001
assign 1 896 3002
iteratorGet 0 0 3002
assign 1 896 3005
hasNextGet 0 896 3005
assign 1 896 3007
nextGet 0 896 3007
assign 1 897 3008
new 0 897 3008
assign 1 897 3009
greater 1 897 3009
assign 1 898 3011
isTypedGet 0 898 3011
assign 1 898 3013
namepathGet 0 898 3013
assign 1 898 3014
notEquals 1 898 3014
assign 1 0 3016
assign 1 0 3019
assign 1 0 3023
assign 1 899 3026
namepathGet 0 899 3026
assign 1 899 3027
getClassConfig 1 899 3027
assign 1 899 3028
formCast 1 899 3028
assign 1 899 3029
new 0 899 3029
assign 1 899 3030
add 1 899 3030
assign 1 901 3033
new 0 901 3033
assign 1 903 3035
new 0 903 3035
assign 1 903 3036
greater 1 903 3036
assign 1 904 3038
new 0 904 3038
assign 1 906 3041
new 0 906 3041
assign 1 908 3043
lesser 1 908 3043
assign 1 909 3045
new 0 909 3045
assign 1 909 3046
new 0 909 3046
assign 1 909 3047
subtract 1 909 3047
assign 1 909 3048
add 1 909 3048
assign 1 911 3051
new 0 911 3051
assign 1 911 3052
subtract 1 911 3052
assign 1 911 3053
add 1 911 3053
assign 1 911 3054
new 0 911 3054
assign 1 911 3055
add 1 911 3055
assign 1 913 3057
addValue 1 913 3057
assign 1 913 3058
addValue 1 913 3058
addValue 1 913 3059
assign 1 915 3061
increment 0 915 3061
assign 1 917 3067
new 0 917 3067
assign 1 917 3068
addValue 1 917 3068
addValue 1 917 3069
assign 1 920 3071
new 0 920 3071
assign 1 920 3072
addValue 1 920 3072
addValue 1 920 3073
addValue 1 923 3075
assign 1 926 3082
new 0 926 3082
assign 1 926 3083
addValue 1 926 3083
addValue 1 926 3084
assign 1 929 3091
new 0 929 3091
assign 1 929 3092
addValue 1 929 3092
addValue 1 929 3093
assign 1 930 3094
new 0 930 3094
assign 1 930 3095
superNameGet 0 930 3095
assign 1 930 3096
add 1 930 3096
assign 1 930 3097
new 0 930 3097
assign 1 930 3098
add 1 930 3098
assign 1 930 3099
addValue 1 930 3099
assign 1 930 3100
addValue 1 930 3100
assign 1 930 3101
new 0 930 3101
assign 1 930 3102
addValue 1 930 3102
assign 1 930 3103
addValue 1 930 3103
assign 1 930 3104
new 0 930 3104
assign 1 930 3105
addValue 1 930 3105
addValue 1 930 3106
assign 1 931 3107
new 0 931 3107
assign 1 931 3108
addValue 1 931 3108
addValue 1 931 3109
buildClassInfo 0 934 3115
buildCreate 0 936 3116
buildInitial 0 938 3117
assign 1 946 3135
new 0 946 3135
assign 1 947 3136
new 0 947 3136
assign 1 947 3137
split 1 947 3137
assign 1 948 3138
new 0 948 3138
assign 1 949 3139
new 0 949 3139
assign 1 950 3140
iteratorGet 0 0 3140
assign 1 950 3143
hasNextGet 0 950 3143
assign 1 950 3145
nextGet 0 950 3145
assign 1 952 3147
new 0 952 3147
assign 1 953 3148
new 1 953 3148
assign 1 954 3149
new 0 954 3149
assign 1 955 3152
new 0 955 3152
assign 1 955 3153
equals 1 955 3153
assign 1 956 3155
new 0 956 3155
assign 1 957 3156
new 0 957 3156
assign 1 958 3159
new 0 958 3159
assign 1 958 3160
equals 1 958 3160
assign 1 959 3162
new 0 959 3162
assign 1 962 3171
new 0 962 3171
assign 1 962 3172
greater 1 962 3172
return 1 965 3175
assign 1 969 3201
overrideMtdDecGet 0 969 3201
assign 1 969 3202
addValue 1 969 3202
assign 1 969 3203
getClassConfig 1 969 3203
assign 1 969 3204
libNameGet 0 969 3204
assign 1 969 3205
relEmitName 1 969 3205
assign 1 969 3206
addValue 1 969 3206
assign 1 969 3207
new 0 969 3207
assign 1 969 3208
addValue 1 969 3208
assign 1 969 3209
addValue 1 969 3209
assign 1 969 3210
new 0 969 3210
assign 1 969 3211
addValue 1 969 3211
addValue 1 969 3212
assign 1 970 3213
new 0 970 3213
assign 1 970 3214
addValue 1 970 3214
assign 1 970 3215
heldGet 0 970 3215
assign 1 970 3216
namepathGet 0 970 3216
assign 1 970 3217
getClassConfig 1 970 3217
assign 1 970 3218
libNameGet 0 970 3218
assign 1 970 3219
relEmitName 1 970 3219
assign 1 970 3220
addValue 1 970 3220
assign 1 970 3221
new 0 970 3221
assign 1 970 3222
addValue 1 970 3222
addValue 1 970 3223
assign 1 972 3224
new 0 972 3224
assign 1 972 3225
addValue 1 972 3225
addValue 1 972 3226
assign 1 976 3273
getClassConfig 1 976 3273
assign 1 976 3274
libNameGet 0 976 3274
assign 1 976 3275
relEmitName 1 976 3275
assign 1 977 3276
emitNameGet 0 977 3276
assign 1 978 3277
heldGet 0 978 3277
assign 1 978 3278
namepathGet 0 978 3278
assign 1 978 3279
getClassConfig 1 978 3279
assign 1 979 3280
getInitialInst 1 979 3280
assign 1 981 3281
overrideMtdDecGet 0 981 3281
assign 1 981 3282
addValue 1 981 3282
assign 1 981 3283
new 0 981 3283
assign 1 981 3284
addValue 1 981 3284
assign 1 981 3285
addValue 1 981 3285
assign 1 981 3286
new 0 981 3286
assign 1 981 3287
addValue 1 981 3287
assign 1 981 3288
addValue 1 981 3288
assign 1 981 3289
new 0 981 3289
assign 1 981 3290
addValue 1 981 3290
addValue 1 981 3291
assign 1 983 3292
notEquals 1 983 3292
assign 1 984 3294
formCast 1 984 3294
assign 1 986 3297
new 0 986 3297
assign 1 989 3299
addValue 1 989 3299
assign 1 989 3300
new 0 989 3300
assign 1 989 3301
addValue 1 989 3301
assign 1 989 3302
addValue 1 989 3302
assign 1 989 3303
new 0 989 3303
assign 1 989 3304
addValue 1 989 3304
addValue 1 989 3305
assign 1 991 3306
new 0 991 3306
assign 1 991 3307
addValue 1 991 3307
addValue 1 991 3308
assign 1 994 3309
overrideMtdDecGet 0 994 3309
assign 1 994 3310
addValue 1 994 3310
assign 1 994 3311
addValue 1 994 3311
assign 1 994 3312
new 0 994 3312
assign 1 994 3313
addValue 1 994 3313
assign 1 994 3314
addValue 1 994 3314
assign 1 994 3315
new 0 994 3315
assign 1 994 3316
addValue 1 994 3316
addValue 1 994 3317
assign 1 996 3318
new 0 996 3318
assign 1 996 3319
addValue 1 996 3319
assign 1 996 3320
addValue 1 996 3320
assign 1 996 3321
new 0 996 3321
assign 1 996 3322
addValue 1 996 3322
addValue 1 996 3323
assign 1 998 3324
new 0 998 3324
assign 1 998 3325
addValue 1 998 3325
addValue 1 998 3326
assign 1 1003 3335
new 0 1003 3335
assign 1 1003 3336
heldGet 0 1003 3336
assign 1 1003 3337
namepathGet 0 1003 3337
assign 1 1003 3338
toString 0 1003 3338
buildClassInfo 2 1003 3339
assign 1 1004 3340
new 0 1004 3340
buildClassInfo 2 1004 3341
assign 1 1009 3358
new 0 1009 3358
assign 1 1009 3359
add 1 1009 3359
assign 1 1011 3360
new 0 1011 3360
lstringStart 2 1012 3361
assign 1 1014 3362
sizeGet 0 1014 3362
assign 1 1015 3363
new 0 1015 3363
assign 1 1016 3364
new 0 1016 3364
assign 1 1017 3365
new 0 1017 3365
assign 1 1017 3366
new 1 1017 3366
assign 1 1018 3369
lesser 1 1018 3369
assign 1 1019 3371
new 0 1019 3371
assign 1 1019 3372
greater 1 1019 3372
assign 1 1020 3374
new 0 1020 3374
assign 1 1020 3375
once 0 1020 3375
addValue 1 1020 3376
lstringByte 5 1022 3378
incrementValue 0 1023 3379
lstringEnd 1 1025 3385
addValue 1 1027 3386
buildClassInfoMethod 1 1029 3387
assign 1 1034 3408
overrideMtdDecGet 0 1034 3408
assign 1 1034 3409
addValue 1 1034 3409
assign 1 1034 3410
new 0 1034 3410
assign 1 1034 3411
addValue 1 1034 3411
assign 1 1034 3412
addValue 1 1034 3412
assign 1 1034 3413
new 0 1034 3413
assign 1 1034 3414
addValue 1 1034 3414
assign 1 1034 3415
addValue 1 1034 3415
assign 1 1034 3416
new 0 1034 3416
assign 1 1034 3417
addValue 1 1034 3417
addValue 1 1034 3418
assign 1 1035 3419
new 0 1035 3419
assign 1 1035 3420
addValue 1 1035 3420
assign 1 1035 3421
addValue 1 1035 3421
assign 1 1035 3422
new 0 1035 3422
assign 1 1035 3423
addValue 1 1035 3423
addValue 1 1035 3424
assign 1 1037 3425
new 0 1037 3425
assign 1 1037 3426
addValue 1 1037 3426
addValue 1 1037 3427
assign 1 1042 3446
new 0 1042 3446
assign 1 1044 3447
namepathGet 0 1044 3447
assign 1 1044 3448
equals 1 1044 3448
assign 1 1045 3450
emitNameGet 0 1045 3450
assign 1 1045 3451
new 0 1045 3451
assign 1 1045 3452
baseSpropDec 2 1045 3452
assign 1 1045 3453
addValue 1 1045 3453
assign 1 1045 3454
new 0 1045 3454
assign 1 1045 3455
addValue 1 1045 3455
addValue 1 1045 3456
assign 1 1047 3459
emitNameGet 0 1047 3459
assign 1 1047 3460
new 0 1047 3460
assign 1 1047 3461
overrideSpropDec 2 1047 3461
assign 1 1047 3462
addValue 1 1047 3462
assign 1 1047 3463
new 0 1047 3463
assign 1 1047 3464
addValue 1 1047 3464
addValue 1 1047 3465
return 1 1050 3467
assign 1 1054 3503
def 1 1054 3508
assign 1 1055 3509
libNameGet 0 1055 3509
assign 1 1055 3510
relEmitName 1 1055 3510
assign 1 1055 3511
extend 1 1055 3511
assign 1 1057 3514
new 0 1057 3514
assign 1 1057 3515
extend 1 1057 3515
assign 1 1059 3517
new 0 1059 3517
assign 1 1059 3518
addValue 1 1059 3518
assign 1 1059 3519
new 0 1059 3519
assign 1 1059 3520
addValue 1 1059 3520
assign 1 1059 3521
addValue 1 1059 3521
assign 1 1060 3522
klassDecGet 0 1060 3522
assign 1 1060 3523
addValue 1 1060 3523
assign 1 1060 3524
emitNameGet 0 1060 3524
assign 1 1060 3525
addValue 1 1060 3525
assign 1 1060 3526
addValue 1 1060 3526
assign 1 1060 3527
new 0 1060 3527
assign 1 1060 3528
addValue 1 1060 3528
addValue 1 1060 3529
assign 1 1061 3530
new 0 1061 3530
assign 1 1061 3531
addValue 1 1061 3531
assign 1 1061 3532
emitNameGet 0 1061 3532
assign 1 1061 3533
addValue 1 1061 3533
assign 1 1061 3534
new 0 1061 3534
addValue 1 1061 3535
assign 1 1062 3536
new 0 1062 3536
assign 1 1062 3537
addValue 1 1062 3537
addValue 1 1062 3538
assign 1 1063 3539
new 0 1063 3539
assign 1 1063 3540
emitting 1 1063 3540
assign 1 1064 3542
new 0 1064 3542
assign 1 1064 3543
addValue 1 1064 3543
assign 1 1064 3544
emitNameGet 0 1064 3544
assign 1 1064 3545
addValue 1 1064 3545
assign 1 1064 3546
new 0 1064 3546
addValue 1 1064 3547
assign 1 1065 3548
new 0 1065 3548
assign 1 1065 3549
addValue 1 1065 3549
addValue 1 1065 3550
return 1 1067 3552
assign 1 1072 3557
new 0 1072 3557
assign 1 1072 3558
addValue 1 1072 3558
return 1 1072 3559
assign 1 1076 3567
new 0 1076 3567
assign 1 1076 3568
add 1 1076 3568
assign 1 1076 3569
new 0 1076 3569
assign 1 1076 3570
add 1 1076 3570
assign 1 1076 3571
add 1 1076 3571
return 1 1076 3572
assign 1 1080 3576
new 0 1080 3576
return 1 1080 3577
assign 1 1085 3581
new 0 1085 3581
return 1 1085 3582
assign 1 1089 3594
new 0 1089 3594
assign 1 1090 3595
def 1 1090 3600
assign 1 1090 3601
nlcGet 0 1090 3601
assign 1 1090 3602
def 1 1090 3607
assign 1 0 3608
assign 1 0 3611
assign 1 0 3615
assign 1 1091 3618
new 0 1091 3618
assign 1 1091 3619
addValue 1 1091 3619
assign 1 1091 3620
nlcGet 0 1091 3620
assign 1 1091 3621
toString 0 1091 3621
addValue 1 1091 3622
return 1 1093 3624
assign 1 1097 3651
containerGet 0 1097 3651
assign 1 1097 3652
def 1 1097 3657
assign 1 1098 3658
containerGet 0 1098 3658
assign 1 1098 3659
typenameGet 0 1098 3659
assign 1 1099 3660
METHODGet 0 1099 3660
assign 1 1099 3661
notEquals 1 1099 3661
assign 1 1099 3663
CLASSGet 0 1099 3663
assign 1 1099 3664
notEquals 1 1099 3664
assign 1 0 3666
assign 1 0 3669
assign 1 0 3673
assign 1 1099 3676
EXPRGet 0 1099 3676
assign 1 1099 3677
notEquals 1 1099 3677
assign 1 0 3679
assign 1 0 3682
assign 1 0 3686
assign 1 1099 3689
PROPERTIESGet 0 1099 3689
assign 1 1099 3690
notEquals 1 1099 3690
assign 1 0 3692
assign 1 0 3695
assign 1 0 3699
assign 1 1099 3702
CATCHGet 0 1099 3702
assign 1 1099 3703
notEquals 1 1099 3703
assign 1 0 3705
assign 1 0 3708
assign 1 0 3712
assign 1 1101 3715
new 0 1101 3715
assign 1 1101 3716
addValue 1 1101 3716
assign 1 1101 3717
getTraceInfo 1 1101 3717
assign 1 1101 3718
addValue 1 1101 3718
assign 1 1101 3719
new 0 1101 3719
assign 1 1101 3720
addValue 1 1101 3720
addValue 1 1101 3721
assign 1 1110 3785
containerGet 0 1110 3785
assign 1 1110 3786
def 1 1110 3791
assign 1 1110 3792
containerGet 0 1110 3792
assign 1 1110 3793
containerGet 0 1110 3793
assign 1 1110 3794
def 1 1110 3799
assign 1 0 3800
assign 1 0 3803
assign 1 0 3807
assign 1 1111 3810
containerGet 0 1111 3810
assign 1 1111 3811
containerGet 0 1111 3811
assign 1 1112 3812
typenameGet 0 1112 3812
assign 1 1113 3813
METHODGet 0 1113 3813
assign 1 1113 3814
equals 1 1113 3814
assign 1 1114 3816
def 1 1114 3821
assign 1 1115 3822
undef 1 1115 3827
assign 1 0 3828
assign 1 1115 3831
heldGet 0 1115 3831
assign 1 1115 3832
orgNameGet 0 1115 3832
assign 1 1115 3833
new 0 1115 3833
assign 1 1115 3834
notEquals 1 1115 3834
assign 1 0 3836
assign 1 0 3839
assign 1 1118 3843
new 0 1118 3843
assign 1 1118 3844
addValue 1 1118 3844
addValue 1 1118 3845
assign 1 1121 3847
new 0 1121 3847
assign 1 1121 3848
greater 1 1121 3848
assign 1 1122 3850
libNameGet 0 1122 3850
assign 1 1122 3851
relEmitName 1 1122 3851
assign 1 1122 3852
addValue 1 1122 3852
assign 1 1122 3853
new 0 1122 3853
assign 1 1122 3854
addValue 1 1122 3854
assign 1 1122 3855
libNameGet 0 1122 3855
assign 1 1122 3856
relEmitName 1 1122 3856
assign 1 1122 3857
addValue 1 1122 3857
assign 1 1122 3858
new 0 1122 3858
assign 1 1122 3859
addValue 1 1122 3859
assign 1 1122 3860
toString 0 1122 3860
assign 1 1122 3861
addValue 1 1122 3861
assign 1 1122 3862
new 0 1122 3862
assign 1 1122 3863
addValue 1 1122 3863
addValue 1 1122 3864
assign 1 1125 3866
countLines 2 1125 3866
addValue 1 1126 3867
assign 1 1127 3868
assign 1 1128 3869
sizeGet 0 1128 3869
assign 1 1132 3870
iteratorGet 0 0 3870
assign 1 1132 3873
hasNextGet 0 1132 3873
assign 1 1132 3875
nextGet 0 1132 3875
assign 1 1133 3876
nlecGet 0 1133 3876
addValue 1 1133 3877
addValue 1 1135 3883
assign 1 1136 3884
new 0 1136 3884
lengthSet 1 1136 3885
addValue 1 1138 3886
clear 0 1139 3887
assign 1 1140 3888
new 0 1140 3888
assign 1 1141 3889
new 0 1141 3889
assign 1 1144 3890
new 0 1144 3890
assign 1 1145 3891
assign 1 1146 3892
new 0 1146 3892
assign 1 1149 3893
new 0 1149 3893
assign 1 1149 3894
addValue 1 1149 3894
addValue 1 1149 3895
assign 1 1150 3896
assign 1 1151 3897
assign 1 1153 3901
EXPRGet 0 1153 3901
assign 1 1153 3902
notEquals 1 1153 3902
assign 1 1153 3904
PROPERTIESGet 0 1153 3904
assign 1 1153 3905
notEquals 1 1153 3905
assign 1 0 3907
assign 1 0 3910
assign 1 0 3914
assign 1 1153 3917
CLASSGet 0 1153 3917
assign 1 1153 3918
notEquals 1 1153 3918
assign 1 0 3920
assign 1 0 3923
assign 1 0 3927
assign 1 1155 3930
new 0 1155 3930
assign 1 1155 3931
addValue 1 1155 3931
assign 1 1155 3932
getTraceInfo 1 1155 3932
assign 1 1155 3933
addValue 1 1155 3933
assign 1 1155 3934
new 0 1155 3934
assign 1 1155 3935
addValue 1 1155 3935
addValue 1 1155 3936
assign 1 1161 3945
new 0 1161 3945
assign 1 1161 3946
countLines 2 1161 3946
return 1 1161 3947
assign 1 1165 3959
new 0 1165 3959
assign 1 1166 3960
new 0 1166 3960
assign 1 1166 3961
new 0 1166 3961
assign 1 1166 3962
getInt 2 1166 3962
assign 1 1167 3963
new 0 1167 3963
assign 1 1168 3964
sizeGet 0 1168 3964
assign 1 1169 3965
assign 1 1169 3968
lesser 1 1169 3968
getInt 2 1170 3970
assign 1 1171 3971
equals 1 1171 3971
incrementValue 0 1172 3973
incrementValue 0 1169 3975
return 1 1175 3981
assign 1 1179 4041
containedGet 0 1179 4041
assign 1 1179 4042
firstGet 0 1179 4042
assign 1 1179 4043
containedGet 0 1179 4043
assign 1 1179 4044
firstGet 0 1179 4044
assign 1 1179 4045
formTarg 1 1179 4045
assign 1 1180 4046
containedGet 0 1180 4046
assign 1 1180 4047
firstGet 0 1180 4047
assign 1 1180 4048
containedGet 0 1180 4048
assign 1 1180 4049
firstGet 0 1180 4049
assign 1 1180 4050
heldGet 0 1180 4050
assign 1 1180 4051
isTypedGet 0 1180 4051
assign 1 1180 4052
not 0 1180 4052
assign 1 0 4054
assign 1 1180 4057
containedGet 0 1180 4057
assign 1 1180 4058
firstGet 0 1180 4058
assign 1 1180 4059
containedGet 0 1180 4059
assign 1 1180 4060
firstGet 0 1180 4060
assign 1 1180 4061
heldGet 0 1180 4061
assign 1 1180 4062
namepathGet 0 1180 4062
assign 1 1180 4063
notEquals 1 1180 4063
assign 1 0 4065
assign 1 0 4068
assign 1 1181 4072
new 0 1181 4072
assign 1 1183 4075
new 0 1183 4075
assign 1 1185 4077
heldGet 0 1185 4077
assign 1 1185 4078
def 1 1185 4083
assign 1 1185 4084
heldGet 0 1185 4084
assign 1 1185 4085
new 0 1185 4085
assign 1 1185 4086
equals 1 1185 4086
assign 1 0 4088
assign 1 0 4091
assign 1 0 4095
assign 1 1186 4098
new 0 1186 4098
assign 1 1188 4101
new 0 1188 4101
assign 1 1190 4103
new 0 1190 4103
assign 1 1192 4105
new 0 1192 4105
addValue 1 1192 4106
assign 1 1196 4109
addValue 1 1196 4109
assign 1 1196 4110
new 0 1196 4110
addValue 1 1196 4111
assign 1 1201 4114
addValue 1 1201 4114
assign 1 1201 4115
new 0 1201 4115
assign 1 1201 4116
addValue 1 1201 4116
assign 1 1201 4117
addValue 1 1201 4117
assign 1 1201 4118
addValue 1 1201 4118
assign 1 1201 4119
libNameGet 0 1201 4119
assign 1 1201 4120
relEmitName 1 1201 4120
assign 1 1201 4121
addValue 1 1201 4121
assign 1 1201 4122
new 0 1201 4122
addValue 1 1201 4123
assign 1 1202 4124
new 0 1202 4124
assign 1 1202 4125
emitting 1 1202 4125
assign 1 1202 4126
not 0 1202 4126
assign 1 1203 4128
new 0 1203 4128
assign 1 1203 4129
addValue 1 1203 4129
assign 1 1203 4130
formCast 1 1203 4130
addValue 1 1203 4131
addValue 1 1205 4133
assign 1 1206 4134
new 0 1206 4134
assign 1 1206 4135
emitting 1 1206 4135
assign 1 1206 4136
not 0 1206 4136
assign 1 1207 4138
new 0 1207 4138
addValue 1 1207 4139
assign 1 1209 4141
new 0 1209 4141
addValue 1 1209 4142
assign 1 1212 4145
new 0 1212 4145
addValue 1 1212 4146
assign 1 1214 4148
new 0 1214 4148
assign 1 1214 4149
addValue 1 1214 4149
assign 1 1214 4150
addValue 1 1214 4150
assign 1 1214 4151
new 0 1214 4151
addValue 1 1214 4152
assign 1 1219 4174
containedGet 0 1219 4174
assign 1 1219 4175
firstGet 0 1219 4175
assign 1 1219 4176
containedGet 0 1219 4176
assign 1 1219 4177
firstGet 0 1219 4177
assign 1 1219 4178
formTarg 1 1219 4178
assign 1 1220 4179
heldGet 0 1220 4179
assign 1 1220 4180
def 1 1220 4185
assign 1 1220 4186
heldGet 0 1220 4186
assign 1 1220 4187
new 0 1220 4187
assign 1 1220 4188
equals 1 1220 4188
assign 1 0 4190
assign 1 0 4193
assign 1 0 4197
assign 1 1221 4200
assign 1 1223 4203
assign 1 1225 4205
new 0 1225 4205
assign 1 1225 4206
addValue 1 1225 4206
assign 1 1225 4207
addValue 1 1225 4207
assign 1 1225 4208
addValue 1 1225 4208
assign 1 1225 4209
addValue 1 1225 4209
assign 1 1225 4210
new 0 1225 4210
addValue 1 1225 4211
assign 1 1232 4223
finalAssignTo 2 1232 4223
assign 1 1232 4224
add 1 1232 4224
assign 1 1232 4225
new 0 1232 4225
assign 1 1232 4226
add 1 1232 4226
assign 1 1232 4227
add 1 1232 4227
return 1 1232 4228
assign 1 1237 4258
typenameGet 0 1237 4258
assign 1 1237 4259
NULLGet 0 1237 4259
assign 1 1237 4260
equals 1 1237 4260
assign 1 1238 4262
new 0 1238 4262
assign 1 1238 4263
new 1 1238 4263
throw 1 1238 4264
assign 1 1240 4266
heldGet 0 1240 4266
assign 1 1240 4267
nameGet 0 1240 4267
assign 1 1240 4268
new 0 1240 4268
assign 1 1240 4269
equals 1 1240 4269
assign 1 1241 4271
new 0 1241 4271
assign 1 1241 4272
new 1 1241 4272
throw 1 1241 4273
assign 1 1243 4275
heldGet 0 1243 4275
assign 1 1243 4276
nameGet 0 1243 4276
assign 1 1243 4277
new 0 1243 4277
assign 1 1243 4278
equals 1 1243 4278
assign 1 1244 4280
new 0 1244 4280
assign 1 1244 4281
new 1 1244 4281
throw 1 1244 4282
assign 1 1246 4284
new 0 1246 4284
assign 1 1247 4285
def 1 1247 4290
assign 1 1248 4291
getClassConfig 1 1248 4291
assign 1 1248 4292
formCast 1 1248 4292
assign 1 1248 4293
new 0 1248 4293
assign 1 1248 4294
add 1 1248 4294
assign 1 1250 4296
heldGet 0 1250 4296
assign 1 1250 4297
nameForVar 1 1250 4297
assign 1 1250 4298
new 0 1250 4298
assign 1 1250 4299
add 1 1250 4299
assign 1 1250 4300
add 1 1250 4300
return 1 1250 4301
assign 1 1254 4305
new 0 1254 4305
return 1 1254 4306
assign 1 1258 4315
new 0 1258 4315
assign 1 1258 4316
libNameGet 0 1258 4316
assign 1 1258 4317
relEmitName 1 1258 4317
assign 1 1258 4318
add 1 1258 4318
assign 1 1258 4319
new 0 1258 4319
assign 1 1258 4320
add 1 1258 4320
return 1 1258 4321
assign 1 1262 4331
new 0 1262 4331
assign 1 1262 4332
addValue 1 1262 4332
assign 1 1262 4333
secondGet 0 1262 4333
assign 1 1262 4334
formTarg 1 1262 4334
assign 1 1262 4335
addValue 1 1262 4335
assign 1 1262 4336
new 0 1262 4336
assign 1 1262 4337
addValue 1 1262 4337
addValue 1 1262 4338
assign 1 1266 4344
new 0 1266 4344
assign 1 1266 4345
add 1 1266 4345
return 1 1266 4346
assign 1 1271 4923
heldGet 0 1271 4923
assign 1 1271 4924
nameGet 0 1271 4924
put 1 1271 4925
assign 1 1273 4926
addValue 1 1275 4927
assign 1 1279 4928
countLines 2 1279 4928
assign 1 1280 4929
add 1 1280 4929
assign 1 1281 4930
sizeGet 0 1281 4930
nlecSet 1 1283 4931
assign 1 1286 4932
heldGet 0 1286 4932
assign 1 1286 4933
orgNameGet 0 1286 4933
assign 1 1286 4934
new 0 1286 4934
assign 1 1286 4935
equals 1 1286 4935
assign 1 1286 4937
containedGet 0 1286 4937
assign 1 1286 4938
lengthGet 0 1286 4938
assign 1 1286 4939
new 0 1286 4939
assign 1 1286 4940
notEquals 1 1286 4940
assign 1 0 4942
assign 1 0 4945
assign 1 0 4949
assign 1 1287 4952
new 0 1287 4952
assign 1 1287 4953
containedGet 0 1287 4953
assign 1 1287 4954
lengthGet 0 1287 4954
assign 1 1287 4955
toString 0 1287 4955
assign 1 1287 4956
add 1 1287 4956
assign 1 1288 4957
new 0 1288 4957
assign 1 1288 4960
containedGet 0 1288 4960
assign 1 1288 4961
lengthGet 0 1288 4961
assign 1 1288 4962
lesser 1 1288 4962
assign 1 1289 4964
new 0 1289 4964
assign 1 1289 4965
add 1 1289 4965
assign 1 1289 4966
add 1 1289 4966
assign 1 1289 4967
new 0 1289 4967
assign 1 1289 4968
add 1 1289 4968
assign 1 1289 4969
containedGet 0 1289 4969
assign 1 1289 4970
get 1 1289 4970
assign 1 1289 4971
add 1 1289 4971
assign 1 1288 4972
increment 0 1288 4972
assign 1 1291 4978
new 2 1291 4978
throw 1 1291 4979
assign 1 1292 4982
heldGet 0 1292 4982
assign 1 1292 4983
orgNameGet 0 1292 4983
assign 1 1292 4984
new 0 1292 4984
assign 1 1292 4985
equals 1 1292 4985
assign 1 1292 4987
containedGet 0 1292 4987
assign 1 1292 4988
firstGet 0 1292 4988
assign 1 1292 4989
heldGet 0 1292 4989
assign 1 1292 4990
nameGet 0 1292 4990
assign 1 1292 4991
new 0 1292 4991
assign 1 1292 4992
equals 1 1292 4992
assign 1 0 4994
assign 1 0 4997
assign 1 0 5001
assign 1 1293 5004
new 0 1293 5004
assign 1 1293 5005
new 2 1293 5005
throw 1 1293 5006
assign 1 1294 5009
heldGet 0 1294 5009
assign 1 1294 5010
orgNameGet 0 1294 5010
assign 1 1294 5011
new 0 1294 5011
assign 1 1294 5012
equals 1 1294 5012
acceptThrow 1 1295 5014
return 1 1296 5015
assign 1 1297 5018
heldGet 0 1297 5018
assign 1 1297 5019
orgNameGet 0 1297 5019
assign 1 1297 5020
new 0 1297 5020
assign 1 1297 5021
equals 1 1297 5021
assign 1 1301 5023
heldGet 0 1301 5023
assign 1 1301 5024
checkTypesGet 0 1301 5024
assign 1 1302 5026
containedGet 0 1302 5026
assign 1 1302 5027
firstGet 0 1302 5027
assign 1 1302 5028
heldGet 0 1302 5028
assign 1 1302 5029
namepathGet 0 1302 5029
assign 1 1304 5031
secondGet 0 1304 5031
assign 1 1304 5032
typenameGet 0 1304 5032
assign 1 1304 5033
VARGet 0 1304 5033
assign 1 1304 5034
equals 1 1304 5034
assign 1 1306 5036
containedGet 0 1306 5036
assign 1 1306 5037
firstGet 0 1306 5037
assign 1 1306 5038
secondGet 0 1306 5038
assign 1 1306 5039
formTarg 1 1306 5039
assign 1 1306 5040
finalAssign 3 1306 5040
addValue 1 1306 5041
assign 1 1307 5044
secondGet 0 1307 5044
assign 1 1307 5045
typenameGet 0 1307 5045
assign 1 1307 5046
NULLGet 0 1307 5046
assign 1 1307 5047
equals 1 1307 5047
assign 1 1308 5049
containedGet 0 1308 5049
assign 1 1308 5050
firstGet 0 1308 5050
assign 1 1308 5051
new 0 1308 5051
assign 1 1308 5052
finalAssign 3 1308 5052
addValue 1 1308 5053
assign 1 1309 5056
secondGet 0 1309 5056
assign 1 1309 5057
typenameGet 0 1309 5057
assign 1 1309 5058
TRUEGet 0 1309 5058
assign 1 1309 5059
equals 1 1309 5059
assign 1 1310 5061
containedGet 0 1310 5061
assign 1 1310 5062
firstGet 0 1310 5062
assign 1 1310 5063
finalAssign 3 1310 5063
addValue 1 1310 5064
assign 1 1311 5067
secondGet 0 1311 5067
assign 1 1311 5068
typenameGet 0 1311 5068
assign 1 1311 5069
FALSEGet 0 1311 5069
assign 1 1311 5070
equals 1 1311 5070
assign 1 1312 5072
containedGet 0 1312 5072
assign 1 1312 5073
firstGet 0 1312 5073
assign 1 1312 5074
finalAssign 3 1312 5074
addValue 1 1312 5075
assign 1 1313 5078
secondGet 0 1313 5078
assign 1 1313 5079
heldGet 0 1313 5079
assign 1 1313 5080
nameGet 0 1313 5080
assign 1 1313 5081
new 0 1313 5081
assign 1 1313 5082
equals 1 1313 5082
assign 1 0 5084
assign 1 1313 5087
secondGet 0 1313 5087
assign 1 1313 5088
heldGet 0 1313 5088
assign 1 1313 5089
nameGet 0 1313 5089
assign 1 1313 5090
new 0 1313 5090
assign 1 1313 5091
equals 1 1313 5091
assign 1 0 5093
assign 1 0 5096
assign 1 0 5100
assign 1 1314 5103
secondGet 0 1314 5103
assign 1 1314 5104
heldGet 0 1314 5104
assign 1 1314 5105
nameGet 0 1314 5105
assign 1 1314 5106
new 0 1314 5106
assign 1 1314 5107
equals 1 1314 5107
assign 1 0 5109
assign 1 0 5112
assign 1 0 5116
assign 1 1314 5119
secondGet 0 1314 5119
assign 1 1314 5120
heldGet 0 1314 5120
assign 1 1314 5121
nameGet 0 1314 5121
assign 1 1314 5122
new 0 1314 5122
assign 1 1314 5123
equals 1 1314 5123
assign 1 0 5125
assign 1 0 5128
assign 1 1321 5132
heldGet 0 1321 5132
assign 1 1321 5133
checkTypesGet 0 1321 5133
assign 1 1322 5135
containedGet 0 1322 5135
assign 1 1322 5136
firstGet 0 1322 5136
assign 1 1322 5137
heldGet 0 1322 5137
assign 1 1322 5138
namepathGet 0 1322 5138
assign 1 1322 5139
toString 0 1322 5139
assign 1 1322 5140
new 0 1322 5140
assign 1 1322 5141
notEquals 1 1322 5141
assign 1 1323 5143
new 0 1323 5143
assign 1 1323 5144
new 2 1323 5144
throw 1 1323 5145
assign 1 1326 5148
secondGet 0 1326 5148
assign 1 1326 5149
heldGet 0 1326 5149
assign 1 1326 5150
nameGet 0 1326 5150
assign 1 1326 5151
new 0 1326 5151
assign 1 1326 5152
begins 1 1326 5152
assign 1 1327 5154
assign 1 1328 5155
assign 1 1330 5158
assign 1 1331 5159
assign 1 1333 5161
new 0 1333 5161
assign 1 1333 5162
addValue 1 1333 5162
assign 1 1333 5163
secondGet 0 1333 5163
assign 1 1333 5164
secondGet 0 1333 5164
assign 1 1333 5165
formTarg 1 1333 5165
assign 1 1333 5166
addValue 1 1333 5166
assign 1 1333 5167
new 0 1333 5167
assign 1 1333 5168
addValue 1 1333 5168
addValue 1 1333 5169
assign 1 1334 5170
containedGet 0 1334 5170
assign 1 1334 5171
firstGet 0 1334 5171
assign 1 1334 5172
finalAssign 3 1334 5172
addValue 1 1334 5173
assign 1 1335 5174
new 0 1335 5174
assign 1 1335 5175
addValue 1 1335 5175
addValue 1 1335 5176
assign 1 1336 5177
containedGet 0 1336 5177
assign 1 1336 5178
firstGet 0 1336 5178
assign 1 1336 5179
finalAssign 3 1336 5179
addValue 1 1336 5180
assign 1 1337 5181
new 0 1337 5181
assign 1 1337 5182
addValue 1 1337 5182
addValue 1 1337 5183
return 1 1339 5189
assign 1 1340 5192
heldGet 0 1340 5192
assign 1 1340 5193
orgNameGet 0 1340 5193
assign 1 1340 5194
new 0 1340 5194
assign 1 1340 5195
equals 1 1340 5195
assign 1 1342 5197
new 0 1342 5197
assign 1 1343 5198
heldGet 0 1343 5198
assign 1 1343 5199
checkTypesGet 0 1343 5199
assign 1 1344 5201
formCast 1 1344 5201
assign 1 1344 5202
new 0 1344 5202
assign 1 1344 5203
add 1 1344 5203
assign 1 1346 5205
new 0 1346 5205
assign 1 1346 5206
addValue 1 1346 5206
assign 1 1346 5207
addValue 1 1346 5207
assign 1 1346 5208
secondGet 0 1346 5208
assign 1 1346 5209
formTarg 1 1346 5209
assign 1 1346 5210
addValue 1 1346 5210
assign 1 1346 5211
new 0 1346 5211
assign 1 1346 5212
addValue 1 1346 5212
addValue 1 1346 5213
return 1 1347 5214
assign 1 1348 5217
heldGet 0 1348 5217
assign 1 1348 5218
nameGet 0 1348 5218
assign 1 1348 5219
new 0 1348 5219
assign 1 1348 5220
equals 1 1348 5220
assign 1 0 5222
assign 1 1348 5225
heldGet 0 1348 5225
assign 1 1348 5226
nameGet 0 1348 5226
assign 1 1348 5227
new 0 1348 5227
assign 1 1348 5228
equals 1 1348 5228
assign 1 0 5230
assign 1 0 5233
assign 1 0 5237
assign 1 1348 5240
heldGet 0 1348 5240
assign 1 1348 5241
nameGet 0 1348 5241
assign 1 1348 5242
new 0 1348 5242
assign 1 1348 5243
equals 1 1348 5243
assign 1 0 5245
assign 1 0 5248
assign 1 0 5252
assign 1 1348 5255
heldGet 0 1348 5255
assign 1 1348 5256
nameGet 0 1348 5256
assign 1 1348 5257
new 0 1348 5257
assign 1 1348 5258
equals 1 1348 5258
assign 1 0 5260
assign 1 0 5263
return 1 1350 5267
assign 1 1353 5274
heldGet 0 1353 5274
assign 1 1353 5275
nameGet 0 1353 5275
assign 1 1353 5276
heldGet 0 1353 5276
assign 1 1353 5277
orgNameGet 0 1353 5277
assign 1 1353 5278
new 0 1353 5278
assign 1 1353 5279
add 1 1353 5279
assign 1 1353 5280
heldGet 0 1353 5280
assign 1 1353 5281
numargsGet 0 1353 5281
assign 1 1353 5282
add 1 1353 5282
assign 1 1353 5283
notEquals 1 1353 5283
assign 1 1354 5285
new 0 1354 5285
assign 1 1354 5286
heldGet 0 1354 5286
assign 1 1354 5287
nameGet 0 1354 5287
assign 1 1354 5288
add 1 1354 5288
assign 1 1354 5289
new 0 1354 5289
assign 1 1354 5290
add 1 1354 5290
assign 1 1354 5291
heldGet 0 1354 5291
assign 1 1354 5292
orgNameGet 0 1354 5292
assign 1 1354 5293
add 1 1354 5293
assign 1 1354 5294
new 0 1354 5294
assign 1 1354 5295
add 1 1354 5295
assign 1 1354 5296
heldGet 0 1354 5296
assign 1 1354 5297
numargsGet 0 1354 5297
assign 1 1354 5298
add 1 1354 5298
assign 1 1354 5299
new 1 1354 5299
throw 1 1354 5300
assign 1 1357 5302
new 0 1357 5302
assign 1 1358 5303
new 0 1358 5303
assign 1 1359 5304
new 0 1359 5304
assign 1 1360 5305
new 0 1360 5305
assign 1 1362 5306
heldGet 0 1362 5306
assign 1 1362 5307
isConstructGet 0 1362 5307
assign 1 1363 5309
new 0 1363 5309
assign 1 1364 5310
heldGet 0 1364 5310
assign 1 1364 5311
newNpGet 0 1364 5311
assign 1 1364 5312
getClassConfig 1 1364 5312
assign 1 1365 5315
containedGet 0 1365 5315
assign 1 1365 5316
firstGet 0 1365 5316
assign 1 1365 5317
heldGet 0 1365 5317
assign 1 1365 5318
nameGet 0 1365 5318
assign 1 1365 5319
new 0 1365 5319
assign 1 1365 5320
equals 1 1365 5320
assign 1 1366 5322
new 0 1366 5322
assign 1 1367 5325
containedGet 0 1367 5325
assign 1 1367 5326
firstGet 0 1367 5326
assign 1 1367 5327
heldGet 0 1367 5327
assign 1 1367 5328
nameGet 0 1367 5328
assign 1 1367 5329
new 0 1367 5329
assign 1 1367 5330
equals 1 1367 5330
assign 1 1368 5332
new 0 1368 5332
assign 1 1369 5333
new 0 1369 5333
addValue 1 1370 5334
assign 1 1371 5335
heldGet 0 1371 5335
assign 1 1371 5336
new 0 1371 5336
superCallSet 1 1371 5337
assign 1 1376 5341
new 0 1376 5341
assign 1 1377 5342
new 0 1377 5342
assign 1 1379 5343
new 0 1379 5343
assign 1 1380 5344
containedGet 0 1380 5344
assign 1 1380 5345
iteratorGet 0 1380 5345
assign 1 1380 5348
hasNextGet 0 1380 5348
assign 1 1381 5350
heldGet 0 1381 5350
assign 1 1381 5351
argCastsGet 0 1381 5351
assign 1 1382 5352
nextGet 0 1382 5352
assign 1 1383 5353
new 0 1383 5353
assign 1 1383 5354
equals 1 1383 5354
assign 1 1385 5356
formTarg 1 1385 5356
assign 1 1386 5357
assign 1 1387 5358
heldGet 0 1387 5358
assign 1 1387 5359
isTypedGet 0 1387 5359
assign 1 1388 5361
new 0 1388 5361
assign 1 0 5366
assign 1 1391 5369
lesser 1 1391 5369
assign 1 0 5371
assign 1 0 5374
assign 1 0 5378
assign 1 1391 5381
useDynMethodsGet 0 1391 5381
assign 1 1391 5382
not 0 1391 5382
assign 1 0 5384
assign 1 0 5387
assign 1 1392 5391
new 0 1392 5391
assign 1 1392 5392
greater 1 1392 5392
assign 1 1393 5394
new 0 1393 5394
addValue 1 1393 5395
assign 1 1395 5397
lengthGet 0 1395 5397
assign 1 1395 5398
greater 1 1395 5398
assign 1 1395 5400
get 1 1395 5400
assign 1 1395 5401
def 1 1395 5406
assign 1 0 5407
assign 1 0 5410
assign 1 0 5414
assign 1 1396 5417
get 1 1396 5417
assign 1 1396 5418
getClassConfig 1 1396 5418
assign 1 1396 5419
formCast 1 1396 5419
assign 1 1396 5420
addValue 1 1396 5420
assign 1 1396 5421
new 0 1396 5421
addValue 1 1396 5422
assign 1 1398 5424
formTarg 1 1398 5424
addValue 1 1398 5425
assign 1 1401 5428
subtract 1 1401 5428
assign 1 1402 5429
new 0 1402 5429
assign 1 1402 5430
addValue 1 1402 5430
assign 1 1402 5431
toString 0 1402 5431
assign 1 1402 5432
addValue 1 1402 5432
assign 1 1402 5433
new 0 1402 5433
assign 1 1402 5434
addValue 1 1402 5434
assign 1 1402 5435
formTarg 1 1402 5435
assign 1 1402 5436
addValue 1 1402 5436
assign 1 1402 5437
new 0 1402 5437
assign 1 1402 5438
addValue 1 1402 5438
addValue 1 1402 5439
assign 1 1405 5442
increment 0 1405 5442
assign 1 1409 5448
decrement 0 1409 5448
assign 1 1411 5450
not 0 1411 5450
assign 1 0 5452
assign 1 0 5455
assign 1 0 5459
assign 1 1412 5462
new 0 1412 5462
assign 1 1412 5463
new 2 1412 5463
throw 1 1412 5464
assign 1 1415 5466
new 0 1415 5466
assign 1 1416 5467
new 0 1416 5467
assign 1 1419 5468
containerGet 0 1419 5468
assign 1 1419 5469
typenameGet 0 1419 5469
assign 1 1419 5470
CALLGet 0 1419 5470
assign 1 1419 5471
equals 1 1419 5471
assign 1 1419 5473
containerGet 0 1419 5473
assign 1 1419 5474
heldGet 0 1419 5474
assign 1 1419 5475
orgNameGet 0 1419 5475
assign 1 1419 5476
new 0 1419 5476
assign 1 1419 5477
equals 1 1419 5477
assign 1 0 5479
assign 1 0 5482
assign 1 0 5486
assign 1 1420 5489
containerGet 0 1420 5489
assign 1 1420 5490
isOnceAssign 1 1420 5490
assign 1 1420 5493
npGet 0 1420 5493
assign 1 1420 5494
equals 1 1420 5494
assign 1 0 5496
assign 1 0 5499
assign 1 0 5503
assign 1 1420 5505
not 0 1420 5505
assign 1 0 5507
assign 1 0 5510
assign 1 0 5514
assign 1 1421 5517
new 0 1421 5517
assign 1 1422 5518
toString 0 1422 5518
assign 1 1422 5519
onceVarDec 1 1422 5519
assign 1 1423 5520
increment 0 1423 5520
assign 1 1425 5521
containerGet 0 1425 5521
assign 1 1425 5522
containedGet 0 1425 5522
assign 1 1425 5523
firstGet 0 1425 5523
assign 1 1425 5524
heldGet 0 1425 5524
assign 1 1425 5525
isTypedGet 0 1425 5525
assign 1 1425 5526
not 0 1425 5526
assign 1 1426 5528
libNameGet 0 1426 5528
assign 1 1426 5529
relEmitName 1 1426 5529
assign 1 1426 5530
onceDec 2 1426 5530
assign 1 1428 5533
containerGet 0 1428 5533
assign 1 1428 5534
containedGet 0 1428 5534
assign 1 1428 5535
firstGet 0 1428 5535
assign 1 1428 5536
heldGet 0 1428 5536
assign 1 1428 5537
namepathGet 0 1428 5537
assign 1 1428 5538
getClassConfig 1 1428 5538
assign 1 1428 5539
libNameGet 0 1428 5539
assign 1 1428 5540
relEmitName 1 1428 5540
assign 1 1428 5541
onceDec 2 1428 5541
assign 1 1433 5544
containerGet 0 1433 5544
assign 1 1433 5545
heldGet 0 1433 5545
assign 1 1433 5546
checkTypesGet 0 1433 5546
assign 1 1435 5548
containerGet 0 1435 5548
assign 1 1435 5549
containedGet 0 1435 5549
assign 1 1435 5550
firstGet 0 1435 5550
assign 1 1435 5551
heldGet 0 1435 5551
assign 1 1435 5552
namepathGet 0 1435 5552
assign 1 1437 5554
containerGet 0 1437 5554
assign 1 1437 5555
containedGet 0 1437 5555
assign 1 1437 5556
firstGet 0 1437 5556
assign 1 1437 5557
finalAssignTo 2 1437 5557
assign 1 1439 5560
new 0 1439 5560
assign 1 1445 5563
containerGet 0 1445 5563
assign 1 1445 5564
containedGet 0 1445 5564
assign 1 1445 5565
firstGet 0 1445 5565
assign 1 1445 5566
heldGet 0 1445 5566
assign 1 1445 5567
nameForVar 1 1445 5567
assign 1 1445 5568
new 0 1445 5568
assign 1 1445 5569
add 1 1445 5569
assign 1 1445 5570
add 1 1445 5570
assign 1 1445 5571
new 0 1445 5571
assign 1 1445 5572
add 1 1445 5572
assign 1 1445 5573
add 1 1445 5573
assign 1 1446 5574
def 1 1446 5579
assign 1 1447 5580
getClassConfig 1 1447 5580
assign 1 1447 5581
formCast 1 1447 5581
assign 1 1447 5582
new 0 1447 5582
assign 1 1447 5583
add 1 1447 5583
assign 1 1449 5586
new 0 1449 5586
assign 1 1451 5588
new 0 1451 5588
assign 1 1451 5589
add 1 1451 5589
assign 1 1451 5590
add 1 1451 5590
assign 1 0 5593
assign 1 1455 5596
useDynMethodsGet 0 1455 5596
assign 1 1455 5597
not 0 1455 5597
assign 1 0 5599
assign 1 0 5602
assign 1 0 5607
assign 1 0 5610
assign 1 0 5614
assign 1 1455 5617
heldGet 0 1455 5617
assign 1 1455 5618
isLiteralGet 0 1455 5618
assign 1 0 5620
assign 1 0 5623
assign 1 0 5627
assign 1 0 5631
assign 1 0 5634
assign 1 0 5638
assign 1 1456 5641
new 0 1456 5641
assign 1 1460 5645
new 0 1460 5645
assign 1 1460 5646
emitting 1 1460 5646
assign 1 1461 5648
new 0 1461 5648
assign 1 1461 5649
addValue 1 1461 5649
assign 1 1461 5650
emitNameGet 0 1461 5650
assign 1 1461 5651
addValue 1 1461 5651
assign 1 1461 5652
new 0 1461 5652
assign 1 1461 5653
addValue 1 1461 5653
addValue 1 1461 5654
assign 1 1462 5657
new 0 1462 5657
assign 1 1462 5658
emitting 1 1462 5658
assign 1 1463 5660
new 0 1463 5660
assign 1 1463 5661
addValue 1 1463 5661
assign 1 1463 5662
emitNameGet 0 1463 5662
assign 1 1463 5663
addValue 1 1463 5663
assign 1 1463 5664
new 0 1463 5664
assign 1 1463 5665
addValue 1 1463 5665
addValue 1 1463 5666
assign 1 1465 5669
new 0 1465 5669
assign 1 1465 5670
add 1 1465 5670
assign 1 1465 5671
new 0 1465 5671
assign 1 1465 5672
add 1 1465 5672
assign 1 1465 5673
addValue 1 1465 5673
addValue 1 1465 5674
assign 1 0 5678
assign 1 1470 5681
useDynMethodsGet 0 1470 5681
assign 1 1470 5682
not 0 1470 5682
assign 1 0 5684
assign 1 0 5687
assign 1 1472 5692
heldGet 0 1472 5692
assign 1 1472 5693
isLiteralGet 0 1472 5693
assign 1 1473 5695
npGet 0 1473 5695
assign 1 1473 5696
equals 1 1473 5696
assign 1 1474 5698
lintConstruct 2 1474 5698
assign 1 1475 5701
npGet 0 1475 5701
assign 1 1475 5702
equals 1 1475 5702
assign 1 1476 5704
lfloatConstruct 2 1476 5704
assign 1 1477 5707
npGet 0 1477 5707
assign 1 1477 5708
equals 1 1477 5708
assign 1 1479 5710
new 0 1479 5710
assign 1 1479 5711
heldGet 0 1479 5711
assign 1 1479 5712
belsCountGet 0 1479 5712
assign 1 1479 5713
toString 0 1479 5713
assign 1 1479 5714
add 1 1479 5714
assign 1 1480 5715
heldGet 0 1480 5715
assign 1 1480 5716
belsCountGet 0 1480 5716
incrementValue 0 1480 5717
assign 1 1481 5718
new 0 1481 5718
lstringStart 2 1482 5719
assign 1 1484 5720
heldGet 0 1484 5720
assign 1 1484 5721
literalValueGet 0 1484 5721
assign 1 1486 5722
wideStringGet 0 1486 5722
assign 1 1487 5724
assign 1 1489 5727
new 0 1489 5727
assign 1 1489 5728
new 0 1489 5728
assign 1 1489 5729
new 0 1489 5729
assign 1 1489 5730
quoteGet 0 1489 5730
assign 1 1489 5731
add 1 1489 5731
assign 1 1489 5732
add 1 1489 5732
assign 1 1489 5733
new 0 1489 5733
assign 1 1489 5734
quoteGet 0 1489 5734
assign 1 1489 5735
add 1 1489 5735
assign 1 1489 5736
new 0 1489 5736
assign 1 1489 5737
add 1 1489 5737
assign 1 1489 5738
unmarshall 1 1489 5738
assign 1 1489 5739
firstGet 0 1489 5739
assign 1 1492 5741
sizeGet 0 1492 5741
assign 1 1493 5742
new 0 1493 5742
assign 1 1494 5743
new 0 1494 5743
assign 1 1495 5744
new 0 1495 5744
assign 1 1495 5745
new 1 1495 5745
assign 1 1496 5748
lesser 1 1496 5748
assign 1 1497 5750
new 0 1497 5750
assign 1 1497 5751
greater 1 1497 5751
assign 1 1498 5753
new 0 1498 5753
assign 1 1498 5754
once 0 1498 5754
addValue 1 1498 5755
lstringByte 5 1500 5757
incrementValue 0 1501 5758
lstringEnd 1 1503 5764
addValue 1 1505 5765
assign 1 1506 5766
lstringConstruct 5 1506 5766
assign 1 1507 5769
npGet 0 1507 5769
assign 1 1507 5770
equals 1 1507 5770
assign 1 1508 5772
heldGet 0 1508 5772
assign 1 1508 5773
literalValueGet 0 1508 5773
assign 1 1508 5774
new 0 1508 5774
assign 1 1508 5775
equals 1 1508 5775
assign 1 1509 5777
assign 1 1511 5780
assign 1 1515 5784
new 0 1515 5784
assign 1 1515 5785
npGet 0 1515 5785
assign 1 1515 5786
toString 0 1515 5786
assign 1 1515 5787
add 1 1515 5787
assign 1 1515 5788
new 1 1515 5788
throw 1 1515 5789
assign 1 1518 5796
new 0 1518 5796
assign 1 1518 5797
libNameGet 0 1518 5797
assign 1 1518 5798
relEmitName 1 1518 5798
assign 1 1518 5799
add 1 1518 5799
assign 1 1518 5800
new 0 1518 5800
assign 1 1518 5801
add 1 1518 5801
assign 1 1520 5803
new 0 1520 5803
assign 1 1520 5804
add 1 1520 5804
assign 1 1520 5805
new 0 1520 5805
assign 1 1520 5806
add 1 1520 5806
assign 1 1522 5807
getInitialInst 1 1522 5807
assign 1 1524 5808
heldGet 0 1524 5808
assign 1 1524 5809
isLiteralGet 0 1524 5809
assign 1 1525 5811
npGet 0 1525 5811
assign 1 1525 5812
equals 1 1525 5812
assign 1 1527 5815
new 0 1527 5815
assign 1 1528 5816
containerGet 0 1528 5816
assign 1 1528 5817
containedGet 0 1528 5817
assign 1 1528 5818
firstGet 0 1528 5818
assign 1 1528 5819
heldGet 0 1528 5819
assign 1 1528 5820
allCallsGet 0 1528 5820
assign 1 1528 5821
iteratorGet 0 0 5821
assign 1 1528 5824
hasNextGet 0 1528 5824
assign 1 1528 5826
nextGet 0 1528 5826
assign 1 1529 5827
keyGet 0 1529 5827
assign 1 1529 5828
heldGet 0 1529 5828
assign 1 1529 5829
nameGet 0 1529 5829
assign 1 1529 5830
addValue 1 1529 5830
assign 1 1529 5831
new 0 1529 5831
addValue 1 1529 5832
assign 1 1531 5838
new 0 1531 5838
assign 1 1531 5839
add 1 1531 5839
assign 1 1531 5840
new 1 1531 5840
throw 1 1531 5841
assign 1 1534 5843
heldGet 0 1534 5843
assign 1 1534 5844
literalValueGet 0 1534 5844
assign 1 1534 5845
new 0 1534 5845
assign 1 1534 5846
equals 1 1534 5846
assign 1 1535 5848
assign 1 1537 5851
assign 1 1541 5855
addValue 1 1541 5855
assign 1 1541 5856
addValue 1 1541 5856
assign 1 1541 5857
addValue 1 1541 5857
assign 1 1541 5858
new 0 1541 5858
assign 1 1541 5859
addValue 1 1541 5859
addValue 1 1541 5860
assign 1 1543 5863
addValue 1 1543 5863
assign 1 1543 5864
addValue 1 1543 5864
assign 1 1543 5865
new 0 1543 5865
assign 1 1543 5866
addValue 1 1543 5866
addValue 1 1543 5867
assign 1 1546 5871
npGet 0 1546 5871
assign 1 1546 5872
getSynNp 1 1546 5872
assign 1 1547 5873
hasDefaultGet 0 1547 5873
assign 1 1548 5875
addValue 1 1548 5875
assign 1 1548 5876
addValue 1 1548 5876
assign 1 1548 5877
new 0 1548 5877
assign 1 1548 5878
addValue 1 1548 5878
assign 1 1548 5879
emitNameForCall 1 1548 5879
assign 1 1548 5880
addValue 1 1548 5880
assign 1 1548 5881
new 0 1548 5881
assign 1 1548 5882
addValue 1 1548 5882
assign 1 1548 5883
addValue 1 1548 5883
assign 1 1548 5884
new 0 1548 5884
assign 1 1548 5885
addValue 1 1548 5885
addValue 1 1548 5886
assign 1 1550 5889
addValue 1 1550 5889
assign 1 1550 5890
addValue 1 1550 5890
assign 1 1550 5891
new 0 1550 5891
assign 1 1550 5892
addValue 1 1550 5892
assign 1 1550 5893
emitNameForCall 1 1550 5893
assign 1 1550 5894
addValue 1 1550 5894
assign 1 1550 5895
new 0 1550 5895
assign 1 1550 5896
addValue 1 1550 5896
assign 1 1550 5897
addValue 1 1550 5897
assign 1 1550 5898
new 0 1550 5898
assign 1 1550 5899
addValue 1 1550 5899
addValue 1 1550 5900
assign 1 1554 5905
not 0 1554 5905
assign 1 1555 5907
addValue 1 1555 5907
assign 1 1555 5908
addValue 1 1555 5908
assign 1 1555 5909
new 0 1555 5909
assign 1 1555 5910
addValue 1 1555 5910
assign 1 1555 5911
emitNameForCall 1 1555 5911
assign 1 1555 5912
addValue 1 1555 5912
assign 1 1555 5913
new 0 1555 5913
assign 1 1555 5914
addValue 1 1555 5914
assign 1 1555 5915
addValue 1 1555 5915
assign 1 1555 5916
new 0 1555 5916
assign 1 1555 5917
addValue 1 1555 5917
addValue 1 1555 5918
assign 1 1557 5921
addValue 1 1557 5921
assign 1 1557 5922
addValue 1 1557 5922
assign 1 1557 5923
new 0 1557 5923
assign 1 1557 5924
addValue 1 1557 5924
assign 1 1557 5925
emitNameForCall 1 1557 5925
assign 1 1557 5926
addValue 1 1557 5926
assign 1 1557 5927
new 0 1557 5927
assign 1 1557 5928
addValue 1 1557 5928
assign 1 1557 5929
addValue 1 1557 5929
assign 1 1557 5930
new 0 1557 5930
assign 1 1557 5931
addValue 1 1557 5931
addValue 1 1557 5932
assign 1 1561 5937
lesser 1 1561 5937
assign 1 1562 5939
toString 0 1562 5939
assign 1 1563 5940
new 0 1563 5940
assign 1 1565 5943
new 0 1565 5943
assign 1 1566 5944
subtract 1 1566 5944
assign 1 1566 5945
new 0 1566 5945
assign 1 1566 5946
add 1 1566 5946
assign 1 1567 5947
greater 1 1567 5947
assign 1 1568 5949
addValue 1 1570 5951
assign 1 1571 5952
new 0 1571 5952
assign 1 1573 5954
new 0 1573 5954
assign 1 1573 5955
greater 1 1573 5955
assign 1 1574 5957
new 0 1574 5957
assign 1 1576 5960
new 0 1576 5960
assign 1 1578 5962
addValue 1 1578 5962
assign 1 1578 5963
addValue 1 1578 5963
assign 1 1578 5964
new 0 1578 5964
assign 1 1578 5965
addValue 1 1578 5965
assign 1 1578 5966
addValue 1 1578 5966
assign 1 1578 5967
new 0 1578 5967
assign 1 1578 5968
addValue 1 1578 5968
assign 1 1578 5969
heldGet 0 1578 5969
assign 1 1578 5970
nameGet 0 1578 5970
assign 1 1578 5971
hashGet 0 1578 5971
assign 1 1578 5972
toString 0 1578 5972
assign 1 1578 5973
addValue 1 1578 5973
assign 1 1578 5974
new 0 1578 5974
assign 1 1578 5975
addValue 1 1578 5975
assign 1 1578 5976
addValue 1 1578 5976
assign 1 1578 5977
new 0 1578 5977
assign 1 1578 5978
addValue 1 1578 5978
assign 1 1578 5979
heldGet 0 1578 5979
assign 1 1578 5980
nameGet 0 1578 5980
assign 1 1578 5981
addValue 1 1578 5981
assign 1 1578 5982
addValue 1 1578 5982
assign 1 1578 5983
addValue 1 1578 5983
assign 1 1578 5984
addValue 1 1578 5984
assign 1 1578 5985
new 0 1578 5985
assign 1 1578 5986
addValue 1 1578 5986
addValue 1 1578 5987
assign 1 1582 5990
not 0 1582 5990
assign 1 1584 5992
new 0 1584 5992
assign 1 1584 5993
addValue 1 1584 5993
addValue 1 1584 5994
assign 1 1585 5995
new 0 1585 5995
assign 1 1585 5996
emitting 1 1585 5996
assign 1 0 5998
assign 1 1585 6001
new 0 1585 6001
assign 1 1585 6002
emitting 1 1585 6002
assign 1 0 6004
assign 1 0 6007
assign 1 1587 6011
new 0 1587 6011
assign 1 1587 6012
addValue 1 1587 6012
addValue 1 1587 6013
addValue 1 1590 6016
assign 1 1591 6017
not 0 1591 6017
assign 1 1592 6019
isEmptyGet 0 1592 6019
assign 1 1592 6020
not 0 1592 6020
assign 1 1593 6022
addValue 1 1593 6022
assign 1 1593 6023
addValue 1 1593 6023
assign 1 1593 6024
new 0 1593 6024
assign 1 1593 6025
addValue 1 1593 6025
addValue 1 1593 6026
assign 1 1601 6045
new 0 1601 6045
assign 1 1602 6046
new 0 1602 6046
assign 1 1602 6047
emitting 1 1602 6047
assign 1 1603 6049
new 0 1603 6049
assign 1 1603 6050
addValue 1 1603 6050
assign 1 1603 6051
addValue 1 1603 6051
assign 1 1603 6052
new 0 1603 6052
addValue 1 1603 6053
assign 1 1605 6056
new 0 1605 6056
assign 1 1605 6057
addValue 1 1605 6057
assign 1 1605 6058
addValue 1 1605 6058
assign 1 1605 6059
new 0 1605 6059
addValue 1 1605 6060
assign 1 1607 6062
new 0 1607 6062
addValue 1 1607 6063
return 1 1608 6064
assign 1 1612 6071
libNameGet 0 1612 6071
assign 1 1612 6072
relEmitName 1 1612 6072
assign 1 1612 6073
new 0 1612 6073
assign 1 1612 6074
add 1 1612 6074
return 1 1612 6075
assign 1 1616 6089
new 0 1616 6089
assign 1 1616 6090
libNameGet 0 1616 6090
assign 1 1616 6091
relEmitName 1 1616 6091
assign 1 1616 6092
add 1 1616 6092
assign 1 1616 6093
new 0 1616 6093
assign 1 1616 6094
add 1 1616 6094
assign 1 1616 6095
heldGet 0 1616 6095
assign 1 1616 6096
literalValueGet 0 1616 6096
assign 1 1616 6097
add 1 1616 6097
assign 1 1616 6098
new 0 1616 6098
assign 1 1616 6099
add 1 1616 6099
return 1 1616 6100
assign 1 1620 6114
new 0 1620 6114
assign 1 1620 6115
libNameGet 0 1620 6115
assign 1 1620 6116
relEmitName 1 1620 6116
assign 1 1620 6117
add 1 1620 6117
assign 1 1620 6118
new 0 1620 6118
assign 1 1620 6119
add 1 1620 6119
assign 1 1620 6120
heldGet 0 1620 6120
assign 1 1620 6121
literalValueGet 0 1620 6121
assign 1 1620 6122
add 1 1620 6122
assign 1 1620 6123
new 0 1620 6123
assign 1 1620 6124
add 1 1620 6124
return 1 1620 6125
assign 1 1625 6153
new 0 1625 6153
assign 1 1625 6154
libNameGet 0 1625 6154
assign 1 1625 6155
relEmitName 1 1625 6155
assign 1 1625 6156
add 1 1625 6156
assign 1 1625 6157
new 0 1625 6157
assign 1 1625 6158
add 1 1625 6158
assign 1 1625 6159
add 1 1625 6159
assign 1 1625 6160
new 0 1625 6160
assign 1 1625 6161
add 1 1625 6161
assign 1 1625 6162
add 1 1625 6162
assign 1 1625 6163
new 0 1625 6163
assign 1 1625 6164
add 1 1625 6164
return 1 1625 6165
assign 1 1627 6167
new 0 1627 6167
assign 1 1627 6168
libNameGet 0 1627 6168
assign 1 1627 6169
relEmitName 1 1627 6169
assign 1 1627 6170
add 1 1627 6170
assign 1 1627 6171
new 0 1627 6171
assign 1 1627 6172
add 1 1627 6172
assign 1 1627 6173
add 1 1627 6173
assign 1 1627 6174
new 0 1627 6174
assign 1 1627 6175
add 1 1627 6175
assign 1 1627 6176
add 1 1627 6176
assign 1 1627 6177
new 0 1627 6177
assign 1 1627 6178
add 1 1627 6178
return 1 1627 6179
assign 1 1631 6186
new 0 1631 6186
assign 1 1631 6187
addValue 1 1631 6187
assign 1 1631 6188
addValue 1 1631 6188
assign 1 1631 6189
new 0 1631 6189
addValue 1 1631 6190
assign 1 1642 6199
new 0 1642 6199
assign 1 1642 6200
addValue 1 1642 6200
addValue 1 1642 6201
assign 1 1646 6214
heldGet 0 1646 6214
assign 1 1646 6215
isManyGet 0 1646 6215
assign 1 1647 6217
new 0 1647 6217
return 1 1647 6218
assign 1 1649 6220
heldGet 0 1649 6220
assign 1 1649 6221
isOnceGet 0 1649 6221
assign 1 0 6223
assign 1 1649 6226
isLiteralOnceGet 0 1649 6226
assign 1 0 6228
assign 1 0 6231
assign 1 1650 6235
new 0 1650 6235
return 1 1650 6236
assign 1 1652 6238
new 0 1652 6238
return 1 1652 6239
assign 1 1656 6248
heldGet 0 1656 6248
assign 1 1656 6249
langsGet 0 1656 6249
assign 1 1656 6250
emitLangGet 0 1656 6250
assign 1 1656 6251
has 1 1656 6251
assign 1 1657 6253
heldGet 0 1657 6253
assign 1 1657 6254
textGet 0 1657 6254
addValue 1 1657 6255
assign 1 1662 6267
heldGet 0 1662 6267
assign 1 1662 6268
langsGet 0 1662 6268
assign 1 1662 6269
emitLangGet 0 1662 6269
assign 1 1662 6270
has 1 1662 6270
assign 1 1662 6271
not 0 1662 6271
assign 1 1663 6273
nextPeerGet 0 1663 6273
return 1 1663 6274
assign 1 1665 6276
nextDescendGet 0 1665 6276
return 1 1665 6277
assign 1 1669 6327
typenameGet 0 1669 6327
assign 1 1669 6328
CLASSGet 0 1669 6328
assign 1 1669 6329
equals 1 1669 6329
acceptClass 1 1670 6331
assign 1 1671 6334
typenameGet 0 1671 6334
assign 1 1671 6335
METHODGet 0 1671 6335
assign 1 1671 6336
equals 1 1671 6336
acceptMethod 1 1672 6338
assign 1 1673 6341
typenameGet 0 1673 6341
assign 1 1673 6342
RBRACESGet 0 1673 6342
assign 1 1673 6343
equals 1 1673 6343
acceptRbraces 1 1674 6345
assign 1 1675 6348
typenameGet 0 1675 6348
assign 1 1675 6349
EMITGet 0 1675 6349
assign 1 1675 6350
equals 1 1675 6350
acceptEmit 1 1676 6352
assign 1 1677 6355
typenameGet 0 1677 6355
assign 1 1677 6356
IFEMITGet 0 1677 6356
assign 1 1677 6357
equals 1 1677 6357
addStackLines 1 1678 6359
assign 1 1679 6360
acceptIfEmit 1 1679 6360
return 1 1679 6361
assign 1 1680 6364
typenameGet 0 1680 6364
assign 1 1680 6365
CALLGet 0 1680 6365
assign 1 1680 6366
equals 1 1680 6366
acceptCall 1 1681 6368
assign 1 1682 6371
typenameGet 0 1682 6371
assign 1 1682 6372
BRACESGet 0 1682 6372
assign 1 1682 6373
equals 1 1682 6373
acceptBraces 1 1683 6375
assign 1 1684 6378
typenameGet 0 1684 6378
assign 1 1684 6379
BREAKGet 0 1684 6379
assign 1 1684 6380
equals 1 1684 6380
assign 1 1685 6382
new 0 1685 6382
assign 1 1685 6383
addValue 1 1685 6383
addValue 1 1685 6384
assign 1 1686 6387
typenameGet 0 1686 6387
assign 1 1686 6388
LOOPGet 0 1686 6388
assign 1 1686 6389
equals 1 1686 6389
assign 1 1687 6391
new 0 1687 6391
assign 1 1687 6392
addValue 1 1687 6392
addValue 1 1687 6393
assign 1 1688 6396
typenameGet 0 1688 6396
assign 1 1688 6397
ELSEGet 0 1688 6397
assign 1 1688 6398
equals 1 1688 6398
assign 1 1689 6400
new 0 1689 6400
addValue 1 1689 6401
assign 1 1690 6404
typenameGet 0 1690 6404
assign 1 1690 6405
TRYGet 0 1690 6405
assign 1 1690 6406
equals 1 1690 6406
assign 1 1691 6408
new 0 1691 6408
addValue 1 1691 6409
assign 1 1692 6412
typenameGet 0 1692 6412
assign 1 1692 6413
CATCHGet 0 1692 6413
assign 1 1692 6414
equals 1 1692 6414
acceptCatch 1 1693 6416
assign 1 1694 6419
typenameGet 0 1694 6419
assign 1 1694 6420
IFGet 0 1694 6420
assign 1 1694 6421
equals 1 1694 6421
acceptIf 1 1695 6423
addStackLines 1 1697 6437
assign 1 1698 6438
nextDescendGet 0 1698 6438
return 1 1698 6439
assign 1 1702 6443
def 1 1702 6448
assign 1 1711 6469
typenameGet 0 1711 6469
assign 1 1711 6470
NULLGet 0 1711 6470
assign 1 1711 6471
equals 1 1711 6471
assign 1 1712 6473
new 0 1712 6473
assign 1 1713 6476
heldGet 0 1713 6476
assign 1 1713 6477
nameGet 0 1713 6477
assign 1 1713 6478
new 0 1713 6478
assign 1 1713 6479
equals 1 1713 6479
assign 1 1714 6481
new 0 1714 6481
assign 1 1715 6484
heldGet 0 1715 6484
assign 1 1715 6485
nameGet 0 1715 6485
assign 1 1715 6486
new 0 1715 6486
assign 1 1715 6487
equals 1 1715 6487
assign 1 1716 6489
superNameGet 0 1716 6489
assign 1 1718 6492
heldGet 0 1718 6492
assign 1 1718 6493
nameForVar 1 1718 6493
return 1 1720 6497
assign 1 1725 6513
typenameGet 0 1725 6513
assign 1 1725 6514
NULLGet 0 1725 6514
assign 1 1725 6515
equals 1 1725 6515
assign 1 1726 6517
new 0 1726 6517
assign 1 1727 6520
heldGet 0 1727 6520
assign 1 1727 6521
nameGet 0 1727 6521
assign 1 1727 6522
new 0 1727 6522
assign 1 1727 6523
equals 1 1727 6523
assign 1 1728 6525
new 0 1728 6525
assign 1 1729 6528
heldGet 0 1729 6528
assign 1 1729 6529
nameGet 0 1729 6529
assign 1 1729 6530
new 0 1729 6530
assign 1 1729 6531
equals 1 1729 6531
assign 1 1730 6533
superNameGet 0 1730 6533
assign 1 1732 6536
heldGet 0 1732 6536
assign 1 1732 6537
nameForVar 1 1732 6537
return 1 1734 6541
end 1 1738 6544
assign 1 1742 6549
new 0 1742 6549
return 1 1742 6550
assign 1 1746 6554
new 0 1746 6554
return 1 1746 6555
assign 1 1750 6559
new 0 1750 6559
return 1 1750 6560
assign 1 1754 6564
new 0 1754 6564
return 1 1754 6565
assign 1 1758 6569
new 0 1758 6569
return 1 1758 6570
assign 1 1763 6574
new 0 1763 6574
return 1 1763 6575
assign 1 1767 6589
new 0 1767 6589
assign 1 1768 6590
new 0 1768 6590
assign 1 1769 6591
stepsGet 0 1769 6591
assign 1 1769 6592
iteratorGet 0 0 6592
assign 1 1769 6595
hasNextGet 0 1769 6595
assign 1 1769 6597
nextGet 0 1769 6597
assign 1 1770 6598
new 0 1770 6598
assign 1 1770 6599
notEquals 1 1770 6599
assign 1 1770 6601
new 0 1770 6601
assign 1 1770 6602
add 1 1770 6602
assign 1 1771 6605
new 0 1771 6605
assign 1 1772 6607
sizeGet 0 1772 6607
assign 1 1772 6608
add 1 1772 6608
assign 1 1773 6609
add 1 1773 6609
assign 1 1775 6615
add 1 1775 6615
return 1 1775 6616
assign 1 1779 6622
new 0 1779 6622
assign 1 1779 6623
mangleName 1 1779 6623
assign 1 1779 6624
add 1 1779 6624
return 1 1779 6625
assign 1 1783 6631
new 0 1783 6631
assign 1 1783 6632
add 1 1783 6632
assign 1 1783 6633
add 1 1783 6633
return 1 1783 6634
assign 1 1787 6640
new 0 1787 6640
assign 1 1787 6641
libEmitName 1 1787 6641
assign 1 1787 6642
add 1 1787 6642
return 1 1787 6643
return 1 0 6646
assign 1 0 6649
return 1 0 6653
assign 1 0 6656
return 1 0 6660
assign 1 0 6663
return 1 0 6667
assign 1 0 6670
return 1 0 6674
assign 1 0 6677
return 1 0 6681
assign 1 0 6684
return 1 0 6688
assign 1 0 6691
return 1 0 6695
assign 1 0 6698
return 1 0 6702
assign 1 0 6705
return 1 0 6709
assign 1 0 6712
return 1 0 6716
assign 1 0 6719
return 1 0 6723
assign 1 0 6726
return 1 0 6730
assign 1 0 6733
return 1 0 6737
assign 1 0 6740
return 1 0 6744
assign 1 0 6747
return 1 0 6751
assign 1 0 6754
return 1 0 6758
assign 1 0 6761
return 1 0 6765
assign 1 0 6768
return 1 0 6772
assign 1 0 6775
return 1 0 6779
assign 1 0 6782
return 1 0 6786
assign 1 0 6789
return 1 0 6793
assign 1 0 6796
return 1 0 6800
assign 1 0 6803
return 1 0 6807
assign 1 0 6810
return 1 0 6814
assign 1 0 6817
return 1 0 6821
assign 1 0 6824
return 1 0 6828
assign 1 0 6831
return 1 0 6835
assign 1 0 6838
return 1 0 6842
assign 1 0 6845
return 1 0 6849
assign 1 0 6852
return 1 0 6856
assign 1 0 6859
return 1 0 6863
assign 1 0 6866
return 1 0 6870
assign 1 0 6873
return 1 0 6877
assign 1 0 6880
return 1 0 6884
assign 1 0 6887
return 1 0 6891
assign 1 0 6894
return 1 0 6898
assign 1 0 6901
return 1 0 6905
assign 1 0 6908
return 1 0 6912
assign 1 0 6915
return 1 0 6919
assign 1 0 6922
return 1 0 6926
assign 1 0 6929
return 1 0 6933
assign 1 0 6936
return 1 0 6940
assign 1 0 6943
return 1 0 6947
assign 1 0 6950
return 1 0 6954
assign 1 0 6957
return 1 0 6961
assign 1 0 6964
return 1 0 6968
assign 1 0 6971
return 1 0 6975
assign 1 0 6978
return 1 0 6982
assign 1 0 6985
return 1 0 6989
assign 1 0 6992
return 1 0 6996
assign 1 0 6999
return 1 0 7003
assign 1 0 7006
return 1 0 7010
assign 1 0 7013
return 1 0 7017
assign 1 0 7020
return 1 0 7024
assign 1 0 7027
return 1 0 7031
assign 1 0 7034
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 493012039: return bem_buildGet_0();
case 1831751774: return bem_cnodeGet_0();
case 4647121: return bem_doEmit_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 902412214: return bem_classCallsGet_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 991255330: return bem_mainStartGet_0();
case 287040793: return bem_hashGet_0();
case 402158238: return bem_inFilePathedGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 498080472: return bem_mnodeGet_0();
case 160277051: return bem_procStartGet_0();
case 622039562: return bem_intNpGet_0();
case 1638160588: return bem_lineCountGet_0();
case 681402717: return bem_boolTypeGet_0();
case 1354714650: return bem_copy_0();
case 845792839: return bem_iteratorGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 916491491: return bem_emitLib_0();
case 1052944126: return bem_csynGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case 314718434: return bem_print_0();
case 229958684: return bem_constGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 1947619572: return bem_msynGet_0();
case 1755995201: return bem_transGet_0();
case 1910715228: return bem_libEmitNameGet_0();
case 1727672536: return bem_propDecGet_0();
case 1064889660: return bem_trueValueGet_0();
case 362974009: return bem_parentConfGet_0();
case 1312373307: return bem_buildCreate_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 727049506: return bem_exceptDecGet_0();
case 722876119: return bem_buildClassInfo_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1820417453: return bem_create_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 2019411446: return bem_classBeginGet_0();
case 1073009537: return bem_beginNs_0();
case 378762597: return bem_boolNpGet_0();
case 89706405: return bem_ccCacheGet_0();
case 220901978: return bem_emitLangGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2055025483: return bem_serializeContents_0();
case 644675716: return bem_ntypesGet_0();
case 1372235405: return bem_superCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 388723214: return bem_preClassGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 2001798761: return bem_nlGet_0();
case 1081412016: return bem_many_0();
case 1774940957: return bem_toString_0();
case 991179882: return bem_qGet_0();
case 946095539: return bem_mainInClassGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1859739893: return bem_methodsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 729571811: return bem_serializeToString_0();
case 1181505319: return bem_buildInitial_0();
case 104713553: return bem_new_0();
case 1413054881: return bem_smnlcsGet_0();
case 57260628: return bem_getClassOutput_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1967844855: return bem_initialDecGet_0();
case 483359873: return bem_superNameGet_0();
case 294732055: return bem_floatNpGet_0();
case 443668840: return bem_methodNotDefined_0();
case 604504089: return bem_falseValueGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1012494862: return bem_once_0();
case 797225458: return bem_dynMethodsGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1369896794: return bem_objectNpGet_0();
case 1380285640: return bem_objectCcGet_0();
case 1487140092: return bem_classEndGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 2085643372: return bem_stringNpGet_0();
case 1607412815: return bem_endNs_0();
case 1431933907: return bem_lastCallGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1109279973: return bem_spropDecGet_0();
case 1498619679: return bem_getLibOutput_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 708434875: return bem_klassDecGet_0();
case 1102720804: return bem_classNameGet_0();
case 944442837: return bem_classConfGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1529527065: return bem_onceCountGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 165152860: return bem_libNs_1((BEC_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_5_4_BuildNode) bevd_0, (BEC_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_5_4_BuildNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_4_6_TextString) bevd_0, (BEC_5_11_BuildClassConfig) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_10_BuildEmitCommon();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_10_BuildEmitCommon.bevs_inst = (BEC_5_10_BuildEmitCommon)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_10_BuildEmitCommon.bevs_inst;
}
}
}
