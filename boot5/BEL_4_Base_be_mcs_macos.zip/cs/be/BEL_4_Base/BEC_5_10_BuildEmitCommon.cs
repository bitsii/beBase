namespace be.BEL_4_Base {
/* File: source/build/EmitCommon.be */
public class BEC_5_10_BuildEmitCommon : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_10_BuildEmitCommon() { }
static BEC_5_10_BuildEmitCommon() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_4 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_5 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_6 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_7 = {0x20,0x3D,0x3D,0x20};
private static byte[] bels_8 = {0x20,0x21,0x3D,0x20};
private static byte[] bels_9 = {0x62,0x65};
private static byte[] bels_10 = {0x63,0x73};
private static byte[] bels_11 = {0x20,0x69,0x73,0x20};
private static byte[] bels_12 = {0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x6F,0x66,0x20};
private static byte[] bels_13 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 33));
private static byte[] bels_14 = {0x42,0x45,0x4C,0x5F};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 4));
private static byte[] bels_15 = {0x5F};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_15, 1));
private static byte[] bels_16 = {0x2E};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 1));
private static byte[] bels_17 = {0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x69,0x6E,0x67,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 17));
private static byte[] bels_18 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_18, 2));
private static byte[] bels_19 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_19, 3));
private static byte[] bels_20 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_20, 4));
private static byte[] bels_21 = {0x20};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_21, 1));
private static byte[] bels_22 = {0x2F,0x2A,0x20,0x42,0x45,0x47,0x49,0x4E,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20};
private static byte[] bels_23 = {0x2C,0x20};
private static byte[] bels_24 = {0x2C,0x20};
private static byte[] bels_25 = {0x20};
private static byte[] bels_26 = {0x20};
private static byte[] bels_27 = {0x20};
private static byte[] bels_28 = {0x45,0x4E,0x44,0x20,0x4C,0x49,0x4E,0x45,0x49,0x4E,0x46,0x4F,0x20,0x2A,0x2F};
private static byte[] bels_29 = {0x2E};
private static byte[] bels_30 = {0x6A,0x73};
private static byte[] bels_31 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_31, 11));
private static byte[] bels_32 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_33, 11));
private static byte[] bels_34 = {0x63,0x73};
private static byte[] bels_35 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_36 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_37 = {0x6A,0x76};
private static byte[] bels_38 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_39 = {0x6A,0x73};
private static byte[] bels_40 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63};
private static byte[] bels_41 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_42 = {0x5D,0x3B};
private static byte[] bels_43 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_44 = {0x7D,0x3B};
private static byte[] bels_45 = {0x63,0x73};
private static byte[] bels_46 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_47 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_48 = {0x6A,0x76};
private static byte[] bels_49 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_50 = {0x6A,0x73};
private static byte[] bels_51 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63};
private static byte[] bels_52 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_53 = {0x5D,0x3B};
private static byte[] bels_54 = {0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x69,0x6E,0x74,0x5B,0x5D,0x20,0x7B};
private static byte[] bels_55 = {0x7D,0x3B};
private static byte[] bels_56 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_57 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_58 = {};
private static byte[] bels_59 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_60 = {};
private static byte[] bels_61 = {};
private static byte[] bels_62 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_63 = {};
private static byte[] bels_64 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_65 = {0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_66 = {0x28,0x29,0x3B};
private static byte[] bels_67 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_68 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_69 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62};
private static byte[] bels_70 = {0x20,0x20,0x7B};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_70, 3));
private static byte[] bels_71 = {0x20,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x66,0x61,0x6C,0x73,0x65,0x3B};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_71, 19));
private static byte[] bels_72 = {0x2E,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bels_73 = {0x6A,0x76};
private static byte[] bels_74 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x2E,0x70,0x75,0x74,0x28};
private static byte[] bels_75 = {0x2C,0x20,0x43,0x6C,0x61,0x73,0x73,0x2E,0x66,0x6F,0x72,0x4E,0x61,0x6D,0x65,0x28};
private static byte[] bels_76 = {0x29,0x29,0x3B};
private static byte[] bels_77 = {0x63,0x73};
private static byte[] bels_78 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_79 = {0x5D,0x20,0x3D,0x20,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_80 = {0x29,0x3B};
private static byte[] bels_81 = {0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_82 = {0x29};
private static byte[] bels_83 = {0x2E,0x47,0x65,0x74,0x46,0x69,0x65,0x6C,0x64,0x28};
private static byte[] bels_84 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_85 = {0x29,0x2E,0x47,0x65,0x74,0x56,0x61,0x6C,0x75,0x65,0x28,0x6E,0x75,0x6C,0x6C,0x29,0x3B};
private static byte[] bels_86 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_86, 4));
private static byte[] bels_87 = {0x28,0x29};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_87, 2));
private static byte[] bels_88 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_89 = {0x29,0x3B};
private static byte[] bels_90 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_91 = {0x29,0x3B};
private static byte[] bels_92 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_92, 9));
private static byte[] bels_93 = {0x3B};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_93, 1));
private static byte[] bels_94 = {0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_95 = {0x20,0x3D,0x20,0x67,0x65,0x74,0x43,0x61,0x6C,0x6C,0x49,0x64,0x28};
private static byte[] bels_96 = {0x29,0x3B};
private static byte[] bels_97 = {0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_98 = {0x2C,0x20};
private static byte[] bels_99 = {0x29,0x3B};
private static byte[] bels_100 = {0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_101 = {0x2C,0x20};
private static byte[] bels_102 = {0x29,0x3B};
private static byte[] bels_103 = {0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_103, 11));
private static byte[] bels_104 = {0x20,0x7B};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_104, 2));
private static byte[] bels_105 = {0x6A,0x76};
private static byte[] bels_106 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_106, 14));
private static byte[] bels_107 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_107, 9));
private static byte[] bels_108 = {0x63,0x73};
private static byte[] bels_109 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_109, 13));
private static byte[] bels_110 = {0x29,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_110, 4));
private static byte[] bels_111 = {0x69,0x66,0x20,0x28,0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x29,0x20,0x7B,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x3B,0x20,0x7D};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_111, 26));
private static byte[] bels_112 = {0x69,0x73,0x49,0x6E,0x69,0x74,0x74,0x65,0x64,0x20,0x3D,0x20,0x74,0x72,0x75,0x65,0x3B};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_112, 17));
private static byte[] bels_113 = {0x6A,0x76};
private static byte[] bels_114 = {0x63,0x73};
private static byte[] bels_115 = {0x7D};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_115, 1));
private static byte[] bels_116 = {0x7D};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_116, 1));
private static byte[] bels_117 = {0x7D};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_117, 1));
private static byte[] bels_118 = {0x28,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x5F,0x36,0x5F,0x37,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x28,0x29,0x29,0x2E,0x62,0x65,0x6D,0x5F,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30,0x28,0x29,0x3B};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_118, 60));
private static byte[] bels_119 = {};
private static byte[] bels_120 = {0x6A,0x76};
private static byte[] bels_121 = {0x63,0x73};
private static byte[] bels_122 = {0x7D,0x20,0x7D};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_122, 3));
private static byte[] bels_123 = {0x7D};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_123, 1));
private static byte[] bels_124 = {};
private static byte[] bels_125 = {0x62,0x65,0x76,0x74,0x5F};
private static byte[] bels_126 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_127 = {0x62,0x65,0x76,0x61,0x5F};
private static byte[] bels_128 = {0x62,0x65,0x76,0x6C,0x5F};
private static byte[] bels_129 = {0x20};
private static byte[] bels_130 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_130, 4));
private static byte[] bels_131 = {0x62,0x65,0x6D,0x5F};
private static BEC_4_6_TextString bevo_33 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_131, 4));
private static byte[] bels_132 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_133 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_134 = {0x2C,0x20};
private static byte[] bels_135 = {0x4E,0x75,0x6C,0x6C,0x20,0x61,0x72,0x67,0x20,0x68,0x65,0x6C,0x64,0x20};
private static BEC_4_6_TextString bevo_34 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_135, 14));
private static byte[] bels_136 = {0x6A,0x73};
private static byte[] bels_137 = {0x3B};
private static byte[] bels_138 = {0x20,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x3B};
private static byte[] bels_139 = {0x20};
private static byte[] bels_140 = {0x28};
private static byte[] bels_141 = {0x29};
private static byte[] bels_142 = {0x20,0x7B};
private static byte[] bels_143 = {0x2F};
private static BEC_4_3_MathInt bevo_35 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_36 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_144 = {0x3B};
private static byte[] bels_145 = {0x62,0x65,0x6D,0x64,0x5F};
private static BEC_4_6_TextString bevo_37 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_145, 5));
private static byte[] bels_146 = {0x62,0x65,0x6D,0x64,0x5F,0x78};
private static byte[] bels_147 = {0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static byte[] bels_148 = {0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x2C,0x20,0x69,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x49,0x64};
private static BEC_4_3_MathInt bevo_38 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_149 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_39 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_149, 2));
private static byte[] bels_150 = {0x20,0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_40 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_150, 6));
private static BEC_4_3_MathInt bevo_41 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_151 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_42 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_151, 2));
private static byte[] bels_152 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_43 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_152, 5));
private static BEC_4_3_MathInt bevo_44 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_153 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_45 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_153, 2));
private static byte[] bels_154 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_6_TextString bevo_46 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_154, 9));
private static byte[] bels_155 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_6_TextString bevo_47 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_155, 8));
private static byte[] bels_156 = {0x20};
private static byte[] bels_157 = {0x28};
private static byte[] bels_158 = {0x29};
private static byte[] bels_159 = {0x20,0x7B};
private static byte[] bels_160 = {0x73,0x77,0x69,0x74,0x63,0x68,0x20,0x28,0x63,0x61,0x6C,0x6C,0x48,0x61,0x73,0x68,0x29,0x20,0x7B};
private static byte[] bels_161 = {0x63,0x61,0x73,0x65,0x20};
private static byte[] bels_162 = {0x3A,0x20};
private static BEC_4_3_MathInt bevo_48 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_163 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static BEC_4_6_TextString bevo_49 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_163, 6));
private static byte[] bels_164 = {0x69,0x66,0x20,0x28,0x63,0x61,0x6C,0x6C,0x49,0x64,0x20,0x3D,0x3D,0x20};
private static byte[] bels_165 = {0x29,0x20,0x7B};
private static byte[] bels_166 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x6D,0x5F};
private static byte[] bels_167 = {0x28};
private static BEC_4_3_MathInt bevo_50 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_168 = {0x20};
private static BEC_4_6_TextString bevo_51 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_168, 1));
private static byte[] bels_169 = {};
private static BEC_4_3_MathInt bevo_52 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_170 = {0x2C,0x20};
private static byte[] bels_171 = {};
private static byte[] bels_172 = {0x62,0x65,0x76,0x64,0x5F};
private static BEC_4_6_TextString bevo_53 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_172, 5));
private static BEC_4_3_MathInt bevo_54 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_173 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static BEC_4_6_TextString bevo_55 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_173, 7));
private static byte[] bels_174 = {0x5D};
private static BEC_4_6_TextString bevo_56 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_174, 1));
private static byte[] bels_175 = {0x29,0x3B};
private static byte[] bels_176 = {0x7D};
private static byte[] bels_177 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_178 = {0x7D};
private static byte[] bels_179 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static BEC_4_6_TextString bevo_57 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_179, 7));
private static byte[] bels_180 = {0x2E};
private static BEC_4_6_TextString bevo_58 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_180, 1));
private static byte[] bels_181 = {0x28};
private static byte[] bels_182 = {0x29,0x3B};
private static byte[] bels_183 = {0x7D};
private static byte[] bels_184 = {0x2F};
private static byte[] bels_185 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x66,0x69,0x72,0x73,0x74,0x53,0x6C,0x6F,0x74,0x4E,0x61,0x74,0x69,0x76,0x65,0x2D,0x2A};
private static byte[] bels_186 = {0x2A,0x2D,0x61,0x74,0x74,0x72,0x2D,0x20,0x2D,0x6E,0x61,0x74,0x69,0x76,0x65,0x53,0x6C,0x6F,0x74,0x73};
private static BEC_4_3_MathInt bevo_59 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_187 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bels_188 = {0x20,0x7B};
private static byte[] bels_189 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_190 = {0x28,0x29,0x3B};
private static byte[] bels_191 = {0x7D};
private static byte[] bels_192 = {0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bels_193 = {0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bels_194 = {0x20,0x7B};
private static byte[] bels_195 = {};
private static byte[] bels_196 = {0x20,0x3D,0x20};
private static byte[] bels_197 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_198 = {0x7D};
private static byte[] bels_199 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bels_200 = {0x20,0x7B};
private static byte[] bels_201 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_202 = {0x3B};
private static byte[] bels_203 = {0x7D};
private static byte[] bels_204 = {0x63,0x6C,0x6E,0x61,0x6D,0x65};
private static byte[] bels_205 = {0x63,0x6C,0x66,0x69,0x6C,0x65};
private static byte[] bels_206 = {0x62,0x65,0x63,0x63,0x5F};
private static BEC_4_6_TextString bevo_60 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_206, 5));
private static BEC_4_3_MathInt bevo_61 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_207 = {0x2C};
private static BEC_4_6_TextString bevo_62 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_207, 1));
private static byte[] bels_208 = {0x62,0x79,0x74,0x65,0x5B,0x5D,0x20,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bels_209 = {0x28,0x29};
private static byte[] bels_210 = {0x20,0x7B};
private static byte[] bels_211 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bels_212 = {0x3B};
private static byte[] bels_213 = {0x7D};
private static byte[] bels_214 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_215 = {0x3B};
private static byte[] bels_216 = {0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_217 = {0x3B};
private static byte[] bels_218 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_219 = {0x2F,0x2A,0x20,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_220 = {0x20,0x2A,0x2F};
private static byte[] bels_221 = {0x20,0x7B};
private static byte[] bels_222 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_223 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_224 = {0x20,0x7D};
private static byte[] bels_225 = {0x63,0x73};
private static byte[] bels_226 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_227 = {0x28,0x29,0x20,0x7B};
private static byte[] bels_228 = {0x20,0x7D};
private static byte[] bels_229 = {0x7D};
private static byte[] bels_230 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_63 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_230, 14));
private static byte[] bels_231 = {0x20};
private static BEC_4_6_TextString bevo_64 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_231, 1));
private static byte[] bels_232 = {};
private static byte[] bels_233 = {};
private static byte[] bels_234 = {0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_235 = {0x20,0x2F,0x2A,0x20};
private static byte[] bels_236 = {0x20,0x2A,0x2F,0x20,0x7B};
private static byte[] bels_237 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_238 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x68,0x69,0x73,0x3B};
private static BEC_4_3_MathInt bevo_65 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_239 = {0x5B,0x5D,0x20,0x62,0x65,0x76,0x64,0x5F,0x78,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_240 = {0x5B};
private static byte[] bels_241 = {0x5D,0x3B};
private static byte[] bels_242 = {0x7D,0x20,0x2F,0x2A,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x65,0x6E,0x64,0x2A,0x2F};
private static byte[] bels_243 = {0x7D,0x20,0x2F,0x2A,0x20};
private static byte[] bels_244 = {0x20,0x2A,0x2F};
private static byte[] bels_245 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_246 = {};
private static byte[] bels_247 = {0x21,0x28};
private static byte[] bels_248 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_249 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x26,0x26,0x20};
private static byte[] bels_250 = {0x20,0x26,0x26,0x20};
private static byte[] bels_251 = {0x6A,0x73};
private static byte[] bels_252 = {0x28};
private static byte[] bels_253 = {0x6A,0x73};
private static byte[] bels_254 = {0x29};
private static byte[] bels_255 = {0x2E,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static byte[] bels_256 = {0x29};
private static byte[] bels_257 = {0x69,0x66,0x20,0x28};
private static byte[] bels_258 = {0x29};
private static byte[] bels_259 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_260 = {0x69,0x66,0x20,0x28};
private static byte[] bels_261 = {0x29};
private static byte[] bels_262 = {0x3B};
private static BEC_4_6_TextString bevo_66 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_262, 1));
private static byte[] bels_263 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x6C,0x69,0x74,0x65,0x72,0x61,0x6C,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_264 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_265 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66};
private static byte[] bels_266 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_267 = {0x43,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x20,0x74,0x6F,0x20,0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_268 = {};
private static byte[] bels_269 = {0x20};
private static BEC_4_6_TextString bevo_67 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_269, 1));
private static byte[] bels_270 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_68 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_270, 3));
private static byte[] bels_271 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_272 = {0x28};
private static BEC_4_6_TextString bevo_69 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_272, 1));
private static byte[] bels_273 = {0x29};
private static BEC_4_6_TextString bevo_70 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_273, 1));
private static byte[] bels_274 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_275 = {0x29,0x3B};
private static byte[] bels_276 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_4_6_TextString bevo_71 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_276, 5));
private static byte[] bels_277 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_4_3_MathInt bevo_72 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static byte[] bels_278 = {0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x20,0x63,0x61,0x6C,0x6C,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20};
private static BEC_4_6_TextString bevo_73 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_278, 51));
private static byte[] bels_279 = {0x20,0x21,0x21,0x21};
private static byte[] bels_280 = {0x21,0x21,0x20};
private static byte[] bels_281 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_282 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_283 = {0x73,0x65,0x6C,0x66,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x74,0x6F};
private static byte[] bels_284 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_285 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_286 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_287 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_288 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_289 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_290 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_291 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_292 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x75,0x6E,0x64,0x65,0x66,0x2F,0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] bels_293 = {0x75};
private static byte[] bels_294 = {0x69,0x66,0x20,0x28};
private static byte[] bels_295 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static byte[] bels_296 = {0x20,0x7D,0x20,0x65,0x6C,0x73,0x65,0x20,0x7B,0x20};
private static byte[] bels_297 = {0x7D};
private static byte[] bels_298 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_299 = {};
private static byte[] bels_300 = {0x20};
private static BEC_4_6_TextString bevo_74 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_300, 1));
private static byte[] bels_301 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_302 = {0x3B};
private static byte[] bels_303 = {0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_304 = {0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_305 = {0x75,0x6E,0x64,0x65,0x66,0x5F,0x31};
private static byte[] bels_306 = {0x75,0x6E,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x5F,0x31};
private static byte[] bels_307 = {0x5F};
private static byte[] bels_308 = {0x42,0x61,0x64,0x20,0x6E,0x61,0x6D,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_4_6_TextString bevo_75 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_308, 18));
private static byte[] bels_309 = {0x20};
private static BEC_4_6_TextString bevo_76 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_309, 1));
private static byte[] bels_310 = {0x20};
private static BEC_4_6_TextString bevo_77 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_310, 1));
private static byte[] bels_311 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_312 = {0x73,0x75,0x70,0x65,0x72};
private static BEC_4_3_MathInt bevo_78 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_79 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_313 = {0x2C,0x20};
private static byte[] bels_314 = {0x20};
private static byte[] bels_315 = {0x62,0x65,0x76,0x64,0x5F,0x78,0x5B};
private static byte[] bels_316 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_317 = {0x3B};
private static byte[] bels_318 = {0x69,0x73,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x69,0x73,0x54,0x79,0x70,0x65,0x64};
private static byte[] bels_319 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_320 = {};
private static byte[] bels_321 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_80 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_321, 3));
private static byte[] bels_322 = {0x3B};
private static BEC_4_6_TextString bevo_81 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_322, 1));
private static byte[] bels_323 = {0x20};
private static BEC_4_6_TextString bevo_82 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_323, 1));
private static byte[] bels_324 = {};
private static byte[] bels_325 = {0x20,0x3D,0x20};
private static BEC_4_6_TextString bevo_83 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_325, 3));
private static byte[] bels_326 = {0x6A,0x76};
private static byte[] bels_327 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bels_328 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bels_329 = {0x63,0x73};
private static byte[] bels_330 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_331 = {0x29,0x29,0x20,0x7B};
private static byte[] bels_332 = {0x69,0x66,0x20,0x28};
private static BEC_4_6_TextString bevo_84 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_332, 4));
private static byte[] bels_333 = {0x20,0x3D,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x29,0x20,0x7B};
private static BEC_4_6_TextString bevo_85 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_333, 11));
private static byte[] bels_334 = {0x62,0x65,0x6C,0x73,0x5F};
private static BEC_4_6_TextString bevo_86 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_334, 5));
private static byte[] bels_335 = {0x5B};
private static BEC_4_6_TextString bevo_87 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_335, 1));
private static byte[] bels_336 = {0x5D};
private static BEC_4_6_TextString bevo_88 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_336, 1));
private static BEC_4_3_MathInt bevo_89 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_337 = {0x2C};
private static BEC_4_6_TextString bevo_90 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_337, 1));
private static byte[] bels_338 = {0x74,0x72,0x75,0x65};
private static byte[] bels_339 = {0x55,0x4E,0x48,0x41,0x4E,0x44,0x4C,0x45,0x44,0x20,0x4C,0x49,0x54,0x45,0x52,0x41,0x4C,0x20,0x54,0x59,0x50,0x45,0x20};
private static BEC_4_6_TextString bevo_91 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_339, 23));
private static byte[] bels_340 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_92 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_340, 4));
private static byte[] bels_341 = {0x28,0x29};
private static BEC_4_6_TextString bevo_93 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_341, 2));
private static byte[] bels_342 = {0x28};
private static BEC_4_6_TextString bevo_94 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_342, 1));
private static byte[] bels_343 = {0x29};
private static BEC_4_6_TextString bevo_95 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_343, 1));
private static byte[] bels_344 = {0x20};
private static byte[] bels_345 = {0x6F,0x68,0x20,0x6E,0x6F,0x65,0x73,0x20,0x6F,0x6E,0x63,0x65,0x20,0x64,0x65,0x63,0x65,0x64,0x20};
private static BEC_4_6_TextString bevo_96 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_345, 19));
private static byte[] bels_346 = {0x74,0x72,0x75,0x65};
private static byte[] bels_347 = {0x3B};
private static byte[] bels_348 = {0x3B};
private static byte[] bels_349 = {0x2E};
private static byte[] bels_350 = {0x28};
private static byte[] bels_351 = {0x29,0x3B};
private static byte[] bels_352 = {0x2E};
private static byte[] bels_353 = {0x28};
private static byte[] bels_354 = {0x29,0x3B};
private static byte[] bels_355 = {0x2E};
private static byte[] bels_356 = {0x28};
private static byte[] bels_357 = {0x29,0x3B};
private static byte[] bels_358 = {0x2E};
private static byte[] bels_359 = {0x28};
private static byte[] bels_360 = {0x29,0x3B};
private static byte[] bels_361 = {};
private static byte[] bels_362 = {0x78};
private static BEC_4_3_MathInt bevo_97 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_363 = {0x2C,0x20,0x62,0x65,0x76,0x64,0x5F,0x78};
private static BEC_4_3_MathInt bevo_98 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_364 = {0x2C,0x20};
private static byte[] bels_365 = {};
private static byte[] bels_366 = {0x2E,0x62,0x65,0x6D,0x64,0x5F};
private static byte[] bels_367 = {0x28};
private static byte[] bels_368 = {0x2C,0x20};
private static byte[] bels_369 = {0x2E,0x62,0x65,0x76,0x6E,0x5F};
private static byte[] bels_370 = {0x29,0x3B};
private static byte[] bels_371 = {0x7D};
private static byte[] bels_372 = {0x6A,0x76};
private static byte[] bels_373 = {0x63,0x73};
private static byte[] bels_374 = {0x7D};
private static byte[] bels_375 = {0x3B};
private static byte[] bels_376 = {0x28};
private static byte[] bels_377 = {0x6A,0x73};
private static byte[] bels_378 = {0x62,0x65,0x5F,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_379 = {0x29};
private static byte[] bels_380 = {0x62,0x65,0x2E,0x42,0x45,0x4C,0x53,0x5F,0x42,0x61,0x73,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x49,0x74,0x5F,0x31,0x28};
private static byte[] bels_381 = {0x29};
private static byte[] bels_382 = {0x29};
private static byte[] bels_383 = {0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bels_384 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_99 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_384, 4));
private static byte[] bels_385 = {0x28};
private static BEC_4_6_TextString bevo_100 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_385, 1));
private static byte[] bels_386 = {0x29};
private static BEC_4_6_TextString bevo_101 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_386, 1));
private static byte[] bels_387 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_102 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_387, 4));
private static byte[] bels_388 = {0x28};
private static BEC_4_6_TextString bevo_103 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_388, 1));
private static byte[] bels_389 = {0x66,0x29};
private static BEC_4_6_TextString bevo_104 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_389, 2));
private static byte[] bels_390 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_105 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_390, 4));
private static byte[] bels_391 = {0x28};
private static BEC_4_6_TextString bevo_106 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_391, 1));
private static byte[] bels_392 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_107 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_392, 2));
private static byte[] bels_393 = {0x29};
private static BEC_4_6_TextString bevo_108 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_393, 1));
private static byte[] bels_394 = {0x6E,0x65,0x77,0x20};
private static BEC_4_6_TextString bevo_109 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_394, 4));
private static byte[] bels_395 = {0x28};
private static BEC_4_6_TextString bevo_110 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_395, 1));
private static byte[] bels_396 = {0x2C,0x20};
private static BEC_4_6_TextString bevo_111 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_396, 2));
private static byte[] bels_397 = {0x29};
private static BEC_4_6_TextString bevo_112 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_397, 1));
private static byte[] bels_398 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x62,0x79,0x74,0x65,0x5B,0x5D,0x20};
private static byte[] bels_399 = {0x20,0x3D,0x20,0x7B};
private static byte[] bels_400 = {0x7D,0x3B};
private static byte[] bels_401 = {0x62,0x72,0x65,0x61,0x6B,0x3B};
private static byte[] bels_402 = {0x77,0x68,0x69,0x6C,0x65,0x20,0x28,0x74,0x72,0x75,0x65,0x29};
private static byte[] bels_403 = {0x20,0x65,0x6C,0x73,0x65,0x20};
private static byte[] bels_404 = {0x74,0x72,0x79,0x20};
private static byte[] bels_405 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_406 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_407 = {0x74,0x68,0x69,0x73};
private static byte[] bels_408 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_409 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bels_410 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_411 = {0x74,0x68,0x69,0x73};
private static byte[] bels_412 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_413 = {};
private static byte[] bels_414 = {};
private static byte[] bels_415 = {};
private static byte[] bels_416 = {};
private static byte[] bels_417 = {};
private static byte[] bels_418 = {};
private static byte[] bels_419 = {};
private static byte[] bels_420 = {};
private static BEC_4_6_TextString bevo_113 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_420, 0));
private static byte[] bels_421 = {0x5F};
private static BEC_4_6_TextString bevo_114 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_421, 1));
private static byte[] bels_422 = {0x5F};
private static byte[] bels_423 = {0x42,0x45,0x43,0x5F};
private static BEC_4_6_TextString bevo_115 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_423, 4));
private static byte[] bels_424 = {0x2E};
private static BEC_4_6_TextString bevo_116 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_424, 1));
private static byte[] bels_425 = {0x62,0x65,0x2E};
private static BEC_4_6_TextString bevo_117 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_425, 3));
public static new BEC_5_10_BuildEmitCommon bevs_inst;
public BEC_5_11_BuildClassConfig bevp_classConf;
public BEC_5_11_BuildClassConfig bevp_parentConf;
public BEC_4_6_TextString bevp_emitLang;
public BEC_4_6_TextString bevp_fileExt;
public BEC_4_6_TextString bevp_exceptDec;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_q;
public BEC_9_3_ContainerMap bevp_ccCache;
public BEC_5_8_BuildNamePath bevp_objectNp;
public BEC_5_8_BuildNamePath bevp_boolNp;
public BEC_5_8_BuildNamePath bevp_intNp;
public BEC_5_8_BuildNamePath bevp_floatNp;
public BEC_5_8_BuildNamePath bevp_stringNp;
public BEC_4_6_TextString bevp_trueValue;
public BEC_4_6_TextString bevp_falseValue;
public BEC_4_6_TextString bevp_instanceEqual;
public BEC_4_6_TextString bevp_instanceNotEqual;
public BEC_4_6_TextString bevp_libEmitName;
public BEC_4_6_TextString bevp_fullLibEmitName;
public BEC_2_4_4_IOFilePath bevp_libEmitPath;
public BEC_4_6_TextString bevp_methodBody;
public BEC_4_3_MathInt bevp_lastMethodBodySize;
public BEC_4_3_MathInt bevp_lastMethodBodyLines;
public BEC_9_5_ContainerArray bevp_methodCalls;
public BEC_4_3_MathInt bevp_methodCatch;
public BEC_4_3_MathInt bevp_maxDynArgs;
public BEC_4_3_MathInt bevp_maxSpillArgsLen;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_BuildNode bevp_lastCall;
public BEC_9_3_ContainerSet bevp_callNames;
public BEC_5_11_BuildClassConfig bevp_objectCc;
public BEC_5_11_BuildClassConfig bevp_boolCc;
public BEC_4_6_TextString bevp_instOf;
public BEC_9_3_ContainerMap bevp_smnlcs;
public BEC_9_3_ContainerMap bevp_smnlecs;
public BEC_9_5_ContainerArray bevp_classesInDepthOrder;
public BEC_4_3_MathInt bevp_lineCount;
public BEC_4_6_TextString bevp_methods;
public BEC_9_5_ContainerArray bevp_classCalls;
public BEC_4_3_MathInt bevp_lastMethodsSize;
public BEC_4_3_MathInt bevp_lastMethodsLines;
public BEC_5_4_BuildNode bevp_mnode;
public BEC_5_11_BuildClassConfig bevp_returnType;
public BEC_5_6_BuildMtdSyn bevp_msyn;
public BEC_4_6_TextString bevp_preClass;
public BEC_4_6_TextString bevp_classEmits;
public BEC_4_6_TextString bevp_onceDecs;
public BEC_4_3_MathInt bevp_onceCount;
public BEC_4_6_TextString bevp_propertyDecs;
public BEC_5_4_BuildNode bevp_cnode;
public BEC_5_8_BuildClassSyn bevp_csyn;
public BEC_4_6_TextString bevp_dynMethods;
public BEC_4_6_TextString bevp_ccMethods;
public BEC_9_5_ContainerArray bevp_superCalls;
public BEC_4_3_MathInt bevp_nativeCSlots;
public BEC_4_6_TextString bevp_inFilePathed;
public virtual BEC_6_6_SystemObject bem_new_1(BEC_5_5_BuildBuild beva__build) {
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
bevp_build = beva__build;
bevp_nl = bevp_build.bem_nlGet_0();
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_q = bevt_0_tmpvar_phold.bem_quoteGet_0();
bevp_ccCache = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_0));
bevp_objectNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_1));
bevp_boolNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_2));
bevp_intNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_3));
bevp_floatNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_4));
bevp_stringNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_1(bevt_5_tmpvar_phold);
bevp_trueValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(34, bels_5));
bevp_falseValue = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_6));
bevp_instanceEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_7));
bevp_instanceNotEqual = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_8));
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_libEmitName = (BEC_4_6_TextString) this.bem_libEmitName_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevp_fullLibEmitName = (BEC_4_6_TextString) this.bem_fullLibEmitName_1(bevt_7_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_copy_0();
bevt_13_tmpvar_phold = this.bem_emitLangGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_9));
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = this.bem_libEmitName_1(bevt_16_tmpvar_phold);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_15_tmpvar_phold);
bevt_17_tmpvar_phold = bevp_libEmitName.bem_add_1(bevp_fileExt);
bevp_libEmitPath = (BEC_2_4_4_IOFilePath) bevt_8_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_17_tmpvar_phold);
bevp_methodBody = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_lastMethodBodySize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_methodCatch = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_maxDynArgs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(8));
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_callNames = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_objectCc = this.bem_getClassConfig_1(bevp_objectNp);
bevp_boolCc = this.bem_getClassConfig_1(bevp_boolNp);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_10));
bevt_18_tmpvar_phold = this.bem_emitting_1(bevt_19_tmpvar_phold);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevp_instOf = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_11));
} /* Line: 141 */
 else  /* Line: 142 */ {
bevp_instOf = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_12));
} /* Line: 143 */
bevp_smnlcs = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_smnlecs = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_runtimeInitGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitName_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_libName.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_libName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullLibEmitName_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_libNs_1(beva_libName);
bevt_3_tmpvar_phold = bevo_3;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_getClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_dname = null;
BEC_5_11_BuildClassConfig bevl_toRet = null;
BEC_5_7_BuildLibrary bevl_pack = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_IOFile bevt_7_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_8_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_2_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_2_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 170 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevl_pack = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_pack.bem_emitPathGet_0();
bevt_5_tmpvar_phold = bevl_pack.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_toRet.bem_synPathGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_fileGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_existsGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
return bevl_toRet;
} /* Line: 174 */
} /* Line: 172 */
 else  /* Line: 170 */ {
break;
} /* Line: 170 */
} /* Line: 170 */
bevt_9_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_10_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_9_tmpvar_phold, bevt_10_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 178 */
return bevl_toRet;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_dname = null;
BEC_5_11_BuildClassConfig bevl_toRet = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_dname = beva_np.bem_toString_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) bevp_ccCache.bem_get_1(bevl_dname);
if (bevl_toRet == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_1_tmpvar_phold = bevp_build.bem_emitPathGet_0();
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_toRet = (BEC_5_11_BuildClassConfig) (new BEC_5_11_BuildClassConfig()).bem_new_4(beva_np, this, bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
bevp_ccCache.bem_put_2(bevl_dname, bevl_toRet);
} /* Line: 188 */
return bevl_toRet;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_complete_1(BEC_5_4_BuildNode beva_clgen) {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_emvisit = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_2_tmpvar_phold = bevp_build.bem_printPlacesGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 194 */ {
bevt_4_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_clgen.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 195 */
bevt_7_tmpvar_phold = beva_clgen.bem_transUnitGet_0();
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_2(bevp_build, (BEC_5_4_BuildNode) bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_9_tmpvar_phold = bevo_5;
bevt_9_tmpvar_phold.bem_echo_0();
} /* Line: 203 */
bevl_emvisit = (new BEC_5_5_6_BuildVisitRewind()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_10_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_11_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 211 */
bevl_emvisit = (new BEC_5_5_9_BuildVisitTypeCheck()).bem_new_0();
bevl_emvisit.bemd_1(2017492794, BEL_4_Base.bevn_emitterSet_1, this);
bevl_emvisit.bemd_1(481929786, BEL_4_Base.bevn_buildSet_1, bevp_build);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevl_emvisit);
bevt_12_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_13_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold.bem_echo_0();
bevt_14_tmpvar_phold = bevo_8;
bevt_14_tmpvar_phold.bem_print_0();
} /* Line: 220 */
bevt_15_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, this);
bevt_16_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 226 */ {
} /* Line: 226 */
bevt_17_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 230 */ {
} /* Line: 230 */
this.bem_buildStackLines_1(beva_clgen);
bevt_18_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 234 */ {
} /* Line: 234 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_doEmit_0() {
BEC_9_3_ContainerMap bevl_depthClasses = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_4_6_TextString bevl_clName = null;
BEC_5_4_BuildNode bevl_clnode = null;
BEC_4_3_MathInt bevl_depth = null;
BEC_9_5_ContainerArray bevl_classes = null;
BEC_9_5_ContainerArray bevl_depths = null;
BEC_2_4_6_IOFileWriter bevl_cle = null;
BEC_4_6_TextString bevl_bns = null;
BEC_4_6_TextString bevl_cb = null;
BEC_4_6_TextString bevl_idec = null;
BEC_4_6_TextString bevl_nlcs = null;
BEC_4_6_TextString bevl_nlecs = null;
BEC_5_4_LogicBool bevl_firstNlc = null;
BEC_4_3_MathInt bevl_lastNlc = null;
BEC_4_3_MathInt bevl_lastNlec = null;
BEC_4_6_TextString bevl_lineInfo = null;
BEC_5_4_BuildNode bevl_cc = null;
BEC_4_6_TextString bevl_nlcNName = null;
BEC_4_6_TextString bevl_smpref = null;
BEC_4_6_TextString bevl_ce = null;
BEC_4_6_TextString bevl_en = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_8_tmpvar_phold = null;
BEC_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_4_3_MathInt bevt_138_tmpvar_phold = null;
bevl_depthClasses = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevt_6_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_parseOrderClassNamesGet_0();
bevl_ci = bevt_5_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 245 */ {
bevt_7_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 245 */ {
bevl_clName = (BEC_4_6_TextString) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_classesGet_0();
bevl_clnode = (BEC_5_4_BuildNode) bevt_8_tmpvar_phold.bem_get_1(bevl_clName);
bevt_11_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_depth = (BEC_4_3_MathInt) bevt_10_tmpvar_phold.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevl_classes = (BEC_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
if (bevl_classes == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevl_classes = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_depthClasses.bem_put_2(bevl_depth, bevl_classes);
} /* Line: 254 */
bevl_classes.bem_addValue_1(bevl_clnode);
} /* Line: 256 */
 else  /* Line: 245 */ {
break;
} /* Line: 245 */
} /* Line: 245 */
bevl_depths = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_ci = bevl_depthClasses.bem_keyIteratorGet_0();
while (true)
 /* Line: 260 */ {
bevt_13_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevl_depth = (BEC_4_3_MathInt) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_depths.bem_addValue_1(bevl_depth);
} /* Line: 262 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevl_depths = (BEC_9_5_ContainerArray) bevl_depths.bem_sort_0();
bevp_classesInDepthOrder = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevt_0_tmpvar_loop = bevl_depths.bem_iteratorGet_0();
while (true)
 /* Line: 269 */ {
bevt_14_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 269 */ {
bevl_depth = (BEC_4_3_MathInt) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_classes = (BEC_9_5_ContainerArray) bevl_depthClasses.bem_get_1(bevl_depth);
bevt_1_tmpvar_loop = bevl_classes.bem_iteratorGet_0();
while (true)
 /* Line: 271 */ {
bevt_15_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevl_clnode = (BEC_5_4_BuildNode) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_classesInDepthOrder.bem_addValue_1(bevl_clnode);
} /* Line: 272 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
} /* Line: 271 */
 else  /* Line: 269 */ {
break;
} /* Line: 269 */
} /* Line: 269 */
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 276 */ {
bevt_16_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 276 */ {
bevl_clnode = (BEC_5_4_BuildNode) bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_18_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_classConf = this.bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_printStepsGet_0();
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 281 */ {
} /* Line: 281 */
this.bem_complete_1(bevl_clnode);
bevl_cle = this.bem_getClassOutput_0();
bevl_bns = this.bem_beginNs_0();
bevt_20_tmpvar_phold = this.bem_countLines_1(bevl_bns);
bevp_lineCount.bem_addValue_1(bevt_20_tmpvar_phold);
bevl_cle.bem_write_1(bevl_bns);
bevt_21_tmpvar_phold = this.bem_countLines_1(bevp_preClass);
bevp_lineCount.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_cle.bem_write_1(bevp_preClass);
bevl_cb = this.bem_classBeginGet_0();
bevt_22_tmpvar_phold = this.bem_countLines_1(bevl_cb);
bevp_lineCount.bem_addValue_1(bevt_22_tmpvar_phold);
bevl_cle.bem_write_1(bevl_cb);
bevt_23_tmpvar_phold = this.bem_countLines_1(bevp_classEmits);
bevp_lineCount.bem_addValue_1(bevt_23_tmpvar_phold);
bevl_cle.bem_write_1(bevp_classEmits);
bevt_24_tmpvar_phold = this.bem_writeOnceDecs_2(bevl_cle, bevp_onceDecs);
bevp_lineCount.bem_addValue_1((BEC_4_3_MathInt) bevt_24_tmpvar_phold);
bevl_idec = this.bem_initialDecGet_0();
bevt_25_tmpvar_phold = this.bem_countLines_1(bevl_idec);
bevp_lineCount.bem_addValue_1(bevt_25_tmpvar_phold);
bevl_cle.bem_write_1(bevl_idec);
bevt_26_tmpvar_phold = this.bem_countLines_1(bevp_propertyDecs);
bevp_lineCount.bem_addValue_1(bevt_26_tmpvar_phold);
bevl_cle.bem_write_1(bevp_propertyDecs);
bevl_nlcs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_nlecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_firstNlc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_22));
bevl_lineInfo = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_2_tmpvar_loop = bevp_classCalls.bem_iteratorGet_0();
while (true)
 /* Line: 335 */ {
bevt_28_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 335 */ {
bevl_cc = (BEC_5_4_BuildNode) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_29_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_29_tmpvar_phold.bem_addValue_1(bevp_lineCount);
bevt_30_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_30_tmpvar_phold.bem_incrementValue_0();
if (bevl_lastNlc == null) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_33_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_32_tmpvar_phold = bevl_lastNlc.bem_notEquals_1(bevt_33_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_35_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_34_tmpvar_phold = bevl_lastNlec.bem_notEquals_1(bevt_35_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 338 */ {
if (bevl_firstNlc.bevi_bool) /* Line: 340 */ {
bevl_firstNlc = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_23));
bevl_nlcs.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_24));
bevl_nlecs.bem_addValue_1(bevt_37_tmpvar_phold);
} /* Line: 344 */
bevt_38_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevl_nlcs.bem_addValue_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevl_nlecs.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 347 */
bevl_lastNlc = bevl_cc.bem_nlcGet_0();
bevl_lastNlec = bevl_cc.bem_nlecGet_0();
bevt_48_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_46_tmpvar_phold = (BEC_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_47_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_25));
bevt_45_tmpvar_phold = (BEC_4_6_TextString) bevt_46_tmpvar_phold.bem_addValue_1(bevt_49_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cc.bem_heldGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_44_tmpvar_phold = (BEC_4_6_TextString) bevt_45_tmpvar_phold.bem_addValue_1(bevt_50_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_26));
bevt_43_tmpvar_phold = (BEC_4_6_TextString) bevt_44_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = bevl_cc.bem_nlcGet_0();
bevt_42_tmpvar_phold = (BEC_4_6_TextString) bevt_43_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_27));
bevt_41_tmpvar_phold = (BEC_4_6_TextString) bevt_42_tmpvar_phold.bem_addValue_1(bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_cc.bem_nlecGet_0();
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevt_41_tmpvar_phold.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 352 */
 else  /* Line: 335 */ {
break;
} /* Line: 335 */
} /* Line: 335 */
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_28));
bevt_56_tmpvar_phold = (BEC_4_6_TextString) bevl_lineInfo.bem_addValue_1(bevt_57_tmpvar_phold);
bevt_56_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_61_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_59_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_60_tmpvar_phold);
bevt_62_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bem_relEmitName_1(bevt_62_tmpvar_phold);
bevt_63_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_29));
bevl_nlcNName = (BEC_4_6_TextString) bevt_58_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_30));
bevt_64_tmpvar_phold = this.bem_emitting_1(bevt_65_tmpvar_phold);
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 358 */ {
bevt_69_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_68_tmpvar_phold);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_emitNameGet_0();
bevt_70_tmpvar_phold = bevo_9;
bevl_smpref = bevt_66_tmpvar_phold.bem_add_1(bevt_70_tmpvar_phold);
bevl_nlcNName = bevl_smpref;
} /* Line: 361 */
bevt_73_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_75_tmpvar_phold = bevo_10;
bevt_74_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_75_tmpvar_phold);
bevp_smnlcs.bem_put_2(bevt_71_tmpvar_phold, bevt_74_tmpvar_phold);
bevt_78_tmpvar_phold = bevl_clnode.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_80_tmpvar_phold = bevo_11;
bevt_79_tmpvar_phold = bevl_nlcNName.bem_add_1(bevt_80_tmpvar_phold);
bevp_smnlecs.bem_put_2(bevt_76_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_82_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_34));
bevt_81_tmpvar_phold = this.bem_emitting_1(bevt_82_tmpvar_phold);
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevt_84_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevt_86_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_35));
bevt_85_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_86_tmpvar_phold);
bevt_85_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 369 */
 else  /* Line: 370 */ {
bevt_88_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(34, bels_36));
bevt_87_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_87_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 371 */
} /* Line: 368 */
bevt_90_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_37));
bevt_89_tmpvar_phold = this.bem_emitting_1(bevt_90_tmpvar_phold);
if (bevt_89_tmpvar_phold.bevi_bool) /* Line: 374 */ {
bevt_92_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(30, bels_38));
bevt_91_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_92_tmpvar_phold);
bevt_91_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 375 */
bevt_94_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_39));
bevt_93_tmpvar_phold = this.bem_emitting_1(bevt_94_tmpvar_phold);
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevt_95_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_96_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_40));
bevt_95_tmpvar_phold.bem_addValue_1(bevt_96_tmpvar_phold);
bevt_100_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_41));
bevt_99_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_98_tmpvar_phold = (BEC_4_6_TextString) bevt_99_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_101_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_42));
bevt_97_tmpvar_phold = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevt_101_tmpvar_phold);
bevt_97_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 379 */
 else  /* Line: 380 */ {
bevt_105_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_43));
bevt_104_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_105_tmpvar_phold);
bevt_103_tmpvar_phold = (BEC_4_6_TextString) bevt_104_tmpvar_phold.bem_addValue_1(bevl_nlcs);
bevt_106_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_44));
bevt_102_tmpvar_phold = (BEC_4_6_TextString) bevt_103_tmpvar_phold.bem_addValue_1(bevt_106_tmpvar_phold);
bevt_102_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 381 */
bevt_108_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_45));
bevt_107_tmpvar_phold = this.bem_emitting_1(bevt_108_tmpvar_phold);
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_110_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 384 */ {
bevt_112_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_46));
bevt_111_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_112_tmpvar_phold);
bevt_111_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 385 */
 else  /* Line: 386 */ {
bevt_114_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(35, bels_47));
bevt_113_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_114_tmpvar_phold);
bevt_113_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 387 */
} /* Line: 384 */
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_48));
bevt_115_tmpvar_phold = this.bem_emitting_1(bevt_116_tmpvar_phold);
if (bevt_115_tmpvar_phold.bevi_bool) /* Line: 390 */ {
bevt_118_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(31, bels_49));
bevt_117_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_118_tmpvar_phold);
bevt_117_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 391 */
bevt_120_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_50));
bevt_119_tmpvar_phold = this.bem_emitting_1(bevt_120_tmpvar_phold);
if (bevt_119_tmpvar_phold.bevi_bool) /* Line: 393 */ {
bevt_121_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevl_smpref);
bevt_122_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_51));
bevt_121_tmpvar_phold.bem_addValue_1(bevt_122_tmpvar_phold);
bevt_126_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_52));
bevt_125_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_126_tmpvar_phold);
bevt_124_tmpvar_phold = (BEC_4_6_TextString) bevt_125_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_127_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_53));
bevt_123_tmpvar_phold = (BEC_4_6_TextString) bevt_124_tmpvar_phold.bem_addValue_1(bevt_127_tmpvar_phold);
bevt_123_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 395 */
 else  /* Line: 396 */ {
bevt_131_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_54));
bevt_130_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_131_tmpvar_phold);
bevt_129_tmpvar_phold = (BEC_4_6_TextString) bevt_130_tmpvar_phold.bem_addValue_1(bevl_nlecs);
bevt_132_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_55));
bevt_128_tmpvar_phold = (BEC_4_6_TextString) bevt_129_tmpvar_phold.bem_addValue_1(bevt_132_tmpvar_phold);
bevt_128_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 397 */
bevp_methods.bem_addValue_1(bevl_lineInfo);
bevt_133_tmpvar_phold = this.bem_countLines_1(bevp_methods);
bevp_lineCount.bem_addValue_1(bevt_133_tmpvar_phold);
bevl_cle.bem_write_1(bevp_methods);
bevt_134_tmpvar_phold = this.bem_useDynMethodsGet_0();
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 407 */ {
bevt_135_tmpvar_phold = this.bem_countLines_1(bevp_dynMethods);
bevp_lineCount.bem_addValue_1(bevt_135_tmpvar_phold);
bevl_cle.bem_write_1(bevp_dynMethods);
} /* Line: 409 */
bevt_136_tmpvar_phold = this.bem_countLines_1(bevp_ccMethods);
bevp_lineCount.bem_addValue_1(bevt_136_tmpvar_phold);
bevl_cle.bem_write_1(bevp_ccMethods);
bevl_ce = this.bem_classEndGet_0();
bevt_137_tmpvar_phold = this.bem_countLines_1(bevl_ce);
bevp_lineCount.bem_addValue_1(bevt_137_tmpvar_phold);
bevl_cle.bem_write_1(bevl_ce);
bevl_en = this.bem_endNs_0();
bevt_138_tmpvar_phold = this.bem_countLines_1(bevl_en);
bevp_lineCount.bem_addValue_1(bevt_138_tmpvar_phold);
bevl_cle.bem_write_1(bevl_en);
this.bem_finishClassOutput_1(bevl_cle);
} /* Line: 427 */
 else  /* Line: 276 */ {
break;
} /* Line: 276 */
} /* Line: 276 */
this.bem_emitLib_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_writeOnceDecs_2(BEC_6_6_SystemObject beva_cle, BEC_6_6_SystemObject beva_onceDecs) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
beva_cle.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_onceDecs);
bevt_0_tmpvar_phold = this.bem_countLines_1((BEC_4_6_TextString) beva_onceDecs);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_IOFile bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_4_IOFile bevt_5_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_IOFile bevt_9_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lineCount = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bem_copy_0();
bevt_4_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_fileGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_existsGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_not_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 446 */ {
bevt_6_tmpvar_phold = bevp_classConf.bem_classDirGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_fileGet_0();
bevt_5_tmpvar_phold.bem_makeDirs_0();
} /* Line: 447 */
bevt_10_tmpvar_phold = bevp_classConf.bem_classPathGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_fileGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_writerGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_2_4_6_IOFileWriter) bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_finishClassOutput_1(BEC_2_4_6_IOFileWriter beva_cle) {
beva_cle.bem_close_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_IOFile bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_writerGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
return (BEC_2_4_6_IOFileWriter) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_finishLibOutput_1(BEC_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_klassDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_56));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_spropDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_57));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_overrideSmtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_58));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_baseSmtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_59));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_baseMtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_60));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_overrideMtdDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_61));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_propDecGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_62));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_emitting_1(BEC_4_6_TextString beva_lang) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(beva_lang);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 493 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 494 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLib_0() {
BEC_4_6_TextString bevl_getNames = null;
BEC_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_5_11_BuildClassConfig bevl_maincc = null;
BEC_4_6_TextString bevl_main = null;
BEC_2_4_6_IOFileWriter bevl_libe = null;
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_initLibs = null;
BEC_5_7_BuildLibrary bevl_bl = null;
BEC_4_6_TextString bevl_typeInstances = null;
BEC_4_6_TextString bevl_notNullInitConstruct = null;
BEC_4_6_TextString bevl_notNullInitDefault = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_4_6_TextString bevl_nc = null;
BEC_4_6_TextString bevl_callName = null;
BEC_4_6_TextString bevl_smap = null;
BEC_4_6_TextString bevl_smk = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_89_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_4_6_TextString bevt_128_tmpvar_phold = null;
BEC_4_6_TextString bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_9_3_11_ContainerSetKeyIterator bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_4_6_TextString bevt_147_tmpvar_phold = null;
BEC_4_6_TextString bevt_148_tmpvar_phold = null;
BEC_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_152_tmpvar_phold = null;
BEC_4_6_TextString bevt_153_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_4_6_TextString bevt_157_tmpvar_phold = null;
BEC_4_6_TextString bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_4_6_TextString bevt_160_tmpvar_phold = null;
BEC_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_169_tmpvar_phold = null;
BEC_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_4_6_TextString bevt_189_tmpvar_phold = null;
BEC_4_6_TextString bevt_190_tmpvar_phold = null;
BEC_4_6_TextString bevt_191_tmpvar_phold = null;
BEC_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_4_6_TextString bevt_193_tmpvar_phold = null;
BEC_4_6_TextString bevt_194_tmpvar_phold = null;
BEC_4_6_TextString bevt_195_tmpvar_phold = null;
BEC_4_6_TextString bevt_196_tmpvar_phold = null;
BEC_4_6_TextString bevt_197_tmpvar_phold = null;
BEC_4_6_TextString bevt_198_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_4_6_TextString bevt_205_tmpvar_phold = null;
BEC_4_6_TextString bevt_206_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_4_6_TextString bevt_208_tmpvar_phold = null;
BEC_4_6_TextString bevt_209_tmpvar_phold = null;
BEC_4_6_TextString bevt_210_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_211_tmpvar_phold = null;
bevl_getNames = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_mainClassNp = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_4_tmpvar_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_4_tmpvar_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_63));
bevt_5_tmpvar_phold = this.bem_mainStartGet_0();
bevl_main.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevp_fullLibEmitName);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_64));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_65));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_66));
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_9_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_67));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_68));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevl_main.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpvar_phold = this.bem_mainEndGet_0();
bevl_main.bem_addValue_1(bevt_21_tmpvar_phold);
bevl_libe = this.bem_getLibOutput_0();
bevt_22_tmpvar_phold = this.bem_beginNs_0();
bevl_libe.bem_write_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_69));
bevl_extends = this.bem_extend_1(bevt_23_tmpvar_phold);
bevt_28_tmpvar_phold = this.bem_klassDecGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevl_extends);
bevt_29_tmpvar_phold = bevo_12;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_24_tmpvar_phold);
bevt_33_tmpvar_phold = this.bem_spropDecGet_0();
bevt_34_tmpvar_phold = this.bem_boolTypeGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevo_13;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevt_35_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_30_tmpvar_phold);
bevl_initLibs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_36_tmpvar_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_0_tmpvar_loop = bevt_36_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 523 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 523 */ {
bevl_bl = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = bevl_bl.bem_libNameGet_0();
bevt_40_tmpvar_phold = this.bem_fullLibEmitName_1(bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) bevl_initLibs.bem_addValue_1(bevt_40_tmpvar_phold);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_72));
bevt_38_tmpvar_phold = (BEC_4_6_TextString) bevt_39_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_38_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 525 */
 else  /* Line: 523 */ {
break;
} /* Line: 523 */
} /* Line: 523 */
bevl_typeInstances = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 531 */ {
bevt_43_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 531 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_73));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 535 */ {
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(44, bels_74));
bevt_54_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_55_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) bevt_54_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_58_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) bevt_53_tmpvar_phold.bem_addValue_1(bevt_56_tmpvar_phold);
bevt_51_tmpvar_phold = (BEC_4_6_TextString) bevt_52_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_75));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_63_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_61_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_fullEmitNameGet_0();
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_60_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_4_6_TextString) bevt_48_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_76));
bevt_46_tmpvar_phold = (BEC_4_6_TextString) bevt_47_tmpvar_phold.bem_addValue_1(bevt_64_tmpvar_phold);
bevt_46_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 536 */
bevt_66_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_77));
bevt_65_tmpvar_phold = this.bem_emitting_1(bevt_66_tmpvar_phold);
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 538 */ {
bevt_74_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(40, bels_78));
bevt_73_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_74_tmpvar_phold);
bevt_72_tmpvar_phold = (BEC_4_6_TextString) bevt_73_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_77_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_71_tmpvar_phold = (BEC_4_6_TextString) bevt_72_tmpvar_phold.bem_addValue_1(bevt_75_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_4_6_TextString) bevt_71_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_78_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_79));
bevt_69_tmpvar_phold = (BEC_4_6_TextString) bevt_70_tmpvar_phold.bem_addValue_1(bevt_78_tmpvar_phold);
bevt_82_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_80_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_81_tmpvar_phold);
bevt_83_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_relEmitName_1(bevt_83_tmpvar_phold);
bevt_68_tmpvar_phold = (BEC_4_6_TextString) bevt_69_tmpvar_phold.bem_addValue_1(bevt_79_tmpvar_phold);
bevt_84_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_80));
bevt_67_tmpvar_phold = (BEC_4_6_TextString) bevt_68_tmpvar_phold.bem_addValue_1(bevt_84_tmpvar_phold);
bevt_67_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_81));
bevt_86_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_87_tmpvar_phold);
bevt_91_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_89_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_90_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_relEmitName_1(bevt_92_tmpvar_phold);
bevt_85_tmpvar_phold = (BEC_4_6_TextString) bevt_86_tmpvar_phold.bem_addValue_1(bevt_88_tmpvar_phold);
bevt_93_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_82));
bevt_85_tmpvar_phold.bem_addValue_1(bevt_93_tmpvar_phold);
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_83));
bevt_98_tmpvar_phold = (BEC_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_99_tmpvar_phold);
bevt_97_tmpvar_phold = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_100_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_84));
bevt_96_tmpvar_phold = (BEC_4_6_TextString) bevt_97_tmpvar_phold.bem_addValue_1(bevt_100_tmpvar_phold);
bevt_95_tmpvar_phold = (BEC_4_6_TextString) bevt_96_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_101_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(17, bels_85));
bevt_94_tmpvar_phold = (BEC_4_6_TextString) bevt_95_tmpvar_phold.bem_addValue_1(bevt_101_tmpvar_phold);
bevt_94_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 541 */
bevt_104_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 544 */ {
bevt_106_tmpvar_phold = bevo_14;
bevt_110_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_108_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_109_tmpvar_phold);
bevt_111_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bem_relEmitName_1(bevt_111_tmpvar_phold);
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevt_112_tmpvar_phold = bevo_15;
bevl_nc = bevt_105_tmpvar_phold.bem_add_1(bevt_112_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(65, bels_88));
bevt_115_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_114_tmpvar_phold = (BEC_4_6_TextString) bevt_115_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_89));
bevt_113_tmpvar_phold = (BEC_4_6_TextString) bevt_114_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_113_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(63, bels_90));
bevt_120_tmpvar_phold = (BEC_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_119_tmpvar_phold = (BEC_4_6_TextString) bevt_120_tmpvar_phold.bem_addValue_1(bevl_nc);
bevt_122_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_91));
bevt_118_tmpvar_phold = (BEC_4_6_TextString) bevt_119_tmpvar_phold.bem_addValue_1(bevt_122_tmpvar_phold);
bevt_118_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 547 */
} /* Line: 544 */
 else  /* Line: 531 */ {
break;
} /* Line: 531 */
} /* Line: 531 */
bevt_1_tmpvar_loop = bevp_callNames.bem_iteratorGet_0();
while (true)
 /* Line: 551 */ {
bevt_123_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 551 */ {
bevl_callName = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_128_tmpvar_phold = this.bem_spropDecGet_0();
bevt_129_tmpvar_phold = bevo_16;
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bem_add_1(bevt_129_tmpvar_phold);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bem_add_1(bevl_callName);
bevt_130_tmpvar_phold = bevo_17;
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bem_add_1(bevt_130_tmpvar_phold);
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_124_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_94));
bevt_137_tmpvar_phold = (BEC_4_6_TextString) bevl_getNames.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_95));
bevt_135_tmpvar_phold = (BEC_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_134_tmpvar_phold = (BEC_4_6_TextString) bevt_135_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_133_tmpvar_phold = (BEC_4_6_TextString) bevt_134_tmpvar_phold.bem_addValue_1(bevl_callName);
bevt_132_tmpvar_phold = (BEC_4_6_TextString) bevt_133_tmpvar_phold.bem_addValue_1(bevp_q);
bevt_140_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_96));
bevt_131_tmpvar_phold = (BEC_4_6_TextString) bevt_132_tmpvar_phold.bem_addValue_1(bevt_140_tmpvar_phold);
bevt_131_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 553 */
 else  /* Line: 551 */ {
break;
} /* Line: 551 */
} /* Line: 551 */
bevl_smap = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_141_tmpvar_phold = bevp_smnlcs.bem_keysGet_0();
bevt_2_tmpvar_loop = bevt_141_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 558 */ {
bevt_142_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_142_tmpvar_phold != null && bevt_142_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_142_tmpvar_phold).bevi_bool) /* Line: 558 */ {
bevl_smk = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_150_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_97));
bevt_149_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_150_tmpvar_phold);
bevt_152_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_151_tmpvar_phold = bevt_152_tmpvar_phold.bem_quoteGet_0();
bevt_148_tmpvar_phold = (BEC_4_6_TextString) bevt_149_tmpvar_phold.bem_addValue_1(bevt_151_tmpvar_phold);
bevt_147_tmpvar_phold = (BEC_4_6_TextString) bevt_148_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_154_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bem_quoteGet_0();
bevt_146_tmpvar_phold = (BEC_4_6_TextString) bevt_147_tmpvar_phold.bem_addValue_1(bevt_153_tmpvar_phold);
bevt_155_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_98));
bevt_145_tmpvar_phold = (BEC_4_6_TextString) bevt_146_tmpvar_phold.bem_addValue_1(bevt_155_tmpvar_phold);
bevt_156_tmpvar_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_144_tmpvar_phold = (BEC_4_6_TextString) bevt_145_tmpvar_phold.bem_addValue_1(bevt_156_tmpvar_phold);
bevt_157_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_99));
bevt_143_tmpvar_phold = (BEC_4_6_TextString) bevt_144_tmpvar_phold.bem_addValue_1(bevt_157_tmpvar_phold);
bevt_143_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_165_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(17, bels_100));
bevt_164_tmpvar_phold = (BEC_4_6_TextString) bevl_smap.bem_addValue_1(bevt_165_tmpvar_phold);
bevt_167_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_quoteGet_0();
bevt_163_tmpvar_phold = (BEC_4_6_TextString) bevt_164_tmpvar_phold.bem_addValue_1(bevt_166_tmpvar_phold);
bevt_162_tmpvar_phold = (BEC_4_6_TextString) bevt_163_tmpvar_phold.bem_addValue_1(bevl_smk);
bevt_169_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bem_quoteGet_0();
bevt_161_tmpvar_phold = (BEC_4_6_TextString) bevt_162_tmpvar_phold.bem_addValue_1(bevt_168_tmpvar_phold);
bevt_170_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_101));
bevt_160_tmpvar_phold = (BEC_4_6_TextString) bevt_161_tmpvar_phold.bem_addValue_1(bevt_170_tmpvar_phold);
bevt_171_tmpvar_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_159_tmpvar_phold = (BEC_4_6_TextString) bevt_160_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_172_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_102));
bevt_158_tmpvar_phold = (BEC_4_6_TextString) bevt_159_tmpvar_phold.bem_addValue_1(bevt_172_tmpvar_phold);
bevt_158_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 561 */
 else  /* Line: 558 */ {
break;
} /* Line: 558 */
} /* Line: 558 */
bevt_176_tmpvar_phold = this.bem_baseSmtdDecGet_0();
bevt_177_tmpvar_phold = bevo_18;
bevt_175_tmpvar_phold = bevt_176_tmpvar_phold.bem_add_1(bevt_177_tmpvar_phold);
bevt_174_tmpvar_phold = (BEC_4_6_TextString) bevt_175_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_179_tmpvar_phold = bevo_19;
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevp_nl);
bevt_173_tmpvar_phold = (BEC_4_6_TextString) bevt_174_tmpvar_phold.bem_addValue_1(bevt_178_tmpvar_phold);
bevl_libe.bem_write_1(bevt_173_tmpvar_phold);
bevt_181_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_105));
bevt_180_tmpvar_phold = this.bem_emitting_1(bevt_181_tmpvar_phold);
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 566 */ {
bevt_185_tmpvar_phold = bevo_20;
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_186_tmpvar_phold = bevo_21;
bevt_183_tmpvar_phold = bevt_184_tmpvar_phold.bem_add_1(bevt_186_tmpvar_phold);
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_182_tmpvar_phold);
} /* Line: 567 */
 else  /* Line: 566 */ {
bevt_188_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_108));
bevt_187_tmpvar_phold = this.bem_emitting_1(bevt_188_tmpvar_phold);
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 568 */ {
bevt_192_tmpvar_phold = bevo_22;
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bem_add_1(bevp_libEmitName);
bevt_193_tmpvar_phold = bevo_23;
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bem_add_1(bevt_193_tmpvar_phold);
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_189_tmpvar_phold);
} /* Line: 569 */
} /* Line: 566 */
bevt_195_tmpvar_phold = bevo_24;
bevt_194_tmpvar_phold = bevt_195_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_194_tmpvar_phold);
bevt_197_tmpvar_phold = bevo_25;
bevt_196_tmpvar_phold = bevt_197_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_196_tmpvar_phold);
bevt_198_tmpvar_phold = this.bem_runtimeInitGet_0();
bevl_libe.bem_write_1(bevt_198_tmpvar_phold);
bevl_libe.bem_write_1(bevl_getNames);
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_initLibs);
bevl_libe.bem_write_1(bevl_typeInstances);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_200_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_113));
bevt_199_tmpvar_phold = this.bem_emitting_1(bevt_200_tmpvar_phold);
if (bevt_199_tmpvar_phold.bevi_bool) /* Line: 580 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 580 */ {
bevt_202_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_114));
bevt_201_tmpvar_phold = this.bem_emitting_1(bevt_202_tmpvar_phold);
if (bevt_201_tmpvar_phold.bevi_bool) /* Line: 580 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 580 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 580 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 580 */ {
bevt_204_tmpvar_phold = bevo_26;
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_203_tmpvar_phold);
} /* Line: 582 */
bevt_206_tmpvar_phold = bevo_27;
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_205_tmpvar_phold);
bevt_207_tmpvar_phold = this.bem_mainInClassGet_0();
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 586 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 587 */
bevt_209_tmpvar_phold = bevo_28;
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bem_add_1(bevp_nl);
bevl_libe.bem_write_1(bevt_208_tmpvar_phold);
bevt_210_tmpvar_phold = this.bem_endNs_0();
bevl_libe.bem_write_1(bevt_210_tmpvar_phold);
bevt_211_tmpvar_phold = this.bem_mainOutsideNsGet_0();
if (bevt_211_tmpvar_phold.bevi_bool) /* Line: 593 */ {
bevl_libe.bem_write_1(bevl_main);
} /* Line: 594 */
this.bem_finishLibOutput_1(bevl_libe);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_procStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_29;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_mainInClassGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainStartGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_119));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mainEndGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_120));
bevt_1_tmpvar_phold = this.bem_emitting_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 620 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 620 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_121));
bevt_3_tmpvar_phold = this.bem_emitting_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 620 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 620 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 620 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 620 */ {
bevt_6_tmpvar_phold = bevo_30;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_5_tmpvar_phold;
} /* Line: 622 */
bevt_8_tmpvar_phold = bevo_31;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_boolTypeGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_124));
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bevp_methods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_classCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_lastMethodsSize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodsLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nameForVar_1(BEC_5_3_BuildVar beva_v) {
BEC_4_6_TextString bevl_prefix = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_v.bem_isTmpVarGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 646 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_125));
} /* Line: 647 */
 else  /* Line: 646 */ {
bevt_1_tmpvar_phold = beva_v.bem_isPropertyGet_0();
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 648 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_126));
} /* Line: 649 */
 else  /* Line: 646 */ {
bevt_2_tmpvar_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 650 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_127));
} /* Line: 651 */
 else  /* Line: 652 */ {
bevl_prefix = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_128));
} /* Line: 653 */
} /* Line: 646 */
} /* Line: 646 */
bevt_4_tmpvar_phold = beva_v.bem_nameGet_0();
bevt_3_tmpvar_phold = bevl_prefix.bem_add_1(bevt_4_tmpvar_phold);
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_typeDecForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_5_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_v.bem_isTypedGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 660 */ {
bevt_3_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_2_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_3_tmpvar_phold);
beva_b.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 661 */
 else  /* Line: 662 */ {
bevt_6_tmpvar_phold = beva_v.bem_namepathGet_0();
bevt_5_tmpvar_phold = this.bem_getClassConfig_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_relEmitName_1(bevt_7_tmpvar_phold);
beva_b.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 663 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_decForVar_2(BEC_4_6_TextString beva_b, BEC_5_3_BuildVar beva_v) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
this.bem_typeDecForVar_2(beva_b, beva_v);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_129));
beva_b.bem_addValue_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitNameForMethod_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_32;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitNameForCall_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_33;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptMethod_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_argDecs = null;
BEC_4_6_TextString bevl_varDecs = null;
BEC_5_4_LogicBool bevl_isFirstArg = null;
BEC_5_4_BuildNode bevl_ov = null;
BEC_5_8_BuildNamePath bevl_ertype = null;
BEC_4_6_TextString bevl_mtdDec = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_40_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
bevp_mnode = beva_node;
bevp_returnType = null;
bevt_2_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_4_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_msyn = (BEC_5_6_BuildMtdSyn) bevt_2_tmpvar_phold.bem_get_1(bevt_3_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_5_tmpvar_phold);
bevl_argDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_varDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_isFirstArg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_0_tmpvar_loop = bevt_7_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 695 */ {
bevt_9_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 695 */ {
bevl_ov = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_132));
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_13_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 696 */ {
bevt_16_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_133));
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_17_tmpvar_phold);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 696 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 696 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 696 */
 else  /* Line: 696 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 696 */ {
bevt_19_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 697 */ {
if (!(bevl_isFirstArg.bevi_bool)) /* Line: 698 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_134));
bevl_argDecs.bem_addValue_1(bevt_20_tmpvar_phold);
} /* Line: 699 */
bevl_isFirstArg = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_22_tmpvar_phold = bevl_ov.bem_heldGet_0();
if (bevt_22_tmpvar_phold == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 702 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_26_tmpvar_phold = bevl_ov.bem_toString_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_26_tmpvar_phold);
bevt_23_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_24_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_23_tmpvar_phold);
} /* Line: 703 */
bevt_27_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_argDecs, (BEC_5_3_BuildVar) bevt_27_tmpvar_phold);
} /* Line: 705 */
 else  /* Line: 706 */ {
bevt_28_tmpvar_phold = bevl_ov.bem_heldGet_0();
this.bem_decForVar_2(bevl_varDecs, (BEC_5_3_BuildVar) bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_136));
bevt_29_tmpvar_phold = this.bem_emitting_1(bevt_30_tmpvar_phold);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 708 */ {
bevt_32_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_137));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 709 */
 else  /* Line: 710 */ {
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_138));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevl_varDecs.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_33_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 711 */
} /* Line: 708 */
bevt_35_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_37_tmpvar_phold = bevl_ov.bem_heldGet_0();
bevt_36_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_37_tmpvar_phold);
bevt_35_tmpvar_phold.bemd_1(792634738, BEL_4_Base.bevn_nativeNameSet_1, bevt_36_tmpvar_phold);
} /* Line: 714 */
} /* Line: 696 */
 else  /* Line: 695 */ {
break;
} /* Line: 695 */
} /* Line: 695 */
bevl_ertype = bevp_msyn.bem_getEmitReturnType_2(bevp_csyn, bevp_build);
if (bevl_ertype == null) {
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_38_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 720 */ {
bevp_returnType = this.bem_getClassConfig_1(bevl_ertype);
} /* Line: 721 */
 else  /* Line: 722 */ {
bevp_returnType = bevp_objectCc;
} /* Line: 723 */
bevt_40_tmpvar_phold = bevp_msyn.bem_declarationGet_0();
bevt_41_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 727 */ {
bevl_mtdDec = this.bem_baseMtdDecGet_0();
} /* Line: 728 */
 else  /* Line: 729 */ {
bevl_mtdDec = this.bem_overrideMtdDecGet_0();
} /* Line: 730 */
bevt_42_tmpvar_phold = this.bem_emitNameForMethod_1(beva_node);
this.bem_startMethod_5(bevl_mtdDec, bevp_returnType, bevt_42_tmpvar_phold, bevl_argDecs, bevp_exceptDec);
bevp_methods.bem_addValue_1(bevl_varDecs);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_startMethod_5(BEC_4_6_TextString beva_mtdDec, BEC_5_11_BuildClassConfig beva_returnType, BEC_4_6_TextString beva_mtdName, BEC_4_6_TextString beva_argDecs, BEC_6_6_SystemObject beva_exceptDec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_5_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpvar_phold = beva_returnType.bem_relEmitName_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_139));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_mtdName);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_140));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_141));
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(beva_exceptDec);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_142));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isClose_1(BEC_5_8_BuildNamePath beva_np) {
BEC_5_8_BuildClassSyn bevl_orgsyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_orgsyn = bevp_build.bem_getSynNp_1(beva_np);
bevt_1_tmpvar_phold = bevp_build.bem_closeLibrariesGet_0();
bevt_2_tmpvar_phold = bevl_orgsyn.bem_libNameGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_has_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 751 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /* Line: 752 */
bevt_4_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptClass_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_te = null;
BEC_6_6_SystemObject bevl_jn = null;
BEC_5_8_BuildClassSyn bevl_psyn = null;
BEC_4_6_TextString bevl_inlang = null;
BEC_5_4_BuildNode bevl_innode = null;
BEC_4_3_MathInt bevl_ovcount = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_9_3_ContainerMap bevl_dynGen = null;
BEC_9_3_ContainerSet bevl_mq = null;
BEC_5_6_BuildMtdSyn bevl_msyn = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_9_3_ContainerMap bevl_dgm = null;
BEC_4_3_MathInt bevl_msh = null;
BEC_9_5_ContainerArray bevl_dgv = null;
BEC_9_3_7_ContainerMapMapNode bevl_dnode = null;
BEC_4_3_MathInt bevl_dnumargs = null;
BEC_4_6_TextString bevl_dmname = null;
BEC_4_6_TextString bevl_superArgs = null;
BEC_4_6_TextString bevl_args = null;
BEC_4_3_MathInt bevl_j = null;
BEC_9_3_7_ContainerMapMapNode bevl_msnode = null;
BEC_4_3_MathInt bevl_thisHash = null;
BEC_5_4_LogicBool bevl_dynConditions = null;
BEC_4_6_TextString bevl_mcall = null;
BEC_4_6_TextString bevl_constName = null;
BEC_4_3_MathInt bevl_vnumargs = null;
BEC_5_6_BuildVarSyn bevl_vsyn = null;
BEC_4_6_TextString bevl_vcast = null;
BEC_4_6_TextString bevl_vcma = null;
BEC_4_6_TextString bevl_varg = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_3_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_4_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_5_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_67_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_4_6_TextString bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_128_tmpvar_phold = null;
BEC_4_3_MathInt bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_4_6_TextString bevt_134_tmpvar_phold = null;
BEC_4_6_TextString bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_151_tmpvar_phold = null;
BEC_4_6_TextString bevt_152_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_153_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_156_tmpvar_phold = null;
BEC_4_3_MathInt bevt_157_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_4_3_MathInt bevt_160_tmpvar_phold = null;
BEC_4_3_MathInt bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_3_MathInt bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_4_6_TextString bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_4_6_TextString bevt_172_tmpvar_phold = null;
BEC_4_6_TextString bevt_173_tmpvar_phold = null;
BEC_4_6_TextString bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_4_6_TextString bevt_176_tmpvar_phold = null;
BEC_4_6_TextString bevt_177_tmpvar_phold = null;
BEC_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_4_6_TextString bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_4_6_TextString bevt_184_tmpvar_phold = null;
BEC_4_6_TextString bevt_185_tmpvar_phold = null;
BEC_4_6_TextString bevt_186_tmpvar_phold = null;
BEC_4_6_TextString bevt_187_tmpvar_phold = null;
BEC_4_6_TextString bevt_188_tmpvar_phold = null;
BEC_4_6_TextString bevt_189_tmpvar_phold = null;
bevp_preClass = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_classEmits = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_onceDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_onceCount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_propertyDecs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_cnode = beva_node;
bevt_10_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_csyn = (BEC_5_8_BuildClassSyn) bevt_10_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevp_dynMethods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_ccMethods = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevp_superCalls = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevp_nativeCSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_12_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_143));
bevp_inFilePathed = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bemd_1(450717861, BEL_4_Base.bevn_toStringWithSeparator_1, bevt_13_tmpvar_phold);
bevt_15_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_te = bevt_14_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevl_te == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 774 */ {
bevl_te = bevl_te.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 775 */ {
bevt_17_tmpvar_phold = bevl_te.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 775 */ {
bevl_jn = bevl_te.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_20_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_21_tmpvar_phold = this.bem_emitLangGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_21_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 777 */ {
bevt_23_tmpvar_phold = bevl_jn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_preClass.bem_addValue_1(bevt_22_tmpvar_phold);
} /* Line: 778 */
} /* Line: 777 */
 else  /* Line: 775 */ {
break;
} /* Line: 775 */
} /* Line: 775 */
} /* Line: 775 */
bevt_26_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 783 */ {
bevt_28_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevp_parentConf = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = bevp_build.bem_getSynNp_1(bevt_29_tmpvar_phold);
} /* Line: 785 */
 else  /* Line: 786 */ {
bevp_parentConf = null;
} /* Line: 787 */
bevt_33_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
if (bevt_32_tmpvar_phold == null) {
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 791 */ {
bevl_inlang = this.bem_emitLangGet_0();
bevt_35_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevt_0_tmpvar_loop = bevt_34_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 793 */ {
bevt_36_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 793 */ {
bevl_innode = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_38_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_nativeCSlots = this.bem_getNativeCSlots_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_41_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_inlang);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 796 */ {
bevt_43_tmpvar_phold = bevl_innode.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_classEmits.bem_addValue_1(bevt_42_tmpvar_phold);
} /* Line: 797 */
} /* Line: 796 */
 else  /* Line: 793 */ {
break;
} /* Line: 793 */
} /* Line: 793 */
} /* Line: 793 */
if (bevl_psyn == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 802 */ {
bevt_46_tmpvar_phold = bevo_35;
bevt_45_tmpvar_phold = bevp_nativeCSlots.bem_greater_1(bevt_46_tmpvar_phold);
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 802 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 802 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 802 */
 else  /* Line: 802 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 802 */ {
bevt_48_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_sizeGet_0();
bevp_nativeCSlots = bevp_nativeCSlots.bem_subtract_1(bevt_47_tmpvar_phold);
bevt_50_tmpvar_phold = bevo_36;
bevt_49_tmpvar_phold = bevp_nativeCSlots.bem_lesser_1(bevt_50_tmpvar_phold);
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 804 */ {
bevp_nativeCSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
} /* Line: 805 */
} /* Line: 804 */
bevl_ovcount = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_52_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_51_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 812 */ {
bevt_53_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 812 */ {
bevt_54_tmpvar_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 814 */ {
bevt_56_tmpvar_phold = bevl_ovcount.bem_greaterEquals_1(bevp_nativeCSlots);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 815 */ {
bevt_57_tmpvar_phold = this.bem_propDecGet_0();
bevp_propertyDecs.bem_addValue_1(bevt_57_tmpvar_phold);
this.bem_decForVar_2(bevp_propertyDecs, (BEC_5_3_BuildVar) bevl_i);
bevt_59_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_144));
bevt_58_tmpvar_phold = (BEC_4_6_TextString) bevp_propertyDecs.bem_addValue_1(bevt_59_tmpvar_phold);
bevt_58_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 818 */
bevl_ovcount = bevl_ovcount.bem_increment_0();
} /* Line: 820 */
} /* Line: 814 */
 else  /* Line: 812 */ {
break;
} /* Line: 812 */
} /* Line: 812 */
bevl_dynGen = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_mq = (BEC_9_3_ContainerSet) (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_60_tmpvar_phold = bevp_csyn.bem_mtdListGet_0();
bevt_1_tmpvar_loop = bevt_60_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 827 */ {
bevt_61_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 827 */ {
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_63_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_62_tmpvar_phold = bevl_mq.bem_has_1(bevt_63_tmpvar_phold);
if (!(bevt_62_tmpvar_phold.bevi_bool)) /* Line: 828 */ {
bevt_64_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_mq.bem_put_1(bevt_64_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_csyn.bem_mtdMapGet_0();
bevt_66_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_65_tmpvar_phold.bem_get_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_msyn.bem_originGet_0();
bevt_67_tmpvar_phold = this.bem_isClose_1(bevt_68_tmpvar_phold);
if (bevt_67_tmpvar_phold.bevi_bool) /* Line: 831 */ {
bevl_numargs = bevl_msyn.bem_numargsGet_0();
bevt_69_tmpvar_phold = bevl_numargs.bem_greater_1(bevp_maxDynArgs);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 833 */ {
bevl_numargs = bevp_maxDynArgs;
} /* Line: 834 */
bevl_dgm = (BEC_9_3_ContainerMap) bevl_dynGen.bem_get_1(bevl_numargs);
if (bevl_dgm == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 837 */ {
bevl_dgm = (BEC_9_3_ContainerMap) (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_dynGen.bem_put_2(bevl_numargs, bevl_dgm);
} /* Line: 839 */
bevt_71_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_msh = bevt_71_tmpvar_phold.bem_hashGet_0();
bevl_dgv = (BEC_9_5_ContainerArray) bevl_dgm.bem_get_1(bevl_msh);
if (bevl_dgv == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 843 */ {
bevl_dgv = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();
bevl_dgm.bem_put_2(bevl_msh, bevl_dgv);
} /* Line: 845 */
bevl_dgv.bem_addValue_1(bevl_msyn);
} /* Line: 847 */
} /* Line: 831 */
} /* Line: 828 */
 else  /* Line: 827 */ {
break;
} /* Line: 827 */
} /* Line: 827 */
bevt_2_tmpvar_loop = bevl_dynGen.bem_iteratorGet_0();
while (true)
 /* Line: 853 */ {
bevt_73_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 853 */ {
bevl_dnode = (BEC_9_3_7_ContainerMapMapNode) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_dnumargs = (BEC_4_3_MathInt) bevl_dnode.bem_keyGet_0();
bevt_74_tmpvar_phold = bevl_dnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 856 */ {
bevt_75_tmpvar_phold = bevo_37;
bevt_76_tmpvar_phold = bevl_dnumargs.bem_toString_0();
bevl_dmname = bevt_75_tmpvar_phold.bem_add_1(bevt_76_tmpvar_phold);
} /* Line: 857 */
 else  /* Line: 858 */ {
bevl_dmname = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_146));
} /* Line: 859 */
bevl_superArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_147));
bevl_args = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_148));
bevl_j = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 864 */ {
bevt_79_tmpvar_phold = bevo_38;
bevt_78_tmpvar_phold = bevl_dnumargs.bem_add_1(bevt_79_tmpvar_phold);
bevt_77_tmpvar_phold = bevl_j.bem_lesser_1(bevt_78_tmpvar_phold);
if (bevt_77_tmpvar_phold.bevi_bool) /* Line: 864 */ {
bevt_80_tmpvar_phold = bevl_j.bem_lesser_1(bevp_maxDynArgs);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 864 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 864 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 864 */
 else  /* Line: 864 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 864 */ {
bevt_84_tmpvar_phold = bevo_39;
bevt_83_tmpvar_phold = bevl_args.bem_add_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_85_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_86_tmpvar_phold);
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevt_85_tmpvar_phold);
bevt_87_tmpvar_phold = bevo_40;
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_add_1(bevt_87_tmpvar_phold);
bevt_89_tmpvar_phold = bevo_41;
bevt_88_tmpvar_phold = bevl_j.bem_subtract_1(bevt_89_tmpvar_phold);
bevl_args = bevt_81_tmpvar_phold.bem_add_1(bevt_88_tmpvar_phold);
bevt_92_tmpvar_phold = bevo_42;
bevt_91_tmpvar_phold = bevl_superArgs.bem_add_1(bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = bevo_43;
bevt_90_tmpvar_phold = bevt_91_tmpvar_phold.bem_add_1(bevt_93_tmpvar_phold);
bevt_95_tmpvar_phold = bevo_44;
bevt_94_tmpvar_phold = bevl_j.bem_subtract_1(bevt_95_tmpvar_phold);
bevl_superArgs = bevt_90_tmpvar_phold.bem_add_1(bevt_94_tmpvar_phold);
bevl_j = bevl_j.bem_increment_0();
} /* Line: 867 */
 else  /* Line: 864 */ {
break;
} /* Line: 864 */
} /* Line: 864 */
bevt_96_tmpvar_phold = bevl_dnumargs.bem_greaterEquals_1(bevp_maxDynArgs);
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 869 */ {
bevt_99_tmpvar_phold = bevo_45;
bevt_98_tmpvar_phold = bevl_args.bem_add_1(bevt_99_tmpvar_phold);
bevt_101_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_100_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_101_tmpvar_phold);
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_add_1(bevt_100_tmpvar_phold);
bevt_102_tmpvar_phold = bevo_46;
bevl_args = bevt_97_tmpvar_phold.bem_add_1(bevt_102_tmpvar_phold);
bevt_103_tmpvar_phold = bevo_47;
bevl_superArgs = bevl_superArgs.bem_add_1(bevt_103_tmpvar_phold);
} /* Line: 871 */
bevt_113_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_112_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_113_tmpvar_phold);
bevt_115_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_114_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_115_tmpvar_phold);
bevt_111_tmpvar_phold = (BEC_4_6_TextString) bevt_112_tmpvar_phold.bem_addValue_1(bevt_114_tmpvar_phold);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_156));
bevt_110_tmpvar_phold = (BEC_4_6_TextString) bevt_111_tmpvar_phold.bem_addValue_1(bevt_116_tmpvar_phold);
bevt_109_tmpvar_phold = (BEC_4_6_TextString) bevt_110_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_117_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_157));
bevt_108_tmpvar_phold = (BEC_4_6_TextString) bevt_109_tmpvar_phold.bem_addValue_1(bevt_117_tmpvar_phold);
bevt_107_tmpvar_phold = (BEC_4_6_TextString) bevt_108_tmpvar_phold.bem_addValue_1(bevl_args);
bevt_118_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_158));
bevt_106_tmpvar_phold = (BEC_4_6_TextString) bevt_107_tmpvar_phold.bem_addValue_1(bevt_118_tmpvar_phold);
bevt_105_tmpvar_phold = (BEC_4_6_TextString) bevt_106_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_119_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_159));
bevt_104_tmpvar_phold = (BEC_4_6_TextString) bevt_105_tmpvar_phold.bem_addValue_1(bevt_119_tmpvar_phold);
bevt_104_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(19, bels_160));
bevt_120_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_121_tmpvar_phold);
bevt_120_tmpvar_phold.bem_addValue_1(bevp_nl);
bevl_dgm = (BEC_9_3_ContainerMap) bevl_dnode.bem_valueGet_0();
bevt_3_tmpvar_loop = bevl_dgm.bem_iteratorGet_0();
while (true)
 /* Line: 877 */ {
bevt_122_tmpvar_phold = bevt_3_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 877 */ {
bevl_msnode = (BEC_9_3_7_ContainerMapMapNode) bevt_3_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_thisHash = (BEC_4_3_MathInt) bevl_msnode.bem_keyGet_0();
bevl_dgv = (BEC_9_5_ContainerArray) bevl_msnode.bem_valueGet_0();
bevt_125_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_161));
bevt_124_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_125_tmpvar_phold);
bevt_126_tmpvar_phold = bevl_thisHash.bem_toString_0();
bevt_123_tmpvar_phold = (BEC_4_6_TextString) bevt_124_tmpvar_phold.bem_addValue_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_162));
bevt_123_tmpvar_phold.bem_addValue_1(bevt_127_tmpvar_phold);
if (bevp_dynConditionsAll.bevi_bool) /* Line: 884 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 884 */ {
bevt_129_tmpvar_phold = bevl_dgv.bem_sizeGet_0();
bevt_130_tmpvar_phold = bevo_48;
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_greater_1(bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold.bevi_bool) /* Line: 884 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 884 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 884 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 884 */ {
bevl_dynConditions = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 885 */
 else  /* Line: 886 */ {
bevl_dynConditions = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 887 */
bevt_4_tmpvar_loop = bevl_dgv.bem_iteratorGet_0();
while (true)
 /* Line: 889 */ {
bevt_131_tmpvar_phold = bevt_4_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_131_tmpvar_phold != null && bevt_131_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_131_tmpvar_phold).bevi_bool) /* Line: 889 */ {
bevl_msyn = (BEC_5_6_BuildMtdSyn) bevt_4_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_mcall = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
if (bevl_dynConditions.bevi_bool) /* Line: 891 */ {
bevt_133_tmpvar_phold = bevo_49;
bevt_132_tmpvar_phold = bevp_libEmitName.bem_add_1(bevt_133_tmpvar_phold);
bevt_134_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevl_constName = bevt_132_tmpvar_phold.bem_add_1(bevt_134_tmpvar_phold);
bevt_138_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_164));
bevt_137_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_138_tmpvar_phold);
bevt_136_tmpvar_phold = (BEC_4_6_TextString) bevt_137_tmpvar_phold.bem_addValue_1(bevl_constName);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_165));
bevt_135_tmpvar_phold = (BEC_4_6_TextString) bevt_136_tmpvar_phold.bem_addValue_1(bevt_139_tmpvar_phold);
bevt_135_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 893 */
bevt_142_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_166));
bevt_141_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_142_tmpvar_phold);
bevt_143_tmpvar_phold = bevl_msyn.bem_nameGet_0();
bevt_140_tmpvar_phold = (BEC_4_6_TextString) bevt_141_tmpvar_phold.bem_addValue_1(bevt_143_tmpvar_phold);
bevt_144_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_167));
bevt_140_tmpvar_phold.bem_addValue_1(bevt_144_tmpvar_phold);
bevl_vnumargs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_145_tmpvar_phold = bevl_msyn.bem_argSynsGet_0();
bevt_5_tmpvar_loop = bevt_145_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 897 */ {
bevt_146_tmpvar_phold = bevt_5_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 897 */ {
bevl_vsyn = (BEC_5_6_BuildVarSyn) bevt_5_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_148_tmpvar_phold = bevo_50;
bevt_147_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_148_tmpvar_phold);
if (bevt_147_tmpvar_phold.bevi_bool) /* Line: 898 */ {
bevt_149_tmpvar_phold = bevl_vsyn.bem_isTypedGet_0();
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 899 */ {
bevt_151_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bem_notEquals_1(bevp_objectNp);
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 899 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 899 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 899 */
 else  /* Line: 899 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 899 */ {
bevt_154_tmpvar_phold = bevl_vsyn.bem_namepathGet_0();
bevt_153_tmpvar_phold = this.bem_getClassConfig_1(bevt_154_tmpvar_phold);
bevt_152_tmpvar_phold = this.bem_formCast_1(bevt_153_tmpvar_phold);
bevt_155_tmpvar_phold = bevo_51;
bevl_vcast = bevt_152_tmpvar_phold.bem_add_1(bevt_155_tmpvar_phold);
} /* Line: 900 */
 else  /* Line: 901 */ {
bevl_vcast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_169));
} /* Line: 902 */
bevt_157_tmpvar_phold = bevo_52;
bevt_156_tmpvar_phold = bevl_vnumargs.bem_greater_1(bevt_157_tmpvar_phold);
if (bevt_156_tmpvar_phold.bevi_bool) /* Line: 904 */ {
bevl_vcma = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_170));
} /* Line: 905 */
 else  /* Line: 906 */ {
bevl_vcma = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_171));
} /* Line: 907 */
bevt_158_tmpvar_phold = bevl_vnumargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_158_tmpvar_phold.bevi_bool) /* Line: 909 */ {
bevt_159_tmpvar_phold = bevo_53;
bevt_161_tmpvar_phold = bevo_54;
bevt_160_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevt_161_tmpvar_phold);
bevl_varg = bevt_159_tmpvar_phold.bem_add_1(bevt_160_tmpvar_phold);
} /* Line: 910 */
 else  /* Line: 911 */ {
bevt_163_tmpvar_phold = bevo_55;
bevt_164_tmpvar_phold = bevl_vnumargs.bem_subtract_1(bevp_maxDynArgs);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bem_add_1(bevt_164_tmpvar_phold);
bevt_165_tmpvar_phold = bevo_56;
bevl_varg = bevt_162_tmpvar_phold.bem_add_1(bevt_165_tmpvar_phold);
} /* Line: 912 */
bevt_167_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevl_vcma);
bevt_166_tmpvar_phold = (BEC_4_6_TextString) bevt_167_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_166_tmpvar_phold.bem_addValue_1(bevl_varg);
} /* Line: 914 */
bevl_vnumargs = bevl_vnumargs.bem_increment_0();
} /* Line: 916 */
 else  /* Line: 897 */ {
break;
} /* Line: 897 */
} /* Line: 897 */
bevt_169_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_175));
bevt_168_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_169_tmpvar_phold);
bevt_168_tmpvar_phold.bem_addValue_1(bevp_nl);
if (bevl_dynConditions.bevi_bool) /* Line: 919 */ {
bevt_171_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_176));
bevt_170_tmpvar_phold = (BEC_4_6_TextString) bevl_mcall.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_170_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 921 */
bevp_dynMethods.bem_addValue_1(bevl_mcall);
} /* Line: 924 */
 else  /* Line: 889 */ {
break;
} /* Line: 889 */
} /* Line: 889 */
if (bevl_dynConditions.bevi_bool) /* Line: 926 */ {
bevt_173_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_177));
bevt_172_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_173_tmpvar_phold);
bevt_172_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 927 */
} /* Line: 926 */
 else  /* Line: 877 */ {
break;
} /* Line: 877 */
} /* Line: 877 */
bevt_175_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_178));
bevt_174_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_175_tmpvar_phold);
bevt_174_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_183_tmpvar_phold = bevo_57;
bevt_184_tmpvar_phold = this.bem_superNameGet_0();
bevt_182_tmpvar_phold = bevt_183_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_185_tmpvar_phold = bevo_58;
bevt_181_tmpvar_phold = bevt_182_tmpvar_phold.bem_add_1(bevt_185_tmpvar_phold);
bevt_180_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_181_tmpvar_phold);
bevt_179_tmpvar_phold = (BEC_4_6_TextString) bevt_180_tmpvar_phold.bem_addValue_1(bevl_dmname);
bevt_186_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_181));
bevt_178_tmpvar_phold = (BEC_4_6_TextString) bevt_179_tmpvar_phold.bem_addValue_1(bevt_186_tmpvar_phold);
bevt_177_tmpvar_phold = (BEC_4_6_TextString) bevt_178_tmpvar_phold.bem_addValue_1(bevl_superArgs);
bevt_187_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_182));
bevt_176_tmpvar_phold = (BEC_4_6_TextString) bevt_177_tmpvar_phold.bem_addValue_1(bevt_187_tmpvar_phold);
bevt_176_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_189_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_183));
bevt_188_tmpvar_phold = (BEC_4_6_TextString) bevp_dynMethods.bem_addValue_1(bevt_189_tmpvar_phold);
bevt_188_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 932 */
 else  /* Line: 853 */ {
break;
} /* Line: 853 */
} /* Line: 853 */
this.bem_buildClassInfo_0();
this.bem_buildCreate_0();
this.bem_buildInitial_0();
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_getNativeCSlots_1(BEC_4_6_TextString beva_text) {
BEC_4_3_MathInt bevl_nativeSlots = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_isfn = null;
BEC_6_6_SystemObject bevl_nextIsNativeSlots = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_184));
bevl_ll = beva_text.bem_split_1(bevt_1_tmpvar_phold);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_loop = bevl_ll.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 951 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 951 */ {
bevl_i = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_nextIsNativeSlots != null && bevl_nextIsNativeSlots is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_nextIsNativeSlots).bevi_bool) /* Line: 952 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(bevl_i);
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 955 */
 else  /* Line: 952 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_185));
bevt_3_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 956 */ {
bevl_isfn = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nativeSlots = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
} /* Line: 958 */
 else  /* Line: 952 */ {
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(20, bels_186));
bevt_5_tmpvar_phold = bevl_i.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 959 */ {
bevl_nextIsNativeSlots = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 960 */
} /* Line: 952 */
} /* Line: 952 */
} /* Line: 952 */
 else  /* Line: 951 */ {
break;
} /* Line: 951 */
} /* Line: 951 */
bevt_8_tmpvar_phold = bevo_59;
bevt_7_tmpvar_phold = bevl_nativeSlots.bem_greater_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 963 */ {
} /* Line: 963 */
return bevl_nativeSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildCreate_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_187));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_188));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_189));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_16_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_relEmitName_1(bevt_19_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_190));
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_11_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_191));
bevt_21_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildInitial_0() {
BEC_4_6_TextString bevl_oname = null;
BEC_4_6_TextString bevl_mname = null;
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_4_6_TextString bevl_vcast = null;
BEC_5_11_BuildClassConfig bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevl_oname = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bem_relEmitName_1(bevt_1_tmpvar_phold);
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_2_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_10_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_192));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevt_8_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_193));
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_194));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpvar_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 984 */ {
bevl_vcast = this.bem_formCast_1(bevp_classConf);
} /* Line: 985 */
 else  /* Line: 986 */ {
bevl_vcast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_195));
} /* Line: 987 */
bevt_18_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_196));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevt_17_tmpvar_phold.bem_addValue_1(bevl_vcast);
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_197));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_198));
bevt_21_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_21_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevl_oname);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(18, bels_199));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_200));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_201));
bevt_33_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevt_33_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_202));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_31_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_203));
bevt_36_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpvar_phold);
bevt_36_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_buildClassInfo_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_204));
bevt_3_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_buildClassInfo_2(bevt_0_tmpvar_phold, (BEC_4_6_TextString) bevt_1_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_205));
this.bem_buildClassInfo_2(bevt_4_tmpvar_phold, bevp_inFilePathed);
return this;
} /*method end*/
public virtual BEC_5_10_BuildEmitCommon bem_buildClassInfo_2(BEC_4_6_TextString beva_belsBase, BEC_4_6_TextString beva_lival) {
BEC_4_6_TextString bevl_belsName = null;
BEC_4_6_TextString bevl_sdec = null;
BEC_4_3_MathInt bevl_lisz = null;
BEC_4_3_MathInt bevl_lipos = null;
BEC_4_3_MathInt bevl_bcode = null;
BEC_4_6_TextString bevl_hs = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_60;
bevl_belsName = bevt_0_tmpvar_phold.bem_add_1(beva_belsBase);
bevl_sdec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevl_lisz = beva_lival.bem_sizeGet_0();
bevl_lipos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_bcode = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_hs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
while (true)
 /* Line: 1019 */ {
bevt_2_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1019 */ {
bevt_4_tmpvar_phold = bevo_61;
bevt_3_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1020 */ {
bevt_6_tmpvar_phold = bevo_62;
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1021 */
this.bem_lstringByte_5(bevl_sdec, beva_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1024 */
 else  /* Line: 1019 */ {
break;
} /* Line: 1019 */
} /* Line: 1019 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
this.bem_buildClassInfoMethod_1(beva_belsBase);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_4_6_TextString beva_belsBase) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_overrideMtdDecGet_0();
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_208));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_209));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_210));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_211));
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(beva_belsBase);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_212));
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_10_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_213));
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_15_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_initialDecGet_0() {
BEC_4_6_TextString bevl_initialDec = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
bevl_initialDec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_1_tmpvar_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1045 */ {
bevt_5_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_214));
bevt_4_tmpvar_phold = this.bem_baseSpropDec_2(bevt_5_tmpvar_phold, bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_215));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevt_2_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1046 */
 else  /* Line: 1047 */ {
bevt_11_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_216));
bevt_10_tmpvar_phold = this.bem_overrideSpropDec_2(bevt_11_tmpvar_phold, bevt_12_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_217));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1048 */
return bevl_initialDec;
} /*method end*/
public virtual BEC_4_6_TextString bem_classBeginGet_0() {
BEC_4_6_TextString bevl_extends = null;
BEC_4_6_TextString bevl_clb = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1055 */ {
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevl_extends = this.bem_extend_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
} /* Line: 1056 */
 else  /* Line: 1057 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(24, bels_218));
bevl_extends = this.bem_extend_1(bevt_3_tmpvar_phold);
} /* Line: 1058 */
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_219));
bevt_5_tmpvar_phold = (BEC_4_6_TextString) bevt_6_tmpvar_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_220));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevt_5_tmpvar_phold.bem_addValue_1(bevt_7_tmpvar_phold);
bevl_clb = (BEC_4_6_TextString) bevt_4_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpvar_phold = this.bem_klassDecGet_0();
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevt_13_tmpvar_phold);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) bevt_10_tmpvar_phold.bem_addValue_1(bevl_extends);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_221));
bevt_8_tmpvar_phold = (BEC_4_6_TextString) bevt_9_tmpvar_phold.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_8_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_222));
bevt_16_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_15_tmpvar_phold = (BEC_4_6_TextString) bevt_16_tmpvar_phold.bem_addValue_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_223));
bevt_15_tmpvar_phold.bem_addValue_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_224));
bevt_20_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_20_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_225));
bevt_22_tmpvar_phold = this.bem_emitting_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1064 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_226));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_227));
bevt_24_tmpvar_phold.bem_addValue_1(bevt_28_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_228));
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevl_clb.bem_addValue_1(bevt_30_tmpvar_phold);
bevt_29_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1066 */
return bevl_clb;
} /*method end*/
public virtual BEC_4_6_TextString bem_classEndGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_229));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_baseSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevo_63;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_typeName);
bevt_4_tmpvar_phold = bevo_64;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_varName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_232));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_overrideSpropDec_2(BEC_4_6_TextString beva_typeName, BEC_4_6_TextString beva_varName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_233));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getTraceInfo_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_trInfo = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_trInfo = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
if (beva_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1091 */ {
bevt_3_tmpvar_phold = beva_node.bem_nlcGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1091 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1091 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1091 */
 else  /* Line: 1091 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1091 */ {
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_234));
bevt_4_tmpvar_phold = (BEC_4_6_TextString) bevl_trInfo.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = beva_node.bem_nlcGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_toString_0();
bevt_4_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
} /* Line: 1092 */
return bevl_trInfo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptBraces_1(BEC_5_4_BuildNode beva_node) {
BEC_4_3_MathInt bevl_typename = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 1098 */ {
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_typename = bevt_6_tmpvar_phold.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1100 */ {
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_9_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1100 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1100 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1100 */
 else  /* Line: 1100 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1100 */ {
bevt_12_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_11_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 1100 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1100 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1100 */
 else  /* Line: 1100 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1100 */ {
bevt_14_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_13_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1100 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1100 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1100 */
 else  /* Line: 1100 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1100 */ {
bevt_16_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_15_tmpvar_phold = bevl_typename.bem_notEquals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 1100 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1100 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1100 */
 else  /* Line: 1100 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1100 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_235));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_addValue_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_236));
bevt_17_tmpvar_phold = (BEC_4_6_TextString) bevt_18_tmpvar_phold.bem_addValue_1(bevt_22_tmpvar_phold);
bevt_17_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1102 */
} /* Line: 1100 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptRbraces_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_nct = null;
BEC_6_6_SystemObject bevl_typename = null;
BEC_4_3_MathInt bevl_methodsOffset = null;
BEC_5_4_BuildNode bevl_mc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_8_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_9_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_containerGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_9_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_containerGet_0();
if (bevt_8_tmpvar_phold == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1111 */
 else  /* Line: 1111 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1111 */ {
bevt_10_tmpvar_phold = beva_node.bem_containerGet_0();
bevl_nct = bevt_10_tmpvar_phold.bem_containerGet_0();
bevl_typename = bevl_nct.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_11_tmpvar_phold = bevl_typename.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1114 */ {
if (bevp_mnode == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 1115 */ {
if (bevp_lastCall == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 1116 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1116 */ {
bevt_17_tmpvar_phold = bevp_lastCall.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_237));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_18_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 1116 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1116 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1116 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1116 */ {
bevt_20_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_238));
bevt_19_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_20_tmpvar_phold);
bevt_19_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1119 */
bevt_22_tmpvar_phold = bevo_65;
bevt_21_tmpvar_phold = bevp_maxSpillArgsLen.bem_greater_1(bevt_22_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 1122 */ {
bevt_30_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_29_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_30_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_29_tmpvar_phold);
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_239));
bevt_27_tmpvar_phold = (BEC_4_6_TextString) bevt_28_tmpvar_phold.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_33_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_32_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_33_tmpvar_phold);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevt_27_tmpvar_phold.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_240));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevt_26_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = bevp_maxSpillArgsLen.bem_toString_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) bevt_25_tmpvar_phold.bem_addValue_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_241));
bevt_23_tmpvar_phold = (BEC_4_6_TextString) bevt_24_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_23_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1123 */
bevl_methodsOffset = this.bem_countLines_2(bevp_methods, bevp_lastMethodsSize);
bevl_methodsOffset.bem_addValue_1(bevp_lastMethodsLines);
bevp_lastMethodsLines = bevl_methodsOffset;
bevp_lastMethodsSize = bevp_methods.bem_sizeGet_0();
bevt_0_tmpvar_loop = bevp_methodCalls.bem_iteratorGet_0();
while (true)
 /* Line: 1133 */ {
bevt_37_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 1133 */ {
bevl_mc = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_38_tmpvar_phold = bevl_mc.bem_nlecGet_0();
bevt_38_tmpvar_phold.bem_addValue_1(bevl_methodsOffset);
} /* Line: 1134 */
 else  /* Line: 1133 */ {
break;
} /* Line: 1133 */
} /* Line: 1133 */
bevp_classCalls.bem_addValue_1(bevp_methodCalls);
bevt_39_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCalls.bem_lengthSet_1(bevt_39_tmpvar_phold);
bevp_methods.bem_addValue_1(bevp_methodBody);
bevp_methodBody.bem_clear_0();
bevp_lastMethodBodySize = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_methodCatch = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevp_lastCall = null;
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(16, bels_242));
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevp_methods.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_40_tmpvar_phold.bem_addValue_1(bevp_nl);
bevp_msyn = null;
bevp_mnode = null;
} /* Line: 1152 */
} /* Line: 1115 */
 else  /* Line: 1114 */ {
bevt_43_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_42_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_43_tmpvar_phold);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 1154 */ {
bevt_45_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_44_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_45_tmpvar_phold);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 1154 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1154 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1154 */
 else  /* Line: 1154 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1154 */ {
bevt_47_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_46_tmpvar_phold = bevl_typename.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 1154 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1154 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1154 */
 else  /* Line: 1154 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1154 */ {
bevt_51_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_243));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_52_tmpvar_phold = this.bem_getTraceInfo_1(beva_node);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_244));
bevt_48_tmpvar_phold = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_addValue_1(bevt_53_tmpvar_phold);
bevt_48_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1156 */
} /* Line: 1114 */
} /* Line: 1114 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_countLines_1(BEC_4_6_TextString beva_text) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_countLines_2(beva_text, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_countLines_2(BEC_4_6_TextString beva_text, BEC_4_3_MathInt beva_start) {
BEC_4_3_MathInt bevl_found = null;
BEC_4_3_MathInt bevl_nlval = null;
BEC_4_3_MathInt bevl_cursor = null;
BEC_4_3_MathInt bevl_slen = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_found = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_nlval = bevp_nl.bem_getInt_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevl_cursor = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevl_slen = beva_text.bem_sizeGet_0();
bevl_i = beva_start;
while (true)
 /* Line: 1170 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_slen);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 1170 */ {
beva_text.bem_getInt_2(bevl_i, bevl_cursor);
bevt_3_tmpvar_phold = bevl_cursor.bem_equals_1(bevl_nlval);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1172 */ {
bevl_found.bem_incrementValue_0();
} /* Line: 1173 */
bevl_i.bem_incrementValue_0();
} /* Line: 1170 */
 else  /* Line: 1170 */ {
break;
} /* Line: 1170 */
} /* Line: 1170 */
return bevl_found;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptIf_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_targs = null;
BEC_5_4_LogicBool bevl_isBool = null;
BEC_5_4_LogicBool bevl_isUnless = null;
BEC_4_6_TextString bevl_ev = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
bevt_5_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_firstGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_5_4_BuildNode) bevt_2_tmpvar_phold);
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_firstGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 1181 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1181 */ {
bevt_19_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_firstGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevp_boolNp);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 1181 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1181 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1181 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1181 */ {
bevl_isBool = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1182 */
 else  /* Line: 1183 */ {
bevl_isBool = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1184 */
bevt_21_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 1186 */ {
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_245));
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 1186 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1186 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1186 */
 else  /* Line: 1186 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1186 */ {
bevl_isUnless = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1187 */
 else  /* Line: 1188 */ {
bevl_isUnless = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 1189 */
bevl_ev = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_246));
if (bevl_isUnless.bevi_bool) /* Line: 1192 */ {
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_247));
bevl_ev.bem_addValue_1(bevt_25_tmpvar_phold);
} /* Line: 1193 */
if (bevl_isBool.bevi_bool) /* Line: 1195 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_27_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_248));
bevt_26_tmpvar_phold.bem_addValue_1(bevt_27_tmpvar_phold);
} /* Line: 1197 */
 else  /* Line: 1198 */ {
bevt_32_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevl_targs);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_249));
bevt_31_tmpvar_phold = (BEC_4_6_TextString) bevt_32_tmpvar_phold.bem_addValue_1(bevt_33_tmpvar_phold);
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevt_31_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) bevt_30_tmpvar_phold.bem_addValue_1(bevp_instOf);
bevt_35_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_34_tmpvar_phold = bevp_boolCc.bem_relEmitName_1(bevt_35_tmpvar_phold);
bevt_28_tmpvar_phold = (BEC_4_6_TextString) bevt_29_tmpvar_phold.bem_addValue_1(bevt_34_tmpvar_phold);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_250));
bevt_28_tmpvar_phold.bem_addValue_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_251));
bevt_38_tmpvar_phold = this.bem_emitting_1(bevt_39_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_not_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 1203 */ {
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_252));
bevt_40_tmpvar_phold = (BEC_4_6_TextString) bevl_ev.bem_addValue_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = this.bem_formCast_1(bevp_boolCc);
bevt_40_tmpvar_phold.bem_addValue_1(bevt_42_tmpvar_phold);
} /* Line: 1204 */
bevl_ev.bem_addValue_1(bevl_targs);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_253));
bevt_44_tmpvar_phold = this.bem_emitting_1(bevt_45_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1207 */ {
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_254));
bevl_ev.bem_addValue_1(bevt_46_tmpvar_phold);
} /* Line: 1208 */
bevt_47_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_255));
bevl_ev.bem_addValue_1(bevt_47_tmpvar_phold);
} /* Line: 1210 */
if (bevl_isUnless.bevi_bool) /* Line: 1212 */ {
bevt_48_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_256));
bevl_ev.bem_addValue_1(bevt_48_tmpvar_phold);
} /* Line: 1213 */
bevt_51_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_257));
bevt_50_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_51_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) bevt_50_tmpvar_phold.bem_addValue_1(bevl_ev);
bevt_52_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_258));
bevt_49_tmpvar_phold.bem_addValue_1(bevt_52_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_oldacceptIf_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_targs = null;
BEC_4_6_TextString bevl_cexpr = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_firstGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_targs = this.bem_formTarg_1((BEC_5_4_BuildNode) bevt_1_tmpvar_phold);
bevt_6_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 1221 */ {
bevt_8_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_259));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1221 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1221 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1221 */
 else  /* Line: 1221 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1221 */ {
bevl_cexpr = bevp_instanceNotEqual;
} /* Line: 1222 */
 else  /* Line: 1223 */ {
bevl_cexpr = bevp_instanceEqual;
} /* Line: 1224 */
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_260));
bevt_13_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = (BEC_4_6_TextString) bevt_13_tmpvar_phold.bem_addValue_1(bevp_trueValue);
bevt_11_tmpvar_phold = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bem_addValue_1(bevl_cexpr);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) bevt_11_tmpvar_phold.bem_addValue_1(bevl_targs);
bevt_15_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_261));
bevt_10_tmpvar_phold.bem_addValue_1(bevt_15_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptCatch_1(BEC_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_finalAssign_3(BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_sFrom, BEC_5_8_BuildNamePath beva_castTo) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_finalAssignTo_2(beva_node, beva_castTo);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(beva_sFrom);
bevt_4_tmpvar_phold = bevo_66;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevp_nl);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_finalAssignTo_2(BEC_5_4_BuildNode beva_node, BEC_5_8_BuildNamePath beva_castTo) {
BEC_4_6_TextString bevl_cast = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1238 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(29, bels_263));
bevt_3_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 1239 */
bevt_7_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_264));
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 1241 */ {
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(21, bels_265));
bevt_9_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_10_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_9_tmpvar_phold);
} /* Line: 1242 */
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_266));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 1244 */ {
bevt_16_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_267));
bevt_15_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_16_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_15_tmpvar_phold);
} /* Line: 1245 */
bevl_cast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_268));
if (beva_castTo == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 1248 */ {
bevt_19_tmpvar_phold = this.bem_getClassConfig_1(beva_castTo);
bevt_18_tmpvar_phold = this.bem_formCast_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevo_67;
bevl_cast = bevt_18_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
} /* Line: 1249 */
bevt_24_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_23_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevo_68;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevl_cast);
return bevt_21_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_superNameGet_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_271));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_formCast_1(BEC_5_11_BuildClassConfig beva_cc) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_69;
bevt_4_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpvar_phold = beva_cc.bem_relEmitName_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevo_70;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptThrow_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(38, bels_274));
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_4_tmpvar_phold = this.bem_formTarg_1(bevt_5_tmpvar_phold);
bevt_1_tmpvar_phold = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_275));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(bevt_6_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_onceVarDec_1(BEC_4_6_TextString beva_count) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_71;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_count);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptCall_1(BEC_5_4_BuildNode beva_node) {
BEC_4_3_MathInt bevl_moreLines = null;
BEC_6_6_SystemObject bevl_errmsg = null;
BEC_4_3_MathInt bevl_ei = null;
BEC_5_8_BuildNamePath bevl_castTo = null;
BEC_4_6_TextString bevl_nullRes = null;
BEC_4_6_TextString bevl_notNullRes = null;
BEC_4_6_TextString bevl_returnCast = null;
BEC_5_4_LogicBool bevl_selfCall = null;
BEC_5_4_LogicBool bevl_superCall = null;
BEC_5_4_LogicBool bevl_isConstruct = null;
BEC_5_4_LogicBool bevl_isTyped = null;
BEC_5_11_BuildClassConfig bevl_newcc = null;
BEC_4_6_TextString bevl_callArgs = null;
BEC_4_6_TextString bevl_spillArgs = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_9_5_ContainerArray bevl_argCasts = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevl_target = null;
BEC_5_4_BuildNode bevl_targetNode = null;
BEC_4_3_MathInt bevl_spillArgPos = null;
BEC_5_4_LogicBool bevl_isOnce = null;
BEC_5_4_LogicBool bevl_onceDeced = null;
BEC_4_6_TextString bevl_ovar = null;
BEC_4_6_TextString bevl_odec = null;
BEC_4_6_TextString bevl_callAssign = null;
BEC_4_6_TextString bevl_postOnceCallAssign = null;
BEC_4_6_TextString bevl_cast = null;
BEC_4_6_TextString bevl_belsName = null;
BEC_4_6_TextString bevl_sdec = null;
BEC_4_6_TextString bevl_liorg = null;
BEC_4_6_TextString bevl_lival = null;
BEC_4_3_MathInt bevl_lisz = null;
BEC_4_3_MathInt bevl_lipos = null;
BEC_4_3_MathInt bevl_bcode = null;
BEC_4_6_TextString bevl_hs = null;
BEC_4_6_TextString bevl_newCall = null;
BEC_4_6_TextString bevl_stinst = null;
BEC_4_6_TextString bevl_odinfo = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_5_8_BuildClassSyn bevl_asyn = null;
BEC_4_6_TextString bevl_dm = null;
BEC_4_6_TextString bevl_callArgSpill = null;
BEC_4_3_MathInt bevl_spillArgsLen = null;
BEC_4_6_TextString bevl_fc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_44_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_90_tmpvar_phold = null;
BEC_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_94_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_115_tmpvar_phold = null;
BEC_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_120_tmpvar_phold = null;
BEC_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_129_tmpvar_phold = null;
BEC_4_6_TextString bevt_130_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_136_tmpvar_phold = null;
BEC_4_6_TextString bevt_137_tmpvar_phold = null;
BEC_4_6_TextString bevt_138_tmpvar_phold = null;
BEC_4_6_TextString bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_4_6_TextString bevt_141_tmpvar_phold = null;
BEC_4_6_TextString bevt_142_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_143_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_144_tmpvar_phold = null;
BEC_4_6_TextString bevt_145_tmpvar_phold = null;
BEC_4_6_TextString bevt_146_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_148_tmpvar_phold = null;
BEC_4_6_TextString bevt_149_tmpvar_phold = null;
BEC_4_6_TextString bevt_150_tmpvar_phold = null;
BEC_4_6_TextString bevt_151_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_153_tmpvar_phold = null;
BEC_4_6_TextString bevt_154_tmpvar_phold = null;
BEC_4_6_TextString bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_4_6_TextString bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_4_6_TextString bevt_166_tmpvar_phold = null;
BEC_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_4_6_TextString bevt_168_tmpvar_phold = null;
BEC_4_6_TextString bevt_169_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_177_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_178_tmpvar_phold = null;
BEC_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_180_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_181_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_4_6_TextString bevt_187_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_4_6_TextString bevt_195_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_198_tmpvar_phold = null;
BEC_4_6_TextString bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_4_6_TextString bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_4_6_TextString bevt_203_tmpvar_phold = null;
BEC_4_6_TextString bevt_204_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_205_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_4_6_TextString bevt_207_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_4_6_TextString bevt_210_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_221_tmpvar_phold = null;
BEC_4_6_TextString bevt_222_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_227_tmpvar_phold = null;
BEC_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_230_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_231_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_234_tmpvar_phold = null;
BEC_4_3_MathInt bevt_235_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_239_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_4_6_TextString bevt_243_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_4_3_MathInt bevt_245_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_246_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_247_tmpvar_phold = null;
BEC_4_6_TextString bevt_248_tmpvar_phold = null;
BEC_4_6_TextString bevt_249_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_250_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_251_tmpvar_phold = null;
BEC_4_6_TextString bevt_252_tmpvar_phold = null;
BEC_4_6_TextString bevt_253_tmpvar_phold = null;
BEC_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_4_6_TextString bevt_257_tmpvar_phold = null;
BEC_4_6_TextString bevt_258_tmpvar_phold = null;
BEC_4_6_TextString bevt_259_tmpvar_phold = null;
BEC_4_6_TextString bevt_260_tmpvar_phold = null;
BEC_4_6_TextString bevt_261_tmpvar_phold = null;
BEC_4_6_TextString bevt_262_tmpvar_phold = null;
BEC_4_6_TextString bevt_263_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_265_tmpvar_phold = null;
BEC_4_6_TextString bevt_266_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_269_tmpvar_phold = null;
BEC_4_3_MathInt bevt_270_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_271_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_272_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_273_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_274_tmpvar_phold = null;
BEC_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_276_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_277_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_278_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_279_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_280_tmpvar_phold = null;
BEC_4_6_TextString bevt_281_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_282_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_283_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_284_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_285_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_286_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_287_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_288_tmpvar_phold = null;
BEC_4_6_TextString bevt_289_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_290_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_291_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_292_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_293_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_294_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_295_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_296_tmpvar_phold = null;
BEC_4_6_TextString bevt_297_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_298_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_299_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_300_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_301_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_302_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_303_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_304_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_305_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_306_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_307_tmpvar_phold = null;
BEC_4_6_TextString bevt_308_tmpvar_phold = null;
BEC_4_6_TextString bevt_309_tmpvar_phold = null;
BEC_4_6_TextString bevt_310_tmpvar_phold = null;
BEC_4_6_TextString bevt_311_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_312_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_313_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_314_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_315_tmpvar_phold = null;
BEC_4_6_TextString bevt_316_tmpvar_phold = null;
BEC_4_6_TextString bevt_317_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_318_tmpvar_phold = null;
BEC_4_6_TextString bevt_319_tmpvar_phold = null;
BEC_5_11_BuildClassConfig bevt_320_tmpvar_phold = null;
BEC_4_6_TextString bevt_321_tmpvar_phold = null;
BEC_4_6_TextString bevt_322_tmpvar_phold = null;
BEC_4_6_TextString bevt_323_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_324_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_325_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_326_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_327_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_328_tmpvar_phold = null;
BEC_4_6_TextString bevt_329_tmpvar_phold = null;
BEC_4_6_TextString bevt_330_tmpvar_phold = null;
BEC_4_6_TextString bevt_331_tmpvar_phold = null;
BEC_4_6_TextString bevt_332_tmpvar_phold = null;
BEC_4_6_TextString bevt_333_tmpvar_phold = null;
BEC_4_6_TextString bevt_334_tmpvar_phold = null;
BEC_4_6_TextString bevt_335_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_336_tmpvar_phold = null;
BEC_4_6_TextString bevt_337_tmpvar_phold = null;
BEC_4_6_TextString bevt_338_tmpvar_phold = null;
BEC_4_6_TextString bevt_339_tmpvar_phold = null;
BEC_4_6_TextString bevt_340_tmpvar_phold = null;
BEC_4_6_TextString bevt_341_tmpvar_phold = null;
BEC_4_6_TextString bevt_342_tmpvar_phold = null;
BEC_4_6_TextString bevt_343_tmpvar_phold = null;
BEC_4_6_TextString bevt_344_tmpvar_phold = null;
BEC_4_6_TextString bevt_345_tmpvar_phold = null;
BEC_4_6_TextString bevt_346_tmpvar_phold = null;
BEC_4_6_TextString bevt_347_tmpvar_phold = null;
BEC_4_6_TextString bevt_348_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_349_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_350_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_351_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_352_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_353_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_354_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_355_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_356_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_357_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_358_tmpvar_phold = null;
BEC_4_6_TextString bevt_359_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_360_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_361_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_362_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_363_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_364_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_365_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_366_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_367_tmpvar_phold = null;
BEC_4_12_JsonUnmarshaller bevt_368_tmpvar_phold = null;
BEC_4_6_TextString bevt_369_tmpvar_phold = null;
BEC_4_6_TextString bevt_370_tmpvar_phold = null;
BEC_4_6_TextString bevt_371_tmpvar_phold = null;
BEC_4_6_TextString bevt_372_tmpvar_phold = null;
BEC_4_6_TextString bevt_373_tmpvar_phold = null;
BEC_4_6_TextString bevt_374_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_375_tmpvar_phold = null;
BEC_4_6_TextString bevt_376_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_377_tmpvar_phold = null;
BEC_4_6_TextString bevt_378_tmpvar_phold = null;
BEC_4_3_MathInt bevt_379_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_380_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_381_tmpvar_phold = null;
BEC_4_3_MathInt bevt_382_tmpvar_phold = null;
BEC_4_6_TextString bevt_383_tmpvar_phold = null;
BEC_4_6_TextString bevt_384_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_385_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_386_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_387_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_388_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_389_tmpvar_phold = null;
BEC_4_6_TextString bevt_390_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_391_tmpvar_phold = null;
BEC_4_6_TextString bevt_392_tmpvar_phold = null;
BEC_4_6_TextString bevt_393_tmpvar_phold = null;
BEC_4_6_TextString bevt_394_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_395_tmpvar_phold = null;
BEC_4_6_TextString bevt_396_tmpvar_phold = null;
BEC_4_6_TextString bevt_397_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_398_tmpvar_phold = null;
BEC_4_6_TextString bevt_399_tmpvar_phold = null;
BEC_4_6_TextString bevt_400_tmpvar_phold = null;
BEC_4_6_TextString bevt_401_tmpvar_phold = null;
BEC_4_6_TextString bevt_402_tmpvar_phold = null;
BEC_4_6_TextString bevt_403_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_404_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_405_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_406_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_407_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_408_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_409_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_410_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_411_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_412_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_413_tmpvar_phold = null;
BEC_4_6_TextString bevt_414_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_415_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_416_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_417_tmpvar_phold = null;
BEC_4_6_TextString bevt_418_tmpvar_phold = null;
BEC_6_9_SystemException bevt_419_tmpvar_phold = null;
BEC_4_6_TextString bevt_420_tmpvar_phold = null;
BEC_4_6_TextString bevt_421_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_422_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_423_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_424_tmpvar_phold = null;
BEC_4_6_TextString bevt_425_tmpvar_phold = null;
BEC_4_6_TextString bevt_426_tmpvar_phold = null;
BEC_4_6_TextString bevt_427_tmpvar_phold = null;
BEC_4_6_TextString bevt_428_tmpvar_phold = null;
BEC_4_6_TextString bevt_429_tmpvar_phold = null;
BEC_4_6_TextString bevt_430_tmpvar_phold = null;
BEC_4_6_TextString bevt_431_tmpvar_phold = null;
BEC_4_6_TextString bevt_432_tmpvar_phold = null;
BEC_4_6_TextString bevt_433_tmpvar_phold = null;
BEC_4_6_TextString bevt_434_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_435_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_436_tmpvar_phold = null;
BEC_4_6_TextString bevt_437_tmpvar_phold = null;
BEC_4_6_TextString bevt_438_tmpvar_phold = null;
BEC_4_6_TextString bevt_439_tmpvar_phold = null;
BEC_4_6_TextString bevt_440_tmpvar_phold = null;
BEC_4_6_TextString bevt_441_tmpvar_phold = null;
BEC_4_6_TextString bevt_442_tmpvar_phold = null;
BEC_4_6_TextString bevt_443_tmpvar_phold = null;
BEC_4_6_TextString bevt_444_tmpvar_phold = null;
BEC_4_6_TextString bevt_445_tmpvar_phold = null;
BEC_4_6_TextString bevt_446_tmpvar_phold = null;
BEC_4_6_TextString bevt_447_tmpvar_phold = null;
BEC_4_6_TextString bevt_448_tmpvar_phold = null;
BEC_4_6_TextString bevt_449_tmpvar_phold = null;
BEC_4_6_TextString bevt_450_tmpvar_phold = null;
BEC_4_6_TextString bevt_451_tmpvar_phold = null;
BEC_4_6_TextString bevt_452_tmpvar_phold = null;
BEC_4_6_TextString bevt_453_tmpvar_phold = null;
BEC_4_6_TextString bevt_454_tmpvar_phold = null;
BEC_4_6_TextString bevt_455_tmpvar_phold = null;
BEC_4_6_TextString bevt_456_tmpvar_phold = null;
BEC_4_6_TextString bevt_457_tmpvar_phold = null;
BEC_4_6_TextString bevt_458_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_459_tmpvar_phold = null;
BEC_4_6_TextString bevt_460_tmpvar_phold = null;
BEC_4_6_TextString bevt_461_tmpvar_phold = null;
BEC_4_6_TextString bevt_462_tmpvar_phold = null;
BEC_4_6_TextString bevt_463_tmpvar_phold = null;
BEC_4_6_TextString bevt_464_tmpvar_phold = null;
BEC_4_6_TextString bevt_465_tmpvar_phold = null;
BEC_4_6_TextString bevt_466_tmpvar_phold = null;
BEC_4_6_TextString bevt_467_tmpvar_phold = null;
BEC_4_6_TextString bevt_468_tmpvar_phold = null;
BEC_4_6_TextString bevt_469_tmpvar_phold = null;
BEC_4_6_TextString bevt_470_tmpvar_phold = null;
BEC_4_6_TextString bevt_471_tmpvar_phold = null;
BEC_4_6_TextString bevt_472_tmpvar_phold = null;
BEC_4_6_TextString bevt_473_tmpvar_phold = null;
BEC_4_6_TextString bevt_474_tmpvar_phold = null;
BEC_4_6_TextString bevt_475_tmpvar_phold = null;
BEC_4_6_TextString bevt_476_tmpvar_phold = null;
BEC_4_6_TextString bevt_477_tmpvar_phold = null;
BEC_4_6_TextString bevt_478_tmpvar_phold = null;
BEC_4_6_TextString bevt_479_tmpvar_phold = null;
BEC_4_6_TextString bevt_480_tmpvar_phold = null;
BEC_4_6_TextString bevt_481_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_482_tmpvar_phold = null;
BEC_4_3_MathInt bevt_483_tmpvar_phold = null;
BEC_4_3_MathInt bevt_484_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_485_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_486_tmpvar_phold = null;
BEC_4_3_MathInt bevt_487_tmpvar_phold = null;
BEC_4_6_TextString bevt_488_tmpvar_phold = null;
BEC_4_6_TextString bevt_489_tmpvar_phold = null;
BEC_4_6_TextString bevt_490_tmpvar_phold = null;
BEC_4_6_TextString bevt_491_tmpvar_phold = null;
BEC_4_6_TextString bevt_492_tmpvar_phold = null;
BEC_4_6_TextString bevt_493_tmpvar_phold = null;
BEC_4_6_TextString bevt_494_tmpvar_phold = null;
BEC_4_6_TextString bevt_495_tmpvar_phold = null;
BEC_4_6_TextString bevt_496_tmpvar_phold = null;
BEC_4_6_TextString bevt_497_tmpvar_phold = null;
BEC_4_6_TextString bevt_498_tmpvar_phold = null;
BEC_4_6_TextString bevt_499_tmpvar_phold = null;
BEC_4_6_TextString bevt_500_tmpvar_phold = null;
BEC_4_6_TextString bevt_501_tmpvar_phold = null;
BEC_4_6_TextString bevt_502_tmpvar_phold = null;
BEC_4_6_TextString bevt_503_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_504_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_505_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_506_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_507_tmpvar_phold = null;
BEC_4_6_TextString bevt_508_tmpvar_phold = null;
BEC_4_6_TextString bevt_509_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_510_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_511_tmpvar_phold = null;
BEC_4_6_TextString bevt_512_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_513_tmpvar_phold = null;
BEC_4_6_TextString bevt_514_tmpvar_phold = null;
BEC_4_6_TextString bevt_515_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_516_tmpvar_phold = null;
BEC_4_6_TextString bevt_517_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_518_tmpvar_phold = null;
BEC_4_6_TextString bevt_519_tmpvar_phold = null;
BEC_4_6_TextString bevt_520_tmpvar_phold = null;
BEC_4_6_TextString bevt_521_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_522_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_523_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_524_tmpvar_phold = null;
BEC_4_6_TextString bevt_525_tmpvar_phold = null;
BEC_4_6_TextString bevt_526_tmpvar_phold = null;
BEC_4_6_TextString bevt_527_tmpvar_phold = null;
BEC_4_6_TextString bevt_528_tmpvar_phold = null;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_callNames.bem_put_1(bevt_21_tmpvar_phold);
bevp_lastCall = beva_node;
bevp_methodCalls.bem_addValue_1(beva_node);
bevl_moreLines = this.bem_countLines_2(bevp_methodBody, bevp_lastMethodBodySize);
bevp_lastMethodBodyLines = bevp_lastMethodBodyLines.bem_add_1(bevl_moreLines);
bevp_lastMethodBodySize = bevp_methodBody.bem_sizeGet_0();
beva_node.bem_nlecSet_1(bevp_lastMethodBodyLines);
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_277));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_26_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 1287 */ {
bevt_29_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_lengthGet_0();
bevt_30_tmpvar_phold = bevo_72;
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_notEquals_1(bevt_30_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 1287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1287 */
 else  /* Line: 1287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 1287 */ {
bevt_31_tmpvar_phold = bevo_73;
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_lengthGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_toString_0();
bevl_errmsg = bevt_31_tmpvar_phold.bem_add_1(bevt_32_tmpvar_phold);
bevl_ei = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 1289 */ {
bevt_37_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_lengthGet_0();
bevt_35_tmpvar_phold = bevl_ei.bem_lesser_1(bevt_36_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 1289 */ {
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_279));
bevt_40_tmpvar_phold = bevl_errmsg.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_41_tmpvar_phold);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_ei);
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_280));
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_get_1(bevl_ei);
bevl_errmsg = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpvar_phold);
bevl_ei = bevl_ei.bem_increment_0();
} /* Line: 1289 */
 else  /* Line: 1289 */ {
break;
} /* Line: 1289 */
} /* Line: 1289 */
bevt_45_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevl_errmsg, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_45_tmpvar_phold);
} /* Line: 1292 */
 else  /* Line: 1287 */ {
bevt_48_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_281));
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpvar_phold);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 1293 */ {
bevt_54_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_55_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_282));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_55_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 1293 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1293 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1293 */
 else  /* Line: 1293 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 1293 */ {
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(26, bels_283));
bevt_56_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_57_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_56_tmpvar_phold);
} /* Line: 1294 */
 else  /* Line: 1287 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_284));
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 1295 */ {
this.bem_acceptThrow_1(beva_node);
return this;
} /* Line: 1297 */
 else  /* Line: 1287 */ {
bevt_64_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_65_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_285));
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_65_tmpvar_phold);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 1298 */ {
bevt_67_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_66_tmpvar_phold != null && bevt_66_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_66_tmpvar_phold).bevi_bool) /* Line: 1302 */ {
bevt_70_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_firstGet_0();
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_5_8_BuildNamePath) bevt_68_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1303 */
bevt_73_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_typenameGet_0();
bevt_74_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_equals_1(bevt_74_tmpvar_phold);
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 1305 */ {
bevt_77_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_firstGet_0();
bevt_79_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_78_tmpvar_phold = this.bem_formTarg_1(bevt_79_tmpvar_phold);
bevt_75_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_76_tmpvar_phold, bevt_78_tmpvar_phold, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_75_tmpvar_phold);
} /* Line: 1307 */
 else  /* Line: 1305 */ {
bevt_82_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bem_typenameGet_0();
bevt_83_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_equals_1(bevt_83_tmpvar_phold);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 1308 */ {
bevt_86_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_firstGet_0();
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_286));
bevt_84_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_85_tmpvar_phold, bevt_87_tmpvar_phold, null);
bevp_methodBody.bem_addValue_1(bevt_84_tmpvar_phold);
} /* Line: 1309 */
 else  /* Line: 1305 */ {
bevt_90_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_typenameGet_0();
bevt_91_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_equals_1(bevt_91_tmpvar_phold);
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 1310 */ {
bevt_94_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_93_tmpvar_phold = bevt_94_tmpvar_phold.bem_firstGet_0();
bevt_92_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_93_tmpvar_phold, bevp_trueValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_92_tmpvar_phold);
} /* Line: 1311 */
 else  /* Line: 1305 */ {
bevt_97_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_typenameGet_0();
bevt_98_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_equals_1(bevt_98_tmpvar_phold);
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 1312 */ {
bevt_101_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_firstGet_0();
bevt_99_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_100_tmpvar_phold, bevp_falseValue, bevl_castTo);
bevp_methodBody.bem_addValue_1(bevt_99_tmpvar_phold);
} /* Line: 1313 */
 else  /* Line: 1305 */ {
bevt_105_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_heldGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_106_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_287));
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpvar_phold);
if (bevt_102_tmpvar_phold != null && bevt_102_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_102_tmpvar_phold).bevi_bool) /* Line: 1314 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_110_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_heldGet_0();
bevt_108_tmpvar_phold = bevt_109_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_111_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_288));
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_111_tmpvar_phold);
if (bevt_107_tmpvar_phold != null && bevt_107_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_107_tmpvar_phold).bevi_bool) /* Line: 1314 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1314 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 1314 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_115_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bem_heldGet_0();
bevt_113_tmpvar_phold = bevt_114_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_289));
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpvar_phold);
if (bevt_112_tmpvar_phold != null && bevt_112_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_112_tmpvar_phold).bevi_bool) /* Line: 1314 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1314 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1314 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 1315 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1315 */ {
bevt_120_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bem_heldGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_290));
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_117_tmpvar_phold != null && bevt_117_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_117_tmpvar_phold).bevi_bool) /* Line: 1315 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1315 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1315 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 1315 */ {
bevt_123_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_122_tmpvar_phold != null && bevt_122_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_122_tmpvar_phold).bevi_bool) /* Line: 1322 */ {
bevt_129_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_firstGet_0();
bevt_127_tmpvar_phold = bevt_128_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_130_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_291));
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_130_tmpvar_phold);
if (bevt_124_tmpvar_phold != null && bevt_124_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_124_tmpvar_phold).bevi_bool) /* Line: 1323 */ {
bevt_132_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(48, bels_292));
bevt_131_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 1324 */
} /* Line: 1323 */
bevt_136_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_137_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_293));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_137_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 1327 */ {
bevl_nullRes = bevp_trueValue;
bevl_notNullRes = bevp_falseValue;
} /* Line: 1329 */
 else  /* Line: 1330 */ {
bevl_nullRes = bevp_falseValue;
bevl_notNullRes = bevp_trueValue;
} /* Line: 1332 */
bevt_141_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_294));
bevt_140_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_141_tmpvar_phold);
bevt_144_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_143_tmpvar_phold = bevt_144_tmpvar_phold.bem_secondGet_0();
bevt_142_tmpvar_phold = this.bem_formTarg_1(bevt_143_tmpvar_phold);
bevt_139_tmpvar_phold = (BEC_4_6_TextString) bevt_140_tmpvar_phold.bem_addValue_1(bevt_142_tmpvar_phold);
bevt_145_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_295));
bevt_138_tmpvar_phold = (BEC_4_6_TextString) bevt_139_tmpvar_phold.bem_addValue_1(bevt_145_tmpvar_phold);
bevt_138_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_148_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_147_tmpvar_phold = bevt_148_tmpvar_phold.bem_firstGet_0();
bevt_146_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_147_tmpvar_phold, bevl_nullRes, null);
bevp_methodBody.bem_addValue_1(bevt_146_tmpvar_phold);
bevt_150_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_296));
bevt_149_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_150_tmpvar_phold);
bevt_149_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_153_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_152_tmpvar_phold = bevt_153_tmpvar_phold.bem_firstGet_0();
bevt_151_tmpvar_phold = this.bem_finalAssign_3((BEC_5_4_BuildNode) bevt_152_tmpvar_phold, bevl_notNullRes, null);
bevp_methodBody.bem_addValue_1(bevt_151_tmpvar_phold);
bevt_155_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_297));
bevt_154_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_155_tmpvar_phold);
bevt_154_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1338 */
} /* Line: 1305 */
} /* Line: 1305 */
} /* Line: 1305 */
} /* Line: 1305 */
return this;
} /* Line: 1340 */
 else  /* Line: 1287 */ {
bevt_158_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_157_tmpvar_phold = bevt_158_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_159_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_298));
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_159_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 1341 */ {
bevl_returnCast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_299));
bevt_161_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_160_tmpvar_phold != null && bevt_160_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_160_tmpvar_phold).bevi_bool) /* Line: 1344 */ {
bevt_162_tmpvar_phold = this.bem_formCast_1(bevp_returnType);
bevt_163_tmpvar_phold = bevo_74;
bevl_returnCast = bevt_162_tmpvar_phold.bem_add_1(bevt_163_tmpvar_phold);
} /* Line: 1345 */
bevt_168_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_301));
bevt_167_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_168_tmpvar_phold);
bevt_166_tmpvar_phold = (BEC_4_6_TextString) bevt_167_tmpvar_phold.bem_addValue_1(bevl_returnCast);
bevt_170_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_169_tmpvar_phold = this.bem_formTarg_1(bevt_170_tmpvar_phold);
bevt_165_tmpvar_phold = (BEC_4_6_TextString) bevt_166_tmpvar_phold.bem_addValue_1(bevt_169_tmpvar_phold);
bevt_171_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_302));
bevt_164_tmpvar_phold = (BEC_4_6_TextString) bevt_165_tmpvar_phold.bem_addValue_1(bevt_171_tmpvar_phold);
bevt_164_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /* Line: 1348 */
 else  /* Line: 1287 */ {
bevt_174_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_173_tmpvar_phold = bevt_174_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_175_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_303));
bevt_172_tmpvar_phold = bevt_173_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_175_tmpvar_phold);
if (bevt_172_tmpvar_phold != null && bevt_172_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_172_tmpvar_phold).bevi_bool) /* Line: 1349 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_178_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_179_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_304));
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_179_tmpvar_phold);
if (bevt_176_tmpvar_phold != null && bevt_176_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_176_tmpvar_phold).bevi_bool) /* Line: 1349 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1349 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 1349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_182_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_181_tmpvar_phold = bevt_182_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_183_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_305));
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_183_tmpvar_phold);
if (bevt_180_tmpvar_phold != null && bevt_180_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_180_tmpvar_phold).bevi_bool) /* Line: 1349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1349 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 1349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_186_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_185_tmpvar_phold = bevt_186_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_187_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_306));
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_187_tmpvar_phold);
if (bevt_184_tmpvar_phold != null && bevt_184_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_184_tmpvar_phold).bevi_bool) /* Line: 1349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1349 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1349 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 1349 */ {
return this;
} /* Line: 1351 */
} /* Line: 1287 */
} /* Line: 1287 */
} /* Line: 1287 */
} /* Line: 1287 */
} /* Line: 1287 */
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_194_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_195_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_307));
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_195_tmpvar_phold);
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_196_tmpvar_phold = bevt_197_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_191_tmpvar_phold = bevt_192_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_196_tmpvar_phold);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_191_tmpvar_phold);
if (bevt_188_tmpvar_phold != null && bevt_188_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_188_tmpvar_phold).bevi_bool) /* Line: 1354 */ {
bevt_204_tmpvar_phold = bevo_75;
bevt_206_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_205_tmpvar_phold = bevt_206_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_203_tmpvar_phold = bevt_204_tmpvar_phold.bem_add_1(bevt_205_tmpvar_phold);
bevt_207_tmpvar_phold = bevo_76;
bevt_202_tmpvar_phold = bevt_203_tmpvar_phold.bem_add_1(bevt_207_tmpvar_phold);
bevt_209_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bem_add_1(bevt_208_tmpvar_phold);
bevt_210_tmpvar_phold = bevo_77;
bevt_200_tmpvar_phold = bevt_201_tmpvar_phold.bem_add_1(bevt_210_tmpvar_phold);
bevt_212_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_211_tmpvar_phold = bevt_212_tmpvar_phold.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_199_tmpvar_phold = bevt_200_tmpvar_phold.bem_add_1(bevt_211_tmpvar_phold);
bevt_198_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_199_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_198_tmpvar_phold);
} /* Line: 1355 */
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_superCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isConstruct = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_214_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_213_tmpvar_phold != null && bevt_213_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_213_tmpvar_phold).bevi_bool) /* Line: 1363 */ {
bevl_isConstruct = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_215_tmpvar_phold);
} /* Line: 1365 */
 else  /* Line: 1363 */ {
bevt_221_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_220_tmpvar_phold = bevt_221_tmpvar_phold.bem_firstGet_0();
bevt_219_tmpvar_phold = bevt_220_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_218_tmpvar_phold = bevt_219_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_222_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_311));
bevt_217_tmpvar_phold = bevt_218_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_222_tmpvar_phold);
if (bevt_217_tmpvar_phold != null && bevt_217_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_217_tmpvar_phold).bevi_bool) /* Line: 1366 */ {
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1367 */
 else  /* Line: 1363 */ {
bevt_227_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_226_tmpvar_phold = bevt_227_tmpvar_phold.bem_firstGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_228_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_312));
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_228_tmpvar_phold);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 1368 */ {
bevl_selfCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_superCall = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevp_superCalls.bem_addValue_1(beva_node);
bevt_229_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_230_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_229_tmpvar_phold.bemd_1(1785494885, BEL_4_Base.bevn_superCallSet_1, bevt_230_tmpvar_phold);
} /* Line: 1372 */
} /* Line: 1363 */
} /* Line: 1363 */
bevl_callArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_spillArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevl_numargs = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_231_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_231_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1381 */ {
bevt_232_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_232_tmpvar_phold != null && bevt_232_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_232_tmpvar_phold).bevi_bool) /* Line: 1381 */ {
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_argCasts = (BEC_9_5_ContainerArray) bevt_233_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_235_tmpvar_phold = bevo_78;
bevt_234_tmpvar_phold = bevl_numargs.bem_equals_1(bevt_235_tmpvar_phold);
if (bevt_234_tmpvar_phold.bevi_bool) /* Line: 1384 */ {
bevl_target = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevl_targetNode = (BEC_5_4_BuildNode) bevl_i;
bevt_237_tmpvar_phold = bevl_targetNode.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_236_tmpvar_phold != null && bevt_236_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_236_tmpvar_phold).bevi_bool) /* Line: 1388 */ {
bevl_isTyped = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1389 */
} /* Line: 1388 */
 else  /* Line: 1391 */ {
if (bevl_isTyped.bevi_bool) /* Line: 1392 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1392 */ {
bevt_238_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 1392 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1392 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1392 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 1392 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1392 */ {
bevt_240_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_239_tmpvar_phold = bevt_240_tmpvar_phold.bem_not_0();
if (bevt_239_tmpvar_phold.bevi_bool) /* Line: 1392 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1392 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1392 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 1392 */ {
bevt_242_tmpvar_phold = bevo_79;
bevt_241_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_242_tmpvar_phold);
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 1393 */ {
bevt_243_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_313));
bevl_callArgs.bem_addValue_1(bevt_243_tmpvar_phold);
} /* Line: 1394 */
bevt_245_tmpvar_phold = bevl_argCasts.bem_lengthGet_0();
bevt_244_tmpvar_phold = bevt_245_tmpvar_phold.bem_greater_1(bevl_numargs);
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 1396 */ {
bevt_247_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
if (bevt_247_tmpvar_phold == null) {
bevt_246_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_246_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_246_tmpvar_phold.bevi_bool) /* Line: 1396 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1396 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1396 */
 else  /* Line: 1396 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 1396 */ {
bevt_251_tmpvar_phold = bevl_argCasts.bem_get_1(bevl_numargs);
bevt_250_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_251_tmpvar_phold);
bevt_249_tmpvar_phold = this.bem_formCast_1(bevt_250_tmpvar_phold);
bevt_248_tmpvar_phold = (BEC_4_6_TextString) bevl_callArgs.bem_addValue_1(bevt_249_tmpvar_phold);
bevt_252_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_314));
bevt_248_tmpvar_phold.bem_addValue_1(bevt_252_tmpvar_phold);
} /* Line: 1397 */
bevt_253_tmpvar_phold = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevl_callArgs.bem_addValue_1(bevt_253_tmpvar_phold);
} /* Line: 1399 */
 else  /* Line: 1400 */ {
bevl_spillArgPos = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_259_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_315));
bevt_258_tmpvar_phold = (BEC_4_6_TextString) bevl_spillArgs.bem_addValue_1(bevt_259_tmpvar_phold);
bevt_260_tmpvar_phold = bevl_spillArgPos.bem_toString_0();
bevt_257_tmpvar_phold = (BEC_4_6_TextString) bevt_258_tmpvar_phold.bem_addValue_1(bevt_260_tmpvar_phold);
bevt_261_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_316));
bevt_256_tmpvar_phold = (BEC_4_6_TextString) bevt_257_tmpvar_phold.bem_addValue_1(bevt_261_tmpvar_phold);
bevt_262_tmpvar_phold = this.bem_formTarg_1((BEC_5_4_BuildNode) bevl_i);
bevt_255_tmpvar_phold = (BEC_4_6_TextString) bevt_256_tmpvar_phold.bem_addValue_1(bevt_262_tmpvar_phold);
bevt_263_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_317));
bevt_254_tmpvar_phold = (BEC_4_6_TextString) bevt_255_tmpvar_phold.bem_addValue_1(bevt_263_tmpvar_phold);
bevt_254_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1403 */
} /* Line: 1392 */
bevl_numargs = bevl_numargs.bem_increment_0();
} /* Line: 1406 */
 else  /* Line: 1381 */ {
break;
} /* Line: 1381 */
} /* Line: 1381 */
bevl_numargs = bevl_numargs.bem_decrement_0();
if (bevl_isConstruct.bevi_bool) /* Line: 1412 */ {
bevt_264_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_264_tmpvar_phold.bevi_bool) /* Line: 1412 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1412 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1412 */
 else  /* Line: 1412 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 1412 */ {
bevt_266_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(27, bels_318));
bevt_265_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_266_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_265_tmpvar_phold);
} /* Line: 1413 */
bevl_isOnce = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_onceDeced = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_269_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_268_tmpvar_phold = bevt_269_tmpvar_phold.bem_typenameGet_0();
bevt_270_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_267_tmpvar_phold = bevt_268_tmpvar_phold.bem_equals_1(bevt_270_tmpvar_phold);
if (bevt_267_tmpvar_phold.bevi_bool) /* Line: 1420 */ {
bevt_274_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_heldGet_0();
bevt_272_tmpvar_phold = bevt_273_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_275_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_319));
bevt_271_tmpvar_phold = bevt_272_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_275_tmpvar_phold);
if (bevt_271_tmpvar_phold != null && bevt_271_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_271_tmpvar_phold).bevi_bool) /* Line: 1420 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1420 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1420 */
 else  /* Line: 1420 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 1420 */ {
bevt_277_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_276_tmpvar_phold = this.bem_isOnceAssign_1(bevt_277_tmpvar_phold);
if (bevt_276_tmpvar_phold.bevi_bool) /* Line: 1421 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1421 */ {
bevt_279_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_278_tmpvar_phold = bevt_279_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_278_tmpvar_phold.bevi_bool) /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1421 */
 else  /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
bevt_280_tmpvar_phold = bevt_14_tmpvar_anchor.bem_not_0();
if (bevt_280_tmpvar_phold.bevi_bool) /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1421 */
 else  /* Line: 1421 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 1421 */ {
bevl_isOnce = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevt_281_tmpvar_phold = bevp_onceCount.bem_toString_0();
bevl_ovar = this.bem_onceVarDec_1(bevt_281_tmpvar_phold);
bevp_onceCount = bevp_onceCount.bem_increment_0();
bevt_287_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_286_tmpvar_phold = bevt_287_tmpvar_phold.bem_containedGet_0();
bevt_285_tmpvar_phold = bevt_286_tmpvar_phold.bem_firstGet_0();
bevt_284_tmpvar_phold = bevt_285_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_283_tmpvar_phold = bevt_284_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_282_tmpvar_phold = bevt_283_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_282_tmpvar_phold != null && bevt_282_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_282_tmpvar_phold).bevi_bool) /* Line: 1426 */ {
bevt_289_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_288_tmpvar_phold = bevp_objectCc.bem_relEmitName_1(bevt_289_tmpvar_phold);
bevl_odec = (BEC_4_6_TextString) this.bem_onceDec_2((BEC_4_6_TextString) bevt_288_tmpvar_phold, bevl_ovar);
} /* Line: 1427 */
 else  /* Line: 1428 */ {
bevt_296_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_295_tmpvar_phold = bevt_296_tmpvar_phold.bem_containedGet_0();
bevt_294_tmpvar_phold = bevt_295_tmpvar_phold.bem_firstGet_0();
bevt_293_tmpvar_phold = bevt_294_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_292_tmpvar_phold = bevt_293_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_291_tmpvar_phold = this.bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevt_292_tmpvar_phold);
bevt_297_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_290_tmpvar_phold = bevt_291_tmpvar_phold.bem_relEmitName_1(bevt_297_tmpvar_phold);
bevl_odec = (BEC_4_6_TextString) this.bem_onceDec_2((BEC_4_6_TextString) bevt_290_tmpvar_phold, bevl_ovar);
} /* Line: 1429 */
} /* Line: 1426 */
bevt_300_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_299_tmpvar_phold = bevt_300_tmpvar_phold.bem_heldGet_0();
bevt_298_tmpvar_phold = bevt_299_tmpvar_phold.bemd_0(655314870, BEL_4_Base.bevn_checkTypesGet_0);
if (bevt_298_tmpvar_phold != null && bevt_298_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_298_tmpvar_phold).bevi_bool) /* Line: 1434 */ {
bevt_304_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bem_containedGet_0();
bevt_302_tmpvar_phold = bevt_303_tmpvar_phold.bem_firstGet_0();
bevt_301_tmpvar_phold = bevt_302_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_castTo = (BEC_5_8_BuildNamePath) bevt_301_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 1436 */
bevt_307_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_306_tmpvar_phold = bevt_307_tmpvar_phold.bem_containedGet_0();
bevt_305_tmpvar_phold = bevt_306_tmpvar_phold.bem_firstGet_0();
bevl_callAssign = this.bem_finalAssignTo_2((BEC_5_4_BuildNode) bevt_305_tmpvar_phold, bevl_castTo);
} /* Line: 1438 */
 else  /* Line: 1439 */ {
bevl_callAssign = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_320));
} /* Line: 1440 */
if (bevl_isOnce.bevi_bool) /* Line: 1443 */ {
bevt_315_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_314_tmpvar_phold = bevt_315_tmpvar_phold.bem_containedGet_0();
bevt_313_tmpvar_phold = bevt_314_tmpvar_phold.bem_firstGet_0();
bevt_312_tmpvar_phold = bevt_313_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_311_tmpvar_phold = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_312_tmpvar_phold);
bevt_316_tmpvar_phold = bevo_80;
bevt_310_tmpvar_phold = bevt_311_tmpvar_phold.bem_add_1(bevt_316_tmpvar_phold);
bevt_309_tmpvar_phold = bevt_310_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_317_tmpvar_phold = bevo_81;
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bem_add_1(bevt_317_tmpvar_phold);
bevl_postOnceCallAssign = bevt_308_tmpvar_phold.bem_add_1(bevp_nl);
if (bevl_castTo == null) {
bevt_318_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_318_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_318_tmpvar_phold.bevi_bool) /* Line: 1447 */ {
bevt_320_tmpvar_phold = this.bem_getClassConfig_1(bevl_castTo);
bevt_319_tmpvar_phold = this.bem_formCast_1(bevt_320_tmpvar_phold);
bevt_321_tmpvar_phold = bevo_82;
bevl_cast = bevt_319_tmpvar_phold.bem_add_1(bevt_321_tmpvar_phold);
} /* Line: 1448 */
 else  /* Line: 1449 */ {
bevl_cast = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_324));
} /* Line: 1450 */
bevt_323_tmpvar_phold = bevo_83;
bevt_322_tmpvar_phold = bevl_ovar.bem_add_1(bevt_323_tmpvar_phold);
bevl_callAssign = bevt_322_tmpvar_phold.bem_add_1(bevl_cast);
} /* Line: 1452 */
if (bevl_isTyped.bevi_bool) /* Line: 1456 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1456 */ {
bevt_325_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_324_tmpvar_phold = bevt_325_tmpvar_phold.bem_not_0();
if (bevt_324_tmpvar_phold.bevi_bool) /* Line: 1456 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1456 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1456 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 1456 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1456 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1456 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1456 */
 else  /* Line: 1456 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 1456 */ {
bevt_327_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_326_tmpvar_phold = bevt_327_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_326_tmpvar_phold != null && bevt_326_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_326_tmpvar_phold).bevi_bool) /* Line: 1456 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1456 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1456 */
 else  /* Line: 1456 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 1456 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1456 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1456 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1456 */
 else  /* Line: 1456 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 1456 */ {
bevl_onceDeced = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 1457 */
 else  /* Line: 1456 */ {
if (bevl_isOnce.bevi_bool) /* Line: 1458 */ {
bevt_329_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_326));
bevt_328_tmpvar_phold = this.bem_emitting_1(bevt_329_tmpvar_phold);
if (bevt_328_tmpvar_phold.bevi_bool) /* Line: 1461 */ {
bevt_333_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_327));
bevt_332_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_333_tmpvar_phold);
bevt_334_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_331_tmpvar_phold = (BEC_4_6_TextString) bevt_332_tmpvar_phold.bem_addValue_1(bevt_334_tmpvar_phold);
bevt_335_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_328));
bevt_330_tmpvar_phold = (BEC_4_6_TextString) bevt_331_tmpvar_phold.bem_addValue_1(bevt_335_tmpvar_phold);
bevt_330_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1462 */
 else  /* Line: 1461 */ {
bevt_337_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_329));
bevt_336_tmpvar_phold = this.bem_emitting_1(bevt_337_tmpvar_phold);
if (bevt_336_tmpvar_phold.bevi_bool) /* Line: 1463 */ {
bevt_341_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_330));
bevt_340_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_341_tmpvar_phold);
bevt_342_tmpvar_phold = bevp_classConf.bem_emitNameGet_0();
bevt_339_tmpvar_phold = (BEC_4_6_TextString) bevt_340_tmpvar_phold.bem_addValue_1(bevt_342_tmpvar_phold);
bevt_343_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_331));
bevt_338_tmpvar_phold = (BEC_4_6_TextString) bevt_339_tmpvar_phold.bem_addValue_1(bevt_343_tmpvar_phold);
bevt_338_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1464 */
} /* Line: 1461 */
bevt_347_tmpvar_phold = bevo_84;
bevt_346_tmpvar_phold = bevt_347_tmpvar_phold.bem_add_1(bevl_ovar);
bevt_348_tmpvar_phold = bevo_85;
bevt_345_tmpvar_phold = bevt_346_tmpvar_phold.bem_add_1(bevt_348_tmpvar_phold);
bevt_344_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_345_tmpvar_phold);
bevt_344_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1466 */
} /* Line: 1456 */
if (bevl_isTyped.bevi_bool) /* Line: 1471 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1471 */ {
bevt_350_tmpvar_phold = this.bem_useDynMethodsGet_0();
bevt_349_tmpvar_phold = bevt_350_tmpvar_phold.bem_not_0();
if (bevt_349_tmpvar_phold.bevi_bool) /* Line: 1471 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1471 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1471 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 1471 */ {
if (bevl_isConstruct.bevi_bool) /* Line: 1472 */ {
bevt_352_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_351_tmpvar_phold = bevt_352_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_351_tmpvar_phold != null && bevt_351_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_351_tmpvar_phold).bevi_bool) /* Line: 1473 */ {
bevt_354_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_353_tmpvar_phold = bevt_354_tmpvar_phold.bem_equals_1(bevp_intNp);
if (bevt_353_tmpvar_phold.bevi_bool) /* Line: 1474 */ {
bevl_newCall = this.bem_lintConstruct_2(bevl_newcc, beva_node);
} /* Line: 1475 */
 else  /* Line: 1474 */ {
bevt_356_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_355_tmpvar_phold = bevt_356_tmpvar_phold.bem_equals_1(bevp_floatNp);
if (bevt_355_tmpvar_phold.bevi_bool) /* Line: 1476 */ {
bevl_newCall = this.bem_lfloatConstruct_2(bevl_newcc, beva_node);
} /* Line: 1477 */
 else  /* Line: 1474 */ {
bevt_358_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_357_tmpvar_phold = bevt_358_tmpvar_phold.bem_equals_1(bevp_stringNp);
if (bevt_357_tmpvar_phold.bevi_bool) /* Line: 1478 */ {
bevt_359_tmpvar_phold = bevo_86;
bevt_362_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_361_tmpvar_phold = bevt_362_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_360_tmpvar_phold = bevt_361_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_belsName = bevt_359_tmpvar_phold.bem_add_1(bevt_360_tmpvar_phold);
bevt_364_tmpvar_phold = bevp_cnode.bem_heldGet_0();
bevt_363_tmpvar_phold = bevt_364_tmpvar_phold.bemd_0(368256414, BEL_4_Base.bevn_belsCountGet_0);
bevt_363_tmpvar_phold.bemd_0(1205852557, BEL_4_Base.bevn_incrementValue_0);
bevl_sdec = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
this.bem_lstringStart_2(bevl_sdec, bevl_belsName);
bevt_365_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_liorg = (BEC_4_6_TextString) bevt_365_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_366_tmpvar_phold = beva_node.bem_wideStringGet_0();
if (bevt_366_tmpvar_phold.bevi_bool) /* Line: 1487 */ {
bevl_lival = bevl_liorg;
} /* Line: 1488 */
 else  /* Line: 1489 */ {
bevt_368_tmpvar_phold = (BEC_4_12_JsonUnmarshaller) (new BEC_4_12_JsonUnmarshaller()).bem_new_0();
bevt_373_tmpvar_phold = bevo_87;
bevt_375_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_374_tmpvar_phold = bevt_375_tmpvar_phold.bem_quoteGet_0();
bevt_372_tmpvar_phold = bevt_373_tmpvar_phold.bem_add_1(bevt_374_tmpvar_phold);
bevt_371_tmpvar_phold = bevt_372_tmpvar_phold.bem_add_1(bevl_liorg);
bevt_377_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_376_tmpvar_phold = bevt_377_tmpvar_phold.bem_quoteGet_0();
bevt_370_tmpvar_phold = bevt_371_tmpvar_phold.bem_add_1(bevt_376_tmpvar_phold);
bevt_378_tmpvar_phold = bevo_88;
bevt_369_tmpvar_phold = bevt_370_tmpvar_phold.bem_add_1(bevt_378_tmpvar_phold);
bevt_367_tmpvar_phold = bevt_368_tmpvar_phold.bem_unmarshall_1(bevt_369_tmpvar_phold);
bevl_lival = (BEC_4_6_TextString) bevt_367_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 1490 */
bevl_lisz = bevl_lival.bem_sizeGet_0();
bevl_lipos = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_bcode = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_0();
bevt_379_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevl_hs = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_1(bevt_379_tmpvar_phold);
while (true)
 /* Line: 1497 */ {
bevt_380_tmpvar_phold = bevl_lipos.bem_lesser_1(bevl_lisz);
if (bevt_380_tmpvar_phold.bevi_bool) /* Line: 1497 */ {
bevt_382_tmpvar_phold = bevo_89;
bevt_381_tmpvar_phold = bevl_lipos.bem_greater_1(bevt_382_tmpvar_phold);
if (bevt_381_tmpvar_phold.bevi_bool) /* Line: 1498 */ {
bevt_384_tmpvar_phold = bevo_90;
bevt_383_tmpvar_phold = (BEC_4_6_TextString) bevt_384_tmpvar_phold.bem_once_0();
bevl_sdec.bem_addValue_1(bevt_383_tmpvar_phold);
} /* Line: 1499 */
this.bem_lstringByte_5(bevl_sdec, bevl_lival, bevl_lipos, bevl_bcode, bevl_hs);
bevl_lipos.bem_incrementValue_0();
} /* Line: 1502 */
 else  /* Line: 1497 */ {
break;
} /* Line: 1497 */
} /* Line: 1497 */
this.bem_lstringEnd_1(bevl_sdec);
bevp_onceDecs.bem_addValue_1(bevl_sdec);
bevl_newCall = this.bem_lstringConstruct_5(bevl_newcc, beva_node, bevl_belsName, bevl_lisz, bevl_isOnce);
} /* Line: 1507 */
 else  /* Line: 1474 */ {
bevt_386_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_385_tmpvar_phold = bevt_386_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_385_tmpvar_phold.bevi_bool) /* Line: 1508 */ {
bevt_389_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_388_tmpvar_phold = bevt_389_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_390_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_338));
bevt_387_tmpvar_phold = bevt_388_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_390_tmpvar_phold);
if (bevt_387_tmpvar_phold != null && bevt_387_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_387_tmpvar_phold).bevi_bool) /* Line: 1509 */ {
bevl_newCall = bevp_trueValue;
} /* Line: 1510 */
 else  /* Line: 1511 */ {
bevl_newCall = bevp_falseValue;
} /* Line: 1512 */
} /* Line: 1509 */
 else  /* Line: 1514 */ {
bevt_393_tmpvar_phold = bevo_91;
bevt_395_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_394_tmpvar_phold = bevt_395_tmpvar_phold.bem_toString_0();
bevt_392_tmpvar_phold = bevt_393_tmpvar_phold.bem_add_1(bevt_394_tmpvar_phold);
bevt_391_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_1(bevt_392_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_391_tmpvar_phold);
} /* Line: 1516 */
} /* Line: 1474 */
} /* Line: 1474 */
} /* Line: 1474 */
} /* Line: 1474 */
 else  /* Line: 1518 */ {
bevt_397_tmpvar_phold = bevo_92;
bevt_399_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_398_tmpvar_phold = bevl_newcc.bem_relEmitName_1(bevt_399_tmpvar_phold);
bevt_396_tmpvar_phold = bevt_397_tmpvar_phold.bem_add_1(bevt_398_tmpvar_phold);
bevt_400_tmpvar_phold = bevo_93;
bevl_newCall = bevt_396_tmpvar_phold.bem_add_1(bevt_400_tmpvar_phold);
} /* Line: 1519 */
bevt_402_tmpvar_phold = bevo_94;
bevt_401_tmpvar_phold = bevt_402_tmpvar_phold.bem_add_1(bevl_newCall);
bevt_403_tmpvar_phold = bevo_95;
bevl_target = bevt_401_tmpvar_phold.bem_add_1(bevt_403_tmpvar_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_405_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_404_tmpvar_phold = bevt_405_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_404_tmpvar_phold != null && bevt_404_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_404_tmpvar_phold).bevi_bool) /* Line: 1525 */ {
bevt_407_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevt_406_tmpvar_phold = bevt_407_tmpvar_phold.bem_equals_1(bevp_boolNp);
if (bevt_406_tmpvar_phold.bevi_bool) /* Line: 1526 */ {
if (bevl_onceDeced.bevi_bool) /* Line: 1527 */ {
bevl_odinfo = (BEC_4_6_TextString) (new BEC_4_6_TextString()).bem_new_0();
bevt_412_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_411_tmpvar_phold = bevt_412_tmpvar_phold.bem_containedGet_0();
bevt_410_tmpvar_phold = bevt_411_tmpvar_phold.bem_firstGet_0();
bevt_409_tmpvar_phold = bevt_410_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_408_tmpvar_phold = bevt_409_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_408_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 1529 */ {
bevt_413_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_413_tmpvar_phold != null && bevt_413_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_413_tmpvar_phold).bevi_bool) /* Line: 1529 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_417_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
bevt_416_tmpvar_phold = bevt_417_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_415_tmpvar_phold = bevt_416_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_414_tmpvar_phold = (BEC_4_6_TextString) bevl_odinfo.bem_addValue_1(bevt_415_tmpvar_phold);
bevt_418_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_344));
bevt_414_tmpvar_phold.bem_addValue_1(bevt_418_tmpvar_phold);
} /* Line: 1530 */
 else  /* Line: 1529 */ {
break;
} /* Line: 1529 */
} /* Line: 1529 */
bevt_421_tmpvar_phold = bevo_96;
bevt_420_tmpvar_phold = bevt_421_tmpvar_phold.bem_add_1(bevl_odinfo);
bevt_419_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_420_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_419_tmpvar_phold);
} /* Line: 1532 */
bevt_424_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_423_tmpvar_phold = bevt_424_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_425_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_346));
bevt_422_tmpvar_phold = bevt_423_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_425_tmpvar_phold);
if (bevt_422_tmpvar_phold != null && bevt_422_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_422_tmpvar_phold).bevi_bool) /* Line: 1535 */ {
bevl_target = bevp_trueValue;
} /* Line: 1536 */
 else  /* Line: 1537 */ {
bevl_target = bevp_falseValue;
} /* Line: 1538 */
} /* Line: 1535 */
if (bevl_onceDeced.bevi_bool) /* Line: 1541 */ {
bevt_429_tmpvar_phold = (BEC_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_428_tmpvar_phold = (BEC_4_6_TextString) bevt_429_tmpvar_phold.bem_addValue_1(bevl_callAssign);
bevt_427_tmpvar_phold = (BEC_4_6_TextString) bevt_428_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_430_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_347));
bevt_426_tmpvar_phold = (BEC_4_6_TextString) bevt_427_tmpvar_phold.bem_addValue_1(bevt_430_tmpvar_phold);
bevt_426_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1542 */
 else  /* Line: 1543 */ {
bevt_433_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_432_tmpvar_phold = (BEC_4_6_TextString) bevt_433_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_434_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_348));
bevt_431_tmpvar_phold = (BEC_4_6_TextString) bevt_432_tmpvar_phold.bem_addValue_1(bevt_434_tmpvar_phold);
bevt_431_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1544 */
} /* Line: 1541 */
 else  /* Line: 1546 */ {
bevt_435_tmpvar_phold = bevl_newcc.bem_npGet_0();
bevl_asyn = bevp_build.bem_getSynNp_1(bevt_435_tmpvar_phold);
bevt_436_tmpvar_phold = bevl_asyn.bem_hasDefaultGet_0();
if (bevt_436_tmpvar_phold.bevi_bool) /* Line: 1548 */ {
bevt_443_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_442_tmpvar_phold = (BEC_4_6_TextString) bevt_443_tmpvar_phold.bem_addValue_1(bevl_stinst);
bevt_444_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_349));
bevt_441_tmpvar_phold = (BEC_4_6_TextString) bevt_442_tmpvar_phold.bem_addValue_1(bevt_444_tmpvar_phold);
bevt_445_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_440_tmpvar_phold = (BEC_4_6_TextString) bevt_441_tmpvar_phold.bem_addValue_1(bevt_445_tmpvar_phold);
bevt_446_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_350));
bevt_439_tmpvar_phold = (BEC_4_6_TextString) bevt_440_tmpvar_phold.bem_addValue_1(bevt_446_tmpvar_phold);
bevt_438_tmpvar_phold = (BEC_4_6_TextString) bevt_439_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_447_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_351));
bevt_437_tmpvar_phold = (BEC_4_6_TextString) bevt_438_tmpvar_phold.bem_addValue_1(bevt_447_tmpvar_phold);
bevt_437_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1549 */
 else  /* Line: 1550 */ {
bevt_454_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_453_tmpvar_phold = (BEC_4_6_TextString) bevt_454_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_455_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_352));
bevt_452_tmpvar_phold = (BEC_4_6_TextString) bevt_453_tmpvar_phold.bem_addValue_1(bevt_455_tmpvar_phold);
bevt_456_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_451_tmpvar_phold = (BEC_4_6_TextString) bevt_452_tmpvar_phold.bem_addValue_1(bevt_456_tmpvar_phold);
bevt_457_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_353));
bevt_450_tmpvar_phold = (BEC_4_6_TextString) bevt_451_tmpvar_phold.bem_addValue_1(bevt_457_tmpvar_phold);
bevt_449_tmpvar_phold = (BEC_4_6_TextString) bevt_450_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_458_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_354));
bevt_448_tmpvar_phold = (BEC_4_6_TextString) bevt_449_tmpvar_phold.bem_addValue_1(bevt_458_tmpvar_phold);
bevt_448_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1551 */
} /* Line: 1548 */
} /* Line: 1525 */
 else  /* Line: 1554 */ {
bevt_459_tmpvar_phold = bevl_isTyped.bem_not_0();
if (bevt_459_tmpvar_phold.bevi_bool) /* Line: 1555 */ {
bevt_466_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_465_tmpvar_phold = (BEC_4_6_TextString) bevt_466_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_467_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_355));
bevt_464_tmpvar_phold = (BEC_4_6_TextString) bevt_465_tmpvar_phold.bem_addValue_1(bevt_467_tmpvar_phold);
bevt_468_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_463_tmpvar_phold = (BEC_4_6_TextString) bevt_464_tmpvar_phold.bem_addValue_1(bevt_468_tmpvar_phold);
bevt_469_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_356));
bevt_462_tmpvar_phold = (BEC_4_6_TextString) bevt_463_tmpvar_phold.bem_addValue_1(bevt_469_tmpvar_phold);
bevt_461_tmpvar_phold = (BEC_4_6_TextString) bevt_462_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_470_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_357));
bevt_460_tmpvar_phold = (BEC_4_6_TextString) bevt_461_tmpvar_phold.bem_addValue_1(bevt_470_tmpvar_phold);
bevt_460_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1556 */
 else  /* Line: 1557 */ {
bevt_477_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_476_tmpvar_phold = (BEC_4_6_TextString) bevt_477_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_478_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_358));
bevt_475_tmpvar_phold = (BEC_4_6_TextString) bevt_476_tmpvar_phold.bem_addValue_1(bevt_478_tmpvar_phold);
bevt_479_tmpvar_phold = this.bem_emitNameForCall_1(beva_node);
bevt_474_tmpvar_phold = (BEC_4_6_TextString) bevt_475_tmpvar_phold.bem_addValue_1(bevt_479_tmpvar_phold);
bevt_480_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_359));
bevt_473_tmpvar_phold = (BEC_4_6_TextString) bevt_474_tmpvar_phold.bem_addValue_1(bevt_480_tmpvar_phold);
bevt_472_tmpvar_phold = (BEC_4_6_TextString) bevt_473_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_481_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_360));
bevt_471_tmpvar_phold = (BEC_4_6_TextString) bevt_472_tmpvar_phold.bem_addValue_1(bevt_481_tmpvar_phold);
bevt_471_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1558 */
} /* Line: 1555 */
} /* Line: 1472 */
 else  /* Line: 1561 */ {
bevt_482_tmpvar_phold = bevl_numargs.bem_lesser_1(bevp_maxDynArgs);
if (bevt_482_tmpvar_phold.bevi_bool) /* Line: 1562 */ {
bevl_dm = bevl_numargs.bem_toString_0();
bevl_callArgSpill = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_361));
} /* Line: 1564 */
 else  /* Line: 1565 */ {
bevl_dm = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_362));
bevt_483_tmpvar_phold = bevl_numargs.bem_subtract_1(bevp_maxDynArgs);
bevt_484_tmpvar_phold = bevo_97;
bevl_spillArgsLen = bevt_483_tmpvar_phold.bem_add_1(bevt_484_tmpvar_phold);
bevt_485_tmpvar_phold = bevl_spillArgsLen.bem_greater_1(bevp_maxSpillArgsLen);
if (bevt_485_tmpvar_phold.bevi_bool) /* Line: 1568 */ {
bevp_maxSpillArgsLen = bevl_spillArgsLen;
} /* Line: 1569 */
bevp_methodBody.bem_addValue_1(bevl_spillArgs);
bevl_callArgSpill = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_363));
} /* Line: 1572 */
bevt_487_tmpvar_phold = bevo_98;
bevt_486_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_487_tmpvar_phold);
if (bevt_486_tmpvar_phold.bevi_bool) /* Line: 1574 */ {
bevl_fc = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_364));
} /* Line: 1575 */
 else  /* Line: 1576 */ {
bevl_fc = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_365));
} /* Line: 1577 */
bevt_501_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevl_callAssign);
bevt_500_tmpvar_phold = (BEC_4_6_TextString) bevt_501_tmpvar_phold.bem_addValue_1(bevl_target);
bevt_502_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_366));
bevt_499_tmpvar_phold = (BEC_4_6_TextString) bevt_500_tmpvar_phold.bem_addValue_1(bevt_502_tmpvar_phold);
bevt_498_tmpvar_phold = (BEC_4_6_TextString) bevt_499_tmpvar_phold.bem_addValue_1(bevl_dm);
bevt_503_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_367));
bevt_497_tmpvar_phold = (BEC_4_6_TextString) bevt_498_tmpvar_phold.bem_addValue_1(bevt_503_tmpvar_phold);
bevt_507_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_506_tmpvar_phold = bevt_507_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_505_tmpvar_phold = bevt_506_tmpvar_phold.bemd_0(287040793, BEL_4_Base.bevn_hashGet_0);
bevt_504_tmpvar_phold = bevt_505_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_496_tmpvar_phold = (BEC_4_6_TextString) bevt_497_tmpvar_phold.bem_addValue_1(bevt_504_tmpvar_phold);
bevt_508_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_368));
bevt_495_tmpvar_phold = (BEC_4_6_TextString) bevt_496_tmpvar_phold.bem_addValue_1(bevt_508_tmpvar_phold);
bevt_494_tmpvar_phold = (BEC_4_6_TextString) bevt_495_tmpvar_phold.bem_addValue_1(bevp_libEmitName);
bevt_509_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_369));
bevt_493_tmpvar_phold = (BEC_4_6_TextString) bevt_494_tmpvar_phold.bem_addValue_1(bevt_509_tmpvar_phold);
bevt_511_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_510_tmpvar_phold = bevt_511_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_492_tmpvar_phold = (BEC_4_6_TextString) bevt_493_tmpvar_phold.bem_addValue_1(bevt_510_tmpvar_phold);
bevt_491_tmpvar_phold = (BEC_4_6_TextString) bevt_492_tmpvar_phold.bem_addValue_1(bevl_fc);
bevt_490_tmpvar_phold = (BEC_4_6_TextString) bevt_491_tmpvar_phold.bem_addValue_1(bevl_callArgs);
bevt_489_tmpvar_phold = (BEC_4_6_TextString) bevt_490_tmpvar_phold.bem_addValue_1(bevl_callArgSpill);
bevt_512_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_370));
bevt_488_tmpvar_phold = (BEC_4_6_TextString) bevt_489_tmpvar_phold.bem_addValue_1(bevt_512_tmpvar_phold);
bevt_488_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1579 */
if (bevl_isOnce.bevi_bool) /* Line: 1582 */ {
bevt_513_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_513_tmpvar_phold.bevi_bool) /* Line: 1583 */ {
bevt_515_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_371));
bevt_514_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_515_tmpvar_phold);
bevt_514_tmpvar_phold.bem_addValue_1(bevp_nl);
bevt_517_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_372));
bevt_516_tmpvar_phold = this.bem_emitting_1(bevt_517_tmpvar_phold);
if (bevt_516_tmpvar_phold.bevi_bool) /* Line: 1586 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1586 */ {
bevt_519_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_373));
bevt_518_tmpvar_phold = this.bem_emitting_1(bevt_519_tmpvar_phold);
if (bevt_518_tmpvar_phold.bevi_bool) /* Line: 1586 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1586 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1586 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 1586 */ {
bevt_521_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_374));
bevt_520_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_521_tmpvar_phold);
bevt_520_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1588 */
} /* Line: 1586 */
bevp_methodBody.bem_addValue_1(bevl_postOnceCallAssign);
bevt_522_tmpvar_phold = bevl_onceDeced.bem_not_0();
if (bevt_522_tmpvar_phold.bevi_bool) /* Line: 1592 */ {
bevt_524_tmpvar_phold = bevl_odec.bem_isEmptyGet_0();
bevt_523_tmpvar_phold = bevt_524_tmpvar_phold.bem_not_0();
if (bevt_523_tmpvar_phold.bevi_bool) /* Line: 1593 */ {
bevt_527_tmpvar_phold = (BEC_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevl_odec);
bevt_526_tmpvar_phold = (BEC_4_6_TextString) bevt_527_tmpvar_phold.bem_addValue_1(bevl_ovar);
bevt_528_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_375));
bevt_525_tmpvar_phold = (BEC_4_6_TextString) bevt_526_tmpvar_phold.bem_addValue_1(bevt_528_tmpvar_phold);
bevt_525_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1594 */
} /* Line: 1593 */
} /* Line: 1592 */
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_doInitializeIt_1(BEC_4_6_TextString beva_nc) {
BEC_4_6_TextString bevl_ii = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevl_ii = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_376));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_377));
bevt_0_tmpvar_phold = this.bem_emitting_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1603 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(67, bels_378));
bevt_3_tmpvar_phold = (BEC_4_6_TextString) bevl_ii.bem_addValue_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_5_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_379));
bevt_2_tmpvar_phold.bem_addValue_1(bevt_5_tmpvar_phold);
} /* Line: 1604 */
 else  /* Line: 1605 */ {
bevt_8_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(57, bels_380));
bevt_7_tmpvar_phold = (BEC_4_6_TextString) bevl_ii.bem_addValue_1(bevt_8_tmpvar_phold);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) bevt_7_tmpvar_phold.bem_addValue_1(beva_nc);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_381));
bevt_6_tmpvar_phold.bem_addValue_1(bevt_9_tmpvar_phold);
} /* Line: 1606 */
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_382));
bevl_ii.bem_addValue_1(bevt_10_tmpvar_phold);
return bevl_ii;
} /*method end*/
public virtual BEC_4_6_TextString bem_getInitialInst_1(BEC_5_11_BuildClassConfig beva_newcc) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_383));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lintConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_99;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_100;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_101;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lfloatConstruct_2(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_4_tmpvar_phold = bevo_102;
bevt_6_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_103;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_104;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_lstringConstruct_5(BEC_5_11_BuildClassConfig beva_newcc, BEC_5_4_BuildNode beva_node, BEC_4_6_TextString beva_belsName, BEC_4_3_MathInt beva_lisz, BEC_5_4_LogicBool beva_isOnce) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 1625 */ {
bevt_6_tmpvar_phold = bevo_105;
bevt_8_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_106;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(beva_belsName);
bevt_10_tmpvar_phold = bevo_107;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(beva_lisz);
bevt_11_tmpvar_phold = bevo_108;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /* Line: 1626 */
bevt_18_tmpvar_phold = bevo_109;
bevt_20_tmpvar_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpvar_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_110;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(beva_lisz);
bevt_22_tmpvar_phold = bevo_111;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_22_tmpvar_phold);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(beva_belsName);
bevt_23_tmpvar_phold = bevo_112;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
return bevt_12_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringStart_2(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_belsName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(22, bels_398));
bevt_1_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_399));
bevt_0_tmpvar_phold.bem_addValue_1(bevt_3_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringByte_5(BEC_4_6_TextString beva_sdec, BEC_4_6_TextString beva_lival, BEC_4_3_MathInt beva_lipos, BEC_4_3_MathInt beva_bcode, BEC_4_6_TextString beva_hs) {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lstringEnd_1(BEC_4_6_TextString beva_sdec) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_400));
bevt_0_tmpvar_phold = (BEC_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpvar_phold);
bevt_0_tmpvar_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isOnceAssign_1(BEC_5_4_BuildNode beva_asnCall) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1362267230, BEL_4_Base.bevn_isManyGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 1647 */ {
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 1648 */
bevt_5_tmpvar_phold = beva_asnCall.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1478834556, BEL_4_Base.bevn_isOnceGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 1650 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1650 */ {
bevt_6_tmpvar_phold = beva_asnCall.bem_isLiteralOnceGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1650 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1650 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1650 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 1650 */ {
bevt_7_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 1651 */
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptEmit_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_3_tmpvar_phold = this.bem_emitLangGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_3_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1657 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1060168614, BEL_4_Base.bevn_textGet_0);
bevp_methodBody.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 1658 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_acceptIfEmit_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_6_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(257792958, BEL_4_Base.bevn_langsGet_0);
bevt_4_tmpvar_phold = this.bem_emitLangGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_4_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 1663 */ {
bevt_5_tmpvar_phold = beva_node.bem_nextPeerGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 1664 */
bevt_6_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_46_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1670 */ {
this.bem_acceptClass_1(beva_node);
} /* Line: 1671 */
 else  /* Line: 1670 */ {
bevt_4_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1672 */ {
this.bem_acceptMethod_1(beva_node);
} /* Line: 1673 */
 else  /* Line: 1670 */ {
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_equals_1(bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 1674 */ {
this.bem_acceptRbraces_1(beva_node);
} /* Line: 1675 */
 else  /* Line: 1670 */ {
bevt_10_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_11_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 1676 */ {
this.bem_acceptEmit_1(beva_node);
} /* Line: 1677 */
 else  /* Line: 1670 */ {
bevt_13_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_14_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 1678 */ {
this.bem_addStackLines_1(beva_node);
bevt_15_tmpvar_phold = this.bem_acceptIfEmit_1(beva_node);
return (BEC_5_4_BuildNode) bevt_15_tmpvar_phold;
} /* Line: 1680 */
 else  /* Line: 1670 */ {
bevt_17_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_18_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 1681 */ {
this.bem_acceptCall_1(beva_node);
} /* Line: 1682 */
 else  /* Line: 1670 */ {
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 1683 */ {
this.bem_acceptBraces_1(beva_node);
} /* Line: 1684 */
 else  /* Line: 1670 */ {
bevt_23_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_24_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 1685 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_401));
bevt_25_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_26_tmpvar_phold);
bevt_25_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1686 */
 else  /* Line: 1670 */ {
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 1687 */ {
bevt_31_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_402));
bevt_30_tmpvar_phold = (BEC_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_31_tmpvar_phold);
bevt_30_tmpvar_phold.bem_addValue_1(bevp_nl);
} /* Line: 1688 */
 else  /* Line: 1670 */ {
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 1689 */ {
bevt_35_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_403));
bevp_methodBody.bem_addValue_1(bevt_35_tmpvar_phold);
} /* Line: 1690 */
 else  /* Line: 1670 */ {
bevt_37_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_38_tmpvar_phold = bevp_ntypes.bem_TRYGet_0();
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_equals_1(bevt_38_tmpvar_phold);
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 1691 */ {
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_404));
bevp_methodBody.bem_addValue_1(bevt_39_tmpvar_phold);
} /* Line: 1692 */
 else  /* Line: 1670 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 1693 */ {
this.bem_acceptCatch_1(beva_node);
} /* Line: 1694 */
 else  /* Line: 1670 */ {
bevt_44_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_45_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_equals_1(bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 1695 */ {
this.bem_acceptIf_1(beva_node);
} /* Line: 1696 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
} /* Line: 1670 */
this.bem_addStackLines_1(beva_node);
bevt_46_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_46_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_addStackLines_1(BEC_5_4_BuildNode beva_node) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_cnode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1703 */ {
} /* Line: 1703 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildStackLines_1(BEC_5_4_BuildNode beva_node) {
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_formTarg_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_tcall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1712 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_405));
} /* Line: 1713 */
 else  /* Line: 1712 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_406));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1714 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_407));
} /* Line: 1715 */
 else  /* Line: 1712 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_408));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1716 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1717 */
 else  /* Line: 1718 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1719 */
} /* Line: 1712 */
} /* Line: 1712 */
return bevl_tcall;
} /*method end*/
public virtual BEC_4_6_TextString bem_formRTarg_1(BEC_5_4_BuildNode beva_node) {
BEC_4_6_TextString bevl_tcall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_equals_1(bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1726 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_409));
} /* Line: 1727 */
 else  /* Line: 1726 */ {
bevt_5_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_410));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 1728 */ {
bevl_tcall = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_411));
} /* Line: 1729 */
 else  /* Line: 1726 */ {
bevt_9_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_412));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_10_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 1730 */ {
bevl_tcall = this.bem_superNameGet_0();
} /* Line: 1731 */
 else  /* Line: 1732 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_tcall = this.bem_nameForVar_1((BEC_5_3_BuildVar) bevt_11_tmpvar_phold);
} /* Line: 1733 */
} /* Line: 1726 */
} /* Line: 1726 */
return bevl_tcall;
} /*method end*/
public override BEC_6_6_SystemObject bem_end_1(BEC_6_6_SystemObject beva_transi) {
base.bem_end_1(beva_transi);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_beginNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_413));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_beginNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_414));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNs_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_415));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_endNs_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_416));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_extend_1(BEC_4_6_TextString beva_parent) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_417));
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_mangleName_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevl_pref = null;
BEC_4_6_TextString bevl_suf = null;
BEC_4_6_TextString bevl_step = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_pref = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_418));
bevl_suf = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_419));
bevt_1_tmpvar_phold = beva_np.bem_stepsGet_0();
bevt_0_tmpvar_loop = bevt_1_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 1770 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 1770 */ {
bevl_step = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevo_113;
bevt_3_tmpvar_phold = bevl_pref.bem_notEquals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 1771 */ {
bevt_5_tmpvar_phold = bevo_114;
bevl_pref = bevl_pref.bem_add_1(bevt_5_tmpvar_phold);
} /* Line: 1771 */
 else  /* Line: 1772 */ {
bevl_suf = (BEC_4_6_TextString) (new BEC_4_6_TextString(1, bels_422));
} /* Line: 1772 */
bevt_6_tmpvar_phold = bevl_step.bem_sizeGet_0();
bevl_pref = bevl_pref.bem_add_1(bevt_6_tmpvar_phold);
bevl_suf = bevl_suf.bem_add_1(bevl_step);
} /* Line: 1774 */
 else  /* Line: 1770 */ {
break;
} /* Line: 1770 */
} /* Line: 1770 */
bevt_7_tmpvar_phold = bevl_pref.bem_add_1(bevl_suf);
return bevt_7_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getEmitName_1(BEC_5_8_BuildNamePath beva_np) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_115;
bevt_2_tmpvar_phold = this.bem_mangleName_1(beva_np);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_getFullEmitName_2(BEC_4_6_TextString beva_nameSpace, BEC_4_6_TextString beva_emitName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_116;
bevt_1_tmpvar_phold = beva_nameSpace.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(beva_emitName);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_6_TextString bem_getNameSpace_1(BEC_4_6_TextString beva_libName) {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_117;
bevt_2_tmpvar_phold = this.bem_libEmitName_1(beva_libName);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_classConfGet_0() {
return bevp_classConf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classConfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classConf = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_parentConfGet_0() {
return bevp_parentConf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_parentConfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_parentConf = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitLangSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_fileExtGet_0() {
return bevp_fileExt;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fileExtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileExt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_exceptDecGet_0() {
return bevp_exceptDec;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exceptDecSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exceptDec = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_qGet_0() {
return bevp_q;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_qSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_q = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_ccCacheGet_0() {
return bevp_ccCache;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccCacheSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccCache = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_objectNpGet_0() {
return bevp_objectNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_objectNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_boolNpGet_0() {
return bevp_boolNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_boolNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_intNpGet_0() {
return bevp_intNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_intNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_intNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_floatNpGet_0() {
return bevp_floatNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_floatNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_floatNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_stringNpGet_0() {
return bevp_stringNp;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_stringNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_stringNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_trueValueGet_0() {
return bevp_trueValue;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_trueValueSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_trueValue = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_falseValueGet_0() {
return bevp_falseValue;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_falseValueSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_falseValue = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instanceEqualGet_0() {
return bevp_instanceEqual;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instanceEqualSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceEqual = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instanceNotEqualGet_0() {
return bevp_instanceNotEqual;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instanceNotEqualSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instanceNotEqual = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libEmitNameGet_0() {
return bevp_libEmitName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_fullLibEmitNameGet_0() {
return bevp_fullLibEmitName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullLibEmitNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fullLibEmitName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_libEmitPathGet_0() {
return bevp_libEmitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libEmitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libEmitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_methodBodyGet_0() {
return bevp_methodBody;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodBodySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodBody = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodBodySizeGet_0() {
return bevp_lastMethodBodySize;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodBodySizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodySize = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodBodyLinesGet_0() {
return bevp_lastMethodBodyLines;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodBodyLinesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodBodyLines = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_methodCallsGet_0() {
return bevp_methodCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_methodCatchGet_0() {
return bevp_methodCatch;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodCatchSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodCatch = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxDynArgsGet_0() {
return bevp_maxDynArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxDynArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxDynArgs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_maxSpillArgsLenGet_0() {
return bevp_maxSpillArgsLen;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_maxSpillArgsLenSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_maxSpillArgsLen = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_dynConditionsAllGet_0() {
return bevp_dynConditionsAll;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_lastCallGet_0() {
return bevp_lastCall;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastCallSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastCall = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerSet bem_callNamesGet_0() {
return bevp_callNames;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_callNamesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_callNames = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_objectCcGet_0() {
return bevp_objectCc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_objectCcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_objectCc = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_boolCcGet_0() {
return bevp_boolCc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_boolCcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_boolCc = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_instOfGet_0() {
return bevp_instOf;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_instOfSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_instOf = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_smnlcsGet_0() {
return bevp_smnlcs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_smnlcsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlcs = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_3_ContainerMap bem_smnlecsGet_0() {
return bevp_smnlecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_smnlecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_smnlecs = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_classesInDepthOrderGet_0() {
return bevp_classesInDepthOrder;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classesInDepthOrderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classesInDepthOrder = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lineCountGet_0() {
return bevp_lineCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lineCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_methodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_classCallsGet_0() {
return bevp_classCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodsSizeGet_0() {
return bevp_lastMethodsSize;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodsSizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsSize = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lastMethodsLinesGet_0() {
return bevp_lastMethodsLines;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastMethodsLinesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lastMethodsLines = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_mnodeGet_0() {
return bevp_mnode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mnodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mnode = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_11_BuildClassConfig bem_returnTypeGet_0() {
return bevp_returnType;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_returnTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_returnType = (BEC_5_11_BuildClassConfig) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_6_BuildMtdSyn bem_msynGet_0() {
return bevp_msyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_msynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_msyn = (BEC_5_6_BuildMtdSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_preClassGet_0() {
return bevp_preClass;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_preClassSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_preClass = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_classEmitsGet_0() {
return bevp_classEmits;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classEmitsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classEmits = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_onceDecsGet_0() {
return bevp_onceDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_onceCountGet_0() {
return bevp_onceCount;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_onceCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_onceCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_propertyDecsGet_0() {
return bevp_propertyDecs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_propertyDecsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_propertyDecs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_4_BuildNode bem_cnodeGet_0() {
return bevp_cnode;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cnodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cnode = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildClassSyn bem_csynGet_0() {
return bevp_csyn;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_csynSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_csyn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_dynMethodsGet_0() {
return bevp_dynMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_dynMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_dynMethods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_ccMethodsGet_0() {
return bevp_ccMethods;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_ccMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_ccMethods = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_superCallsGet_0() {
return bevp_superCalls;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_superCallsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_superCalls = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_nativeCSlotsGet_0() {
return bevp_nativeCSlots;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nativeCSlotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nativeCSlots = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_inFilePathedGet_0() {
return bevp_inFilePathed;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_inFilePathedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_inFilePathed = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {78, 93, 95, 95, 98, 101, 101, 102, 102, 103, 103, 104, 104, 105, 105, 109, 110, 112, 113, 116, 116, 117, 117, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 120, 121, 122, 123, 124, 126, 127, 133, 136, 137, 140, 140, 141, 143, 148, 149, 155, 155, 155, 159, 159, 159, 159, 159, 159, 159, 163, 163, 163, 163, 163, 163, 167, 168, 169, 169, 170, 170, 0, 170, 170, 171, 171, 171, 172, 172, 172, 173, 174, 177, 177, 177, 178, 180, 184, 185, 186, 186, 187, 187, 187, 188, 190, 194, 0, 194, 0, 0, 195, 195, 195, 195, 195, 197, 197, 202, 203, 203, 205, 206, 207, 208, 210, 211, 211, 213, 214, 215, 216, 218, 219, 219, 220, 220, 222, 225, 226, 230, 233, 234, 244, 245, 245, 245, 245, 246, 248, 248, 248, 250, 250, 250, 251, 252, 252, 253, 254, 256, 259, 260, 260, 261, 262, 265, 267, 269, 0, 269, 269, 270, 271, 0, 271, 271, 272, 276, 276, 278, 280, 280, 280, 281, 285, 288, 292, 293, 293, 294, 297, 297, 298, 301, 302, 302, 303, 306, 306, 307, 311, 311, 314, 315, 315, 316, 319, 319, 320, 326, 327, 329, 334, 334, 335, 0, 335, 335, 336, 336, 337, 337, 338, 338, 0, 338, 338, 0, 0, 0, 338, 338, 0, 0, 341, 343, 343, 344, 344, 346, 346, 347, 347, 350, 351, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 354, 354, 354, 356, 356, 356, 356, 356, 356, 356, 358, 358, 360, 360, 360, 360, 360, 359, 360, 361, 364, 364, 364, 364, 364, 364, 365, 365, 365, 365, 365, 365, 367, 367, 368, 368, 369, 369, 369, 371, 371, 371, 374, 374, 375, 375, 375, 377, 377, 378, 378, 378, 379, 379, 379, 379, 379, 379, 381, 381, 381, 381, 381, 381, 383, 383, 384, 384, 385, 385, 385, 387, 387, 387, 390, 390, 391, 391, 391, 393, 393, 394, 394, 394, 395, 395, 395, 395, 395, 395, 397, 397, 397, 397, 397, 397, 400, 403, 403, 404, 407, 408, 408, 409, 412, 412, 413, 416, 417, 417, 418, 421, 422, 422, 423, 427, 430, 434, 435, 435, 439, 439, 444, 444, 446, 446, 446, 446, 447, 447, 447, 449, 449, 449, 449, 449, 453, 457, 457, 457, 457, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 481, 485, 485, 489, 489, 493, 493, 494, 494, 496, 496, 501, 503, 504, 504, 505, 507, 508, 508, 509, 509, 509, 509, 511, 511, 511, 511, 511, 511, 511, 511, 511, 512, 512, 512, 513, 513, 513, 514, 514, 516, 517, 517, 518, 518, 519, 519, 519, 519, 519, 519, 519, 520, 520, 520, 520, 520, 520, 520, 522, 523, 523, 0, 523, 523, 525, 525, 525, 525, 525, 525, 528, 529, 530, 531, 531, 533, 535, 535, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 536, 538, 538, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 539, 540, 540, 540, 540, 540, 540, 540, 540, 540, 540, 541, 541, 541, 541, 541, 541, 541, 541, 541, 544, 544, 544, 545, 545, 545, 545, 545, 545, 545, 545, 545, 546, 546, 546, 546, 546, 546, 547, 547, 547, 547, 547, 547, 551, 0, 551, 551, 552, 552, 552, 552, 552, 552, 552, 552, 553, 553, 553, 553, 553, 553, 553, 553, 553, 553, 553, 556, 558, 558, 0, 558, 558, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 560, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 561, 565, 565, 565, 565, 565, 565, 565, 565, 566, 566, 567, 567, 567, 567, 567, 567, 568, 568, 569, 569, 569, 569, 569, 569, 571, 571, 571, 572, 572, 572, 573, 573, 574, 575, 576, 577, 578, 579, 580, 580, 0, 580, 580, 0, 0, 582, 582, 582, 584, 584, 584, 586, 587, 590, 590, 590, 591, 591, 593, 594, 597, 602, 602, 602, 606, 606, 610, 610, 614, 614, 620, 620, 0, 620, 620, 0, 0, 622, 622, 622, 625, 625, 625, 629, 629, 634, 636, 637, 638, 639, 646, 647, 648, 649, 650, 651, 653, 655, 655, 655, 660, 660, 661, 661, 661, 663, 663, 663, 663, 663, 668, 669, 669, 670, 670, 674, 674, 674, 674, 674, 678, 678, 678, 678, 678, 683, 684, 687, 687, 687, 687, 689, 689, 689, 691, 692, 694, 695, 695, 695, 0, 695, 695, 696, 696, 696, 696, 696, 696, 696, 696, 0, 0, 0, 697, 697, 699, 699, 701, 702, 702, 702, 703, 703, 703, 703, 703, 705, 705, 707, 707, 708, 708, 709, 709, 709, 711, 711, 711, 714, 714, 714, 714, 718, 720, 720, 721, 723, 727, 727, 727, 728, 730, 733, 733, 735, 741, 741, 741, 741, 741, 741, 741, 741, 741, 743, 745, 745, 745, 745, 745, 745, 750, 751, 751, 751, 752, 752, 754, 754, 759, 760, 761, 762, 763, 764, 765, 765, 766, 767, 768, 769, 770, 770, 770, 770, 773, 773, 773, 774, 774, 775, 775, 776, 777, 777, 777, 777, 778, 778, 778, 783, 783, 783, 783, 784, 784, 784, 785, 785, 785, 787, 791, 791, 791, 791, 792, 793, 793, 793, 0, 793, 793, 795, 795, 795, 796, 796, 796, 797, 797, 797, 802, 802, 802, 802, 0, 0, 0, 803, 803, 803, 804, 804, 805, 811, 812, 812, 812, 812, 813, 813, 814, 815, 816, 816, 817, 818, 818, 818, 820, 825, 826, 827, 827, 0, 827, 827, 828, 828, 829, 829, 830, 830, 830, 831, 831, 832, 833, 834, 836, 837, 837, 838, 839, 841, 841, 842, 843, 843, 844, 845, 847, 853, 0, 853, 853, 854, 856, 857, 857, 857, 859, 861, 862, 863, 864, 864, 864, 864, 0, 0, 0, 865, 865, 865, 865, 865, 865, 865, 865, 865, 865, 866, 866, 866, 866, 866, 866, 866, 867, 869, 870, 870, 870, 870, 870, 870, 870, 871, 871, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 873, 874, 874, 874, 876, 877, 0, 877, 877, 878, 879, 880, 880, 880, 880, 880, 880, 0, 884, 884, 884, 0, 0, 885, 887, 889, 0, 889, 889, 890, 892, 892, 892, 892, 893, 893, 893, 893, 893, 893, 895, 895, 895, 895, 895, 895, 896, 897, 897, 0, 897, 897, 898, 898, 899, 899, 899, 0, 0, 0, 900, 900, 900, 900, 900, 902, 904, 904, 905, 907, 909, 910, 910, 910, 910, 912, 912, 912, 912, 912, 914, 914, 914, 916, 918, 918, 918, 921, 921, 921, 924, 927, 927, 927, 930, 930, 930, 931, 931, 931, 931, 931, 931, 931, 931, 931, 931, 931, 931, 931, 932, 932, 932, 935, 937, 939, 947, 948, 948, 949, 950, 951, 0, 951, 951, 953, 954, 955, 956, 956, 957, 958, 959, 959, 960, 963, 963, 966, 970, 970, 970, 970, 970, 970, 970, 970, 970, 970, 970, 970, 971, 971, 971, 971, 971, 971, 971, 971, 971, 971, 971, 973, 973, 973, 977, 977, 977, 978, 979, 979, 979, 980, 982, 982, 982, 982, 982, 982, 982, 982, 982, 982, 982, 984, 985, 987, 990, 990, 990, 990, 990, 990, 990, 992, 992, 992, 995, 995, 995, 995, 995, 995, 995, 995, 995, 997, 997, 997, 997, 997, 997, 999, 999, 999, 1004, 1004, 1004, 1004, 1004, 1005, 1005, 1010, 1010, 1012, 1013, 1015, 1016, 1017, 1018, 1018, 1019, 1020, 1020, 1021, 1021, 1021, 1023, 1024, 1026, 1028, 1030, 1035, 1035, 1035, 1035, 1035, 1035, 1035, 1035, 1035, 1035, 1035, 1036, 1036, 1036, 1036, 1036, 1036, 1038, 1038, 1038, 1043, 1045, 1045, 1046, 1046, 1046, 1046, 1046, 1046, 1046, 1048, 1048, 1048, 1048, 1048, 1048, 1048, 1051, 1055, 1055, 1056, 1056, 1056, 1058, 1058, 1060, 1060, 1060, 1060, 1060, 1061, 1061, 1061, 1061, 1061, 1061, 1061, 1061, 1062, 1062, 1062, 1062, 1062, 1062, 1063, 1063, 1063, 1064, 1064, 1065, 1065, 1065, 1065, 1065, 1065, 1066, 1066, 1066, 1068, 1073, 1073, 1073, 1077, 1077, 1077, 1077, 1077, 1077, 1081, 1081, 1086, 1086, 1090, 1091, 1091, 1091, 1091, 1091, 0, 0, 0, 1092, 1092, 1092, 1092, 1092, 1094, 1098, 1098, 1098, 1099, 1099, 1100, 1100, 1100, 1100, 0, 0, 0, 1100, 1100, 0, 0, 0, 1100, 1100, 0, 0, 0, 1100, 1100, 0, 0, 0, 1102, 1102, 1102, 1102, 1102, 1102, 1102, 1111, 1111, 1111, 1111, 1111, 1111, 1111, 0, 0, 0, 1112, 1112, 1113, 1114, 1114, 1115, 1115, 1116, 1116, 0, 1116, 1116, 1116, 1116, 0, 0, 1119, 1119, 1119, 1122, 1122, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1123, 1126, 1127, 1128, 1129, 1133, 0, 1133, 1133, 1134, 1134, 1136, 1137, 1137, 1139, 1140, 1141, 1142, 1145, 1146, 1147, 1150, 1150, 1150, 1151, 1152, 1154, 1154, 1154, 1154, 0, 0, 0, 1154, 1154, 0, 0, 0, 1156, 1156, 1156, 1156, 1156, 1156, 1156, 1162, 1162, 1162, 1166, 1167, 1167, 1167, 1168, 1169, 1170, 1170, 1171, 1172, 1173, 1170, 1176, 1180, 1180, 1180, 1180, 1180, 1181, 1181, 1181, 1181, 1181, 1181, 1181, 0, 1181, 1181, 1181, 1181, 1181, 1181, 1181, 0, 0, 1182, 1184, 1186, 1186, 1186, 1186, 1186, 1186, 0, 0, 0, 1187, 1189, 1191, 1193, 1193, 1197, 1197, 1197, 1202, 1202, 1202, 1202, 1202, 1202, 1202, 1202, 1202, 1202, 1203, 1203, 1203, 1204, 1204, 1204, 1204, 1206, 1207, 1207, 1207, 1208, 1208, 1210, 1210, 1213, 1213, 1215, 1215, 1215, 1215, 1215, 1220, 1220, 1220, 1220, 1220, 1221, 1221, 1221, 1221, 1221, 1221, 0, 0, 0, 1222, 1224, 1226, 1226, 1226, 1226, 1226, 1226, 1226, 1233, 1233, 1233, 1233, 1233, 1233, 1238, 1238, 1238, 1239, 1239, 1239, 1241, 1241, 1241, 1241, 1242, 1242, 1242, 1244, 1244, 1244, 1244, 1245, 1245, 1245, 1247, 1248, 1248, 1249, 1249, 1249, 1249, 1251, 1251, 1251, 1251, 1251, 1251, 1255, 1255, 1259, 1259, 1259, 1259, 1259, 1259, 1259, 1263, 1263, 1263, 1263, 1263, 1263, 1263, 1263, 1267, 1267, 1267, 1272, 1272, 1272, 1274, 1276, 1280, 1281, 1282, 1284, 1287, 1287, 1287, 1287, 1287, 1287, 1287, 1287, 0, 0, 0, 1288, 1288, 1288, 1288, 1288, 1289, 1289, 1289, 1289, 1290, 1290, 1290, 1290, 1290, 1290, 1290, 1290, 1289, 1292, 1292, 1293, 1293, 1293, 1293, 1293, 1293, 1293, 1293, 1293, 1293, 0, 0, 0, 1294, 1294, 1294, 1295, 1295, 1295, 1295, 1296, 1297, 1298, 1298, 1298, 1298, 1302, 1302, 1303, 1303, 1303, 1303, 1305, 1305, 1305, 1305, 1307, 1307, 1307, 1307, 1307, 1307, 1308, 1308, 1308, 1308, 1309, 1309, 1309, 1309, 1309, 1310, 1310, 1310, 1310, 1311, 1311, 1311, 1311, 1312, 1312, 1312, 1312, 1313, 1313, 1313, 1313, 1314, 1314, 1314, 1314, 1314, 0, 1314, 1314, 1314, 1314, 1314, 0, 0, 0, 1315, 1315, 1315, 1315, 1315, 0, 0, 0, 1315, 1315, 1315, 1315, 1315, 0, 0, 1322, 1322, 1323, 1323, 1323, 1323, 1323, 1323, 1323, 1324, 1324, 1324, 1327, 1327, 1327, 1327, 1327, 1328, 1329, 1331, 1332, 1334, 1334, 1334, 1334, 1334, 1334, 1334, 1334, 1334, 1335, 1335, 1335, 1335, 1336, 1336, 1336, 1337, 1337, 1337, 1337, 1338, 1338, 1338, 1340, 1341, 1341, 1341, 1341, 1343, 1344, 1344, 1345, 1345, 1345, 1347, 1347, 1347, 1347, 1347, 1347, 1347, 1347, 1347, 1348, 1349, 1349, 1349, 1349, 0, 1349, 1349, 1349, 1349, 0, 0, 0, 1349, 1349, 1349, 1349, 0, 0, 0, 1349, 1349, 1349, 1349, 0, 0, 1351, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1354, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1355, 1358, 1359, 1360, 1361, 1363, 1363, 1364, 1365, 1365, 1365, 1366, 1366, 1366, 1366, 1366, 1366, 1367, 1368, 1368, 1368, 1368, 1368, 1368, 1369, 1370, 1371, 1372, 1372, 1372, 1377, 1378, 1380, 1381, 1381, 1381, 1382, 1382, 1383, 1384, 1384, 1386, 1387, 1388, 1388, 1389, 0, 1392, 0, 0, 0, 1392, 1392, 0, 0, 1393, 1393, 1394, 1394, 1396, 1396, 1396, 1396, 1396, 0, 0, 0, 1397, 1397, 1397, 1397, 1397, 1397, 1399, 1399, 1402, 1403, 1403, 1403, 1403, 1403, 1403, 1403, 1403, 1403, 1403, 1403, 1406, 1410, 1412, 0, 0, 0, 1413, 1413, 1413, 1416, 1417, 1420, 1420, 1420, 1420, 1420, 1420, 1420, 1420, 1420, 0, 0, 0, 1421, 1421, 1421, 1421, 0, 0, 0, 1421, 0, 0, 0, 1422, 1423, 1423, 1424, 1426, 1426, 1426, 1426, 1426, 1426, 1427, 1427, 1427, 1429, 1429, 1429, 1429, 1429, 1429, 1429, 1429, 1429, 1434, 1434, 1434, 1436, 1436, 1436, 1436, 1436, 1438, 1438, 1438, 1438, 1440, 1446, 1446, 1446, 1446, 1446, 1446, 1446, 1446, 1446, 1446, 1446, 1447, 1447, 1448, 1448, 1448, 1448, 1450, 1452, 1452, 1452, 0, 1456, 1456, 0, 0, 0, 0, 0, 1456, 1456, 0, 0, 0, 0, 0, 0, 1457, 1461, 1461, 1462, 1462, 1462, 1462, 1462, 1462, 1462, 1463, 1463, 1464, 1464, 1464, 1464, 1464, 1464, 1464, 1466, 1466, 1466, 1466, 1466, 1466, 0, 1471, 1471, 0, 0, 1473, 1473, 1474, 1474, 1475, 1476, 1476, 1477, 1478, 1478, 1480, 1480, 1480, 1480, 1480, 1481, 1481, 1481, 1482, 1483, 1485, 1485, 1487, 1488, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1490, 1493, 1494, 1495, 1496, 1496, 1497, 1498, 1498, 1499, 1499, 1499, 1501, 1502, 1504, 1506, 1507, 1508, 1508, 1509, 1509, 1509, 1509, 1510, 1512, 1516, 1516, 1516, 1516, 1516, 1516, 1519, 1519, 1519, 1519, 1519, 1519, 1521, 1521, 1521, 1521, 1523, 1525, 1525, 1526, 1526, 1528, 1529, 1529, 1529, 1529, 1529, 1529, 0, 1529, 1529, 1530, 1530, 1530, 1530, 1530, 1530, 1532, 1532, 1532, 1532, 1535, 1535, 1535, 1535, 1536, 1538, 1542, 1542, 1542, 1542, 1542, 1542, 1544, 1544, 1544, 1544, 1544, 1547, 1547, 1548, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1549, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1551, 1555, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1556, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1558, 1562, 1563, 1564, 1566, 1567, 1567, 1567, 1568, 1569, 1571, 1572, 1574, 1574, 1575, 1577, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1579, 1583, 1585, 1585, 1585, 1586, 1586, 0, 1586, 1586, 0, 0, 1588, 1588, 1588, 1591, 1592, 1593, 1593, 1594, 1594, 1594, 1594, 1594, 1602, 1603, 1603, 1604, 1604, 1604, 1604, 1604, 1606, 1606, 1606, 1606, 1606, 1608, 1608, 1609, 1613, 1613, 1613, 1613, 1613, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1617, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1621, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1626, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1628, 1632, 1632, 1632, 1632, 1632, 1643, 1643, 1643, 1647, 1647, 1648, 1648, 1650, 1650, 0, 1650, 0, 0, 1651, 1651, 1653, 1653, 1657, 1657, 1657, 1657, 1658, 1658, 1658, 1663, 1663, 1663, 1663, 1663, 1664, 1664, 1666, 1666, 1670, 1670, 1670, 1671, 1672, 1672, 1672, 1673, 1674, 1674, 1674, 1675, 1676, 1676, 1676, 1677, 1678, 1678, 1678, 1679, 1680, 1680, 1681, 1681, 1681, 1682, 1683, 1683, 1683, 1684, 1685, 1685, 1685, 1686, 1686, 1686, 1687, 1687, 1687, 1688, 1688, 1688, 1689, 1689, 1689, 1690, 1690, 1691, 1691, 1691, 1692, 1692, 1693, 1693, 1693, 1694, 1695, 1695, 1695, 1696, 1698, 1699, 1699, 1703, 1703, 1712, 1712, 1712, 1713, 1714, 1714, 1714, 1714, 1715, 1716, 1716, 1716, 1716, 1717, 1719, 1719, 1721, 1726, 1726, 1726, 1727, 1728, 1728, 1728, 1728, 1729, 1730, 1730, 1730, 1730, 1731, 1733, 1733, 1735, 1739, 1743, 1743, 1747, 1747, 1751, 1751, 1755, 1755, 1759, 1759, 1764, 1764, 1768, 1769, 1770, 1770, 0, 1770, 1770, 1771, 1771, 1771, 1771, 1772, 1773, 1773, 1774, 1776, 1776, 1780, 1780, 1780, 1780, 1784, 1784, 1784, 1784, 1788, 1788, 1788, 1788, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 677, 680, 682, 683, 689, 690, 691, 700, 701, 702, 703, 704, 705, 706, 714, 715, 716, 717, 718, 719, 736, 737, 738, 743, 744, 745, 745, 748, 750, 751, 752, 753, 754, 755, 756, 758, 759, 766, 767, 768, 769, 771, 779, 780, 781, 786, 787, 788, 789, 790, 792, 816, 818, 821, 823, 826, 830, 831, 832, 833, 834, 836, 837, 838, 840, 841, 843, 844, 845, 846, 847, 849, 850, 852, 853, 854, 855, 856, 858, 859, 860, 861, 863, 866, 867, 870, 873, 874, 1041, 1042, 1043, 1044, 1047, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1062, 1063, 1064, 1066, 1072, 1073, 1076, 1078, 1079, 1085, 1086, 1087, 1087, 1090, 1092, 1093, 1094, 1094, 1097, 1099, 1100, 1111, 1114, 1116, 1117, 1118, 1119, 1120, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1153, 1156, 1158, 1159, 1160, 1161, 1162, 1163, 1168, 1169, 1172, 1173, 1175, 1178, 1182, 1185, 1186, 1188, 1191, 1196, 1199, 1200, 1201, 1202, 1204, 1205, 1206, 1207, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1246, 1247, 1248, 1249, 1250, 1251, 1251, 1252, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1269, 1270, 1272, 1273, 1274, 1277, 1278, 1279, 1282, 1283, 1285, 1286, 1287, 1289, 1290, 1292, 1293, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 1303, 1304, 1305, 1306, 1307, 1308, 1310, 1311, 1313, 1314, 1316, 1317, 1318, 1321, 1322, 1323, 1326, 1327, 1329, 1330, 1331, 1333, 1334, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1347, 1348, 1349, 1350, 1351, 1352, 1354, 1355, 1356, 1357, 1358, 1360, 1361, 1362, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1381, 1386, 1387, 1388, 1392, 1393, 1407, 1408, 1409, 1410, 1411, 1412, 1414, 1415, 1416, 1418, 1419, 1420, 1421, 1422, 1425, 1432, 1433, 1434, 1435, 1438, 1443, 1444, 1448, 1449, 1453, 1454, 1458, 1459, 1463, 1464, 1468, 1469, 1473, 1474, 1481, 1482, 1484, 1485, 1487, 1488, 1720, 1721, 1722, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1770, 1773, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1787, 1788, 1789, 1790, 1793, 1795, 1796, 1797, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1816, 1817, 1818, 1820, 1821, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1857, 1858, 1859, 1860, 1862, 1863, 1864, 1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882, 1883, 1884, 1885, 1886, 1893, 1893, 1896, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1923, 1924, 1925, 1925, 1928, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960, 1961, 1962, 1968, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1979, 1980, 1981, 1982, 1983, 1984, 1987, 1988, 1990, 1991, 1992, 1993, 1994, 1995, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2015, 2018, 2019, 2021, 2024, 2028, 2029, 2030, 2032, 2033, 2034, 2035, 2037, 2039, 2040, 2041, 2042, 2043, 2044, 2046, 2048, 2054, 2055, 2056, 2060, 2061, 2065, 2066, 2070, 2071, 2083, 2084, 2086, 2089, 2090, 2092, 2095, 2099, 2100, 2101, 2103, 2104, 2105, 2109, 2110, 2113, 2114, 2115, 2116, 2117, 2127, 2129, 2132, 2134, 2137, 2139, 2142, 2146, 2147, 2148, 2159, 2160, 2162, 2163, 2164, 2167, 2168, 2169, 2170, 2171, 2178, 2179, 2180, 2181, 2182, 2190, 2191, 2192, 2193, 2194, 2201, 2202, 2203, 2204, 2205, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2271, 2274, 2276, 2277, 2278, 2279, 2280, 2282, 2283, 2284, 2285, 2287, 2290, 2294, 2297, 2298, 2301, 2302, 2304, 2305, 2306, 2311, 2312, 2313, 2314, 2315, 2316, 2318, 2319, 2322, 2323, 2324, 2325, 2327, 2328, 2329, 2332, 2333, 2334, 2337, 2338, 2339, 2340, 2347, 2348, 2353, 2354, 2357, 2359, 2360, 2361, 2363, 2366, 2368, 2369, 2370, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2412, 2413, 2414, 2415, 2417, 2418, 2420, 2421, 2645, 2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658, 2659, 2660, 2661, 2662, 2663, 2664, 2669, 2670, 2673, 2675, 2676, 2677, 2678, 2679, 2681, 2682, 2683, 2691, 2692, 2693, 2698, 2699, 2700, 2701, 2702, 2703, 2704, 2707, 2709, 2710, 2711, 2716, 2717, 2718, 2719, 2720, 2720, 2723, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2733, 2734, 2735, 2743, 2748, 2749, 2750, 2752, 2755, 2759, 2762, 2763, 2764, 2765, 2766, 2768, 2771, 2772, 2773, 2774, 2777, 2779, 2780, 2781, 2783, 2785, 2786, 2787, 2788, 2789, 2790, 2792, 2799, 2800, 2801, 2802, 2802, 2805, 2807, 2808, 2809, 2811, 2812, 2813, 2814, 2815, 2816, 2817, 2819, 2820, 2822, 2824, 2825, 2830, 2831, 2832, 2834, 2835, 2836, 2837, 2842, 2843, 2844, 2846, 2854, 2854, 2857, 2859, 2860, 2861, 2863, 2864, 2865, 2868, 2870, 2871, 2872, 2875, 2876, 2877, 2879, 2881, 2884, 2888, 2891, 2892, 2893, 2894, 2895, 2896, 2897, 2898, 2899, 2900, 2901, 2902, 2903, 2904, 2905, 2906, 2907, 2908, 2914, 2916, 2917, 2918, 2919, 2920, 2921, 2922, 2923, 2924, 2926, 2927, 2928, 2929, 2930, 2931, 2932, 2933, 2934, 2935, 2936, 2937, 2938, 2939, 2940, 2941, 2942, 2943, 2944, 2945, 2946, 2947, 2947, 2950, 2952, 2953, 2954, 2955, 2956, 2957, 2958, 2959, 2960, 2962, 2965, 2966, 2967, 2969, 2972, 2976, 2979, 2981, 2981, 2984, 2986, 2987, 2989, 2990, 2991, 2992, 2993, 2994, 2995, 2996, 2997, 2998, 3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3008, 3011, 3013, 3014, 3015, 3017, 3019, 3020, 3022, 3025, 3029, 3032, 3033, 3034, 3035, 3036, 3039, 3041, 3042, 3044, 3047, 3049, 3051, 3052, 3053, 3054, 3057, 3058, 3059, 3060, 3061, 3063, 3064, 3065, 3067, 3073, 3074, 3075, 3077, 3078, 3079, 3081, 3088, 3089, 3090, 3097, 3098, 3099, 3100, 3101, 3102, 3103, 3104, 3105, 3106, 3107, 3108, 3109, 3110, 3111, 3112, 3113, 3114, 3115, 3121, 3122, 3123, 3141, 3142, 3143, 3144, 3145, 3146, 3146, 3149, 3151, 3153, 3154, 3155, 3158, 3159, 3161, 3162, 3165, 3166, 3168, 3177, 3178, 3181, 3207, 3208, 3209, 3210, 3211, 3212, 3213, 3214, 3215, 3216, 3217, 3218, 3219, 3220, 3221, 3222, 3223, 3224, 3225, 3226, 3227, 3228, 3229, 3230, 3231, 3232, 3279, 3280, 3281, 3282, 3283, 3284, 3285, 3286, 3287, 3288, 3289, 3290, 3291, 3292, 3293, 3294, 3295, 3296, 3297, 3298, 3300, 3303, 3305, 3306, 3307, 3308, 3309, 3310, 3311, 3312, 3313, 3314, 3315, 3316, 3317, 3318, 3319, 3320, 3321, 3322, 3323, 3324, 3325, 3326, 3327, 3328, 3329, 3330, 3331, 3332, 3341, 3342, 3343, 3344, 3345, 3346, 3347, 3364, 3365, 3366, 3367, 3368, 3369, 3370, 3371, 3372, 3375, 3377, 3378, 3380, 3381, 3382, 3384, 3385, 3391, 3392, 3393, 3414, 3415, 3416, 3417, 3418, 3419, 3420, 3421, 3422, 3423, 3424, 3425, 3426, 3427, 3428, 3429, 3430, 3431, 3432, 3433, 3452, 3453, 3454, 3456, 3457, 3458, 3459, 3460, 3461, 3462, 3465, 3466, 3467, 3468, 3469, 3470, 3471, 3473, 3509, 3514, 3515, 3516, 3517, 3520, 3521, 3523, 3524, 3525, 3526, 3527, 3528, 3529, 3530, 3531, 3532, 3533, 3534, 3535, 3536, 3537, 3538, 3539, 3540, 3541, 3542, 3543, 3544, 3545, 3546, 3548, 3549, 3550, 3551, 3552, 3553, 3554, 3555, 3556, 3558, 3563, 3564, 3565, 3573, 3574, 3575, 3576, 3577, 3578, 3582, 3583, 3587, 3588, 3600, 3601, 3606, 3607, 3608, 3613, 3614, 3617, 3621, 3624, 3625, 3626, 3627, 3628, 3630, 3657, 3658, 3663, 3664, 3665, 3666, 3667, 3669, 3670, 3672, 3675, 3679, 3682, 3683, 3685, 3688, 3692, 3695, 3696, 3698, 3701, 3705, 3708, 3709, 3711, 3714, 3718, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3791, 3792, 3797, 3798, 3799, 3800, 3805, 3806, 3809, 3813, 3816, 3817, 3818, 3819, 3820, 3822, 3827, 3828, 3833, 3834, 3837, 3838, 3839, 3840, 3842, 3845, 3849, 3850, 3851, 3853, 3854, 3856, 3857, 3858, 3859, 3860, 3861, 3862, 3863, 3864, 3865, 3866, 3867, 3868, 3869, 3870, 3872, 3873, 3874, 3875, 3876, 3876, 3879, 3881, 3882, 3883, 3889, 3890, 3891, 3892, 3893, 3894, 3895, 3896, 3897, 3898, 3899, 3900, 3901, 3902, 3903, 3907, 3908, 3910, 3911, 3913, 3916, 3920, 3923, 3924, 3926, 3929, 3933, 3936, 3937, 3938, 3939, 3940, 3941, 3942, 3951, 3952, 3953, 3965, 3966, 3967, 3968, 3969, 3970, 3971, 3974, 3976, 3977, 3979, 3981, 3987, 4047, 4048, 4049, 4050, 4051, 4052, 4053, 4054, 4055, 4056, 4057, 4058, 4060, 4063, 4064, 4065, 4066, 4067, 4068, 4069, 4071, 4074, 4078, 4081, 4083, 4084, 4089, 4090, 4091, 4092, 4094, 4097, 4101, 4104, 4107, 4109, 4111, 4112, 4115, 4116, 4117, 4120, 4121, 4122, 4123, 4124, 4125, 4126, 4127, 4128, 4129, 4130, 4131, 4132, 4134, 4135, 4136, 4137, 4139, 4140, 4141, 4142, 4144, 4145, 4147, 4148, 4151, 4152, 4154, 4155, 4156, 4157, 4158, 4180, 4181, 4182, 4183, 4184, 4185, 4186, 4191, 4192, 4193, 4194, 4196, 4199, 4203, 4206, 4209, 4211, 4212, 4213, 4214, 4215, 4216, 4217, 4229, 4230, 4231, 4232, 4233, 4234, 4264, 4265, 4266, 4268, 4269, 4270, 4272, 4273, 4274, 4275, 4277, 4278, 4279, 4281, 4282, 4283, 4284, 4286, 4287, 4288, 4290, 4291, 4296, 4297, 4298, 4299, 4300, 4302, 4303, 4304, 4305, 4306, 4307, 4311, 4312, 4321, 4322, 4323, 4324, 4325, 4326, 4327, 4337, 4338, 4339, 4340, 4341, 4342, 4343, 4344, 4350, 4351, 4352, 4929, 4930, 4931, 4932, 4933, 4934, 4935, 4936, 4937, 4938, 4939, 4940, 4941, 4943, 4944, 4945, 4946, 4948, 4951, 4955, 4958, 4959, 4960, 4961, 4962, 4963, 4966, 4967, 4968, 4970, 4971, 4972, 4973, 4974, 4975, 4976, 4977, 4978, 4984, 4985, 4988, 4989, 4990, 4991, 4993, 4994, 4995, 4996, 4997, 4998, 5000, 5003, 5007, 5010, 5011, 5012, 5015, 5016, 5017, 5018, 5020, 5021, 5024, 5025, 5026, 5027, 5029, 5030, 5032, 5033, 5034, 5035, 5037, 5038, 5039, 5040, 5042, 5043, 5044, 5045, 5046, 5047, 5050, 5051, 5052, 5053, 5055, 5056, 5057, 5058, 5059, 5062, 5063, 5064, 5065, 5067, 5068, 5069, 5070, 5073, 5074, 5075, 5076, 5078, 5079, 5080, 5081, 5084, 5085, 5086, 5087, 5088, 5090, 5093, 5094, 5095, 5096, 5097, 5099, 5102, 5106, 5109, 5110, 5111, 5112, 5113, 5115, 5118, 5122, 5125, 5126, 5127, 5128, 5129, 5131, 5134, 5138, 5139, 5141, 5142, 5143, 5144, 5145, 5146, 5147, 5149, 5150, 5151, 5154, 5155, 5156, 5157, 5158, 5160, 5161, 5164, 5165, 5167, 5168, 5169, 5170, 5171, 5172, 5173, 5174, 5175, 5176, 5177, 5178, 5179, 5180, 5181, 5182, 5183, 5184, 5185, 5186, 5187, 5188, 5189, 5195, 5198, 5199, 5200, 5201, 5203, 5204, 5205, 5207, 5208, 5209, 5211, 5212, 5213, 5214, 5215, 5216, 5217, 5218, 5219, 5220, 5223, 5224, 5225, 5226, 5228, 5231, 5232, 5233, 5234, 5236, 5239, 5243, 5246, 5247, 5248, 5249, 5251, 5254, 5258, 5261, 5262, 5263, 5264, 5266, 5269, 5273, 5280, 5281, 5282, 5283, 5284, 5285, 5286, 5287, 5288, 5289, 5291, 5292, 5293, 5294, 5295, 5296, 5297, 5298, 5299, 5300, 5301, 5302, 5303, 5304, 5305, 5306, 5308, 5309, 5310, 5311, 5312, 5313, 5315, 5316, 5317, 5318, 5321, 5322, 5323, 5324, 5325, 5326, 5328, 5331, 5332, 5333, 5334, 5335, 5336, 5338, 5339, 5340, 5341, 5342, 5343, 5347, 5348, 5349, 5350, 5351, 5354, 5356, 5357, 5358, 5359, 5360, 5362, 5363, 5364, 5365, 5367, 5372, 5375, 5377, 5380, 5384, 5387, 5388, 5390, 5393, 5397, 5398, 5400, 5401, 5403, 5404, 5406, 5407, 5412, 5413, 5416, 5420, 5423, 5424, 5425, 5426, 5427, 5428, 5430, 5431, 5434, 5435, 5436, 5437, 5438, 5439, 5440, 5441, 5442, 5443, 5444, 5445, 5448, 5454, 5456, 5458, 5461, 5465, 5468, 5469, 5470, 5472, 5473, 5474, 5475, 5476, 5477, 5479, 5480, 5481, 5482, 5483, 5485, 5488, 5492, 5495, 5496, 5499, 5500, 5502, 5505, 5509, 5511, 5513, 5516, 5520, 5523, 5524, 5525, 5526, 5527, 5528, 5529, 5530, 5531, 5532, 5534, 5535, 5536, 5539, 5540, 5541, 5542, 5543, 5544, 5545, 5546, 5547, 5550, 5551, 5552, 5554, 5555, 5556, 5557, 5558, 5560, 5561, 5562, 5563, 5566, 5569, 5570, 5571, 5572, 5573, 5574, 5575, 5576, 5577, 5578, 5579, 5580, 5585, 5586, 5587, 5588, 5589, 5592, 5594, 5595, 5596, 5599, 5602, 5603, 5605, 5608, 5613, 5616, 5620, 5623, 5624, 5626, 5629, 5633, 5637, 5640, 5644, 5647, 5651, 5652, 5654, 5655, 5656, 5657, 5658, 5659, 5660, 5663, 5664, 5666, 5667, 5668, 5669, 5670, 5671, 5672, 5675, 5676, 5677, 5678, 5679, 5680, 5684, 5687, 5688, 5690, 5693, 5698, 5699, 5701, 5702, 5704, 5707, 5708, 5710, 5713, 5714, 5716, 5717, 5718, 5719, 5720, 5721, 5722, 5723, 5724, 5725, 5726, 5727, 5728, 5730, 5733, 5734, 5735, 5736, 5737, 5738, 5739, 5740, 5741, 5742, 5743, 5744, 5745, 5747, 5748, 5749, 5750, 5751, 5754, 5756, 5757, 5759, 5760, 5761, 5763, 5764, 5770, 5771, 5772, 5775, 5776, 5778, 5779, 5780, 5781, 5783, 5786, 5790, 5791, 5792, 5793, 5794, 5795, 5802, 5803, 5804, 5805, 5806, 5807, 5809, 5810, 5811, 5812, 5813, 5814, 5815, 5817, 5818, 5821, 5822, 5823, 5824, 5825, 5826, 5827, 5827, 5830, 5832, 5833, 5834, 5835, 5836, 5837, 5838, 5844, 5845, 5846, 5847, 5849, 5850, 5851, 5852, 5854, 5857, 5861, 5862, 5863, 5864, 5865, 5866, 5869, 5870, 5871, 5872, 5873, 5877, 5878, 5879, 5881, 5882, 5883, 5884, 5885, 5886, 5887, 5888, 5889, 5890, 5891, 5892, 5895, 5896, 5897, 5898, 5899, 5900, 5901, 5902, 5903, 5904, 5905, 5906, 5911, 5913, 5914, 5915, 5916, 5917, 5918, 5919, 5920, 5921, 5922, 5923, 5924, 5927, 5928, 5929, 5930, 5931, 5932, 5933, 5934, 5935, 5936, 5937, 5938, 5943, 5945, 5946, 5949, 5950, 5951, 5952, 5953, 5955, 5957, 5958, 5960, 5961, 5963, 5966, 5968, 5969, 5970, 5971, 5972, 5973, 5974, 5975, 5976, 5977, 5978, 5979, 5980, 5981, 5982, 5983, 5984, 5985, 5986, 5987, 5988, 5989, 5990, 5991, 5992, 5993, 5996, 5998, 5999, 6000, 6001, 6002, 6004, 6007, 6008, 6010, 6013, 6017, 6018, 6019, 6022, 6023, 6025, 6026, 6028, 6029, 6030, 6031, 6032, 6051, 6052, 6053, 6055, 6056, 6057, 6058, 6059, 6062, 6063, 6064, 6065, 6066, 6068, 6069, 6070, 6077, 6078, 6079, 6080, 6081, 6095, 6096, 6097, 6098, 6099, 6100, 6101, 6102, 6103, 6104, 6105, 6106, 6120, 6121, 6122, 6123, 6124, 6125, 6126, 6127, 6128, 6129, 6130, 6131, 6159, 6160, 6161, 6162, 6163, 6164, 6165, 6166, 6167, 6168, 6169, 6170, 6171, 6173, 6174, 6175, 6176, 6177, 6178, 6179, 6180, 6181, 6182, 6183, 6184, 6185, 6192, 6193, 6194, 6195, 6196, 6205, 6206, 6207, 6220, 6221, 6223, 6224, 6226, 6227, 6229, 6232, 6234, 6237, 6241, 6242, 6244, 6245, 6254, 6255, 6256, 6257, 6259, 6260, 6261, 6273, 6274, 6275, 6276, 6277, 6279, 6280, 6282, 6283, 6333, 6334, 6335, 6337, 6340, 6341, 6342, 6344, 6347, 6348, 6349, 6351, 6354, 6355, 6356, 6358, 6361, 6362, 6363, 6365, 6366, 6367, 6370, 6371, 6372, 6374, 6377, 6378, 6379, 6381, 6384, 6385, 6386, 6388, 6389, 6390, 6393, 6394, 6395, 6397, 6398, 6399, 6402, 6403, 6404, 6406, 6407, 6410, 6411, 6412, 6414, 6415, 6418, 6419, 6420, 6422, 6425, 6426, 6427, 6429, 6443, 6444, 6445, 6449, 6454, 6475, 6476, 6477, 6479, 6482, 6483, 6484, 6485, 6487, 6490, 6491, 6492, 6493, 6495, 6498, 6499, 6503, 6519, 6520, 6521, 6523, 6526, 6527, 6528, 6529, 6531, 6534, 6535, 6536, 6537, 6539, 6542, 6543, 6547, 6550, 6555, 6556, 6560, 6561, 6565, 6566, 6570, 6571, 6575, 6576, 6580, 6581, 6595, 6596, 6597, 6598, 6598, 6601, 6603, 6604, 6605, 6607, 6608, 6611, 6613, 6614, 6615, 6621, 6622, 6628, 6629, 6630, 6631, 6637, 6638, 6639, 6640, 6646, 6647, 6648, 6649, 6652, 6655, 6659, 6662, 6666, 6669, 6673, 6676, 6680, 6683, 6687, 6690, 6694, 6697, 6701, 6704, 6708, 6711, 6715, 6718, 6722, 6725, 6729, 6732, 6736, 6739, 6743, 6746, 6750, 6753, 6757, 6760, 6764, 6767, 6771, 6774, 6778, 6781, 6785, 6788, 6792, 6795, 6799, 6802, 6806, 6809, 6813, 6816, 6820, 6823, 6827, 6830, 6834, 6837, 6841, 6844, 6848, 6851, 6855, 6858, 6862, 6865, 6869, 6872, 6876, 6879, 6883, 6886, 6890, 6893, 6897, 6900, 6904, 6907, 6911, 6914, 6918, 6921, 6925, 6928, 6932, 6935, 6939, 6942, 6946, 6949, 6953, 6956, 6960, 6963, 6967, 6970, 6974, 6977, 6981, 6984, 6988, 6991, 6995, 6998, 7002, 7005, 7009, 7012, 7016, 7019, 7023, 7026, 7030, 7033, 7037, 7040};
/* BEGIN LINEINFO 
assign 1 78 630
assign 1 93 631
nlGet 0 93 631
assign 1 95 632
new 0 95 632
assign 1 95 633
quoteGet 0 95 633
assign 1 98 634
new 0 98 634
assign 1 101 635
new 0 101 635
assign 1 101 636
new 1 101 636
assign 1 102 637
new 0 102 637
assign 1 102 638
new 1 102 638
assign 1 103 639
new 0 103 639
assign 1 103 640
new 1 103 640
assign 1 104 641
new 0 104 641
assign 1 104 642
new 1 104 642
assign 1 105 643
new 0 105 643
assign 1 105 644
new 1 105 644
assign 1 109 645
new 0 109 645
assign 1 110 646
new 0 110 646
assign 1 112 647
new 0 112 647
assign 1 113 648
new 0 113 648
assign 1 116 649
libNameGet 0 116 649
assign 1 116 650
libEmitName 1 116 650
assign 1 117 651
libNameGet 0 117 651
assign 1 117 652
fullLibEmitName 1 117 652
assign 1 118 653
emitPathGet 0 118 653
assign 1 118 654
copy 0 118 654
assign 1 118 655
emitLangGet 0 118 655
assign 1 118 656
addStep 1 118 656
assign 1 118 657
new 0 118 657
assign 1 118 658
addStep 1 118 658
assign 1 118 659
libNameGet 0 118 659
assign 1 118 660
libEmitName 1 118 660
assign 1 118 661
addStep 1 118 661
assign 1 118 662
add 1 118 662
assign 1 118 663
addStep 1 118 663
assign 1 120 664
new 0 120 664
assign 1 121 665
new 0 121 665
assign 1 122 666
new 0 122 666
assign 1 123 667
new 0 123 667
assign 1 124 668
new 0 124 668
assign 1 126 669
new 0 126 669
assign 1 127 670
new 0 127 670
assign 1 133 671
new 0 133 671
assign 1 136 672
getClassConfig 1 136 672
assign 1 137 673
getClassConfig 1 137 673
assign 1 140 674
new 0 140 674
assign 1 140 675
emitting 1 140 675
assign 1 141 677
new 0 141 677
assign 1 143 680
new 0 143 680
assign 1 148 682
new 0 148 682
assign 1 149 683
new 0 149 683
assign 1 155 689
new 0 155 689
assign 1 155 690
add 1 155 690
return 1 155 691
assign 1 159 700
new 0 159 700
assign 1 159 701
sizeGet 0 159 701
assign 1 159 702
add 1 159 702
assign 1 159 703
new 0 159 703
assign 1 159 704
add 1 159 704
assign 1 159 705
add 1 159 705
return 1 159 706
assign 1 163 714
libNs 1 163 714
assign 1 163 715
new 0 163 715
assign 1 163 716
add 1 163 716
assign 1 163 717
libEmitName 1 163 717
assign 1 163 718
add 1 163 718
return 1 163 719
assign 1 167 736
toString 0 167 736
assign 1 168 737
get 1 168 737
assign 1 169 738
undef 1 169 743
assign 1 170 744
usedLibrarysGet 0 170 744
assign 1 170 745
iteratorGet 0 0 745
assign 1 170 748
hasNextGet 0 170 748
assign 1 170 750
nextGet 0 170 750
assign 1 171 751
emitPathGet 0 171 751
assign 1 171 752
libNameGet 0 171 752
assign 1 171 753
new 4 171 753
assign 1 172 754
synPathGet 0 172 754
assign 1 172 755
fileGet 0 172 755
assign 1 172 756
existsGet 0 172 756
put 2 173 758
return 1 174 759
assign 1 177 766
emitPathGet 0 177 766
assign 1 177 767
libNameGet 0 177 767
assign 1 177 768
new 4 177 768
put 2 178 769
return 1 180 771
assign 1 184 779
toString 0 184 779
assign 1 185 780
get 1 185 780
assign 1 186 781
undef 1 186 786
assign 1 187 787
emitPathGet 0 187 787
assign 1 187 788
libNameGet 0 187 788
assign 1 187 789
new 4 187 789
put 2 188 790
return 1 190 792
assign 1 194 816
printStepsGet 0 194 816
assign 1 0 818
assign 1 194 821
printPlacesGet 0 194 821
assign 1 0 823
assign 1 0 826
assign 1 195 830
new 0 195 830
assign 1 195 831
heldGet 0 195 831
assign 1 195 832
nameGet 0 195 832
assign 1 195 833
add 1 195 833
print 0 195 834
assign 1 197 836
transUnitGet 0 197 836
assign 1 197 837
new 2 197 837
assign 1 202 838
printStepsGet 0 202 838
assign 1 203 840
new 0 203 840
echo 0 203 841
assign 1 205 843
new 0 205 843
emitterSet 1 206 844
buildSet 1 207 845
traverse 1 208 846
assign 1 210 847
printStepsGet 0 210 847
assign 1 211 849
new 0 211 849
echo 0 211 850
assign 1 213 852
new 0 213 852
emitterSet 1 214 853
buildSet 1 215 854
traverse 1 216 855
assign 1 218 856
printStepsGet 0 218 856
assign 1 219 858
new 0 219 858
echo 0 219 859
assign 1 220 860
new 0 220 860
print 0 220 861
assign 1 222 863
printStepsGet 0 222 863
traverse 1 225 866
assign 1 226 867
printStepsGet 0 226 867
assign 1 230 870
printStepsGet 0 230 870
buildStackLines 1 233 873
assign 1 234 874
printStepsGet 0 234 874
assign 1 244 1041
new 0 244 1041
assign 1 245 1042
emitDataGet 0 245 1042
assign 1 245 1043
parseOrderClassNamesGet 0 245 1043
assign 1 245 1044
iteratorGet 0 245 1044
assign 1 245 1047
hasNextGet 0 245 1047
assign 1 246 1049
nextGet 0 246 1049
assign 1 248 1050
emitDataGet 0 248 1050
assign 1 248 1051
classesGet 0 248 1051
assign 1 248 1052
get 1 248 1052
assign 1 250 1053
heldGet 0 250 1053
assign 1 250 1054
synGet 0 250 1054
assign 1 250 1055
depthGet 0 250 1055
assign 1 251 1056
get 1 251 1056
assign 1 252 1057
undef 1 252 1062
assign 1 253 1063
new 0 253 1063
put 2 254 1064
addValue 1 256 1066
assign 1 259 1072
new 0 259 1072
assign 1 260 1073
keyIteratorGet 0 260 1073
assign 1 260 1076
hasNextGet 0 260 1076
assign 1 261 1078
nextGet 0 261 1078
addValue 1 262 1079
assign 1 265 1085
sort 0 265 1085
assign 1 267 1086
new 0 267 1086
assign 1 269 1087
iteratorGet 0 0 1087
assign 1 269 1090
hasNextGet 0 269 1090
assign 1 269 1092
nextGet 0 269 1092
assign 1 270 1093
get 1 270 1093
assign 1 271 1094
iteratorGet 0 0 1094
assign 1 271 1097
hasNextGet 0 271 1097
assign 1 271 1099
nextGet 0 271 1099
addValue 1 272 1100
assign 1 276 1111
iteratorGet 0 276 1111
assign 1 276 1114
hasNextGet 0 276 1114
assign 1 278 1116
nextGet 0 278 1116
assign 1 280 1117
heldGet 0 280 1117
assign 1 280 1118
namepathGet 0 280 1118
assign 1 280 1119
getLocalClassConfig 1 280 1119
assign 1 281 1120
printStepsGet 0 281 1120
complete 1 285 1123
assign 1 288 1124
getClassOutput 0 288 1124
assign 1 292 1125
beginNs 0 292 1125
assign 1 293 1126
countLines 1 293 1126
addValue 1 293 1127
write 1 294 1128
assign 1 297 1129
countLines 1 297 1129
addValue 1 297 1130
write 1 298 1131
assign 1 301 1132
classBeginGet 0 301 1132
assign 1 302 1133
countLines 1 302 1133
addValue 1 302 1134
write 1 303 1135
assign 1 306 1136
countLines 1 306 1136
addValue 1 306 1137
write 1 307 1138
assign 1 311 1139
writeOnceDecs 2 311 1139
addValue 1 311 1140
assign 1 314 1141
initialDecGet 0 314 1141
assign 1 315 1142
countLines 1 315 1142
addValue 1 315 1143
write 1 316 1144
assign 1 319 1145
countLines 1 319 1145
addValue 1 319 1146
write 1 320 1147
assign 1 326 1148
new 0 326 1148
assign 1 327 1149
new 0 327 1149
assign 1 329 1150
new 0 329 1150
assign 1 334 1151
new 0 334 1151
assign 1 334 1152
addValue 1 334 1152
assign 1 335 1153
iteratorGet 0 0 1153
assign 1 335 1156
hasNextGet 0 335 1156
assign 1 335 1158
nextGet 0 335 1158
assign 1 336 1159
nlecGet 0 336 1159
addValue 1 336 1160
assign 1 337 1161
nlecGet 0 337 1161
incrementValue 0 337 1162
assign 1 338 1163
undef 1 338 1168
assign 1 0 1169
assign 1 338 1172
nlcGet 0 338 1172
assign 1 338 1173
notEquals 1 338 1173
assign 1 0 1175
assign 1 0 1178
assign 1 0 1182
assign 1 338 1185
nlecGet 0 338 1185
assign 1 338 1186
notEquals 1 338 1186
assign 1 0 1188
assign 1 0 1191
assign 1 341 1196
new 0 341 1196
assign 1 343 1199
new 0 343 1199
addValue 1 343 1200
assign 1 344 1201
new 0 344 1201
addValue 1 344 1202
assign 1 346 1204
nlcGet 0 346 1204
addValue 1 346 1205
assign 1 347 1206
nlecGet 0 347 1206
addValue 1 347 1207
assign 1 350 1209
nlcGet 0 350 1209
assign 1 351 1210
nlecGet 0 351 1210
assign 1 352 1211
heldGet 0 352 1211
assign 1 352 1212
orgNameGet 0 352 1212
assign 1 352 1213
addValue 1 352 1213
assign 1 352 1214
new 0 352 1214
assign 1 352 1215
addValue 1 352 1215
assign 1 352 1216
heldGet 0 352 1216
assign 1 352 1217
numargsGet 0 352 1217
assign 1 352 1218
addValue 1 352 1218
assign 1 352 1219
new 0 352 1219
assign 1 352 1220
addValue 1 352 1220
assign 1 352 1221
nlcGet 0 352 1221
assign 1 352 1222
addValue 1 352 1222
assign 1 352 1223
new 0 352 1223
assign 1 352 1224
addValue 1 352 1224
assign 1 352 1225
nlecGet 0 352 1225
assign 1 352 1226
addValue 1 352 1226
addValue 1 352 1227
assign 1 354 1233
new 0 354 1233
assign 1 354 1234
addValue 1 354 1234
addValue 1 354 1235
assign 1 356 1236
heldGet 0 356 1236
assign 1 356 1237
namepathGet 0 356 1237
assign 1 356 1238
getClassConfig 1 356 1238
assign 1 356 1239
libNameGet 0 356 1239
assign 1 356 1240
relEmitName 1 356 1240
assign 1 356 1241
new 0 356 1241
assign 1 356 1242
add 1 356 1242
assign 1 358 1243
new 0 358 1243
assign 1 358 1244
emitting 1 358 1244
assign 1 360 1246
heldGet 0 360 1246
assign 1 360 1247
namepathGet 0 360 1247
assign 1 360 1248
getClassConfig 1 360 1248
assign 1 360 1249
emitNameGet 0 360 1249
assign 1 360 1250
new 0 360 1250
assign 1 359 1251
add 1 360 1251
assign 1 361 1252
assign 1 364 1254
heldGet 0 364 1254
assign 1 364 1255
namepathGet 0 364 1255
assign 1 364 1256
toString 0 364 1256
assign 1 364 1257
new 0 364 1257
assign 1 364 1258
add 1 364 1258
put 2 364 1259
assign 1 365 1260
heldGet 0 365 1260
assign 1 365 1261
namepathGet 0 365 1261
assign 1 365 1262
toString 0 365 1262
assign 1 365 1263
new 0 365 1263
assign 1 365 1264
add 1 365 1264
put 2 365 1265
assign 1 367 1266
new 0 367 1266
assign 1 367 1267
emitting 1 367 1267
assign 1 368 1269
namepathGet 0 368 1269
assign 1 368 1270
equals 1 368 1270
assign 1 369 1272
new 0 369 1272
assign 1 369 1273
addValue 1 369 1273
addValue 1 369 1274
assign 1 371 1277
new 0 371 1277
assign 1 371 1278
addValue 1 371 1278
addValue 1 371 1279
assign 1 374 1282
new 0 374 1282
assign 1 374 1283
emitting 1 374 1283
assign 1 375 1285
new 0 375 1285
assign 1 375 1286
addValue 1 375 1286
addValue 1 375 1287
assign 1 377 1289
new 0 377 1289
assign 1 377 1290
emitting 1 377 1290
assign 1 378 1292
addValue 1 378 1292
assign 1 378 1293
new 0 378 1293
addValue 1 378 1294
assign 1 379 1295
new 0 379 1295
assign 1 379 1296
addValue 1 379 1296
assign 1 379 1297
addValue 1 379 1297
assign 1 379 1298
new 0 379 1298
assign 1 379 1299
addValue 1 379 1299
addValue 1 379 1300
assign 1 381 1303
new 0 381 1303
assign 1 381 1304
addValue 1 381 1304
assign 1 381 1305
addValue 1 381 1305
assign 1 381 1306
new 0 381 1306
assign 1 381 1307
addValue 1 381 1307
addValue 1 381 1308
assign 1 383 1310
new 0 383 1310
assign 1 383 1311
emitting 1 383 1311
assign 1 384 1313
namepathGet 0 384 1313
assign 1 384 1314
equals 1 384 1314
assign 1 385 1316
new 0 385 1316
assign 1 385 1317
addValue 1 385 1317
addValue 1 385 1318
assign 1 387 1321
new 0 387 1321
assign 1 387 1322
addValue 1 387 1322
addValue 1 387 1323
assign 1 390 1326
new 0 390 1326
assign 1 390 1327
emitting 1 390 1327
assign 1 391 1329
new 0 391 1329
assign 1 391 1330
addValue 1 391 1330
addValue 1 391 1331
assign 1 393 1333
new 0 393 1333
assign 1 393 1334
emitting 1 393 1334
assign 1 394 1336
addValue 1 394 1336
assign 1 394 1337
new 0 394 1337
addValue 1 394 1338
assign 1 395 1339
new 0 395 1339
assign 1 395 1340
addValue 1 395 1340
assign 1 395 1341
addValue 1 395 1341
assign 1 395 1342
new 0 395 1342
assign 1 395 1343
addValue 1 395 1343
addValue 1 395 1344
assign 1 397 1347
new 0 397 1347
assign 1 397 1348
addValue 1 397 1348
assign 1 397 1349
addValue 1 397 1349
assign 1 397 1350
new 0 397 1350
assign 1 397 1351
addValue 1 397 1351
addValue 1 397 1352
addValue 1 400 1354
assign 1 403 1355
countLines 1 403 1355
addValue 1 403 1356
write 1 404 1357
assign 1 407 1358
useDynMethodsGet 0 407 1358
assign 1 408 1360
countLines 1 408 1360
addValue 1 408 1361
write 1 409 1362
assign 1 412 1364
countLines 1 412 1364
addValue 1 412 1365
write 1 413 1366
assign 1 416 1367
classEndGet 0 416 1367
assign 1 417 1368
countLines 1 417 1368
addValue 1 417 1369
write 1 418 1370
assign 1 421 1371
endNs 0 421 1371
assign 1 422 1372
countLines 1 422 1372
addValue 1 422 1373
write 1 423 1374
finishClassOutput 1 427 1375
emitLib 0 430 1381
write 1 434 1386
assign 1 435 1387
countLines 1 435 1387
return 1 435 1388
assign 1 439 1392
new 0 439 1392
return 1 439 1393
assign 1 444 1407
new 0 444 1407
assign 1 444 1408
copy 0 444 1408
assign 1 446 1409
classDirGet 0 446 1409
assign 1 446 1410
fileGet 0 446 1410
assign 1 446 1411
existsGet 0 446 1411
assign 1 446 1412
not 0 446 1412
assign 1 447 1414
classDirGet 0 447 1414
assign 1 447 1415
fileGet 0 447 1415
makeDirs 0 447 1416
assign 1 449 1418
classPathGet 0 449 1418
assign 1 449 1419
fileGet 0 449 1419
assign 1 449 1420
writerGet 0 449 1420
assign 1 449 1421
open 0 449 1421
return 1 449 1422
close 0 453 1425
assign 1 457 1432
fileGet 0 457 1432
assign 1 457 1433
writerGet 0 457 1433
assign 1 457 1434
open 0 457 1434
return 1 457 1435
close 0 461 1438
assign 1 465 1443
new 0 465 1443
return 1 465 1444
assign 1 469 1448
new 0 469 1448
return 1 469 1449
assign 1 473 1453
new 0 473 1453
return 1 473 1454
assign 1 477 1458
new 0 477 1458
return 1 477 1459
assign 1 481 1463
new 0 481 1463
return 1 481 1464
assign 1 485 1468
new 0 485 1468
return 1 485 1469
assign 1 489 1473
new 0 489 1473
return 1 489 1474
assign 1 493 1481
emitLangGet 0 493 1481
assign 1 493 1482
equals 1 493 1482
assign 1 494 1484
new 0 494 1484
return 1 494 1485
assign 1 496 1487
new 0 496 1487
return 1 496 1488
assign 1 501 1720
new 0 501 1720
assign 1 503 1721
new 0 503 1721
assign 1 504 1722
mainNameGet 0 504 1722
fromString 1 504 1723
assign 1 505 1724
getClassConfig 1 505 1724
assign 1 507 1725
new 0 507 1725
assign 1 508 1726
mainStartGet 0 508 1726
addValue 1 508 1727
assign 1 509 1728
addValue 1 509 1728
assign 1 509 1729
new 0 509 1729
assign 1 509 1730
addValue 1 509 1730
addValue 1 509 1731
assign 1 511 1732
fullEmitNameGet 0 511 1732
assign 1 511 1733
addValue 1 511 1733
assign 1 511 1734
new 0 511 1734
assign 1 511 1735
addValue 1 511 1735
assign 1 511 1736
fullEmitNameGet 0 511 1736
assign 1 511 1737
addValue 1 511 1737
assign 1 511 1738
new 0 511 1738
assign 1 511 1739
addValue 1 511 1739
addValue 1 511 1740
assign 1 512 1741
new 0 512 1741
assign 1 512 1742
addValue 1 512 1742
addValue 1 512 1743
assign 1 513 1744
new 0 513 1744
assign 1 513 1745
addValue 1 513 1745
addValue 1 513 1746
assign 1 514 1747
mainEndGet 0 514 1747
addValue 1 514 1748
assign 1 516 1749
getLibOutput 0 516 1749
assign 1 517 1750
beginNs 0 517 1750
write 1 517 1751
assign 1 518 1752
new 0 518 1752
assign 1 518 1753
extend 1 518 1753
assign 1 519 1754
klassDecGet 0 519 1754
assign 1 519 1755
add 1 519 1755
assign 1 519 1756
add 1 519 1756
assign 1 519 1757
new 0 519 1757
assign 1 519 1758
add 1 519 1758
assign 1 519 1759
add 1 519 1759
write 1 519 1760
assign 1 520 1761
spropDecGet 0 520 1761
assign 1 520 1762
boolTypeGet 0 520 1762
assign 1 520 1763
add 1 520 1763
assign 1 520 1764
new 0 520 1764
assign 1 520 1765
add 1 520 1765
assign 1 520 1766
add 1 520 1766
write 1 520 1767
assign 1 522 1768
new 0 522 1768
assign 1 523 1769
usedLibrarysGet 0 523 1769
assign 1 523 1770
iteratorGet 0 0 1770
assign 1 523 1773
hasNextGet 0 523 1773
assign 1 523 1775
nextGet 0 523 1775
assign 1 525 1776
libNameGet 0 525 1776
assign 1 525 1777
fullLibEmitName 1 525 1777
assign 1 525 1778
addValue 1 525 1778
assign 1 525 1779
new 0 525 1779
assign 1 525 1780
addValue 1 525 1780
addValue 1 525 1781
assign 1 528 1787
new 0 528 1787
assign 1 529 1788
new 0 529 1788
assign 1 530 1789
new 0 530 1789
assign 1 531 1790
iteratorGet 0 531 1790
assign 1 531 1793
hasNextGet 0 531 1793
assign 1 533 1795
nextGet 0 533 1795
assign 1 535 1796
new 0 535 1796
assign 1 535 1797
emitting 1 535 1797
assign 1 536 1799
new 0 536 1799
assign 1 536 1800
addValue 1 536 1800
assign 1 536 1801
addValue 1 536 1801
assign 1 536 1802
heldGet 0 536 1802
assign 1 536 1803
namepathGet 0 536 1803
assign 1 536 1804
toString 0 536 1804
assign 1 536 1805
addValue 1 536 1805
assign 1 536 1806
addValue 1 536 1806
assign 1 536 1807
new 0 536 1807
assign 1 536 1808
addValue 1 536 1808
assign 1 536 1809
addValue 1 536 1809
assign 1 536 1810
heldGet 0 536 1810
assign 1 536 1811
namepathGet 0 536 1811
assign 1 536 1812
getClassConfig 1 536 1812
assign 1 536 1813
fullEmitNameGet 0 536 1813
assign 1 536 1814
addValue 1 536 1814
assign 1 536 1815
addValue 1 536 1815
assign 1 536 1816
new 0 536 1816
assign 1 536 1817
addValue 1 536 1817
addValue 1 536 1818
assign 1 538 1820
new 0 538 1820
assign 1 538 1821
emitting 1 538 1821
assign 1 539 1823
new 0 539 1823
assign 1 539 1824
addValue 1 539 1824
assign 1 539 1825
addValue 1 539 1825
assign 1 539 1826
heldGet 0 539 1826
assign 1 539 1827
namepathGet 0 539 1827
assign 1 539 1828
toString 0 539 1828
assign 1 539 1829
addValue 1 539 1829
assign 1 539 1830
addValue 1 539 1830
assign 1 539 1831
new 0 539 1831
assign 1 539 1832
addValue 1 539 1832
assign 1 539 1833
heldGet 0 539 1833
assign 1 539 1834
namepathGet 0 539 1834
assign 1 539 1835
getClassConfig 1 539 1835
assign 1 539 1836
libNameGet 0 539 1836
assign 1 539 1837
relEmitName 1 539 1837
assign 1 539 1838
addValue 1 539 1838
assign 1 539 1839
new 0 539 1839
assign 1 539 1840
addValue 1 539 1840
addValue 1 539 1841
assign 1 540 1842
new 0 540 1842
assign 1 540 1843
addValue 1 540 1843
assign 1 540 1844
heldGet 0 540 1844
assign 1 540 1845
namepathGet 0 540 1845
assign 1 540 1846
getClassConfig 1 540 1846
assign 1 540 1847
libNameGet 0 540 1847
assign 1 540 1848
relEmitName 1 540 1848
assign 1 540 1849
addValue 1 540 1849
assign 1 540 1850
new 0 540 1850
addValue 1 540 1851
assign 1 541 1852
new 0 541 1852
assign 1 541 1853
addValue 1 541 1853
assign 1 541 1854
addValue 1 541 1854
assign 1 541 1855
new 0 541 1855
assign 1 541 1856
addValue 1 541 1856
assign 1 541 1857
addValue 1 541 1857
assign 1 541 1858
new 0 541 1858
assign 1 541 1859
addValue 1 541 1859
addValue 1 541 1860
assign 1 544 1862
heldGet 0 544 1862
assign 1 544 1863
synGet 0 544 1863
assign 1 544 1864
hasDefaultGet 0 544 1864
assign 1 545 1866
new 0 545 1866
assign 1 545 1867
heldGet 0 545 1867
assign 1 545 1868
namepathGet 0 545 1868
assign 1 545 1869
getClassConfig 1 545 1869
assign 1 545 1870
libNameGet 0 545 1870
assign 1 545 1871
relEmitName 1 545 1871
assign 1 545 1872
add 1 545 1872
assign 1 545 1873
new 0 545 1873
assign 1 545 1874
add 1 545 1874
assign 1 546 1875
new 0 546 1875
assign 1 546 1876
addValue 1 546 1876
assign 1 546 1877
addValue 1 546 1877
assign 1 546 1878
new 0 546 1878
assign 1 546 1879
addValue 1 546 1879
addValue 1 546 1880
assign 1 547 1881
new 0 547 1881
assign 1 547 1882
addValue 1 547 1882
assign 1 547 1883
addValue 1 547 1883
assign 1 547 1884
new 0 547 1884
assign 1 547 1885
addValue 1 547 1885
addValue 1 547 1886
assign 1 551 1893
iteratorGet 0 0 1893
assign 1 551 1896
hasNextGet 0 551 1896
assign 1 551 1898
nextGet 0 551 1898
assign 1 552 1899
spropDecGet 0 552 1899
assign 1 552 1900
new 0 552 1900
assign 1 552 1901
add 1 552 1901
assign 1 552 1902
add 1 552 1902
assign 1 552 1903
new 0 552 1903
assign 1 552 1904
add 1 552 1904
assign 1 552 1905
add 1 552 1905
write 1 552 1906
assign 1 553 1907
new 0 553 1907
assign 1 553 1908
addValue 1 553 1908
assign 1 553 1909
addValue 1 553 1909
assign 1 553 1910
new 0 553 1910
assign 1 553 1911
addValue 1 553 1911
assign 1 553 1912
addValue 1 553 1912
assign 1 553 1913
addValue 1 553 1913
assign 1 553 1914
addValue 1 553 1914
assign 1 553 1915
new 0 553 1915
assign 1 553 1916
addValue 1 553 1916
addValue 1 553 1917
assign 1 556 1923
new 0 556 1923
assign 1 558 1924
keysGet 0 558 1924
assign 1 558 1925
iteratorGet 0 0 1925
assign 1 558 1928
hasNextGet 0 558 1928
assign 1 558 1930
nextGet 0 558 1930
assign 1 560 1931
new 0 560 1931
assign 1 560 1932
addValue 1 560 1932
assign 1 560 1933
new 0 560 1933
assign 1 560 1934
quoteGet 0 560 1934
assign 1 560 1935
addValue 1 560 1935
assign 1 560 1936
addValue 1 560 1936
assign 1 560 1937
new 0 560 1937
assign 1 560 1938
quoteGet 0 560 1938
assign 1 560 1939
addValue 1 560 1939
assign 1 560 1940
new 0 560 1940
assign 1 560 1941
addValue 1 560 1941
assign 1 560 1942
get 1 560 1942
assign 1 560 1943
addValue 1 560 1943
assign 1 560 1944
new 0 560 1944
assign 1 560 1945
addValue 1 560 1945
addValue 1 560 1946
assign 1 561 1947
new 0 561 1947
assign 1 561 1948
addValue 1 561 1948
assign 1 561 1949
new 0 561 1949
assign 1 561 1950
quoteGet 0 561 1950
assign 1 561 1951
addValue 1 561 1951
assign 1 561 1952
addValue 1 561 1952
assign 1 561 1953
new 0 561 1953
assign 1 561 1954
quoteGet 0 561 1954
assign 1 561 1955
addValue 1 561 1955
assign 1 561 1956
new 0 561 1956
assign 1 561 1957
addValue 1 561 1957
assign 1 561 1958
get 1 561 1958
assign 1 561 1959
addValue 1 561 1959
assign 1 561 1960
new 0 561 1960
assign 1 561 1961
addValue 1 561 1961
addValue 1 561 1962
assign 1 565 1968
baseSmtdDecGet 0 565 1968
assign 1 565 1969
new 0 565 1969
assign 1 565 1970
add 1 565 1970
assign 1 565 1971
addValue 1 565 1971
assign 1 565 1972
new 0 565 1972
assign 1 565 1973
add 1 565 1973
assign 1 565 1974
addValue 1 565 1974
write 1 565 1975
assign 1 566 1976
new 0 566 1976
assign 1 566 1977
emitting 1 566 1977
assign 1 567 1979
new 0 567 1979
assign 1 567 1980
add 1 567 1980
assign 1 567 1981
new 0 567 1981
assign 1 567 1982
add 1 567 1982
assign 1 567 1983
add 1 567 1983
write 1 567 1984
assign 1 568 1987
new 0 568 1987
assign 1 568 1988
emitting 1 568 1988
assign 1 569 1990
new 0 569 1990
assign 1 569 1991
add 1 569 1991
assign 1 569 1992
new 0 569 1992
assign 1 569 1993
add 1 569 1993
assign 1 569 1994
add 1 569 1994
write 1 569 1995
assign 1 571 1998
new 0 571 1998
assign 1 571 1999
add 1 571 1999
write 1 571 2000
assign 1 572 2001
new 0 572 2001
assign 1 572 2002
add 1 572 2002
write 1 572 2003
assign 1 573 2004
runtimeInitGet 0 573 2004
write 1 573 2005
write 1 574 2006
write 1 575 2007
write 1 576 2008
write 1 577 2009
write 1 578 2010
write 1 579 2011
assign 1 580 2012
new 0 580 2012
assign 1 580 2013
emitting 1 580 2013
assign 1 0 2015
assign 1 580 2018
new 0 580 2018
assign 1 580 2019
emitting 1 580 2019
assign 1 0 2021
assign 1 0 2024
assign 1 582 2028
new 0 582 2028
assign 1 582 2029
add 1 582 2029
write 1 582 2030
assign 1 584 2032
new 0 584 2032
assign 1 584 2033
add 1 584 2033
write 1 584 2034
assign 1 586 2035
mainInClassGet 0 586 2035
write 1 587 2037
assign 1 590 2039
new 0 590 2039
assign 1 590 2040
add 1 590 2040
write 1 590 2041
assign 1 591 2042
endNs 0 591 2042
write 1 591 2043
assign 1 593 2044
mainOutsideNsGet 0 593 2044
write 1 594 2046
finishLibOutput 1 597 2048
assign 1 602 2054
new 0 602 2054
assign 1 602 2055
add 1 602 2055
return 1 602 2056
assign 1 606 2060
new 0 606 2060
return 1 606 2061
assign 1 610 2065
new 0 610 2065
return 1 610 2066
assign 1 614 2070
new 0 614 2070
return 1 614 2071
assign 1 620 2083
new 0 620 2083
assign 1 620 2084
emitting 1 620 2084
assign 1 0 2086
assign 1 620 2089
new 0 620 2089
assign 1 620 2090
emitting 1 620 2090
assign 1 0 2092
assign 1 0 2095
assign 1 622 2099
new 0 622 2099
assign 1 622 2100
add 1 622 2100
return 1 622 2101
assign 1 625 2103
new 0 625 2103
assign 1 625 2104
add 1 625 2104
return 1 625 2105
assign 1 629 2109
new 0 629 2109
return 1 629 2110
begin 1 634 2113
assign 1 636 2114
new 0 636 2114
assign 1 637 2115
new 0 637 2115
assign 1 638 2116
new 0 638 2116
assign 1 639 2117
new 0 639 2117
assign 1 646 2127
isTmpVarGet 0 646 2127
assign 1 647 2129
new 0 647 2129
assign 1 648 2132
isPropertyGet 0 648 2132
assign 1 649 2134
new 0 649 2134
assign 1 650 2137
isArgGet 0 650 2137
assign 1 651 2139
new 0 651 2139
assign 1 653 2142
new 0 653 2142
assign 1 655 2146
nameGet 0 655 2146
assign 1 655 2147
add 1 655 2147
return 1 655 2148
assign 1 660 2159
isTypedGet 0 660 2159
assign 1 660 2160
not 0 660 2160
assign 1 661 2162
libNameGet 0 661 2162
assign 1 661 2163
relEmitName 1 661 2163
addValue 1 661 2164
assign 1 663 2167
namepathGet 0 663 2167
assign 1 663 2168
getClassConfig 1 663 2168
assign 1 663 2169
libNameGet 0 663 2169
assign 1 663 2170
relEmitName 1 663 2170
addValue 1 663 2171
typeDecForVar 2 668 2178
assign 1 669 2179
new 0 669 2179
addValue 1 669 2180
assign 1 670 2181
nameForVar 1 670 2181
addValue 1 670 2182
assign 1 674 2190
new 0 674 2190
assign 1 674 2191
heldGet 0 674 2191
assign 1 674 2192
nameGet 0 674 2192
assign 1 674 2193
add 1 674 2193
return 1 674 2194
assign 1 678 2201
new 0 678 2201
assign 1 678 2202
heldGet 0 678 2202
assign 1 678 2203
nameGet 0 678 2203
assign 1 678 2204
add 1 678 2204
return 1 678 2205
assign 1 683 2257
assign 1 684 2258
assign 1 687 2259
mtdMapGet 0 687 2259
assign 1 687 2260
heldGet 0 687 2260
assign 1 687 2261
nameGet 0 687 2261
assign 1 687 2262
get 1 687 2262
assign 1 689 2263
heldGet 0 689 2263
assign 1 689 2264
nameGet 0 689 2264
put 1 689 2265
assign 1 691 2266
new 0 691 2266
assign 1 692 2267
new 0 692 2267
assign 1 694 2268
new 0 694 2268
assign 1 695 2269
heldGet 0 695 2269
assign 1 695 2270
orderedVarsGet 0 695 2270
assign 1 695 2271
iteratorGet 0 0 2271
assign 1 695 2274
hasNextGet 0 695 2274
assign 1 695 2276
nextGet 0 695 2276
assign 1 696 2277
heldGet 0 696 2277
assign 1 696 2278
nameGet 0 696 2278
assign 1 696 2279
new 0 696 2279
assign 1 696 2280
notEquals 1 696 2280
assign 1 696 2282
heldGet 0 696 2282
assign 1 696 2283
nameGet 0 696 2283
assign 1 696 2284
new 0 696 2284
assign 1 696 2285
notEquals 1 696 2285
assign 1 0 2287
assign 1 0 2290
assign 1 0 2294
assign 1 697 2297
heldGet 0 697 2297
assign 1 697 2298
isArgGet 0 697 2298
assign 1 699 2301
new 0 699 2301
addValue 1 699 2302
assign 1 701 2304
new 0 701 2304
assign 1 702 2305
heldGet 0 702 2305
assign 1 702 2306
undef 1 702 2311
assign 1 703 2312
new 0 703 2312
assign 1 703 2313
toString 0 703 2313
assign 1 703 2314
add 1 703 2314
assign 1 703 2315
new 2 703 2315
throw 1 703 2316
assign 1 705 2318
heldGet 0 705 2318
decForVar 2 705 2319
assign 1 707 2322
heldGet 0 707 2322
decForVar 2 707 2323
assign 1 708 2324
new 0 708 2324
assign 1 708 2325
emitting 1 708 2325
assign 1 709 2327
new 0 709 2327
assign 1 709 2328
addValue 1 709 2328
addValue 1 709 2329
assign 1 711 2332
new 0 711 2332
assign 1 711 2333
addValue 1 711 2333
addValue 1 711 2334
assign 1 714 2337
heldGet 0 714 2337
assign 1 714 2338
heldGet 0 714 2338
assign 1 714 2339
nameForVar 1 714 2339
nativeNameSet 1 714 2340
assign 1 718 2347
getEmitReturnType 2 718 2347
assign 1 720 2348
def 1 720 2353
assign 1 721 2354
getClassConfig 1 721 2354
assign 1 723 2357
assign 1 727 2359
declarationGet 0 727 2359
assign 1 727 2360
namepathGet 0 727 2360
assign 1 727 2361
equals 1 727 2361
assign 1 728 2363
baseMtdDecGet 0 728 2363
assign 1 730 2366
overrideMtdDecGet 0 730 2366
assign 1 733 2368
emitNameForMethod 1 733 2368
startMethod 5 733 2369
addValue 1 735 2370
assign 1 741 2387
addValue 1 741 2387
assign 1 741 2388
libNameGet 0 741 2388
assign 1 741 2389
relEmitName 1 741 2389
assign 1 741 2390
addValue 1 741 2390
assign 1 741 2391
new 0 741 2391
assign 1 741 2392
addValue 1 741 2392
assign 1 741 2393
addValue 1 741 2393
assign 1 741 2394
new 0 741 2394
addValue 1 741 2395
addValue 1 743 2396
assign 1 745 2397
new 0 745 2397
assign 1 745 2398
addValue 1 745 2398
assign 1 745 2399
addValue 1 745 2399
assign 1 745 2400
new 0 745 2400
assign 1 745 2401
addValue 1 745 2401
addValue 1 745 2402
assign 1 750 2412
getSynNp 1 750 2412
assign 1 751 2413
closeLibrariesGet 0 751 2413
assign 1 751 2414
libNameGet 0 751 2414
assign 1 751 2415
has 1 751 2415
assign 1 752 2417
new 0 752 2417
return 1 752 2418
assign 1 754 2420
new 0 754 2420
return 1 754 2421
assign 1 759 2645
new 0 759 2645
assign 1 760 2646
new 0 760 2646
assign 1 761 2647
new 0 761 2647
assign 1 762 2648
new 0 762 2648
assign 1 763 2649
new 0 763 2649
assign 1 764 2650
assign 1 765 2651
heldGet 0 765 2651
assign 1 765 2652
synGet 0 765 2652
assign 1 766 2653
new 0 766 2653
assign 1 767 2654
new 0 767 2654
assign 1 768 2655
new 0 768 2655
assign 1 769 2656
new 0 769 2656
assign 1 770 2657
heldGet 0 770 2657
assign 1 770 2658
fromFileGet 0 770 2658
assign 1 770 2659
new 0 770 2659
assign 1 770 2660
toStringWithSeparator 1 770 2660
assign 1 773 2661
transUnitGet 0 773 2661
assign 1 773 2662
heldGet 0 773 2662
assign 1 773 2663
emitsGet 0 773 2663
assign 1 774 2664
def 1 774 2669
assign 1 775 2670
iteratorGet 0 775 2670
assign 1 775 2673
hasNextGet 0 775 2673
assign 1 776 2675
nextGet 0 776 2675
assign 1 777 2676
heldGet 0 777 2676
assign 1 777 2677
langsGet 0 777 2677
assign 1 777 2678
emitLangGet 0 777 2678
assign 1 777 2679
has 1 777 2679
assign 1 778 2681
heldGet 0 778 2681
assign 1 778 2682
textGet 0 778 2682
addValue 1 778 2683
assign 1 783 2691
heldGet 0 783 2691
assign 1 783 2692
extendsGet 0 783 2692
assign 1 783 2693
def 1 783 2698
assign 1 784 2699
heldGet 0 784 2699
assign 1 784 2700
extendsGet 0 784 2700
assign 1 784 2701
getClassConfig 1 784 2701
assign 1 785 2702
heldGet 0 785 2702
assign 1 785 2703
extendsGet 0 785 2703
assign 1 785 2704
getSynNp 1 785 2704
assign 1 787 2707
assign 1 791 2709
heldGet 0 791 2709
assign 1 791 2710
emitsGet 0 791 2710
assign 1 791 2711
def 1 791 2716
assign 1 792 2717
emitLangGet 0 792 2717
assign 1 793 2718
heldGet 0 793 2718
assign 1 793 2719
emitsGet 0 793 2719
assign 1 793 2720
iteratorGet 0 0 2720
assign 1 793 2723
hasNextGet 0 793 2723
assign 1 793 2725
nextGet 0 793 2725
assign 1 795 2726
heldGet 0 795 2726
assign 1 795 2727
textGet 0 795 2727
assign 1 795 2728
getNativeCSlots 1 795 2728
assign 1 796 2729
heldGet 0 796 2729
assign 1 796 2730
langsGet 0 796 2730
assign 1 796 2731
has 1 796 2731
assign 1 797 2733
heldGet 0 797 2733
assign 1 797 2734
textGet 0 797 2734
addValue 1 797 2735
assign 1 802 2743
def 1 802 2748
assign 1 802 2749
new 0 802 2749
assign 1 802 2750
greater 1 802 2750
assign 1 0 2752
assign 1 0 2755
assign 1 0 2759
assign 1 803 2762
ptyListGet 0 803 2762
assign 1 803 2763
sizeGet 0 803 2763
assign 1 803 2764
subtract 1 803 2764
assign 1 804 2765
new 0 804 2765
assign 1 804 2766
lesser 1 804 2766
assign 1 805 2768
new 0 805 2768
assign 1 811 2771
new 0 811 2771
assign 1 812 2772
heldGet 0 812 2772
assign 1 812 2773
orderedVarsGet 0 812 2773
assign 1 812 2774
iteratorGet 0 812 2774
assign 1 812 2777
hasNextGet 0 812 2777
assign 1 813 2779
nextGet 0 813 2779
assign 1 813 2780
heldGet 0 813 2780
assign 1 814 2781
isDeclaredGet 0 814 2781
assign 1 815 2783
greaterEquals 1 815 2783
assign 1 816 2785
propDecGet 0 816 2785
addValue 1 816 2786
decForVar 2 817 2787
assign 1 818 2788
new 0 818 2788
assign 1 818 2789
addValue 1 818 2789
addValue 1 818 2790
assign 1 820 2792
increment 0 820 2792
assign 1 825 2799
new 0 825 2799
assign 1 826 2800
new 0 826 2800
assign 1 827 2801
mtdListGet 0 827 2801
assign 1 827 2802
iteratorGet 0 0 2802
assign 1 827 2805
hasNextGet 0 827 2805
assign 1 827 2807
nextGet 0 827 2807
assign 1 828 2808
nameGet 0 828 2808
assign 1 828 2809
has 1 828 2809
assign 1 829 2811
nameGet 0 829 2811
put 1 829 2812
assign 1 830 2813
mtdMapGet 0 830 2813
assign 1 830 2814
nameGet 0 830 2814
assign 1 830 2815
get 1 830 2815
assign 1 831 2816
originGet 0 831 2816
assign 1 831 2817
isClose 1 831 2817
assign 1 832 2819
numargsGet 0 832 2819
assign 1 833 2820
greater 1 833 2820
assign 1 834 2822
assign 1 836 2824
get 1 836 2824
assign 1 837 2825
undef 1 837 2830
assign 1 838 2831
new 0 838 2831
put 2 839 2832
assign 1 841 2834
nameGet 0 841 2834
assign 1 841 2835
hashGet 0 841 2835
assign 1 842 2836
get 1 842 2836
assign 1 843 2837
undef 1 843 2842
assign 1 844 2843
new 0 844 2843
put 2 845 2844
addValue 1 847 2846
assign 1 853 2854
iteratorGet 0 0 2854
assign 1 853 2857
hasNextGet 0 853 2857
assign 1 853 2859
nextGet 0 853 2859
assign 1 854 2860
keyGet 0 854 2860
assign 1 856 2861
lesser 1 856 2861
assign 1 857 2863
new 0 857 2863
assign 1 857 2864
toString 0 857 2864
assign 1 857 2865
add 1 857 2865
assign 1 859 2868
new 0 859 2868
assign 1 861 2870
new 0 861 2870
assign 1 862 2871
new 0 862 2871
assign 1 863 2872
new 0 863 2872
assign 1 864 2875
new 0 864 2875
assign 1 864 2876
add 1 864 2876
assign 1 864 2877
lesser 1 864 2877
assign 1 864 2879
lesser 1 864 2879
assign 1 0 2881
assign 1 0 2884
assign 1 0 2888
assign 1 865 2891
new 0 865 2891
assign 1 865 2892
add 1 865 2892
assign 1 865 2893
libNameGet 0 865 2893
assign 1 865 2894
relEmitName 1 865 2894
assign 1 865 2895
add 1 865 2895
assign 1 865 2896
new 0 865 2896
assign 1 865 2897
add 1 865 2897
assign 1 865 2898
new 0 865 2898
assign 1 865 2899
subtract 1 865 2899
assign 1 865 2900
add 1 865 2900
assign 1 866 2901
new 0 866 2901
assign 1 866 2902
add 1 866 2902
assign 1 866 2903
new 0 866 2903
assign 1 866 2904
add 1 866 2904
assign 1 866 2905
new 0 866 2905
assign 1 866 2906
subtract 1 866 2906
assign 1 866 2907
add 1 866 2907
assign 1 867 2908
increment 0 867 2908
assign 1 869 2914
greaterEquals 1 869 2914
assign 1 870 2916
new 0 870 2916
assign 1 870 2917
add 1 870 2917
assign 1 870 2918
libNameGet 0 870 2918
assign 1 870 2919
relEmitName 1 870 2919
assign 1 870 2920
add 1 870 2920
assign 1 870 2921
new 0 870 2921
assign 1 870 2922
add 1 870 2922
assign 1 871 2923
new 0 871 2923
assign 1 871 2924
add 1 871 2924
assign 1 873 2926
overrideMtdDecGet 0 873 2926
assign 1 873 2927
addValue 1 873 2927
assign 1 873 2928
libNameGet 0 873 2928
assign 1 873 2929
relEmitName 1 873 2929
assign 1 873 2930
addValue 1 873 2930
assign 1 873 2931
new 0 873 2931
assign 1 873 2932
addValue 1 873 2932
assign 1 873 2933
addValue 1 873 2933
assign 1 873 2934
new 0 873 2934
assign 1 873 2935
addValue 1 873 2935
assign 1 873 2936
addValue 1 873 2936
assign 1 873 2937
new 0 873 2937
assign 1 873 2938
addValue 1 873 2938
assign 1 873 2939
addValue 1 873 2939
assign 1 873 2940
new 0 873 2940
assign 1 873 2941
addValue 1 873 2941
addValue 1 873 2942
assign 1 874 2943
new 0 874 2943
assign 1 874 2944
addValue 1 874 2944
addValue 1 874 2945
assign 1 876 2946
valueGet 0 876 2946
assign 1 877 2947
iteratorGet 0 0 2947
assign 1 877 2950
hasNextGet 0 877 2950
assign 1 877 2952
nextGet 0 877 2952
assign 1 878 2953
keyGet 0 878 2953
assign 1 879 2954
valueGet 0 879 2954
assign 1 880 2955
new 0 880 2955
assign 1 880 2956
addValue 1 880 2956
assign 1 880 2957
toString 0 880 2957
assign 1 880 2958
addValue 1 880 2958
assign 1 880 2959
new 0 880 2959
addValue 1 880 2960
assign 1 0 2962
assign 1 884 2965
sizeGet 0 884 2965
assign 1 884 2966
new 0 884 2966
assign 1 884 2967
greater 1 884 2967
assign 1 0 2969
assign 1 0 2972
assign 1 885 2976
new 0 885 2976
assign 1 887 2979
new 0 887 2979
assign 1 889 2981
iteratorGet 0 0 2981
assign 1 889 2984
hasNextGet 0 889 2984
assign 1 889 2986
nextGet 0 889 2986
assign 1 890 2987
new 0 890 2987
assign 1 892 2989
new 0 892 2989
assign 1 892 2990
add 1 892 2990
assign 1 892 2991
nameGet 0 892 2991
assign 1 892 2992
add 1 892 2992
assign 1 893 2993
new 0 893 2993
assign 1 893 2994
addValue 1 893 2994
assign 1 893 2995
addValue 1 893 2995
assign 1 893 2996
new 0 893 2996
assign 1 893 2997
addValue 1 893 2997
addValue 1 893 2998
assign 1 895 3000
new 0 895 3000
assign 1 895 3001
addValue 1 895 3001
assign 1 895 3002
nameGet 0 895 3002
assign 1 895 3003
addValue 1 895 3003
assign 1 895 3004
new 0 895 3004
addValue 1 895 3005
assign 1 896 3006
new 0 896 3006
assign 1 897 3007
argSynsGet 0 897 3007
assign 1 897 3008
iteratorGet 0 0 3008
assign 1 897 3011
hasNextGet 0 897 3011
assign 1 897 3013
nextGet 0 897 3013
assign 1 898 3014
new 0 898 3014
assign 1 898 3015
greater 1 898 3015
assign 1 899 3017
isTypedGet 0 899 3017
assign 1 899 3019
namepathGet 0 899 3019
assign 1 899 3020
notEquals 1 899 3020
assign 1 0 3022
assign 1 0 3025
assign 1 0 3029
assign 1 900 3032
namepathGet 0 900 3032
assign 1 900 3033
getClassConfig 1 900 3033
assign 1 900 3034
formCast 1 900 3034
assign 1 900 3035
new 0 900 3035
assign 1 900 3036
add 1 900 3036
assign 1 902 3039
new 0 902 3039
assign 1 904 3041
new 0 904 3041
assign 1 904 3042
greater 1 904 3042
assign 1 905 3044
new 0 905 3044
assign 1 907 3047
new 0 907 3047
assign 1 909 3049
lesser 1 909 3049
assign 1 910 3051
new 0 910 3051
assign 1 910 3052
new 0 910 3052
assign 1 910 3053
subtract 1 910 3053
assign 1 910 3054
add 1 910 3054
assign 1 912 3057
new 0 912 3057
assign 1 912 3058
subtract 1 912 3058
assign 1 912 3059
add 1 912 3059
assign 1 912 3060
new 0 912 3060
assign 1 912 3061
add 1 912 3061
assign 1 914 3063
addValue 1 914 3063
assign 1 914 3064
addValue 1 914 3064
addValue 1 914 3065
assign 1 916 3067
increment 0 916 3067
assign 1 918 3073
new 0 918 3073
assign 1 918 3074
addValue 1 918 3074
addValue 1 918 3075
assign 1 921 3077
new 0 921 3077
assign 1 921 3078
addValue 1 921 3078
addValue 1 921 3079
addValue 1 924 3081
assign 1 927 3088
new 0 927 3088
assign 1 927 3089
addValue 1 927 3089
addValue 1 927 3090
assign 1 930 3097
new 0 930 3097
assign 1 930 3098
addValue 1 930 3098
addValue 1 930 3099
assign 1 931 3100
new 0 931 3100
assign 1 931 3101
superNameGet 0 931 3101
assign 1 931 3102
add 1 931 3102
assign 1 931 3103
new 0 931 3103
assign 1 931 3104
add 1 931 3104
assign 1 931 3105
addValue 1 931 3105
assign 1 931 3106
addValue 1 931 3106
assign 1 931 3107
new 0 931 3107
assign 1 931 3108
addValue 1 931 3108
assign 1 931 3109
addValue 1 931 3109
assign 1 931 3110
new 0 931 3110
assign 1 931 3111
addValue 1 931 3111
addValue 1 931 3112
assign 1 932 3113
new 0 932 3113
assign 1 932 3114
addValue 1 932 3114
addValue 1 932 3115
buildClassInfo 0 935 3121
buildCreate 0 937 3122
buildInitial 0 939 3123
assign 1 947 3141
new 0 947 3141
assign 1 948 3142
new 0 948 3142
assign 1 948 3143
split 1 948 3143
assign 1 949 3144
new 0 949 3144
assign 1 950 3145
new 0 950 3145
assign 1 951 3146
iteratorGet 0 0 3146
assign 1 951 3149
hasNextGet 0 951 3149
assign 1 951 3151
nextGet 0 951 3151
assign 1 953 3153
new 0 953 3153
assign 1 954 3154
new 1 954 3154
assign 1 955 3155
new 0 955 3155
assign 1 956 3158
new 0 956 3158
assign 1 956 3159
equals 1 956 3159
assign 1 957 3161
new 0 957 3161
assign 1 958 3162
new 0 958 3162
assign 1 959 3165
new 0 959 3165
assign 1 959 3166
equals 1 959 3166
assign 1 960 3168
new 0 960 3168
assign 1 963 3177
new 0 963 3177
assign 1 963 3178
greater 1 963 3178
return 1 966 3181
assign 1 970 3207
overrideMtdDecGet 0 970 3207
assign 1 970 3208
addValue 1 970 3208
assign 1 970 3209
getClassConfig 1 970 3209
assign 1 970 3210
libNameGet 0 970 3210
assign 1 970 3211
relEmitName 1 970 3211
assign 1 970 3212
addValue 1 970 3212
assign 1 970 3213
new 0 970 3213
assign 1 970 3214
addValue 1 970 3214
assign 1 970 3215
addValue 1 970 3215
assign 1 970 3216
new 0 970 3216
assign 1 970 3217
addValue 1 970 3217
addValue 1 970 3218
assign 1 971 3219
new 0 971 3219
assign 1 971 3220
addValue 1 971 3220
assign 1 971 3221
heldGet 0 971 3221
assign 1 971 3222
namepathGet 0 971 3222
assign 1 971 3223
getClassConfig 1 971 3223
assign 1 971 3224
libNameGet 0 971 3224
assign 1 971 3225
relEmitName 1 971 3225
assign 1 971 3226
addValue 1 971 3226
assign 1 971 3227
new 0 971 3227
assign 1 971 3228
addValue 1 971 3228
addValue 1 971 3229
assign 1 973 3230
new 0 973 3230
assign 1 973 3231
addValue 1 973 3231
addValue 1 973 3232
assign 1 977 3279
getClassConfig 1 977 3279
assign 1 977 3280
libNameGet 0 977 3280
assign 1 977 3281
relEmitName 1 977 3281
assign 1 978 3282
emitNameGet 0 978 3282
assign 1 979 3283
heldGet 0 979 3283
assign 1 979 3284
namepathGet 0 979 3284
assign 1 979 3285
getClassConfig 1 979 3285
assign 1 980 3286
getInitialInst 1 980 3286
assign 1 982 3287
overrideMtdDecGet 0 982 3287
assign 1 982 3288
addValue 1 982 3288
assign 1 982 3289
new 0 982 3289
assign 1 982 3290
addValue 1 982 3290
assign 1 982 3291
addValue 1 982 3291
assign 1 982 3292
new 0 982 3292
assign 1 982 3293
addValue 1 982 3293
assign 1 982 3294
addValue 1 982 3294
assign 1 982 3295
new 0 982 3295
assign 1 982 3296
addValue 1 982 3296
addValue 1 982 3297
assign 1 984 3298
notEquals 1 984 3298
assign 1 985 3300
formCast 1 985 3300
assign 1 987 3303
new 0 987 3303
assign 1 990 3305
addValue 1 990 3305
assign 1 990 3306
new 0 990 3306
assign 1 990 3307
addValue 1 990 3307
assign 1 990 3308
addValue 1 990 3308
assign 1 990 3309
new 0 990 3309
assign 1 990 3310
addValue 1 990 3310
addValue 1 990 3311
assign 1 992 3312
new 0 992 3312
assign 1 992 3313
addValue 1 992 3313
addValue 1 992 3314
assign 1 995 3315
overrideMtdDecGet 0 995 3315
assign 1 995 3316
addValue 1 995 3316
assign 1 995 3317
addValue 1 995 3317
assign 1 995 3318
new 0 995 3318
assign 1 995 3319
addValue 1 995 3319
assign 1 995 3320
addValue 1 995 3320
assign 1 995 3321
new 0 995 3321
assign 1 995 3322
addValue 1 995 3322
addValue 1 995 3323
assign 1 997 3324
new 0 997 3324
assign 1 997 3325
addValue 1 997 3325
assign 1 997 3326
addValue 1 997 3326
assign 1 997 3327
new 0 997 3327
assign 1 997 3328
addValue 1 997 3328
addValue 1 997 3329
assign 1 999 3330
new 0 999 3330
assign 1 999 3331
addValue 1 999 3331
addValue 1 999 3332
assign 1 1004 3341
new 0 1004 3341
assign 1 1004 3342
heldGet 0 1004 3342
assign 1 1004 3343
namepathGet 0 1004 3343
assign 1 1004 3344
toString 0 1004 3344
buildClassInfo 2 1004 3345
assign 1 1005 3346
new 0 1005 3346
buildClassInfo 2 1005 3347
assign 1 1010 3364
new 0 1010 3364
assign 1 1010 3365
add 1 1010 3365
assign 1 1012 3366
new 0 1012 3366
lstringStart 2 1013 3367
assign 1 1015 3368
sizeGet 0 1015 3368
assign 1 1016 3369
new 0 1016 3369
assign 1 1017 3370
new 0 1017 3370
assign 1 1018 3371
new 0 1018 3371
assign 1 1018 3372
new 1 1018 3372
assign 1 1019 3375
lesser 1 1019 3375
assign 1 1020 3377
new 0 1020 3377
assign 1 1020 3378
greater 1 1020 3378
assign 1 1021 3380
new 0 1021 3380
assign 1 1021 3381
once 0 1021 3381
addValue 1 1021 3382
lstringByte 5 1023 3384
incrementValue 0 1024 3385
lstringEnd 1 1026 3391
addValue 1 1028 3392
buildClassInfoMethod 1 1030 3393
assign 1 1035 3414
overrideMtdDecGet 0 1035 3414
assign 1 1035 3415
addValue 1 1035 3415
assign 1 1035 3416
new 0 1035 3416
assign 1 1035 3417
addValue 1 1035 3417
assign 1 1035 3418
addValue 1 1035 3418
assign 1 1035 3419
new 0 1035 3419
assign 1 1035 3420
addValue 1 1035 3420
assign 1 1035 3421
addValue 1 1035 3421
assign 1 1035 3422
new 0 1035 3422
assign 1 1035 3423
addValue 1 1035 3423
addValue 1 1035 3424
assign 1 1036 3425
new 0 1036 3425
assign 1 1036 3426
addValue 1 1036 3426
assign 1 1036 3427
addValue 1 1036 3427
assign 1 1036 3428
new 0 1036 3428
assign 1 1036 3429
addValue 1 1036 3429
addValue 1 1036 3430
assign 1 1038 3431
new 0 1038 3431
assign 1 1038 3432
addValue 1 1038 3432
addValue 1 1038 3433
assign 1 1043 3452
new 0 1043 3452
assign 1 1045 3453
namepathGet 0 1045 3453
assign 1 1045 3454
equals 1 1045 3454
assign 1 1046 3456
emitNameGet 0 1046 3456
assign 1 1046 3457
new 0 1046 3457
assign 1 1046 3458
baseSpropDec 2 1046 3458
assign 1 1046 3459
addValue 1 1046 3459
assign 1 1046 3460
new 0 1046 3460
assign 1 1046 3461
addValue 1 1046 3461
addValue 1 1046 3462
assign 1 1048 3465
emitNameGet 0 1048 3465
assign 1 1048 3466
new 0 1048 3466
assign 1 1048 3467
overrideSpropDec 2 1048 3467
assign 1 1048 3468
addValue 1 1048 3468
assign 1 1048 3469
new 0 1048 3469
assign 1 1048 3470
addValue 1 1048 3470
addValue 1 1048 3471
return 1 1051 3473
assign 1 1055 3509
def 1 1055 3514
assign 1 1056 3515
libNameGet 0 1056 3515
assign 1 1056 3516
relEmitName 1 1056 3516
assign 1 1056 3517
extend 1 1056 3517
assign 1 1058 3520
new 0 1058 3520
assign 1 1058 3521
extend 1 1058 3521
assign 1 1060 3523
new 0 1060 3523
assign 1 1060 3524
addValue 1 1060 3524
assign 1 1060 3525
new 0 1060 3525
assign 1 1060 3526
addValue 1 1060 3526
assign 1 1060 3527
addValue 1 1060 3527
assign 1 1061 3528
klassDecGet 0 1061 3528
assign 1 1061 3529
addValue 1 1061 3529
assign 1 1061 3530
emitNameGet 0 1061 3530
assign 1 1061 3531
addValue 1 1061 3531
assign 1 1061 3532
addValue 1 1061 3532
assign 1 1061 3533
new 0 1061 3533
assign 1 1061 3534
addValue 1 1061 3534
addValue 1 1061 3535
assign 1 1062 3536
new 0 1062 3536
assign 1 1062 3537
addValue 1 1062 3537
assign 1 1062 3538
emitNameGet 0 1062 3538
assign 1 1062 3539
addValue 1 1062 3539
assign 1 1062 3540
new 0 1062 3540
addValue 1 1062 3541
assign 1 1063 3542
new 0 1063 3542
assign 1 1063 3543
addValue 1 1063 3543
addValue 1 1063 3544
assign 1 1064 3545
new 0 1064 3545
assign 1 1064 3546
emitting 1 1064 3546
assign 1 1065 3548
new 0 1065 3548
assign 1 1065 3549
addValue 1 1065 3549
assign 1 1065 3550
emitNameGet 0 1065 3550
assign 1 1065 3551
addValue 1 1065 3551
assign 1 1065 3552
new 0 1065 3552
addValue 1 1065 3553
assign 1 1066 3554
new 0 1066 3554
assign 1 1066 3555
addValue 1 1066 3555
addValue 1 1066 3556
return 1 1068 3558
assign 1 1073 3563
new 0 1073 3563
assign 1 1073 3564
addValue 1 1073 3564
return 1 1073 3565
assign 1 1077 3573
new 0 1077 3573
assign 1 1077 3574
add 1 1077 3574
assign 1 1077 3575
new 0 1077 3575
assign 1 1077 3576
add 1 1077 3576
assign 1 1077 3577
add 1 1077 3577
return 1 1077 3578
assign 1 1081 3582
new 0 1081 3582
return 1 1081 3583
assign 1 1086 3587
new 0 1086 3587
return 1 1086 3588
assign 1 1090 3600
new 0 1090 3600
assign 1 1091 3601
def 1 1091 3606
assign 1 1091 3607
nlcGet 0 1091 3607
assign 1 1091 3608
def 1 1091 3613
assign 1 0 3614
assign 1 0 3617
assign 1 0 3621
assign 1 1092 3624
new 0 1092 3624
assign 1 1092 3625
addValue 1 1092 3625
assign 1 1092 3626
nlcGet 0 1092 3626
assign 1 1092 3627
toString 0 1092 3627
addValue 1 1092 3628
return 1 1094 3630
assign 1 1098 3657
containerGet 0 1098 3657
assign 1 1098 3658
def 1 1098 3663
assign 1 1099 3664
containerGet 0 1099 3664
assign 1 1099 3665
typenameGet 0 1099 3665
assign 1 1100 3666
METHODGet 0 1100 3666
assign 1 1100 3667
notEquals 1 1100 3667
assign 1 1100 3669
CLASSGet 0 1100 3669
assign 1 1100 3670
notEquals 1 1100 3670
assign 1 0 3672
assign 1 0 3675
assign 1 0 3679
assign 1 1100 3682
EXPRGet 0 1100 3682
assign 1 1100 3683
notEquals 1 1100 3683
assign 1 0 3685
assign 1 0 3688
assign 1 0 3692
assign 1 1100 3695
PROPERTIESGet 0 1100 3695
assign 1 1100 3696
notEquals 1 1100 3696
assign 1 0 3698
assign 1 0 3701
assign 1 0 3705
assign 1 1100 3708
CATCHGet 0 1100 3708
assign 1 1100 3709
notEquals 1 1100 3709
assign 1 0 3711
assign 1 0 3714
assign 1 0 3718
assign 1 1102 3721
new 0 1102 3721
assign 1 1102 3722
addValue 1 1102 3722
assign 1 1102 3723
getTraceInfo 1 1102 3723
assign 1 1102 3724
addValue 1 1102 3724
assign 1 1102 3725
new 0 1102 3725
assign 1 1102 3726
addValue 1 1102 3726
addValue 1 1102 3727
assign 1 1111 3791
containerGet 0 1111 3791
assign 1 1111 3792
def 1 1111 3797
assign 1 1111 3798
containerGet 0 1111 3798
assign 1 1111 3799
containerGet 0 1111 3799
assign 1 1111 3800
def 1 1111 3805
assign 1 0 3806
assign 1 0 3809
assign 1 0 3813
assign 1 1112 3816
containerGet 0 1112 3816
assign 1 1112 3817
containerGet 0 1112 3817
assign 1 1113 3818
typenameGet 0 1113 3818
assign 1 1114 3819
METHODGet 0 1114 3819
assign 1 1114 3820
equals 1 1114 3820
assign 1 1115 3822
def 1 1115 3827
assign 1 1116 3828
undef 1 1116 3833
assign 1 0 3834
assign 1 1116 3837
heldGet 0 1116 3837
assign 1 1116 3838
orgNameGet 0 1116 3838
assign 1 1116 3839
new 0 1116 3839
assign 1 1116 3840
notEquals 1 1116 3840
assign 1 0 3842
assign 1 0 3845
assign 1 1119 3849
new 0 1119 3849
assign 1 1119 3850
addValue 1 1119 3850
addValue 1 1119 3851
assign 1 1122 3853
new 0 1122 3853
assign 1 1122 3854
greater 1 1122 3854
assign 1 1123 3856
libNameGet 0 1123 3856
assign 1 1123 3857
relEmitName 1 1123 3857
assign 1 1123 3858
addValue 1 1123 3858
assign 1 1123 3859
new 0 1123 3859
assign 1 1123 3860
addValue 1 1123 3860
assign 1 1123 3861
libNameGet 0 1123 3861
assign 1 1123 3862
relEmitName 1 1123 3862
assign 1 1123 3863
addValue 1 1123 3863
assign 1 1123 3864
new 0 1123 3864
assign 1 1123 3865
addValue 1 1123 3865
assign 1 1123 3866
toString 0 1123 3866
assign 1 1123 3867
addValue 1 1123 3867
assign 1 1123 3868
new 0 1123 3868
assign 1 1123 3869
addValue 1 1123 3869
addValue 1 1123 3870
assign 1 1126 3872
countLines 2 1126 3872
addValue 1 1127 3873
assign 1 1128 3874
assign 1 1129 3875
sizeGet 0 1129 3875
assign 1 1133 3876
iteratorGet 0 0 3876
assign 1 1133 3879
hasNextGet 0 1133 3879
assign 1 1133 3881
nextGet 0 1133 3881
assign 1 1134 3882
nlecGet 0 1134 3882
addValue 1 1134 3883
addValue 1 1136 3889
assign 1 1137 3890
new 0 1137 3890
lengthSet 1 1137 3891
addValue 1 1139 3892
clear 0 1140 3893
assign 1 1141 3894
new 0 1141 3894
assign 1 1142 3895
new 0 1142 3895
assign 1 1145 3896
new 0 1145 3896
assign 1 1146 3897
assign 1 1147 3898
new 0 1147 3898
assign 1 1150 3899
new 0 1150 3899
assign 1 1150 3900
addValue 1 1150 3900
addValue 1 1150 3901
assign 1 1151 3902
assign 1 1152 3903
assign 1 1154 3907
EXPRGet 0 1154 3907
assign 1 1154 3908
notEquals 1 1154 3908
assign 1 1154 3910
PROPERTIESGet 0 1154 3910
assign 1 1154 3911
notEquals 1 1154 3911
assign 1 0 3913
assign 1 0 3916
assign 1 0 3920
assign 1 1154 3923
CLASSGet 0 1154 3923
assign 1 1154 3924
notEquals 1 1154 3924
assign 1 0 3926
assign 1 0 3929
assign 1 0 3933
assign 1 1156 3936
new 0 1156 3936
assign 1 1156 3937
addValue 1 1156 3937
assign 1 1156 3938
getTraceInfo 1 1156 3938
assign 1 1156 3939
addValue 1 1156 3939
assign 1 1156 3940
new 0 1156 3940
assign 1 1156 3941
addValue 1 1156 3941
addValue 1 1156 3942
assign 1 1162 3951
new 0 1162 3951
assign 1 1162 3952
countLines 2 1162 3952
return 1 1162 3953
assign 1 1166 3965
new 0 1166 3965
assign 1 1167 3966
new 0 1167 3966
assign 1 1167 3967
new 0 1167 3967
assign 1 1167 3968
getInt 2 1167 3968
assign 1 1168 3969
new 0 1168 3969
assign 1 1169 3970
sizeGet 0 1169 3970
assign 1 1170 3971
assign 1 1170 3974
lesser 1 1170 3974
getInt 2 1171 3976
assign 1 1172 3977
equals 1 1172 3977
incrementValue 0 1173 3979
incrementValue 0 1170 3981
return 1 1176 3987
assign 1 1180 4047
containedGet 0 1180 4047
assign 1 1180 4048
firstGet 0 1180 4048
assign 1 1180 4049
containedGet 0 1180 4049
assign 1 1180 4050
firstGet 0 1180 4050
assign 1 1180 4051
formTarg 1 1180 4051
assign 1 1181 4052
containedGet 0 1181 4052
assign 1 1181 4053
firstGet 0 1181 4053
assign 1 1181 4054
containedGet 0 1181 4054
assign 1 1181 4055
firstGet 0 1181 4055
assign 1 1181 4056
heldGet 0 1181 4056
assign 1 1181 4057
isTypedGet 0 1181 4057
assign 1 1181 4058
not 0 1181 4058
assign 1 0 4060
assign 1 1181 4063
containedGet 0 1181 4063
assign 1 1181 4064
firstGet 0 1181 4064
assign 1 1181 4065
containedGet 0 1181 4065
assign 1 1181 4066
firstGet 0 1181 4066
assign 1 1181 4067
heldGet 0 1181 4067
assign 1 1181 4068
namepathGet 0 1181 4068
assign 1 1181 4069
notEquals 1 1181 4069
assign 1 0 4071
assign 1 0 4074
assign 1 1182 4078
new 0 1182 4078
assign 1 1184 4081
new 0 1184 4081
assign 1 1186 4083
heldGet 0 1186 4083
assign 1 1186 4084
def 1 1186 4089
assign 1 1186 4090
heldGet 0 1186 4090
assign 1 1186 4091
new 0 1186 4091
assign 1 1186 4092
equals 1 1186 4092
assign 1 0 4094
assign 1 0 4097
assign 1 0 4101
assign 1 1187 4104
new 0 1187 4104
assign 1 1189 4107
new 0 1189 4107
assign 1 1191 4109
new 0 1191 4109
assign 1 1193 4111
new 0 1193 4111
addValue 1 1193 4112
assign 1 1197 4115
addValue 1 1197 4115
assign 1 1197 4116
new 0 1197 4116
addValue 1 1197 4117
assign 1 1202 4120
addValue 1 1202 4120
assign 1 1202 4121
new 0 1202 4121
assign 1 1202 4122
addValue 1 1202 4122
assign 1 1202 4123
addValue 1 1202 4123
assign 1 1202 4124
addValue 1 1202 4124
assign 1 1202 4125
libNameGet 0 1202 4125
assign 1 1202 4126
relEmitName 1 1202 4126
assign 1 1202 4127
addValue 1 1202 4127
assign 1 1202 4128
new 0 1202 4128
addValue 1 1202 4129
assign 1 1203 4130
new 0 1203 4130
assign 1 1203 4131
emitting 1 1203 4131
assign 1 1203 4132
not 0 1203 4132
assign 1 1204 4134
new 0 1204 4134
assign 1 1204 4135
addValue 1 1204 4135
assign 1 1204 4136
formCast 1 1204 4136
addValue 1 1204 4137
addValue 1 1206 4139
assign 1 1207 4140
new 0 1207 4140
assign 1 1207 4141
emitting 1 1207 4141
assign 1 1207 4142
not 0 1207 4142
assign 1 1208 4144
new 0 1208 4144
addValue 1 1208 4145
assign 1 1210 4147
new 0 1210 4147
addValue 1 1210 4148
assign 1 1213 4151
new 0 1213 4151
addValue 1 1213 4152
assign 1 1215 4154
new 0 1215 4154
assign 1 1215 4155
addValue 1 1215 4155
assign 1 1215 4156
addValue 1 1215 4156
assign 1 1215 4157
new 0 1215 4157
addValue 1 1215 4158
assign 1 1220 4180
containedGet 0 1220 4180
assign 1 1220 4181
firstGet 0 1220 4181
assign 1 1220 4182
containedGet 0 1220 4182
assign 1 1220 4183
firstGet 0 1220 4183
assign 1 1220 4184
formTarg 1 1220 4184
assign 1 1221 4185
heldGet 0 1221 4185
assign 1 1221 4186
def 1 1221 4191
assign 1 1221 4192
heldGet 0 1221 4192
assign 1 1221 4193
new 0 1221 4193
assign 1 1221 4194
equals 1 1221 4194
assign 1 0 4196
assign 1 0 4199
assign 1 0 4203
assign 1 1222 4206
assign 1 1224 4209
assign 1 1226 4211
new 0 1226 4211
assign 1 1226 4212
addValue 1 1226 4212
assign 1 1226 4213
addValue 1 1226 4213
assign 1 1226 4214
addValue 1 1226 4214
assign 1 1226 4215
addValue 1 1226 4215
assign 1 1226 4216
new 0 1226 4216
addValue 1 1226 4217
assign 1 1233 4229
finalAssignTo 2 1233 4229
assign 1 1233 4230
add 1 1233 4230
assign 1 1233 4231
new 0 1233 4231
assign 1 1233 4232
add 1 1233 4232
assign 1 1233 4233
add 1 1233 4233
return 1 1233 4234
assign 1 1238 4264
typenameGet 0 1238 4264
assign 1 1238 4265
NULLGet 0 1238 4265
assign 1 1238 4266
equals 1 1238 4266
assign 1 1239 4268
new 0 1239 4268
assign 1 1239 4269
new 1 1239 4269
throw 1 1239 4270
assign 1 1241 4272
heldGet 0 1241 4272
assign 1 1241 4273
nameGet 0 1241 4273
assign 1 1241 4274
new 0 1241 4274
assign 1 1241 4275
equals 1 1241 4275
assign 1 1242 4277
new 0 1242 4277
assign 1 1242 4278
new 1 1242 4278
throw 1 1242 4279
assign 1 1244 4281
heldGet 0 1244 4281
assign 1 1244 4282
nameGet 0 1244 4282
assign 1 1244 4283
new 0 1244 4283
assign 1 1244 4284
equals 1 1244 4284
assign 1 1245 4286
new 0 1245 4286
assign 1 1245 4287
new 1 1245 4287
throw 1 1245 4288
assign 1 1247 4290
new 0 1247 4290
assign 1 1248 4291
def 1 1248 4296
assign 1 1249 4297
getClassConfig 1 1249 4297
assign 1 1249 4298
formCast 1 1249 4298
assign 1 1249 4299
new 0 1249 4299
assign 1 1249 4300
add 1 1249 4300
assign 1 1251 4302
heldGet 0 1251 4302
assign 1 1251 4303
nameForVar 1 1251 4303
assign 1 1251 4304
new 0 1251 4304
assign 1 1251 4305
add 1 1251 4305
assign 1 1251 4306
add 1 1251 4306
return 1 1251 4307
assign 1 1255 4311
new 0 1255 4311
return 1 1255 4312
assign 1 1259 4321
new 0 1259 4321
assign 1 1259 4322
libNameGet 0 1259 4322
assign 1 1259 4323
relEmitName 1 1259 4323
assign 1 1259 4324
add 1 1259 4324
assign 1 1259 4325
new 0 1259 4325
assign 1 1259 4326
add 1 1259 4326
return 1 1259 4327
assign 1 1263 4337
new 0 1263 4337
assign 1 1263 4338
addValue 1 1263 4338
assign 1 1263 4339
secondGet 0 1263 4339
assign 1 1263 4340
formTarg 1 1263 4340
assign 1 1263 4341
addValue 1 1263 4341
assign 1 1263 4342
new 0 1263 4342
assign 1 1263 4343
addValue 1 1263 4343
addValue 1 1263 4344
assign 1 1267 4350
new 0 1267 4350
assign 1 1267 4351
add 1 1267 4351
return 1 1267 4352
assign 1 1272 4929
heldGet 0 1272 4929
assign 1 1272 4930
nameGet 0 1272 4930
put 1 1272 4931
assign 1 1274 4932
addValue 1 1276 4933
assign 1 1280 4934
countLines 2 1280 4934
assign 1 1281 4935
add 1 1281 4935
assign 1 1282 4936
sizeGet 0 1282 4936
nlecSet 1 1284 4937
assign 1 1287 4938
heldGet 0 1287 4938
assign 1 1287 4939
orgNameGet 0 1287 4939
assign 1 1287 4940
new 0 1287 4940
assign 1 1287 4941
equals 1 1287 4941
assign 1 1287 4943
containedGet 0 1287 4943
assign 1 1287 4944
lengthGet 0 1287 4944
assign 1 1287 4945
new 0 1287 4945
assign 1 1287 4946
notEquals 1 1287 4946
assign 1 0 4948
assign 1 0 4951
assign 1 0 4955
assign 1 1288 4958
new 0 1288 4958
assign 1 1288 4959
containedGet 0 1288 4959
assign 1 1288 4960
lengthGet 0 1288 4960
assign 1 1288 4961
toString 0 1288 4961
assign 1 1288 4962
add 1 1288 4962
assign 1 1289 4963
new 0 1289 4963
assign 1 1289 4966
containedGet 0 1289 4966
assign 1 1289 4967
lengthGet 0 1289 4967
assign 1 1289 4968
lesser 1 1289 4968
assign 1 1290 4970
new 0 1290 4970
assign 1 1290 4971
add 1 1290 4971
assign 1 1290 4972
add 1 1290 4972
assign 1 1290 4973
new 0 1290 4973
assign 1 1290 4974
add 1 1290 4974
assign 1 1290 4975
containedGet 0 1290 4975
assign 1 1290 4976
get 1 1290 4976
assign 1 1290 4977
add 1 1290 4977
assign 1 1289 4978
increment 0 1289 4978
assign 1 1292 4984
new 2 1292 4984
throw 1 1292 4985
assign 1 1293 4988
heldGet 0 1293 4988
assign 1 1293 4989
orgNameGet 0 1293 4989
assign 1 1293 4990
new 0 1293 4990
assign 1 1293 4991
equals 1 1293 4991
assign 1 1293 4993
containedGet 0 1293 4993
assign 1 1293 4994
firstGet 0 1293 4994
assign 1 1293 4995
heldGet 0 1293 4995
assign 1 1293 4996
nameGet 0 1293 4996
assign 1 1293 4997
new 0 1293 4997
assign 1 1293 4998
equals 1 1293 4998
assign 1 0 5000
assign 1 0 5003
assign 1 0 5007
assign 1 1294 5010
new 0 1294 5010
assign 1 1294 5011
new 2 1294 5011
throw 1 1294 5012
assign 1 1295 5015
heldGet 0 1295 5015
assign 1 1295 5016
orgNameGet 0 1295 5016
assign 1 1295 5017
new 0 1295 5017
assign 1 1295 5018
equals 1 1295 5018
acceptThrow 1 1296 5020
return 1 1297 5021
assign 1 1298 5024
heldGet 0 1298 5024
assign 1 1298 5025
orgNameGet 0 1298 5025
assign 1 1298 5026
new 0 1298 5026
assign 1 1298 5027
equals 1 1298 5027
assign 1 1302 5029
heldGet 0 1302 5029
assign 1 1302 5030
checkTypesGet 0 1302 5030
assign 1 1303 5032
containedGet 0 1303 5032
assign 1 1303 5033
firstGet 0 1303 5033
assign 1 1303 5034
heldGet 0 1303 5034
assign 1 1303 5035
namepathGet 0 1303 5035
assign 1 1305 5037
secondGet 0 1305 5037
assign 1 1305 5038
typenameGet 0 1305 5038
assign 1 1305 5039
VARGet 0 1305 5039
assign 1 1305 5040
equals 1 1305 5040
assign 1 1307 5042
containedGet 0 1307 5042
assign 1 1307 5043
firstGet 0 1307 5043
assign 1 1307 5044
secondGet 0 1307 5044
assign 1 1307 5045
formTarg 1 1307 5045
assign 1 1307 5046
finalAssign 3 1307 5046
addValue 1 1307 5047
assign 1 1308 5050
secondGet 0 1308 5050
assign 1 1308 5051
typenameGet 0 1308 5051
assign 1 1308 5052
NULLGet 0 1308 5052
assign 1 1308 5053
equals 1 1308 5053
assign 1 1309 5055
containedGet 0 1309 5055
assign 1 1309 5056
firstGet 0 1309 5056
assign 1 1309 5057
new 0 1309 5057
assign 1 1309 5058
finalAssign 3 1309 5058
addValue 1 1309 5059
assign 1 1310 5062
secondGet 0 1310 5062
assign 1 1310 5063
typenameGet 0 1310 5063
assign 1 1310 5064
TRUEGet 0 1310 5064
assign 1 1310 5065
equals 1 1310 5065
assign 1 1311 5067
containedGet 0 1311 5067
assign 1 1311 5068
firstGet 0 1311 5068
assign 1 1311 5069
finalAssign 3 1311 5069
addValue 1 1311 5070
assign 1 1312 5073
secondGet 0 1312 5073
assign 1 1312 5074
typenameGet 0 1312 5074
assign 1 1312 5075
FALSEGet 0 1312 5075
assign 1 1312 5076
equals 1 1312 5076
assign 1 1313 5078
containedGet 0 1313 5078
assign 1 1313 5079
firstGet 0 1313 5079
assign 1 1313 5080
finalAssign 3 1313 5080
addValue 1 1313 5081
assign 1 1314 5084
secondGet 0 1314 5084
assign 1 1314 5085
heldGet 0 1314 5085
assign 1 1314 5086
nameGet 0 1314 5086
assign 1 1314 5087
new 0 1314 5087
assign 1 1314 5088
equals 1 1314 5088
assign 1 0 5090
assign 1 1314 5093
secondGet 0 1314 5093
assign 1 1314 5094
heldGet 0 1314 5094
assign 1 1314 5095
nameGet 0 1314 5095
assign 1 1314 5096
new 0 1314 5096
assign 1 1314 5097
equals 1 1314 5097
assign 1 0 5099
assign 1 0 5102
assign 1 0 5106
assign 1 1315 5109
secondGet 0 1315 5109
assign 1 1315 5110
heldGet 0 1315 5110
assign 1 1315 5111
nameGet 0 1315 5111
assign 1 1315 5112
new 0 1315 5112
assign 1 1315 5113
equals 1 1315 5113
assign 1 0 5115
assign 1 0 5118
assign 1 0 5122
assign 1 1315 5125
secondGet 0 1315 5125
assign 1 1315 5126
heldGet 0 1315 5126
assign 1 1315 5127
nameGet 0 1315 5127
assign 1 1315 5128
new 0 1315 5128
assign 1 1315 5129
equals 1 1315 5129
assign 1 0 5131
assign 1 0 5134
assign 1 1322 5138
heldGet 0 1322 5138
assign 1 1322 5139
checkTypesGet 0 1322 5139
assign 1 1323 5141
containedGet 0 1323 5141
assign 1 1323 5142
firstGet 0 1323 5142
assign 1 1323 5143
heldGet 0 1323 5143
assign 1 1323 5144
namepathGet 0 1323 5144
assign 1 1323 5145
toString 0 1323 5145
assign 1 1323 5146
new 0 1323 5146
assign 1 1323 5147
notEquals 1 1323 5147
assign 1 1324 5149
new 0 1324 5149
assign 1 1324 5150
new 2 1324 5150
throw 1 1324 5151
assign 1 1327 5154
secondGet 0 1327 5154
assign 1 1327 5155
heldGet 0 1327 5155
assign 1 1327 5156
nameGet 0 1327 5156
assign 1 1327 5157
new 0 1327 5157
assign 1 1327 5158
begins 1 1327 5158
assign 1 1328 5160
assign 1 1329 5161
assign 1 1331 5164
assign 1 1332 5165
assign 1 1334 5167
new 0 1334 5167
assign 1 1334 5168
addValue 1 1334 5168
assign 1 1334 5169
secondGet 0 1334 5169
assign 1 1334 5170
secondGet 0 1334 5170
assign 1 1334 5171
formTarg 1 1334 5171
assign 1 1334 5172
addValue 1 1334 5172
assign 1 1334 5173
new 0 1334 5173
assign 1 1334 5174
addValue 1 1334 5174
addValue 1 1334 5175
assign 1 1335 5176
containedGet 0 1335 5176
assign 1 1335 5177
firstGet 0 1335 5177
assign 1 1335 5178
finalAssign 3 1335 5178
addValue 1 1335 5179
assign 1 1336 5180
new 0 1336 5180
assign 1 1336 5181
addValue 1 1336 5181
addValue 1 1336 5182
assign 1 1337 5183
containedGet 0 1337 5183
assign 1 1337 5184
firstGet 0 1337 5184
assign 1 1337 5185
finalAssign 3 1337 5185
addValue 1 1337 5186
assign 1 1338 5187
new 0 1338 5187
assign 1 1338 5188
addValue 1 1338 5188
addValue 1 1338 5189
return 1 1340 5195
assign 1 1341 5198
heldGet 0 1341 5198
assign 1 1341 5199
orgNameGet 0 1341 5199
assign 1 1341 5200
new 0 1341 5200
assign 1 1341 5201
equals 1 1341 5201
assign 1 1343 5203
new 0 1343 5203
assign 1 1344 5204
heldGet 0 1344 5204
assign 1 1344 5205
checkTypesGet 0 1344 5205
assign 1 1345 5207
formCast 1 1345 5207
assign 1 1345 5208
new 0 1345 5208
assign 1 1345 5209
add 1 1345 5209
assign 1 1347 5211
new 0 1347 5211
assign 1 1347 5212
addValue 1 1347 5212
assign 1 1347 5213
addValue 1 1347 5213
assign 1 1347 5214
secondGet 0 1347 5214
assign 1 1347 5215
formTarg 1 1347 5215
assign 1 1347 5216
addValue 1 1347 5216
assign 1 1347 5217
new 0 1347 5217
assign 1 1347 5218
addValue 1 1347 5218
addValue 1 1347 5219
return 1 1348 5220
assign 1 1349 5223
heldGet 0 1349 5223
assign 1 1349 5224
nameGet 0 1349 5224
assign 1 1349 5225
new 0 1349 5225
assign 1 1349 5226
equals 1 1349 5226
assign 1 0 5228
assign 1 1349 5231
heldGet 0 1349 5231
assign 1 1349 5232
nameGet 0 1349 5232
assign 1 1349 5233
new 0 1349 5233
assign 1 1349 5234
equals 1 1349 5234
assign 1 0 5236
assign 1 0 5239
assign 1 0 5243
assign 1 1349 5246
heldGet 0 1349 5246
assign 1 1349 5247
nameGet 0 1349 5247
assign 1 1349 5248
new 0 1349 5248
assign 1 1349 5249
equals 1 1349 5249
assign 1 0 5251
assign 1 0 5254
assign 1 0 5258
assign 1 1349 5261
heldGet 0 1349 5261
assign 1 1349 5262
nameGet 0 1349 5262
assign 1 1349 5263
new 0 1349 5263
assign 1 1349 5264
equals 1 1349 5264
assign 1 0 5266
assign 1 0 5269
return 1 1351 5273
assign 1 1354 5280
heldGet 0 1354 5280
assign 1 1354 5281
nameGet 0 1354 5281
assign 1 1354 5282
heldGet 0 1354 5282
assign 1 1354 5283
orgNameGet 0 1354 5283
assign 1 1354 5284
new 0 1354 5284
assign 1 1354 5285
add 1 1354 5285
assign 1 1354 5286
heldGet 0 1354 5286
assign 1 1354 5287
numargsGet 0 1354 5287
assign 1 1354 5288
add 1 1354 5288
assign 1 1354 5289
notEquals 1 1354 5289
assign 1 1355 5291
new 0 1355 5291
assign 1 1355 5292
heldGet 0 1355 5292
assign 1 1355 5293
nameGet 0 1355 5293
assign 1 1355 5294
add 1 1355 5294
assign 1 1355 5295
new 0 1355 5295
assign 1 1355 5296
add 1 1355 5296
assign 1 1355 5297
heldGet 0 1355 5297
assign 1 1355 5298
orgNameGet 0 1355 5298
assign 1 1355 5299
add 1 1355 5299
assign 1 1355 5300
new 0 1355 5300
assign 1 1355 5301
add 1 1355 5301
assign 1 1355 5302
heldGet 0 1355 5302
assign 1 1355 5303
numargsGet 0 1355 5303
assign 1 1355 5304
add 1 1355 5304
assign 1 1355 5305
new 1 1355 5305
throw 1 1355 5306
assign 1 1358 5308
new 0 1358 5308
assign 1 1359 5309
new 0 1359 5309
assign 1 1360 5310
new 0 1360 5310
assign 1 1361 5311
new 0 1361 5311
assign 1 1363 5312
heldGet 0 1363 5312
assign 1 1363 5313
isConstructGet 0 1363 5313
assign 1 1364 5315
new 0 1364 5315
assign 1 1365 5316
heldGet 0 1365 5316
assign 1 1365 5317
newNpGet 0 1365 5317
assign 1 1365 5318
getClassConfig 1 1365 5318
assign 1 1366 5321
containedGet 0 1366 5321
assign 1 1366 5322
firstGet 0 1366 5322
assign 1 1366 5323
heldGet 0 1366 5323
assign 1 1366 5324
nameGet 0 1366 5324
assign 1 1366 5325
new 0 1366 5325
assign 1 1366 5326
equals 1 1366 5326
assign 1 1367 5328
new 0 1367 5328
assign 1 1368 5331
containedGet 0 1368 5331
assign 1 1368 5332
firstGet 0 1368 5332
assign 1 1368 5333
heldGet 0 1368 5333
assign 1 1368 5334
nameGet 0 1368 5334
assign 1 1368 5335
new 0 1368 5335
assign 1 1368 5336
equals 1 1368 5336
assign 1 1369 5338
new 0 1369 5338
assign 1 1370 5339
new 0 1370 5339
addValue 1 1371 5340
assign 1 1372 5341
heldGet 0 1372 5341
assign 1 1372 5342
new 0 1372 5342
superCallSet 1 1372 5343
assign 1 1377 5347
new 0 1377 5347
assign 1 1378 5348
new 0 1378 5348
assign 1 1380 5349
new 0 1380 5349
assign 1 1381 5350
containedGet 0 1381 5350
assign 1 1381 5351
iteratorGet 0 1381 5351
assign 1 1381 5354
hasNextGet 0 1381 5354
assign 1 1382 5356
heldGet 0 1382 5356
assign 1 1382 5357
argCastsGet 0 1382 5357
assign 1 1383 5358
nextGet 0 1383 5358
assign 1 1384 5359
new 0 1384 5359
assign 1 1384 5360
equals 1 1384 5360
assign 1 1386 5362
formTarg 1 1386 5362
assign 1 1387 5363
assign 1 1388 5364
heldGet 0 1388 5364
assign 1 1388 5365
isTypedGet 0 1388 5365
assign 1 1389 5367
new 0 1389 5367
assign 1 0 5372
assign 1 1392 5375
lesser 1 1392 5375
assign 1 0 5377
assign 1 0 5380
assign 1 0 5384
assign 1 1392 5387
useDynMethodsGet 0 1392 5387
assign 1 1392 5388
not 0 1392 5388
assign 1 0 5390
assign 1 0 5393
assign 1 1393 5397
new 0 1393 5397
assign 1 1393 5398
greater 1 1393 5398
assign 1 1394 5400
new 0 1394 5400
addValue 1 1394 5401
assign 1 1396 5403
lengthGet 0 1396 5403
assign 1 1396 5404
greater 1 1396 5404
assign 1 1396 5406
get 1 1396 5406
assign 1 1396 5407
def 1 1396 5412
assign 1 0 5413
assign 1 0 5416
assign 1 0 5420
assign 1 1397 5423
get 1 1397 5423
assign 1 1397 5424
getClassConfig 1 1397 5424
assign 1 1397 5425
formCast 1 1397 5425
assign 1 1397 5426
addValue 1 1397 5426
assign 1 1397 5427
new 0 1397 5427
addValue 1 1397 5428
assign 1 1399 5430
formTarg 1 1399 5430
addValue 1 1399 5431
assign 1 1402 5434
subtract 1 1402 5434
assign 1 1403 5435
new 0 1403 5435
assign 1 1403 5436
addValue 1 1403 5436
assign 1 1403 5437
toString 0 1403 5437
assign 1 1403 5438
addValue 1 1403 5438
assign 1 1403 5439
new 0 1403 5439
assign 1 1403 5440
addValue 1 1403 5440
assign 1 1403 5441
formTarg 1 1403 5441
assign 1 1403 5442
addValue 1 1403 5442
assign 1 1403 5443
new 0 1403 5443
assign 1 1403 5444
addValue 1 1403 5444
addValue 1 1403 5445
assign 1 1406 5448
increment 0 1406 5448
assign 1 1410 5454
decrement 0 1410 5454
assign 1 1412 5456
not 0 1412 5456
assign 1 0 5458
assign 1 0 5461
assign 1 0 5465
assign 1 1413 5468
new 0 1413 5468
assign 1 1413 5469
new 2 1413 5469
throw 1 1413 5470
assign 1 1416 5472
new 0 1416 5472
assign 1 1417 5473
new 0 1417 5473
assign 1 1420 5474
containerGet 0 1420 5474
assign 1 1420 5475
typenameGet 0 1420 5475
assign 1 1420 5476
CALLGet 0 1420 5476
assign 1 1420 5477
equals 1 1420 5477
assign 1 1420 5479
containerGet 0 1420 5479
assign 1 1420 5480
heldGet 0 1420 5480
assign 1 1420 5481
orgNameGet 0 1420 5481
assign 1 1420 5482
new 0 1420 5482
assign 1 1420 5483
equals 1 1420 5483
assign 1 0 5485
assign 1 0 5488
assign 1 0 5492
assign 1 1421 5495
containerGet 0 1421 5495
assign 1 1421 5496
isOnceAssign 1 1421 5496
assign 1 1421 5499
npGet 0 1421 5499
assign 1 1421 5500
equals 1 1421 5500
assign 1 0 5502
assign 1 0 5505
assign 1 0 5509
assign 1 1421 5511
not 0 1421 5511
assign 1 0 5513
assign 1 0 5516
assign 1 0 5520
assign 1 1422 5523
new 0 1422 5523
assign 1 1423 5524
toString 0 1423 5524
assign 1 1423 5525
onceVarDec 1 1423 5525
assign 1 1424 5526
increment 0 1424 5526
assign 1 1426 5527
containerGet 0 1426 5527
assign 1 1426 5528
containedGet 0 1426 5528
assign 1 1426 5529
firstGet 0 1426 5529
assign 1 1426 5530
heldGet 0 1426 5530
assign 1 1426 5531
isTypedGet 0 1426 5531
assign 1 1426 5532
not 0 1426 5532
assign 1 1427 5534
libNameGet 0 1427 5534
assign 1 1427 5535
relEmitName 1 1427 5535
assign 1 1427 5536
onceDec 2 1427 5536
assign 1 1429 5539
containerGet 0 1429 5539
assign 1 1429 5540
containedGet 0 1429 5540
assign 1 1429 5541
firstGet 0 1429 5541
assign 1 1429 5542
heldGet 0 1429 5542
assign 1 1429 5543
namepathGet 0 1429 5543
assign 1 1429 5544
getClassConfig 1 1429 5544
assign 1 1429 5545
libNameGet 0 1429 5545
assign 1 1429 5546
relEmitName 1 1429 5546
assign 1 1429 5547
onceDec 2 1429 5547
assign 1 1434 5550
containerGet 0 1434 5550
assign 1 1434 5551
heldGet 0 1434 5551
assign 1 1434 5552
checkTypesGet 0 1434 5552
assign 1 1436 5554
containerGet 0 1436 5554
assign 1 1436 5555
containedGet 0 1436 5555
assign 1 1436 5556
firstGet 0 1436 5556
assign 1 1436 5557
heldGet 0 1436 5557
assign 1 1436 5558
namepathGet 0 1436 5558
assign 1 1438 5560
containerGet 0 1438 5560
assign 1 1438 5561
containedGet 0 1438 5561
assign 1 1438 5562
firstGet 0 1438 5562
assign 1 1438 5563
finalAssignTo 2 1438 5563
assign 1 1440 5566
new 0 1440 5566
assign 1 1446 5569
containerGet 0 1446 5569
assign 1 1446 5570
containedGet 0 1446 5570
assign 1 1446 5571
firstGet 0 1446 5571
assign 1 1446 5572
heldGet 0 1446 5572
assign 1 1446 5573
nameForVar 1 1446 5573
assign 1 1446 5574
new 0 1446 5574
assign 1 1446 5575
add 1 1446 5575
assign 1 1446 5576
add 1 1446 5576
assign 1 1446 5577
new 0 1446 5577
assign 1 1446 5578
add 1 1446 5578
assign 1 1446 5579
add 1 1446 5579
assign 1 1447 5580
def 1 1447 5585
assign 1 1448 5586
getClassConfig 1 1448 5586
assign 1 1448 5587
formCast 1 1448 5587
assign 1 1448 5588
new 0 1448 5588
assign 1 1448 5589
add 1 1448 5589
assign 1 1450 5592
new 0 1450 5592
assign 1 1452 5594
new 0 1452 5594
assign 1 1452 5595
add 1 1452 5595
assign 1 1452 5596
add 1 1452 5596
assign 1 0 5599
assign 1 1456 5602
useDynMethodsGet 0 1456 5602
assign 1 1456 5603
not 0 1456 5603
assign 1 0 5605
assign 1 0 5608
assign 1 0 5613
assign 1 0 5616
assign 1 0 5620
assign 1 1456 5623
heldGet 0 1456 5623
assign 1 1456 5624
isLiteralGet 0 1456 5624
assign 1 0 5626
assign 1 0 5629
assign 1 0 5633
assign 1 0 5637
assign 1 0 5640
assign 1 0 5644
assign 1 1457 5647
new 0 1457 5647
assign 1 1461 5651
new 0 1461 5651
assign 1 1461 5652
emitting 1 1461 5652
assign 1 1462 5654
new 0 1462 5654
assign 1 1462 5655
addValue 1 1462 5655
assign 1 1462 5656
emitNameGet 0 1462 5656
assign 1 1462 5657
addValue 1 1462 5657
assign 1 1462 5658
new 0 1462 5658
assign 1 1462 5659
addValue 1 1462 5659
addValue 1 1462 5660
assign 1 1463 5663
new 0 1463 5663
assign 1 1463 5664
emitting 1 1463 5664
assign 1 1464 5666
new 0 1464 5666
assign 1 1464 5667
addValue 1 1464 5667
assign 1 1464 5668
emitNameGet 0 1464 5668
assign 1 1464 5669
addValue 1 1464 5669
assign 1 1464 5670
new 0 1464 5670
assign 1 1464 5671
addValue 1 1464 5671
addValue 1 1464 5672
assign 1 1466 5675
new 0 1466 5675
assign 1 1466 5676
add 1 1466 5676
assign 1 1466 5677
new 0 1466 5677
assign 1 1466 5678
add 1 1466 5678
assign 1 1466 5679
addValue 1 1466 5679
addValue 1 1466 5680
assign 1 0 5684
assign 1 1471 5687
useDynMethodsGet 0 1471 5687
assign 1 1471 5688
not 0 1471 5688
assign 1 0 5690
assign 1 0 5693
assign 1 1473 5698
heldGet 0 1473 5698
assign 1 1473 5699
isLiteralGet 0 1473 5699
assign 1 1474 5701
npGet 0 1474 5701
assign 1 1474 5702
equals 1 1474 5702
assign 1 1475 5704
lintConstruct 2 1475 5704
assign 1 1476 5707
npGet 0 1476 5707
assign 1 1476 5708
equals 1 1476 5708
assign 1 1477 5710
lfloatConstruct 2 1477 5710
assign 1 1478 5713
npGet 0 1478 5713
assign 1 1478 5714
equals 1 1478 5714
assign 1 1480 5716
new 0 1480 5716
assign 1 1480 5717
heldGet 0 1480 5717
assign 1 1480 5718
belsCountGet 0 1480 5718
assign 1 1480 5719
toString 0 1480 5719
assign 1 1480 5720
add 1 1480 5720
assign 1 1481 5721
heldGet 0 1481 5721
assign 1 1481 5722
belsCountGet 0 1481 5722
incrementValue 0 1481 5723
assign 1 1482 5724
new 0 1482 5724
lstringStart 2 1483 5725
assign 1 1485 5726
heldGet 0 1485 5726
assign 1 1485 5727
literalValueGet 0 1485 5727
assign 1 1487 5728
wideStringGet 0 1487 5728
assign 1 1488 5730
assign 1 1490 5733
new 0 1490 5733
assign 1 1490 5734
new 0 1490 5734
assign 1 1490 5735
new 0 1490 5735
assign 1 1490 5736
quoteGet 0 1490 5736
assign 1 1490 5737
add 1 1490 5737
assign 1 1490 5738
add 1 1490 5738
assign 1 1490 5739
new 0 1490 5739
assign 1 1490 5740
quoteGet 0 1490 5740
assign 1 1490 5741
add 1 1490 5741
assign 1 1490 5742
new 0 1490 5742
assign 1 1490 5743
add 1 1490 5743
assign 1 1490 5744
unmarshall 1 1490 5744
assign 1 1490 5745
firstGet 0 1490 5745
assign 1 1493 5747
sizeGet 0 1493 5747
assign 1 1494 5748
new 0 1494 5748
assign 1 1495 5749
new 0 1495 5749
assign 1 1496 5750
new 0 1496 5750
assign 1 1496 5751
new 1 1496 5751
assign 1 1497 5754
lesser 1 1497 5754
assign 1 1498 5756
new 0 1498 5756
assign 1 1498 5757
greater 1 1498 5757
assign 1 1499 5759
new 0 1499 5759
assign 1 1499 5760
once 0 1499 5760
addValue 1 1499 5761
lstringByte 5 1501 5763
incrementValue 0 1502 5764
lstringEnd 1 1504 5770
addValue 1 1506 5771
assign 1 1507 5772
lstringConstruct 5 1507 5772
assign 1 1508 5775
npGet 0 1508 5775
assign 1 1508 5776
equals 1 1508 5776
assign 1 1509 5778
heldGet 0 1509 5778
assign 1 1509 5779
literalValueGet 0 1509 5779
assign 1 1509 5780
new 0 1509 5780
assign 1 1509 5781
equals 1 1509 5781
assign 1 1510 5783
assign 1 1512 5786
assign 1 1516 5790
new 0 1516 5790
assign 1 1516 5791
npGet 0 1516 5791
assign 1 1516 5792
toString 0 1516 5792
assign 1 1516 5793
add 1 1516 5793
assign 1 1516 5794
new 1 1516 5794
throw 1 1516 5795
assign 1 1519 5802
new 0 1519 5802
assign 1 1519 5803
libNameGet 0 1519 5803
assign 1 1519 5804
relEmitName 1 1519 5804
assign 1 1519 5805
add 1 1519 5805
assign 1 1519 5806
new 0 1519 5806
assign 1 1519 5807
add 1 1519 5807
assign 1 1521 5809
new 0 1521 5809
assign 1 1521 5810
add 1 1521 5810
assign 1 1521 5811
new 0 1521 5811
assign 1 1521 5812
add 1 1521 5812
assign 1 1523 5813
getInitialInst 1 1523 5813
assign 1 1525 5814
heldGet 0 1525 5814
assign 1 1525 5815
isLiteralGet 0 1525 5815
assign 1 1526 5817
npGet 0 1526 5817
assign 1 1526 5818
equals 1 1526 5818
assign 1 1528 5821
new 0 1528 5821
assign 1 1529 5822
containerGet 0 1529 5822
assign 1 1529 5823
containedGet 0 1529 5823
assign 1 1529 5824
firstGet 0 1529 5824
assign 1 1529 5825
heldGet 0 1529 5825
assign 1 1529 5826
allCallsGet 0 1529 5826
assign 1 1529 5827
iteratorGet 0 0 5827
assign 1 1529 5830
hasNextGet 0 1529 5830
assign 1 1529 5832
nextGet 0 1529 5832
assign 1 1530 5833
keyGet 0 1530 5833
assign 1 1530 5834
heldGet 0 1530 5834
assign 1 1530 5835
nameGet 0 1530 5835
assign 1 1530 5836
addValue 1 1530 5836
assign 1 1530 5837
new 0 1530 5837
addValue 1 1530 5838
assign 1 1532 5844
new 0 1532 5844
assign 1 1532 5845
add 1 1532 5845
assign 1 1532 5846
new 1 1532 5846
throw 1 1532 5847
assign 1 1535 5849
heldGet 0 1535 5849
assign 1 1535 5850
literalValueGet 0 1535 5850
assign 1 1535 5851
new 0 1535 5851
assign 1 1535 5852
equals 1 1535 5852
assign 1 1536 5854
assign 1 1538 5857
assign 1 1542 5861
addValue 1 1542 5861
assign 1 1542 5862
addValue 1 1542 5862
assign 1 1542 5863
addValue 1 1542 5863
assign 1 1542 5864
new 0 1542 5864
assign 1 1542 5865
addValue 1 1542 5865
addValue 1 1542 5866
assign 1 1544 5869
addValue 1 1544 5869
assign 1 1544 5870
addValue 1 1544 5870
assign 1 1544 5871
new 0 1544 5871
assign 1 1544 5872
addValue 1 1544 5872
addValue 1 1544 5873
assign 1 1547 5877
npGet 0 1547 5877
assign 1 1547 5878
getSynNp 1 1547 5878
assign 1 1548 5879
hasDefaultGet 0 1548 5879
assign 1 1549 5881
addValue 1 1549 5881
assign 1 1549 5882
addValue 1 1549 5882
assign 1 1549 5883
new 0 1549 5883
assign 1 1549 5884
addValue 1 1549 5884
assign 1 1549 5885
emitNameForCall 1 1549 5885
assign 1 1549 5886
addValue 1 1549 5886
assign 1 1549 5887
new 0 1549 5887
assign 1 1549 5888
addValue 1 1549 5888
assign 1 1549 5889
addValue 1 1549 5889
assign 1 1549 5890
new 0 1549 5890
assign 1 1549 5891
addValue 1 1549 5891
addValue 1 1549 5892
assign 1 1551 5895
addValue 1 1551 5895
assign 1 1551 5896
addValue 1 1551 5896
assign 1 1551 5897
new 0 1551 5897
assign 1 1551 5898
addValue 1 1551 5898
assign 1 1551 5899
emitNameForCall 1 1551 5899
assign 1 1551 5900
addValue 1 1551 5900
assign 1 1551 5901
new 0 1551 5901
assign 1 1551 5902
addValue 1 1551 5902
assign 1 1551 5903
addValue 1 1551 5903
assign 1 1551 5904
new 0 1551 5904
assign 1 1551 5905
addValue 1 1551 5905
addValue 1 1551 5906
assign 1 1555 5911
not 0 1555 5911
assign 1 1556 5913
addValue 1 1556 5913
assign 1 1556 5914
addValue 1 1556 5914
assign 1 1556 5915
new 0 1556 5915
assign 1 1556 5916
addValue 1 1556 5916
assign 1 1556 5917
emitNameForCall 1 1556 5917
assign 1 1556 5918
addValue 1 1556 5918
assign 1 1556 5919
new 0 1556 5919
assign 1 1556 5920
addValue 1 1556 5920
assign 1 1556 5921
addValue 1 1556 5921
assign 1 1556 5922
new 0 1556 5922
assign 1 1556 5923
addValue 1 1556 5923
addValue 1 1556 5924
assign 1 1558 5927
addValue 1 1558 5927
assign 1 1558 5928
addValue 1 1558 5928
assign 1 1558 5929
new 0 1558 5929
assign 1 1558 5930
addValue 1 1558 5930
assign 1 1558 5931
emitNameForCall 1 1558 5931
assign 1 1558 5932
addValue 1 1558 5932
assign 1 1558 5933
new 0 1558 5933
assign 1 1558 5934
addValue 1 1558 5934
assign 1 1558 5935
addValue 1 1558 5935
assign 1 1558 5936
new 0 1558 5936
assign 1 1558 5937
addValue 1 1558 5937
addValue 1 1558 5938
assign 1 1562 5943
lesser 1 1562 5943
assign 1 1563 5945
toString 0 1563 5945
assign 1 1564 5946
new 0 1564 5946
assign 1 1566 5949
new 0 1566 5949
assign 1 1567 5950
subtract 1 1567 5950
assign 1 1567 5951
new 0 1567 5951
assign 1 1567 5952
add 1 1567 5952
assign 1 1568 5953
greater 1 1568 5953
assign 1 1569 5955
addValue 1 1571 5957
assign 1 1572 5958
new 0 1572 5958
assign 1 1574 5960
new 0 1574 5960
assign 1 1574 5961
greater 1 1574 5961
assign 1 1575 5963
new 0 1575 5963
assign 1 1577 5966
new 0 1577 5966
assign 1 1579 5968
addValue 1 1579 5968
assign 1 1579 5969
addValue 1 1579 5969
assign 1 1579 5970
new 0 1579 5970
assign 1 1579 5971
addValue 1 1579 5971
assign 1 1579 5972
addValue 1 1579 5972
assign 1 1579 5973
new 0 1579 5973
assign 1 1579 5974
addValue 1 1579 5974
assign 1 1579 5975
heldGet 0 1579 5975
assign 1 1579 5976
nameGet 0 1579 5976
assign 1 1579 5977
hashGet 0 1579 5977
assign 1 1579 5978
toString 0 1579 5978
assign 1 1579 5979
addValue 1 1579 5979
assign 1 1579 5980
new 0 1579 5980
assign 1 1579 5981
addValue 1 1579 5981
assign 1 1579 5982
addValue 1 1579 5982
assign 1 1579 5983
new 0 1579 5983
assign 1 1579 5984
addValue 1 1579 5984
assign 1 1579 5985
heldGet 0 1579 5985
assign 1 1579 5986
nameGet 0 1579 5986
assign 1 1579 5987
addValue 1 1579 5987
assign 1 1579 5988
addValue 1 1579 5988
assign 1 1579 5989
addValue 1 1579 5989
assign 1 1579 5990
addValue 1 1579 5990
assign 1 1579 5991
new 0 1579 5991
assign 1 1579 5992
addValue 1 1579 5992
addValue 1 1579 5993
assign 1 1583 5996
not 0 1583 5996
assign 1 1585 5998
new 0 1585 5998
assign 1 1585 5999
addValue 1 1585 5999
addValue 1 1585 6000
assign 1 1586 6001
new 0 1586 6001
assign 1 1586 6002
emitting 1 1586 6002
assign 1 0 6004
assign 1 1586 6007
new 0 1586 6007
assign 1 1586 6008
emitting 1 1586 6008
assign 1 0 6010
assign 1 0 6013
assign 1 1588 6017
new 0 1588 6017
assign 1 1588 6018
addValue 1 1588 6018
addValue 1 1588 6019
addValue 1 1591 6022
assign 1 1592 6023
not 0 1592 6023
assign 1 1593 6025
isEmptyGet 0 1593 6025
assign 1 1593 6026
not 0 1593 6026
assign 1 1594 6028
addValue 1 1594 6028
assign 1 1594 6029
addValue 1 1594 6029
assign 1 1594 6030
new 0 1594 6030
assign 1 1594 6031
addValue 1 1594 6031
addValue 1 1594 6032
assign 1 1602 6051
new 0 1602 6051
assign 1 1603 6052
new 0 1603 6052
assign 1 1603 6053
emitting 1 1603 6053
assign 1 1604 6055
new 0 1604 6055
assign 1 1604 6056
addValue 1 1604 6056
assign 1 1604 6057
addValue 1 1604 6057
assign 1 1604 6058
new 0 1604 6058
addValue 1 1604 6059
assign 1 1606 6062
new 0 1606 6062
assign 1 1606 6063
addValue 1 1606 6063
assign 1 1606 6064
addValue 1 1606 6064
assign 1 1606 6065
new 0 1606 6065
addValue 1 1606 6066
assign 1 1608 6068
new 0 1608 6068
addValue 1 1608 6069
return 1 1609 6070
assign 1 1613 6077
libNameGet 0 1613 6077
assign 1 1613 6078
relEmitName 1 1613 6078
assign 1 1613 6079
new 0 1613 6079
assign 1 1613 6080
add 1 1613 6080
return 1 1613 6081
assign 1 1617 6095
new 0 1617 6095
assign 1 1617 6096
libNameGet 0 1617 6096
assign 1 1617 6097
relEmitName 1 1617 6097
assign 1 1617 6098
add 1 1617 6098
assign 1 1617 6099
new 0 1617 6099
assign 1 1617 6100
add 1 1617 6100
assign 1 1617 6101
heldGet 0 1617 6101
assign 1 1617 6102
literalValueGet 0 1617 6102
assign 1 1617 6103
add 1 1617 6103
assign 1 1617 6104
new 0 1617 6104
assign 1 1617 6105
add 1 1617 6105
return 1 1617 6106
assign 1 1621 6120
new 0 1621 6120
assign 1 1621 6121
libNameGet 0 1621 6121
assign 1 1621 6122
relEmitName 1 1621 6122
assign 1 1621 6123
add 1 1621 6123
assign 1 1621 6124
new 0 1621 6124
assign 1 1621 6125
add 1 1621 6125
assign 1 1621 6126
heldGet 0 1621 6126
assign 1 1621 6127
literalValueGet 0 1621 6127
assign 1 1621 6128
add 1 1621 6128
assign 1 1621 6129
new 0 1621 6129
assign 1 1621 6130
add 1 1621 6130
return 1 1621 6131
assign 1 1626 6159
new 0 1626 6159
assign 1 1626 6160
libNameGet 0 1626 6160
assign 1 1626 6161
relEmitName 1 1626 6161
assign 1 1626 6162
add 1 1626 6162
assign 1 1626 6163
new 0 1626 6163
assign 1 1626 6164
add 1 1626 6164
assign 1 1626 6165
add 1 1626 6165
assign 1 1626 6166
new 0 1626 6166
assign 1 1626 6167
add 1 1626 6167
assign 1 1626 6168
add 1 1626 6168
assign 1 1626 6169
new 0 1626 6169
assign 1 1626 6170
add 1 1626 6170
return 1 1626 6171
assign 1 1628 6173
new 0 1628 6173
assign 1 1628 6174
libNameGet 0 1628 6174
assign 1 1628 6175
relEmitName 1 1628 6175
assign 1 1628 6176
add 1 1628 6176
assign 1 1628 6177
new 0 1628 6177
assign 1 1628 6178
add 1 1628 6178
assign 1 1628 6179
add 1 1628 6179
assign 1 1628 6180
new 0 1628 6180
assign 1 1628 6181
add 1 1628 6181
assign 1 1628 6182
add 1 1628 6182
assign 1 1628 6183
new 0 1628 6183
assign 1 1628 6184
add 1 1628 6184
return 1 1628 6185
assign 1 1632 6192
new 0 1632 6192
assign 1 1632 6193
addValue 1 1632 6193
assign 1 1632 6194
addValue 1 1632 6194
assign 1 1632 6195
new 0 1632 6195
addValue 1 1632 6196
assign 1 1643 6205
new 0 1643 6205
assign 1 1643 6206
addValue 1 1643 6206
addValue 1 1643 6207
assign 1 1647 6220
heldGet 0 1647 6220
assign 1 1647 6221
isManyGet 0 1647 6221
assign 1 1648 6223
new 0 1648 6223
return 1 1648 6224
assign 1 1650 6226
heldGet 0 1650 6226
assign 1 1650 6227
isOnceGet 0 1650 6227
assign 1 0 6229
assign 1 1650 6232
isLiteralOnceGet 0 1650 6232
assign 1 0 6234
assign 1 0 6237
assign 1 1651 6241
new 0 1651 6241
return 1 1651 6242
assign 1 1653 6244
new 0 1653 6244
return 1 1653 6245
assign 1 1657 6254
heldGet 0 1657 6254
assign 1 1657 6255
langsGet 0 1657 6255
assign 1 1657 6256
emitLangGet 0 1657 6256
assign 1 1657 6257
has 1 1657 6257
assign 1 1658 6259
heldGet 0 1658 6259
assign 1 1658 6260
textGet 0 1658 6260
addValue 1 1658 6261
assign 1 1663 6273
heldGet 0 1663 6273
assign 1 1663 6274
langsGet 0 1663 6274
assign 1 1663 6275
emitLangGet 0 1663 6275
assign 1 1663 6276
has 1 1663 6276
assign 1 1663 6277
not 0 1663 6277
assign 1 1664 6279
nextPeerGet 0 1664 6279
return 1 1664 6280
assign 1 1666 6282
nextDescendGet 0 1666 6282
return 1 1666 6283
assign 1 1670 6333
typenameGet 0 1670 6333
assign 1 1670 6334
CLASSGet 0 1670 6334
assign 1 1670 6335
equals 1 1670 6335
acceptClass 1 1671 6337
assign 1 1672 6340
typenameGet 0 1672 6340
assign 1 1672 6341
METHODGet 0 1672 6341
assign 1 1672 6342
equals 1 1672 6342
acceptMethod 1 1673 6344
assign 1 1674 6347
typenameGet 0 1674 6347
assign 1 1674 6348
RBRACESGet 0 1674 6348
assign 1 1674 6349
equals 1 1674 6349
acceptRbraces 1 1675 6351
assign 1 1676 6354
typenameGet 0 1676 6354
assign 1 1676 6355
EMITGet 0 1676 6355
assign 1 1676 6356
equals 1 1676 6356
acceptEmit 1 1677 6358
assign 1 1678 6361
typenameGet 0 1678 6361
assign 1 1678 6362
IFEMITGet 0 1678 6362
assign 1 1678 6363
equals 1 1678 6363
addStackLines 1 1679 6365
assign 1 1680 6366
acceptIfEmit 1 1680 6366
return 1 1680 6367
assign 1 1681 6370
typenameGet 0 1681 6370
assign 1 1681 6371
CALLGet 0 1681 6371
assign 1 1681 6372
equals 1 1681 6372
acceptCall 1 1682 6374
assign 1 1683 6377
typenameGet 0 1683 6377
assign 1 1683 6378
BRACESGet 0 1683 6378
assign 1 1683 6379
equals 1 1683 6379
acceptBraces 1 1684 6381
assign 1 1685 6384
typenameGet 0 1685 6384
assign 1 1685 6385
BREAKGet 0 1685 6385
assign 1 1685 6386
equals 1 1685 6386
assign 1 1686 6388
new 0 1686 6388
assign 1 1686 6389
addValue 1 1686 6389
addValue 1 1686 6390
assign 1 1687 6393
typenameGet 0 1687 6393
assign 1 1687 6394
LOOPGet 0 1687 6394
assign 1 1687 6395
equals 1 1687 6395
assign 1 1688 6397
new 0 1688 6397
assign 1 1688 6398
addValue 1 1688 6398
addValue 1 1688 6399
assign 1 1689 6402
typenameGet 0 1689 6402
assign 1 1689 6403
ELSEGet 0 1689 6403
assign 1 1689 6404
equals 1 1689 6404
assign 1 1690 6406
new 0 1690 6406
addValue 1 1690 6407
assign 1 1691 6410
typenameGet 0 1691 6410
assign 1 1691 6411
TRYGet 0 1691 6411
assign 1 1691 6412
equals 1 1691 6412
assign 1 1692 6414
new 0 1692 6414
addValue 1 1692 6415
assign 1 1693 6418
typenameGet 0 1693 6418
assign 1 1693 6419
CATCHGet 0 1693 6419
assign 1 1693 6420
equals 1 1693 6420
acceptCatch 1 1694 6422
assign 1 1695 6425
typenameGet 0 1695 6425
assign 1 1695 6426
IFGet 0 1695 6426
assign 1 1695 6427
equals 1 1695 6427
acceptIf 1 1696 6429
addStackLines 1 1698 6443
assign 1 1699 6444
nextDescendGet 0 1699 6444
return 1 1699 6445
assign 1 1703 6449
def 1 1703 6454
assign 1 1712 6475
typenameGet 0 1712 6475
assign 1 1712 6476
NULLGet 0 1712 6476
assign 1 1712 6477
equals 1 1712 6477
assign 1 1713 6479
new 0 1713 6479
assign 1 1714 6482
heldGet 0 1714 6482
assign 1 1714 6483
nameGet 0 1714 6483
assign 1 1714 6484
new 0 1714 6484
assign 1 1714 6485
equals 1 1714 6485
assign 1 1715 6487
new 0 1715 6487
assign 1 1716 6490
heldGet 0 1716 6490
assign 1 1716 6491
nameGet 0 1716 6491
assign 1 1716 6492
new 0 1716 6492
assign 1 1716 6493
equals 1 1716 6493
assign 1 1717 6495
superNameGet 0 1717 6495
assign 1 1719 6498
heldGet 0 1719 6498
assign 1 1719 6499
nameForVar 1 1719 6499
return 1 1721 6503
assign 1 1726 6519
typenameGet 0 1726 6519
assign 1 1726 6520
NULLGet 0 1726 6520
assign 1 1726 6521
equals 1 1726 6521
assign 1 1727 6523
new 0 1727 6523
assign 1 1728 6526
heldGet 0 1728 6526
assign 1 1728 6527
nameGet 0 1728 6527
assign 1 1728 6528
new 0 1728 6528
assign 1 1728 6529
equals 1 1728 6529
assign 1 1729 6531
new 0 1729 6531
assign 1 1730 6534
heldGet 0 1730 6534
assign 1 1730 6535
nameGet 0 1730 6535
assign 1 1730 6536
new 0 1730 6536
assign 1 1730 6537
equals 1 1730 6537
assign 1 1731 6539
superNameGet 0 1731 6539
assign 1 1733 6542
heldGet 0 1733 6542
assign 1 1733 6543
nameForVar 1 1733 6543
return 1 1735 6547
end 1 1739 6550
assign 1 1743 6555
new 0 1743 6555
return 1 1743 6556
assign 1 1747 6560
new 0 1747 6560
return 1 1747 6561
assign 1 1751 6565
new 0 1751 6565
return 1 1751 6566
assign 1 1755 6570
new 0 1755 6570
return 1 1755 6571
assign 1 1759 6575
new 0 1759 6575
return 1 1759 6576
assign 1 1764 6580
new 0 1764 6580
return 1 1764 6581
assign 1 1768 6595
new 0 1768 6595
assign 1 1769 6596
new 0 1769 6596
assign 1 1770 6597
stepsGet 0 1770 6597
assign 1 1770 6598
iteratorGet 0 0 6598
assign 1 1770 6601
hasNextGet 0 1770 6601
assign 1 1770 6603
nextGet 0 1770 6603
assign 1 1771 6604
new 0 1771 6604
assign 1 1771 6605
notEquals 1 1771 6605
assign 1 1771 6607
new 0 1771 6607
assign 1 1771 6608
add 1 1771 6608
assign 1 1772 6611
new 0 1772 6611
assign 1 1773 6613
sizeGet 0 1773 6613
assign 1 1773 6614
add 1 1773 6614
assign 1 1774 6615
add 1 1774 6615
assign 1 1776 6621
add 1 1776 6621
return 1 1776 6622
assign 1 1780 6628
new 0 1780 6628
assign 1 1780 6629
mangleName 1 1780 6629
assign 1 1780 6630
add 1 1780 6630
return 1 1780 6631
assign 1 1784 6637
new 0 1784 6637
assign 1 1784 6638
add 1 1784 6638
assign 1 1784 6639
add 1 1784 6639
return 1 1784 6640
assign 1 1788 6646
new 0 1788 6646
assign 1 1788 6647
libEmitName 1 1788 6647
assign 1 1788 6648
add 1 1788 6648
return 1 1788 6649
return 1 0 6652
assign 1 0 6655
return 1 0 6659
assign 1 0 6662
return 1 0 6666
assign 1 0 6669
return 1 0 6673
assign 1 0 6676
return 1 0 6680
assign 1 0 6683
return 1 0 6687
assign 1 0 6690
return 1 0 6694
assign 1 0 6697
return 1 0 6701
assign 1 0 6704
return 1 0 6708
assign 1 0 6711
return 1 0 6715
assign 1 0 6718
return 1 0 6722
assign 1 0 6725
return 1 0 6729
assign 1 0 6732
return 1 0 6736
assign 1 0 6739
return 1 0 6743
assign 1 0 6746
return 1 0 6750
assign 1 0 6753
return 1 0 6757
assign 1 0 6760
return 1 0 6764
assign 1 0 6767
return 1 0 6771
assign 1 0 6774
return 1 0 6778
assign 1 0 6781
return 1 0 6785
assign 1 0 6788
return 1 0 6792
assign 1 0 6795
return 1 0 6799
assign 1 0 6802
return 1 0 6806
assign 1 0 6809
return 1 0 6813
assign 1 0 6816
return 1 0 6820
assign 1 0 6823
return 1 0 6827
assign 1 0 6830
return 1 0 6834
assign 1 0 6837
return 1 0 6841
assign 1 0 6844
return 1 0 6848
assign 1 0 6851
return 1 0 6855
assign 1 0 6858
return 1 0 6862
assign 1 0 6865
return 1 0 6869
assign 1 0 6872
return 1 0 6876
assign 1 0 6879
return 1 0 6883
assign 1 0 6886
return 1 0 6890
assign 1 0 6893
return 1 0 6897
assign 1 0 6900
return 1 0 6904
assign 1 0 6907
return 1 0 6911
assign 1 0 6914
return 1 0 6918
assign 1 0 6921
return 1 0 6925
assign 1 0 6928
return 1 0 6932
assign 1 0 6935
return 1 0 6939
assign 1 0 6942
return 1 0 6946
assign 1 0 6949
return 1 0 6953
assign 1 0 6956
return 1 0 6960
assign 1 0 6963
return 1 0 6967
assign 1 0 6970
return 1 0 6974
assign 1 0 6977
return 1 0 6981
assign 1 0 6984
return 1 0 6988
assign 1 0 6991
return 1 0 6995
assign 1 0 6998
return 1 0 7002
assign 1 0 7005
return 1 0 7009
assign 1 0 7012
return 1 0 7016
assign 1 0 7019
return 1 0 7023
assign 1 0 7026
return 1 0 7030
assign 1 0 7033
return 1 0 7037
assign 1 0 7040
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 493012039: return bem_buildGet_0();
case 1831751774: return bem_cnodeGet_0();
case 4647121: return bem_doEmit_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 902412214: return bem_classCallsGet_0();
case 1703922349: return bem_fullLibEmitNameGet_0();
case 991255330: return bem_mainStartGet_0();
case 287040793: return bem_hashGet_0();
case 402158238: return bem_inFilePathedGet_0();
case 1711936384: return bem_baseSmtdDecGet_0();
case 498080472: return bem_mnodeGet_0();
case 160277051: return bem_procStartGet_0();
case 622039562: return bem_intNpGet_0();
case 1638160588: return bem_lineCountGet_0();
case 681402717: return bem_boolTypeGet_0();
case 1354714650: return bem_copy_0();
case 845792839: return bem_iteratorGet_0();
case 103017121: return bem_runtimeInitGet_0();
case 1841706211: return bem_returnTypeGet_0();
case 772789066: return bem_libEmitPathGet_0();
case 916491491: return bem_emitLib_0();
case 1052944126: return bem_csynGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 955058175: return bem_lastMethodBodyLinesGet_0();
case 1177623581: return bem_callNamesGet_0();
case 36542021: return bem_mainEndGet_0();
case 314718434: return bem_print_0();
case 229958684: return bem_constGet_0();
case 101343106: return bem_nativeCSlotsGet_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case 1566392515: return bem_covariantReturnsGet_0();
case 1240611285: return bem_onceDecsGet_0();
case 786424307: return bem_tagGet_0();
case 1947619572: return bem_msynGet_0();
case 1755995201: return bem_transGet_0();
case 1910715228: return bem_libEmitNameGet_0();
case 1727672536: return bem_propDecGet_0();
case 1064889660: return bem_trueValueGet_0();
case 362974009: return bem_parentConfGet_0();
case 1312373307: return bem_buildCreate_0();
case 1241388883: return bem_lastMethodBodySizeGet_0();
case 727049506: return bem_exceptDecGet_0();
case 722876119: return bem_buildClassInfo_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case 86482693: return bem_overrideSmtdDecGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 1152064310: return bem_instOfGet_0();
case 1820417453: return bem_create_0();
case 2039613615: return bem_instanceNotEqualGet_0();
case 1317806639: return bem_baseMtdDecGet_0();
case 2019411446: return bem_classBeginGet_0();
case 1073009537: return bem_beginNs_0();
case 378762597: return bem_boolNpGet_0();
case 89706405: return bem_ccCacheGet_0();
case 220901978: return bem_emitLangGet_0();
case 397629001: return bem_maxSpillArgsLenGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2055025483: return bem_serializeContents_0();
case 644675716: return bem_ntypesGet_0();
case 1372235405: return bem_superCallsGet_0();
case 361542143: return bem_classEmitsGet_0();
case 388723214: return bem_preClassGet_0();
case 1081275759: return bem_classesInDepthOrderGet_0();
case 2001798761: return bem_nlGet_0();
case 1081412016: return bem_many_0();
case 1774940957: return bem_toString_0();
case 991179882: return bem_qGet_0();
case 946095539: return bem_mainInClassGet_0();
case 1449942744: return bem_instanceEqualGet_0();
case 1500143225: return bem_useDynMethodsGet_0();
case 1859739893: return bem_methodsGet_0();
case 1786051763: return bem_methodCatchGet_0();
case 729571811: return bem_serializeToString_0();
case 1181505319: return bem_buildInitial_0();
case 104713553: return bem_new_0();
case 1413054881: return bem_smnlcsGet_0();
case 57260628: return bem_getClassOutput_0();
case 628036310: return bem_lastMethodsSizeGet_0();
case 1967844855: return bem_initialDecGet_0();
case 483359873: return bem_superNameGet_0();
case 294732055: return bem_floatNpGet_0();
case 443668840: return bem_methodNotDefined_0();
case 604504089: return bem_falseValueGet_0();
case 1923547459: return bem_boolCcGet_0();
case 1012494862: return bem_once_0();
case 797225458: return bem_dynMethodsGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1369896794: return bem_objectNpGet_0();
case 1380285640: return bem_objectCcGet_0();
case 1487140092: return bem_classEndGet_0();
case 1327064356: return bem_methodBodyGet_0();
case 2085643372: return bem_stringNpGet_0();
case 1607412815: return bem_endNs_0();
case 1431933907: return bem_lastCallGet_0();
case 1795655423: return bem_propertyDecsGet_0();
case 1109279973: return bem_spropDecGet_0();
case 1498619679: return bem_getLibOutput_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 708434875: return bem_klassDecGet_0();
case 1102720804: return bem_classNameGet_0();
case 944442837: return bem_classConfGet_0();
case 1747980150: return bem_smnlecsGet_0();
case 1529527065: return bem_onceCountGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 571409003: return bem_libEmitName_1((BEC_4_6_TextString) bevd_0);
case 367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 1053807407: return bem_trueValueSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 165152860: return bem_libNs_1((BEC_4_6_TextString) bevd_0);
case 1227314505: return bem_acceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 541207893: return bem_complete_1((BEC_5_4_BuildNode) bevd_0);
case 283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case 1702694534: return bem_acceptBraces_1((BEC_5_4_BuildNode) bevd_0);
case 1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 610957309: return bem_intNpSet_1(bevd_0);
case 386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_5_4_BuildNode) bevd_0);
case 593061802: return bem_getClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case 891329961: return bem_classCallsSet_1(bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_5_4_BuildNode) bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1820669521: return bem_cnodeSet_1(bevd_0);
case 945327254: return bem_acceptIfEmit_1((BEC_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case 1073009536: return bem_beginNs_1((BEC_4_6_TextString) bevd_0);
case 90260853: return bem_nativeCSlotsSet_1(bevd_0);
case 1022041723: return bem_acceptCatch_1((BEC_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case 1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1901078234: return bem_getEmitName_1((BEC_5_8_BuildNamePath) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_4_6_TextString) bevd_0);
case 1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case 1912465206: return bem_boolCcSet_1(bevd_0);
case 377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case 943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case 1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 70425956: return bem_acceptRbraces_1((BEC_5_4_BuildNode) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 16141842: return bem_onceVarDec_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case 1980754914: return bem_oldacceptIf_1((BEC_5_4_BuildNode) bevd_0);
case 1936537319: return bem_msynSet_1(bevd_0);
case 551679723: return bem_formCast_1((BEC_5_11_BuildClassConfig) bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1438860491: return bem_instanceEqualSet_1(bevd_0);
case 1899632975: return bem_libEmitNameSet_1(bevd_0);
case 478502832: return bem_lstringEnd_1((BEC_4_6_TextString) bevd_0);
case 1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_5_3_BuildVar) bevd_0);
case 2110408325: return bem_acceptMethod_1((BEC_5_4_BuildNode) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_5_4_BuildNode) bevd_0);
case 391075985: return bem_inFilePathedSet_1(bevd_0);
case 36312873: return bem_buildStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_5_4_BuildNode) bevd_0);
case 1041861873: return bem_csynSet_1(bevd_0);
case 1931824221: return bem_mangleName_1((BEC_5_8_BuildNamePath) bevd_0);
case 715967253: return bem_exceptDecSet_1(bevd_0);
case 1830623958: return bem_returnTypeSet_1(bevd_0);
case 1562282714: return bem_getInitialInst_1((BEC_5_11_BuildClassConfig) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case 1774969510: return bem_methodCatchSet_1(bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case 1358814541: return bem_objectNpSet_1(bevd_0);
case 1820890036: return bem_extend_1((BEC_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case 2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case 65026440: return bem_formTarg_1((BEC_5_4_BuildNode) bevd_0);
case 627952553: return bem_getLocalClassConfig_1((BEC_5_8_BuildNamePath) bevd_0);
case 508002125: return bem_emitting_1((BEC_4_6_TextString) bevd_0);
case 707569329: return bem_getTraceInfo_1((BEC_5_4_BuildNode) bevd_0);
case 724180734: return bem_acceptClass_1((BEC_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_5_4_BuildNode) bevd_0, (BEC_5_8_BuildNamePath) bevd_1);
case 1978614329: return bem_lintConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1604046278: return bem_lfloatConstruct_2((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 569933480: return bem_lstringStart_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1697242261: return bem_overrideSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1671519971: return bem_countLines_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 6388749: return bem_decForVar_2((BEC_4_6_TextString) bevd_0, (BEC_5_3_BuildVar) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 722876117: return bem_buildClassInfo_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_5_4_BuildNode) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_5_8_BuildNamePath) bevd_2);
}
return base.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 316092711: return bem_startMethod_5((BEC_4_6_TextString) bevd_0, (BEC_5_11_BuildClassConfig) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3, bevd_4);
case 2023930725: return bem_lstringByte_5((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_4_6_TextString) bevd_4);
case 1591575024: return bem_lstringConstruct_5((BEC_5_11_BuildClassConfig) bevd_0, (BEC_5_4_BuildNode) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_3_MathInt) bevd_3, (BEC_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_10_BuildEmitCommon();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_10_BuildEmitCommon.bevs_inst = (BEC_5_10_BuildEmitCommon)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_10_BuildEmitCommon.bevs_inst;
}
}
}
