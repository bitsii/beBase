namespace be.BEL_4_Base {
/* IO:File: source/build/CEmitter.be */
public class BEC_5_9_BuildClassInfo : BEC_6_6_SystemObject {
public BEC_5_9_BuildClassInfo() { }
static BEC_5_9_BuildClassInfo() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 5));
private static byte[] bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_4_6_TextString bevo_1 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_1, 5));
private static byte[] bels_2 = {0x5F};
private static BEC_4_6_TextString bevo_2 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_3 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_3, 5));
private static byte[] bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_4_6_TextString bevo_4 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_4, 6));
private static byte[] bels_5 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_5 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_5, 5));
private static byte[] bels_6 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_4_6_TextString bevo_6 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_6, 12));
private static byte[] bels_7 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_7 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_7, 5));
private static byte[] bels_8 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_4_6_TextString bevo_8 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_8, 11));
private static byte[] bels_9 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_4_6_TextString bevo_9 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_4_6_TextString bevo_10 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_10, 6));
private static byte[] bels_11 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_4_6_TextString bevo_11 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_11, 5));
private static byte[] bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_4_6_TextString bevo_12 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_12, 12));
private static byte[] bels_13 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_13 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_13, 5));
private static byte[] bels_14 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_4_6_TextString bevo_14 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_14, 16));
private static byte[] bels_15 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_4_6_TextString bevo_15 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_15, 5));
private static byte[] bels_16 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_4_6_TextString bevo_16 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_16, 12));
private static byte[] bels_17 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_17 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_17, 5));
private static byte[] bels_18 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_4_6_TextString bevo_18 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_18, 16));
private static byte[] bels_19 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_4_6_TextString bevo_19 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_4_6_TextString bevo_20 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_20, 17));
private static byte[] bels_21 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_4_6_TextString bevo_21 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_21, 5));
private static byte[] bels_22 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_4_6_TextString bevo_22 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_22, 12));
private static byte[] bels_23 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_4_6_TextString bevo_23 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_23, 5));
private static byte[] bels_24 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_4_6_TextString bevo_24 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_24, 16));
private static byte[] bels_25 = {0x42,0x45,0x58,0x5F};
private static BEC_4_6_TextString bevo_25 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_25, 4));
private static byte[] bels_26 = {0x42,0x45,0x4B,0x5F};
private static BEC_4_6_TextString bevo_26 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_26, 4));
private static byte[] bels_27 = {0x2E,0x68};
private static BEC_4_6_TextString bevo_27 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_27, 2));
private static byte[] bels_28 = {0x2E,0x68};
private static BEC_4_6_TextString bevo_28 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_28, 2));
private static byte[] bels_29 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_4_6_TextString bevo_29 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_29, 5));
private static byte[] bels_30 = {0x2E,0x68};
private static BEC_4_6_TextString bevo_30 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x2E,0x68};
private static BEC_4_6_TextString bevo_31 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_31, 2));
private static byte[] bels_32 = {0x2E,0x73,0x79,0x6E};
private static BEC_4_6_TextString bevo_32 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_32, 4));
public static new BEC_5_9_BuildClassInfo bevs_inst;
public BEC_5_8_BuildNamePath bevp_np;
public BEC_6_6_SystemObject bevp_emitter;
public BEC_5_15_BuildCompilerProfile bevp_cpro;
public BEC_5_8_BuildNamePath bevp_npar;
public BEC_6_6_SystemObject bevp_nparSteps;
public BEC_4_6_TextString bevp_clName;
public BEC_4_6_TextString bevp_clBase;
public BEC_4_6_TextString bevp_midName;
public BEC_4_6_TextString bevp_incBlock;
public BEC_4_6_TextString bevp_mtdName;
public BEC_4_6_TextString bevp_cldefName;
public BEC_4_6_TextString bevp_shClassName;
public BEC_4_6_TextString bevp_shFileName;
public BEC_4_6_TextString bevp_cldefBuild;
public BEC_4_6_TextString bevp_libnameInit;
public BEC_4_6_TextString bevp_libnameInitDone;
public BEC_4_6_TextString bevp_libnameData;
public BEC_4_6_TextString bevp_libnameDataDone;
public BEC_4_6_TextString bevp_libnameDataClear;
public BEC_4_6_TextString bevp_libNotNullInit;
public BEC_4_6_TextString bevp_libNotNullInitDone;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_4_IOFilePath bevp_basePath;
public BEC_2_4_4_IOFilePath bevp_cuBase;
public BEC_2_4_4_IOFilePath bevp_nsDir;
public BEC_4_6_TextString bevp_xbase;
public BEC_4_6_TextString bevp_lbase;
public BEC_4_6_TextString bevp_nbase;
public BEC_4_6_TextString bevp_kbase;
public BEC_2_4_4_IOFilePath bevp_cuinitH;
public BEC_4_6_TextString bevp_namesIncH;
public BEC_2_4_4_IOFilePath bevp_cuinit;
public BEC_2_4_4_IOFilePath bevp_namesO;
public BEC_2_4_4_IOFilePath bevp_unitShlib;
public BEC_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_2_4_4_IOFilePath bevp_unitExe;
public BEC_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_2_4_4_IOFilePath bevp_classExeO;
public BEC_2_4_4_IOFilePath bevp_makeSrc;
public BEC_2_4_4_IOFilePath bevp_classSrc;
public BEC_2_4_4_IOFilePath bevp_classSrcH;
public BEC_2_4_4_IOFilePath bevp_classIncH;
public BEC_2_4_4_IOFilePath bevp_classO;
public BEC_2_4_4_IOFilePath bevp_synSrc;
public virtual BEC_5_9_BuildClassInfo bem_new_4(BEC_5_8_BuildNamePath beva__np, BEC_6_6_SystemObject beva__emitter, BEC_2_4_4_IOFilePath beva__emitPath, BEC_4_6_TextString beva__libName) {
this.bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public virtual BEC_5_9_BuildClassInfo bem_new_5(BEC_5_8_BuildNamePath beva__np, BEC_6_6_SystemObject beva__emitter, BEC_2_4_4_IOFilePath beva__emitPath, BEC_4_6_TextString beva__libName, BEC_4_6_TextString beva__exeName) {
BEC_4_6_TextString bevl_cext = null;
BEC_4_6_TextString bevl_oext = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpvar_phold = bevp_emitter.bemd_0(493012039, BEL_4_Base.bevn_buildGet_0);
bevp_cpro = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_phold.bemd_0(829911139, BEL_4_Base.bevn_compilerProfileGet_0);
bevp_npar = (BEC_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpvar_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_lastGet_0();
bevp_midName = (BEC_4_6_TextString) bevp_emitter.bemd_2(205318895, BEL_4_Base.bevn_midNameDo_2, beva__libName, beva__np);
this.bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpvar_phold = bevo_0;
bevp_incBlock = bevt_2_tmpvar_phold.bem_add_1(bevp_midName);
bevt_4_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_midName);
bevt_5_tmpvar_phold = bevo_2;
bevp_mtdName = bevt_3_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_midName);
bevt_8_tmpvar_phold = bevo_4;
bevp_cldefName = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_5;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevp_midName);
bevt_11_tmpvar_phold = bevo_6;
bevp_shClassName = bevt_9_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_7;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevp_midName);
bevt_14_tmpvar_phold = bevo_8;
bevp_shFileName = bevt_12_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_9;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevp_midName);
bevt_17_tmpvar_phold = bevo_10;
bevp_cldefBuild = bevt_15_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_11;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_midName);
bevt_20_tmpvar_phold = bevo_12;
bevp_libnameInit = bevt_18_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_22_tmpvar_phold = bevo_13;
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevp_midName);
bevt_23_tmpvar_phold = bevo_14;
bevp_libnameInitDone = bevt_21_tmpvar_phold.bem_add_1(bevt_23_tmpvar_phold);
bevt_25_tmpvar_phold = bevo_15;
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevp_midName);
bevt_26_tmpvar_phold = bevo_16;
bevp_libnameData = bevt_24_tmpvar_phold.bem_add_1(bevt_26_tmpvar_phold);
bevt_28_tmpvar_phold = bevo_17;
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_add_1(bevp_midName);
bevt_29_tmpvar_phold = bevo_18;
bevp_libnameDataDone = bevt_27_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_midName);
bevt_32_tmpvar_phold = bevo_20;
bevp_libnameDataClear = bevt_30_tmpvar_phold.bem_add_1(bevt_32_tmpvar_phold);
bevt_34_tmpvar_phold = bevo_21;
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_add_1(bevp_midName);
bevt_35_tmpvar_phold = bevo_22;
bevp_libNotNullInit = bevt_33_tmpvar_phold.bem_add_1(bevt_35_tmpvar_phold);
bevt_37_tmpvar_phold = bevo_23;
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_add_1(bevp_midName);
bevt_38_tmpvar_phold = bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpvar_phold.bem_add_1(bevt_38_tmpvar_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = (BEC_2_4_4_IOFilePath) beva__emitPath.bem_copy_0();
bevt_39_tmpvar_phold = bevo_25;
bevp_xbase = bevt_39_tmpvar_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpvar_phold = bevo_26;
bevp_kbase = bevt_40_tmpvar_phold.bem_add_1(bevp_clBase);
bevt_41_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_43_tmpvar_phold = bevo_27;
bevt_42_tmpvar_phold = bevp_nbase.bem_add_1(bevt_43_tmpvar_phold);
bevp_cuinitH = (BEC_2_4_4_IOFilePath) bevt_41_tmpvar_phold.bem_addStep_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_46_tmpvar_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_2_4_4_IOFilePath) bevt_45_tmpvar_phold.bem_addStep_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_48_tmpvar_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_2_4_4_IOFilePath) bevt_47_tmpvar_phold.bem_addStep_1(bevt_48_tmpvar_phold);
bevt_49_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_51_tmpvar_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpvar_phold = bevp_lbase.bem_add_1(bevt_51_tmpvar_phold);
bevp_unitShlib = (BEC_2_4_4_IOFilePath) bevt_49_tmpvar_phold.bem_addStep_1(bevt_50_tmpvar_phold);
bevt_52_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_54_tmpvar_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpvar_phold = bevp_lbase.bem_add_1(bevt_54_tmpvar_phold);
bevp_unitExeLink = (BEC_2_4_4_IOFilePath) bevt_52_tmpvar_phold.bem_addStep_1(bevt_53_tmpvar_phold);
bevt_55_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_57_tmpvar_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpvar_phold = beva__exeName.bem_add_1(bevt_57_tmpvar_phold);
bevp_unitExe = (BEC_2_4_4_IOFilePath) bevt_55_tmpvar_phold.bem_addStep_1(bevt_56_tmpvar_phold);
bevt_58_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_59_tmpvar_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_2_4_4_IOFilePath) bevt_58_tmpvar_phold.bem_addStep_1(bevt_59_tmpvar_phold);
bevt_60_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_61_tmpvar_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_2_4_4_IOFilePath) bevt_60_tmpvar_phold.bem_addStep_1(bevt_61_tmpvar_phold);
bevt_62_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_64_tmpvar_phold = bevo_29;
bevt_63_tmpvar_phold = bevp_xbase.bem_add_1(bevt_64_tmpvar_phold);
bevp_makeSrc = (BEC_2_4_4_IOFilePath) bevt_62_tmpvar_phold.bem_addStep_1(bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_66_tmpvar_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_2_4_4_IOFilePath) bevt_65_tmpvar_phold.bem_addStep_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_69_tmpvar_phold = bevo_30;
bevt_68_tmpvar_phold = bevp_kbase.bem_add_1(bevt_69_tmpvar_phold);
bevp_classSrcH = (BEC_2_4_4_IOFilePath) bevt_67_tmpvar_phold.bem_addStep_1(bevt_68_tmpvar_phold);
bevt_70_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_nsDir.bem_copy_0();
bevt_72_tmpvar_phold = bevo_31;
bevt_71_tmpvar_phold = bevp_kbase.bem_add_1(bevt_72_tmpvar_phold);
bevp_classIncH = (BEC_2_4_4_IOFilePath) bevt_70_tmpvar_phold.bem_addStep_1(bevt_71_tmpvar_phold);
bevt_73_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_74_tmpvar_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_2_4_4_IOFilePath) bevt_73_tmpvar_phold.bem_addStep_1(bevt_74_tmpvar_phold);
bevt_75_tmpvar_phold = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_77_tmpvar_phold = bevo_32;
bevt_76_tmpvar_phold = bevp_kbase.bem_add_1(bevt_77_tmpvar_phold);
bevp_synSrc = (BEC_2_4_4_IOFilePath) bevt_75_tmpvar_phold.bem_addStep_1(bevt_76_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nsDirDo_1(BEC_4_6_TextString beva__libName) {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevp_nsDir = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 114 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_nsDir.bem_addStep_1(bevt_1_tmpvar_phold);
} /* Line: 115 */
 else  /* Line: 114 */ {
break;
} /* Line: 114 */
} /* Line: 114 */
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_npSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_np = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_15_BuildCompilerProfile bem_cproGet_0() {
return bevp_cpro;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cproSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cpro = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_8_BuildNamePath bem_nparGet_0() {
return bevp_npar;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nparSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_npar = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nparStepsGet_0() {
return bevp_nparSteps;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nparStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nparSteps = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_clNameGet_0() {
return bevp_clName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_clNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_clName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_clBaseGet_0() {
return bevp_clBase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_clBaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_clBase = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_midNameGet_0() {
return bevp_midName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_midNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_midName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_incBlockGet_0() {
return bevp_incBlock;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_incBlockSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_incBlock = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_mtdNameGet_0() {
return bevp_mtdName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_mtdNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_mtdName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_cldefNameGet_0() {
return bevp_cldefName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cldefNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cldefName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_shClassNameGet_0() {
return bevp_shClassName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_shClassNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shClassName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_shFileNameGet_0() {
return bevp_shFileName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_shFileNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_shFileName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_cldefBuildGet_0() {
return bevp_cldefBuild;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cldefBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cldefBuild = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libnameInitGet_0() {
return bevp_libnameInit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameInitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameInit = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libnameInitDoneGet_0() {
return bevp_libnameInitDone;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameInitDoneSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameInitDone = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libnameDataGet_0() {
return bevp_libnameData;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameData = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libnameDataDoneGet_0() {
return bevp_libnameDataDone;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameDataDoneSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameDataDone = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libnameDataClearGet_0() {
return bevp_libnameDataClear;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameDataClearSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameDataClear = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNotNullInitGet_0() {
return bevp_libNotNullInit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNotNullInitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libNotNullInit = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNotNullInitDoneGet_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNotNullInitDoneSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libNotNullInitDone = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_basePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_basePath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_cuBaseGet_0() {
return bevp_cuBase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cuBaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cuBase = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_nsDirGet_0() {
return bevp_nsDir;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nsDirSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nsDir = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_xbaseGet_0() {
return bevp_xbase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_xbaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_xbase = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_lbaseGet_0() {
return bevp_lbase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lbaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lbase = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_nbaseGet_0() {
return bevp_nbase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_nbaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_nbase = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_kbaseGet_0() {
return bevp_kbase;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_kbaseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_kbase = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_cuinitHGet_0() {
return bevp_cuinitH;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cuinitHSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cuinitH = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_namesIncHGet_0() {
return bevp_namesIncH;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_namesIncHSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namesIncH = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_cuinitGet_0() {
return bevp_cuinit;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_cuinitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_cuinit = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_namesOGet_0() {
return bevp_namesO;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_namesOSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_namesO = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_unitShlibGet_0() {
return bevp_unitShlib;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unitShlibSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unitShlib = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_unitExeLinkGet_0() {
return bevp_unitExeLink;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unitExeLinkSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unitExeLink = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_unitExeGet_0() {
return bevp_unitExe;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_unitExeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_unitExe = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classExeSrcGet_0() {
return bevp_classExeSrc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classExeSrcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classExeSrc = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classExeOGet_0() {
return bevp_classExeO;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classExeOSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classExeO = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_makeSrcGet_0() {
return bevp_makeSrc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_makeSrcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_makeSrc = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classSrcGet_0() {
return bevp_classSrc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classSrcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classSrc = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classSrcHGet_0() {
return bevp_classSrcH;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classSrcHSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classSrcH = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classIncHGet_0() {
return bevp_classIncH;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classIncHSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classIncH = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_classOGet_0() {
return bevp_classO;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_classOSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_classO = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_synSrcGet_0() {
return bevp_synSrc;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_synSrcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_synSrc = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 31, 32, 33, 34, 35, 36, 38, 40, 42, 43, 44, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 70, 72, 74, 75, 78, 79, 80, 81, 83, 84, 85, 86, 90, 91, 92, 94, 95, 96, 98, 99, 100, 101, 102, 112, 113, 114, 115, 0};
public static new int[] bevs_smnlec
 = new int[] {120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120};
/* BEGIN LINEINFO 
new 5 24 120
assign 1 31 120
assign 1 32 120
assign 1 33 120
buildGet 0 33 120
assign 1 33 120
compilerProfileGet 0 33 120
assign 1 34 120
parentGet 0 34 120
assign 1 35 120
stepsGet 0 35 120
assign 1 36 120
toString 0 36 120
assign 1 38 120
stepsGet 0 38 120
assign 1 38 120
lastGet 0 38 120
assign 1 40 120
midNameDo 2 40 120
nsDirDo 1 42 120
assign 1 43 120
cextGet 0 43 120
assign 1 44 120
oextGet 0 44 120
assign 1 47 120
new 0 47 120
assign 1 47 120
add 1 47 120
assign 1 49 120
new 0 49 120
assign 1 49 120
add 1 49 120
assign 1 49 120
new 0 49 120
assign 1 49 120
add 1 49 120
assign 1 51 120
new 0 51 120
assign 1 51 120
add 1 51 120
assign 1 51 120
new 0 51 120
assign 1 51 120
add 1 51 120
assign 1 53 120
new 0 53 120
assign 1 53 120
add 1 53 120
assign 1 53 120
new 0 53 120
assign 1 53 120
add 1 53 120
assign 1 55 120
new 0 55 120
assign 1 55 120
add 1 55 120
assign 1 55 120
new 0 55 120
assign 1 55 120
add 1 55 120
assign 1 57 120
new 0 57 120
assign 1 57 120
add 1 57 120
assign 1 57 120
new 0 57 120
assign 1 57 120
add 1 57 120
assign 1 59 120
new 0 59 120
assign 1 59 120
add 1 59 120
assign 1 59 120
new 0 59 120
assign 1 59 120
add 1 59 120
assign 1 61 120
new 0 61 120
assign 1 61 120
add 1 61 120
assign 1 61 120
new 0 61 120
assign 1 61 120
add 1 61 120
assign 1 63 120
new 0 63 120
assign 1 63 120
add 1 63 120
assign 1 63 120
new 0 63 120
assign 1 63 120
add 1 63 120
assign 1 65 120
new 0 65 120
assign 1 65 120
add 1 65 120
assign 1 65 120
new 0 65 120
assign 1 65 120
add 1 65 120
assign 1 67 120
new 0 67 120
assign 1 67 120
add 1 67 120
assign 1 67 120
new 0 67 120
assign 1 67 120
add 1 67 120
assign 1 69 120
new 0 69 120
assign 1 69 120
add 1 69 120
assign 1 69 120
new 0 69 120
assign 1 69 120
add 1 69 120
assign 1 70 120
new 0 70 120
assign 1 70 120
add 1 70 120
assign 1 70 120
new 0 70 120
assign 1 70 120
add 1 70 120
assign 1 72 120
assign 1 74 120
add 1 74 120
assign 1 75 120
copy 0 75 120
assign 1 78 120
new 0 78 120
assign 1 78 120
add 1 78 120
assign 1 79 120
assign 1 80 120
assign 1 81 120
new 0 81 120
assign 1 81 120
add 1 81 120
assign 1 83 120
copy 0 83 120
assign 1 83 120
new 0 83 120
assign 1 83 120
add 1 83 120
assign 1 83 120
addStep 1 83 120
assign 1 84 120
new 0 84 120
assign 1 84 120
add 1 84 120
assign 1 85 120
copy 0 85 120
assign 1 85 120
add 1 85 120
assign 1 85 120
addStep 1 85 120
assign 1 86 120
copy 0 86 120
assign 1 86 120
add 1 86 120
assign 1 86 120
addStep 1 86 120
assign 1 90 120
copy 0 90 120
assign 1 90 120
libExtGet 0 90 120
assign 1 90 120
add 1 90 120
assign 1 90 120
addStep 1 90 120
assign 1 91 120
copy 0 91 120
assign 1 91 120
exeLibExtGet 0 91 120
assign 1 91 120
add 1 91 120
assign 1 91 120
addStep 1 91 120
assign 1 92 120
copy 0 92 120
assign 1 92 120
exeExtGet 0 92 120
assign 1 92 120
add 1 92 120
assign 1 92 120
addStep 1 92 120
assign 1 94 120
copy 0 94 120
assign 1 94 120
add 1 94 120
assign 1 94 120
addStep 1 94 120
assign 1 95 120
copy 0 95 120
assign 1 95 120
add 1 95 120
assign 1 95 120
addStep 1 95 120
assign 1 96 120
copy 0 96 120
assign 1 96 120
new 0 96 120
assign 1 96 120
add 1 96 120
assign 1 96 120
addStep 1 96 120
assign 1 98 120
copy 0 98 120
assign 1 98 120
add 1 98 120
assign 1 98 120
addStep 1 98 120
assign 1 99 120
copy 0 99 120
assign 1 99 120
new 0 99 120
assign 1 99 120
add 1 99 120
assign 1 99 120
addStep 1 99 120
assign 1 100 120
copy 0 100 120
assign 1 100 120
new 0 100 120
assign 1 100 120
add 1 100 120
assign 1 100 120
addStep 1 100 120
assign 1 101 120
copy 0 101 120
assign 1 101 120
add 1 101 120
assign 1 101 120
addStep 1 101 120
assign 1 102 120
copy 0 102 120
assign 1 102 120
new 0 102 120
assign 1 102 120
add 1 102 120
assign 1 102 120
addStep 1 102 120
assign 1 112 120
new 0 112 120
addStep 1 113 120
assign 1 114 120
iteratorGet 0 114 120
assign 1 114 120
hasNextGet 0 114 120
assign 1 115 120
nextGet 0 115 120
addStep 1 115 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
return 1 0 120
assign 1 0 120
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 127248149: return bem_synSrcGet_0();
case 104305708: return bem_nparGet_0();
case 287040793: return bem_hashGet_0();
case 1080018081: return bem_unitExeLinkGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 862807520: return bem_cldefNameGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 1886714699: return bem_shFileNameGet_0();
case 1820417453: return bem_create_0();
case 383660736: return bem_libNotNullInitDoneGet_0();
case 609562407: return bem_shClassNameGet_0();
case 359052641: return bem_mtdNameGet_0();
case 1391130325: return bem_kbaseGet_0();
case 104713553: return bem_new_0();
case 1557441057: return bem_nsDirGet_0();
case 607794031: return bem_basePathGet_0();
case 177846336: return bem_namesOGet_0();
case 881662481: return bem_makeSrcGet_0();
case 1012494862: return bem_once_0();
case 1616408805: return bem_classIncHGet_0();
case 360786829: return bem_nparStepsGet_0();
case 1587643830: return bem_lbaseGet_0();
case 365019179: return bem_cldefBuildGet_0();
case 845792839: return bem_iteratorGet_0();
case 219204885: return bem_namesIncHGet_0();
case 419630141: return bem_cproGet_0();
case 1388201267: return bem_clBaseGet_0();
case 1980670840: return bem_nbaseGet_0();
case 314718434: return bem_print_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1354714650: return bem_copy_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 253960615: return bem_libnameInitGet_0();
case 159064069: return bem_unitShlibGet_0();
case 2067424172: return bem_midNameGet_0();
case 576422196: return bem_libnameDataClearGet_0();
case 349161406: return bem_xbaseGet_0();
case 135159317: return bem_libnameDataDoneGet_0();
case 692930085: return bem_cuinitGet_0();
case 2024533880: return bem_incBlockGet_0();
case 1138144484: return bem_cuBaseGet_0();
case 1071259835: return bem_libnameInitDoneGet_0();
case 1004321502: return bem_libNotNullInitGet_0();
case 6494497: return bem_cuinitHGet_0();
case 2116315365: return bem_npGet_0();
case 1537579065: return bem_unitExeGet_0();
case 1598889373: return bem_classExeSrcGet_0();
case 908741136: return bem_classOGet_0();
case 1081412016: return bem_many_0();
case 896959893: return bem_classSrcHGet_0();
case 1662094163: return bem_clNameGet_0();
case 663786395: return bem_classSrcGet_0();
case 148252493: return bem_libnameDataGet_0();
case 1308786538: return bem_echo_0();
case 2097068593: return bem_emitPathGet_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 2028575047: return bem_emitterGet_0();
case 729571811: return bem_serializeToString_0();
case 1815029646: return bem_classExeOGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1546358804: return bem_nsDirSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1673176416: return bem_clNameSet_1(bevd_0);
case 2127397618: return bem_npSet_1(bevd_0);
case 1609971626: return bem_classExeSrcSet_1(bevd_0);
case 885877640: return bem_classSrcHSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 993239249: return bem_libNotNullInitSet_1(bevd_0);
case 587504449: return bem_libnameDataClearSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 360243659: return bem_xbaseSet_1(bevd_0);
case 851725267: return bem_cldefNameSet_1(bevd_0);
case 265042868: return bem_libnameInitSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1380048072: return bem_kbaseSet_1(bevd_0);
case 166764083: return bem_namesOSet_1(bevd_0);
case 372578483: return bem_libNotNullInitDoneSet_1(bevd_0);
case 897658883: return bem_classOSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1548661318: return bem_unitExeSet_1(bevd_0);
case 353936926: return bem_cldefBuildSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2035616133: return bem_incBlockSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1897796952: return bem_shFileNameSet_1(bevd_0);
case 598480154: return bem_shClassNameSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 642416165: return bem_nsDirDo_1((BEC_4_6_TextString) bevd_0);
case 349704576: return bem_nparStepsSet_1(bevd_0);
case 596711778: return bem_basePathSet_1(bevd_0);
case 1969588587: return bem_nbaseSet_1(bevd_0);
case 1803947393: return bem_classExeOSet_1(bevd_0);
case 1377119014: return bem_clBaseSet_1(bevd_0);
case 147981816: return bem_unitShlibSet_1(bevd_0);
case 1068935828: return bem_unitExeLinkSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 674868648: return bem_classSrcSet_1(bevd_0);
case 93223455: return bem_nparSet_1(bevd_0);
case 1627491058: return bem_classIncHSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 124077064: return bem_libnameDataDoneSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 116165896: return bem_synSrcSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2056341919: return bem_midNameSet_1(bevd_0);
case 892744734: return bem_makeSrcSet_1(bevd_0);
case 1149226737: return bem_cuBaseSet_1(bevd_0);
case 704012338: return bem_cuinitSet_1(bevd_0);
case 230287138: return bem_namesIncHSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 159334746: return bem_libnameDataSet_1(bevd_0);
case 17576750: return bem_cuinitHSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1576561577: return bem_lbaseSet_1(bevd_0);
case 1060177582: return bem_libnameInitDoneSet_1(bevd_0);
case 347970388: return bem_mtdNameSet_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 430712394: return bem_cproSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 104713557: return bem_new_4((BEC_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_2_4_4_IOFilePath) bevd_2, (BEC_4_6_TextString) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_6_6_SystemObject bemd_5(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3, BEC_6_6_SystemObject bevd_4) {
switch (callHash) {
case 104713558: return bem_new_5((BEC_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_2_4_4_IOFilePath) bevd_2, (BEC_4_6_TextString) bevd_3, (BEC_4_6_TextString) bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_9_BuildClassInfo();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_9_BuildClassInfo.bevs_inst = (BEC_5_9_BuildClassInfo)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_9_BuildClassInfo.bevs_inst;
}
}
}
