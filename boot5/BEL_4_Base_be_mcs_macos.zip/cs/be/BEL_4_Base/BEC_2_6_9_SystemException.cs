namespace be.BEL_4_Base {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 3));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_15 = {0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 1));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_16 = {0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 2));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_17 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_18 = {0x3A};
private static BEC_2_4_3_MathInt bevo_13 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_19 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x28};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_21, 1));
private static BEC_2_4_3_MathInt bevo_18 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_19 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_22 = {0x3A};
private static BEC_2_4_3_MathInt bevo_20 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_23 = {0x3A};
private static BEC_2_4_3_MathInt bevo_21 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_22 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_24 = {0x28};
private static BEC_2_4_6_TextString bevo_23 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_24, 1));
private static BEC_2_4_3_MathInt bevo_24 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_25 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_26 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_25 = {0x2E};
private static byte[] bels_26 = {0x2E};
private static BEC_2_4_3_MathInt bevo_27 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x42,0x45,0x4C,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_27, 4));
private static BEC_2_4_3_MathInt bevo_29 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static byte[] bels_28 = {0x5F};
private static BEC_2_4_6_TextString bevo_30 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_28, 1));
private static BEC_2_4_3_MathInt bevo_31 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_33 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
private static byte[] bels_29 = {0x62,0x65};
private static byte[] bels_30 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_35 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x62,0x65};
private static byte[] bels_32 = {0x2E};
private static byte[] bels_33 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_36 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_33, 4));
private static byte[] bels_34 = {0x5F};
private static BEC_2_4_3_MathInt bevo_37 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_35 = {0x3A};
private static byte[] bels_36 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_39 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x5F};
private static BEC_2_4_3_MathInt bevo_40 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_41 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_38 = {0x5F};
private static byte[] bels_39 = {0x0A};
private static BEC_2_4_6_TextString bevo_42 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_39, 1));
public static new BEC_2_6_9_SystemException bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 41 */ {
bevt_2_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 42 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_5_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 45 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 47 */ {
bevt_8_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 48 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_11_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 51 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_14_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 54 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 56 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 57 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 59 */ {
bevt_20_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 60 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_24_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 63 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 66 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedException_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 72 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 73 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold.bem_print_0();
} /* Line: 75 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translateEmittedExceptionInner_0() {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_4_6_TextString bevl_libLens = null;
BEC_2_4_3_MathInt bevl_libLen = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
if (bevp_translated == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 83 */ {
if (bevp_translated.bevi_bool) /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 83 */
 else  /* Line: 83 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 83 */ {
return this;
} /* Line: 84 */
bevp_translated = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 87 */ {
if (bevp_lang == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_16_tmpvar_phold = bevo_1;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_18_tmpvar_phold = bevo_2;
bevt_17_tmpvar_phold = bevp_lang.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
 else  /* Line: 87 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 87 */ {
bevt_19_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_12));
bevl_ltok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpvar_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpvar_phold = bevo_3;
bevt_20_tmpvar_phold = bevp_lang.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 91 */
 else  /* Line: 92 */ {
bevl_isCs = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 93 */
bevt_0_tmpvar_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 95 */ {
bevt_22_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 95 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_23_tmpvar_phold = bevo_4;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_26_tmpvar_phold = bevo_5;
bevt_25_tmpvar_phold = bevl_start.bem_greaterEquals_1(bevt_26_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 100 */ {
bevt_27_tmpvar_phold = bevo_6;
bevt_29_tmpvar_phold = bevo_7;
bevt_28_tmpvar_phold = bevl_start.bem_add_1(bevt_29_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold);
if (bevl_end == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_31_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_33_tmpvar_phold = bevo_8;
bevt_32_tmpvar_phold = bevl_start.bem_add_1(bevt_33_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 107 */ {
bevt_34_tmpvar_phold = bevo_9;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_37_tmpvar_phold = bevo_10;
bevt_36_tmpvar_phold = bevl_start.bem_add_1(bevt_37_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_11;
bevt_38_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_41_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpvar_phold = bevo_12;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_subtract_1(bevt_42_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpvar_phold);
} /* Line: 113 */
bevt_43_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_18));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_45_tmpvar_phold = bevo_13;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpvar_phold, bevl_pdelim);
bevt_47_tmpvar_phold = bevo_14;
bevt_46_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_47_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = bevo_15;
bevt_48_tmpvar_phold = bevl_iv.bem_begins_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_50_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpvar_phold);
} /* Line: 122 */
bevt_51_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 126 */
} /* Line: 125 */
} /* Line: 117 */
} /* Line: 109 */
 else  /* Line: 130 */ {
bevt_52_tmpvar_phold = bevo_16;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 132 */ {
bevt_54_tmpvar_phold = bevo_17;
bevt_56_tmpvar_phold = bevo_18;
bevt_55_tmpvar_phold = bevl_start.bem_add_1(bevt_56_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
if (bevl_end == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_59_tmpvar_phold = bevo_19;
bevt_58_tmpvar_phold = bevl_start.bem_add_1(bevt_59_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpvar_phold, bevl_end);
bevt_60_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_62_tmpvar_phold = bevo_20;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpvar_phold, bevl_pdelim);
bevt_63_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_23));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_65_tmpvar_phold = bevo_21;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpvar_phold, bevl_pdelim);
} /* Line: 146 */
bevt_67_tmpvar_phold = bevo_22;
bevt_66_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_67_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 150 */ {
bevl_eline = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 151 */
} /* Line: 150 */
} /* Line: 141 */
} /* Line: 136 */
} /* Line: 132 */
} /* Line: 107 */
 else  /* Line: 157 */ {
bevt_69_tmpvar_phold = bevo_23;
bevt_71_tmpvar_phold = bevo_24;
bevt_70_tmpvar_phold = bevl_start.bem_add_1(bevt_71_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
if (bevl_end == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_73_tmpvar_phold = bevl_end.bem_greater_1(bevl_start);
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 159 */
 else  /* Line: 159 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 159 */ {
bevt_75_tmpvar_phold = bevo_25;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpvar_phold, bevl_end);
} /* Line: 160 */
 else  /* Line: 161 */ {
bevt_77_tmpvar_phold = bevo_26;
bevt_76_tmpvar_phold = bevl_start.bem_add_1(bevt_77_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpvar_phold);
} /* Line: 162 */
} /* Line: 159 */
if (bevl_callPart == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 165 */ {
if (bevl_isCs.bevi_bool) /* Line: 166 */ {
bevt_79_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_25));
bevl_parts = bevl_callPart.bem_split_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpvar_phold);
bevt_81_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpvar_phold = this.bem_getSourceFileName_1(bevt_83_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_84_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpvar_phold = bevo_27;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_greater_1(bevt_87_tmpvar_phold);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 184 */ {
bevt_88_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevo_28;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpvar_phold);
if (bevl_start == null) {
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevt_93_tmpvar_phold = bevo_29;
bevt_92_tmpvar_phold = bevl_start.bem_greater_1(bevt_93_tmpvar_phold);
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 190 */
 else  /* Line: 190 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 190 */ {
bevt_94_tmpvar_phold = bevo_30;
bevt_96_tmpvar_phold = bevo_31;
bevt_95_tmpvar_phold = bevl_start.bem_add_1(bevt_96_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
if (bevl_end == null) {
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_99_tmpvar_phold = bevo_32;
bevt_98_tmpvar_phold = bevl_end.bem_greater_1(bevt_99_tmpvar_phold);
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 192 */ {
bevt_101_tmpvar_phold = bevo_33;
bevt_100_tmpvar_phold = bevl_start.bem_add_1(bevt_101_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_100_tmpvar_phold, bevl_end);
bevl_libLen = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_104_tmpvar_phold = bevo_34;
bevt_103_tmpvar_phold = bevl_start.bem_add_1(bevt_104_tmpvar_phold);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_102_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_106_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_105_tmpvar_phold = this.bem_getSourceFileName_1(bevt_106_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_105_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 202 */
} /* Line: 192 */
} /* Line: 190 */
} /* Line: 184 */
} /* Line: 166 */
} /* Line: 165 */
} /* Line: 100 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_29));
bevp_framesText = null;
} /* Line: 212 */
 else  /* Line: 87 */ {
if (bevp_frames == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 213 */ {
if (bevp_lang == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
 else  /* Line: 213 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 213 */ {
bevt_110_tmpvar_phold = bevo_35;
bevt_109_tmpvar_phold = bevp_lang.bem_equals_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 213 */
 else  /* Line: 213 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 213 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 214 */ {
bevt_111_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 214 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpvar_loop.bem_nextGet_0();
bevt_113_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractKlassLib_1(bevt_113_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_114_tmpvar_phold = this.bem_extractMethod_1(bevt_115_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_114_tmpvar_phold);
bevt_117_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_116_tmpvar_phold = this.bem_getSourceFileName_1(bevt_117_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_116_tmpvar_phold);
} /* Line: 218 */
 else  /* Line: 214 */ {
break;
} /* Line: 214 */
} /* Line: 214 */
bevp_emitLang = bevp_lang;
bevp_lang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_31));
} /* Line: 223 */
 else  /* Line: 224 */ {
} /* Line: 224 */
} /* Line: 87 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_2_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 234 */
return null;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_32));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 248 */ {
bevt_0_tmpvar_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpvar_phold;
} /* Line: 249 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 250 */
return beva_klass;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_4_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
return beva_klass;
} /* Line: 258 */
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_34));
bevl_kparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_37;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 265 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_kps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_38;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lesser_1(bevl_kps);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_17_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_35));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 269 */
bevl_sofar.bem_addValue_1(bevl_len);
bevl_i.bem_incrementValue_0();
} /* Line: 265 */
 else  /* Line: 265 */ {
break;
} /* Line: 265 */
} /* Line: 265 */
return bevl_bec;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_4_tmpvar_phold = bevo_39;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 277 */ {
return beva_mtd;
} /* Line: 278 */
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_37));
bevl_mparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_40;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 283 */ {
bevt_10_tmpvar_phold = bevl_i.bem_lesser_1(bevl_mps);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_41;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_lesser_1(bevl_mps);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_15_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bels_38));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 285 */
bevl_i.bem_incrementValue_0();
} /* Line: 283 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
return bevl_bem;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 301 */ {
bevt_2_tmpvar_phold = bevo_42;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 303 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 303 */ {
bevl_ft = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 304 */
 else  /* Line: 303 */ {
break;
} /* Line: 303 */
} /* Line: 303 */
} /* Line: 303 */
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 316 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {33, 37, 40, 41, 42, 44, 45, 47, 48, 50, 51, 53, 54, 56, 57, 59, 60, 62, 63, 65, 66, 68, 73, 75, 83, 0, 84, 86, 87, 0, 87, 0, 87, 0, 88, 89, 90, 91, 93, 95, 0, 95, 97, 98, 99, 100, 0, 102, 103, 0, 105, 108, 109, 111, 112, 113, 116, 117, 118, 120, 121, 122, 125, 126, 131, 132, 135, 136, 138, 140, 141, 142, 144, 145, 146, 148, 150, 151, 158, 159, 0, 160, 162, 165, 168, 170, 171, 173, 175, 177, 178, 179, 183, 184, 185, 186, 188, 189, 190, 0, 191, 192, 0, 193, 195, 196, 198, 200, 201, 202, 210, 211, 212, 213, 0, 213, 0, 214, 0, 214, 215, 216, 217, 222, 223, 231, 232, 234, 237, 242, 244, 249, 253, 257, 0, 257, 0, 258, 260, 261, 262, 263, 264, 265, 266, 268, 269, 270, 265, 273, 277, 0, 277, 0, 278, 280, 281, 282, 283, 284, 285, 283, 288, 294, 298, 299, 300, 301, 302, 303, 0, 303, 304, 307, 311, 315, 316, 318, 322, 0};
public static new int[] bevs_smnlec
 = new int[] {103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 104, 104, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 104, 104, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103};
/* BEGIN LINEINFO 
assign 1 33 103
translateEmittedException 0 37 103
assign 1 40 103
new 0 40 103
assign 1 41 103
def 1 41 103
assign 1 42 103
new 0 42 103
assign 1 42 103
add 1 42 103
assign 1 42 103
add 1 42 103
assign 1 44 103
def 1 44 103
assign 1 45 103
new 0 45 103
assign 1 45 103
add 1 45 103
assign 1 45 103
add 1 45 103
assign 1 47 103
def 1 47 103
assign 1 48 103
new 0 48 103
assign 1 48 103
add 1 48 103
assign 1 48 103
add 1 48 103
assign 1 50 103
def 1 50 103
assign 1 51 103
new 0 51 103
assign 1 51 103
add 1 51 103
assign 1 51 103
add 1 51 103
assign 1 53 103
def 1 53 103
assign 1 54 103
new 0 54 103
assign 1 54 103
add 1 54 103
assign 1 54 103
add 1 54 103
assign 1 56 103
def 1 56 103
assign 1 57 103
new 0 57 103
assign 1 57 103
add 1 57 103
assign 1 57 103
add 1 57 103
assign 1 59 103
def 1 59 103
assign 1 60 103
new 0 60 103
assign 1 60 103
add 1 60 103
assign 1 60 103
toString 0 60 103
assign 1 60 103
add 1 60 103
assign 1 62 103
def 1 62 103
assign 1 63 103
new 0 63 103
assign 1 63 103
add 1 63 103
assign 1 63 103
add 1 63 103
assign 1 65 103
def 1 65 103
assign 1 66 103
getFrameText 0 66 103
assign 1 66 103
add 1 66 103
return 1 68 103
translateEmittedExceptionInner 0 73 104
assign 1 75 104
new 0 75 104
print 0 75 104
assign 1 83 103
def 1 83 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
return 1 84 103
assign 1 86 103
new 0 86 103
assign 1 87 103
def 1 87 103
assign 1 87 103
def 1 87 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 87 103
new 0 87 103
assign 1 87 103
equals 1 87 103
assign 1 0 103
assign 1 87 103
new 0 87 103
assign 1 87 103
equals 1 87 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 88 103
new 0 88 103
assign 1 88 103
new 1 88 103
assign 1 89 103
tokenize 1 89 103
assign 1 90 103
new 0 90 103
assign 1 90 103
equals 1 90 103
assign 1 91 103
new 0 91 103
assign 1 93 103
new 0 93 103
assign 1 95 103
linkedListIteratorGet 0 0 103
assign 1 95 103
hasNextGet 0 95 103
assign 1 95 103
nextGet 0 95 103
assign 1 97 103
new 0 97 103
assign 1 97 103
find 1 97 103
assign 1 98 103
assign 1 99 103
assign 1 100 103
def 1 100 103
assign 1 100 103
new 0 100 103
assign 1 100 103
greaterEquals 1 100 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 102 103
new 0 102 103
assign 1 102 103
new 0 102 103
assign 1 102 103
add 1 102 103
assign 1 102 103
find 2 102 103
assign 1 103 103
def 1 103 103
assign 1 103 103
greater 1 103 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 105 103
new 0 105 103
assign 1 105 103
add 1 105 103
assign 1 105 103
substring 2 105 103
assign 1 108 103
new 0 108 103
assign 1 108 103
find 2 108 103
assign 1 109 103
def 1 109 103
assign 1 111 103
new 0 111 103
assign 1 111 103
add 1 111 103
assign 1 111 103
substring 1 111 103
assign 1 112 103
new 0 112 103
assign 1 112 103
ends 1 112 103
assign 1 113 103
sizeGet 0 113 103
assign 1 113 103
new 0 113 103
assign 1 113 103
subtract 1 113 103
sizeSet 1 113 103
assign 1 116 103
new 0 116 103
assign 1 116 103
rfind 1 116 103
assign 1 117 103
def 1 117 103
assign 1 118 103
new 0 118 103
assign 1 118 103
substring 2 118 103
assign 1 120 103
new 0 120 103
assign 1 120 103
add 1 120 103
assign 1 120 103
substring 1 120 103
assign 1 121 103
new 0 121 103
assign 1 121 103
begins 1 121 103
assign 1 122 103
new 0 122 103
assign 1 122 103
substring 1 122 103
assign 1 125 103
isInteger 0 125 103
assign 1 126 103
new 1 126 103
assign 1 131 103
new 0 131 103
assign 1 131 103
find 2 131 103
assign 1 132 103
def 1 132 103
assign 1 135 103
new 0 135 103
assign 1 135 103
new 0 135 103
assign 1 135 103
add 1 135 103
assign 1 135 103
find 2 135 103
assign 1 136 103
def 1 136 103
assign 1 138 103
new 0 138 103
assign 1 138 103
add 1 138 103
assign 1 138 103
substring 2 138 103
assign 1 140 103
new 0 140 103
assign 1 140 103
rfind 1 140 103
assign 1 141 103
def 1 141 103
assign 1 142 103
new 0 142 103
assign 1 142 103
substring 2 142 103
assign 1 144 103
new 0 144 103
assign 1 144 103
rfind 1 144 103
assign 1 145 103
def 1 145 103
assign 1 146 103
new 0 146 103
assign 1 146 103
substring 2 146 103
assign 1 148 103
new 0 148 103
assign 1 148 103
add 1 148 103
assign 1 148 103
substring 1 148 103
assign 1 150 103
isInteger 0 150 103
assign 1 151 103
new 1 151 103
assign 1 158 103
new 0 158 103
assign 1 158 103
new 0 158 103
assign 1 158 103
add 1 158 103
assign 1 158 103
find 2 158 103
assign 1 159 103
def 1 159 103
assign 1 159 103
greater 1 159 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 160 103
new 0 160 103
assign 1 160 103
add 1 160 103
assign 1 160 103
substring 2 160 103
assign 1 162 103
new 0 162 103
assign 1 162 103
add 1 162 103
assign 1 162 103
substring 1 162 103
assign 1 165 103
def 1 165 103
assign 1 168 103
new 0 168 103
assign 1 168 103
split 1 168 103
assign 1 170 103
new 0 170 103
assign 1 170 103
get 1 170 103
assign 1 171 103
new 0 171 103
assign 1 171 103
get 1 171 103
assign 1 173 103
extractKlass 1 173 103
assign 1 175 103
extractMethod 1 175 103
assign 1 177 103
new 4 177 103
assign 1 178 103
klassNameGet 0 178 103
assign 1 178 103
getSourceFileName 1 178 103
fileNameSet 1 178 103
addFrame 1 179 103
assign 1 183 103
new 0 183 103
assign 1 183 103
split 1 183 103
assign 1 184 103
sizeGet 0 184 103
assign 1 184 103
new 0 184 103
assign 1 184 103
greater 1 184 103
assign 1 185 103
new 0 185 103
assign 1 185 103
get 1 185 103
assign 1 186 103
extractMethod 1 186 103
assign 1 188 103
new 0 188 103
assign 1 188 103
get 1 188 103
assign 1 189 103
new 0 189 103
assign 1 189 103
find 1 189 103
assign 1 190 103
def 1 190 103
assign 1 190 103
new 0 190 103
assign 1 190 103
greater 1 190 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 191 103
new 0 191 103
assign 1 191 103
new 0 191 103
assign 1 191 103
add 1 191 103
assign 1 191 103
find 2 191 103
assign 1 192 103
def 1 192 103
assign 1 192 103
new 0 192 103
assign 1 192 103
greater 1 192 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 193 103
new 0 193 103
assign 1 193 103
add 1 193 103
assign 1 193 103
substring 2 193 103
assign 1 195 103
new 1 195 103
assign 1 196 103
new 0 196 103
assign 1 196 103
add 1 196 103
assign 1 196 103
add 1 196 103
assign 1 196 103
substring 1 196 103
assign 1 198 103
extractKlass 1 198 103
assign 1 200 103
new 4 200 103
assign 1 201 103
klassNameGet 0 201 103
assign 1 201 103
getSourceFileName 1 201 103
fileNameSet 1 201 103
addFrame 1 202 103
assign 1 210 103
assign 1 211 103
new 0 211 103
assign 1 212 103
assign 1 213 103
def 1 213 103
assign 1 213 103
def 1 213 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 213 103
new 0 213 103
assign 1 213 103
equals 1 213 103
assign 1 0 103
assign 1 0 103
assign 1 0 103
assign 1 214 103
linkedListIteratorGet 0 0 103
assign 1 214 103
hasNextGet 0 214 103
assign 1 214 103
nextGet 0 214 103
assign 1 215 103
klassNameGet 0 215 103
assign 1 215 103
extractKlassLib 1 215 103
klassNameSet 1 215 103
assign 1 216 103
methodNameGet 0 216 103
assign 1 216 103
extractMethod 1 216 103
methodNameSet 1 216 103
assign 1 217 103
klassNameGet 0 217 103
assign 1 217 103
getSourceFileName 1 217 103
fileNameSet 1 217 103
assign 1 222 103
assign 1 223 103
new 0 223 103
assign 1 231 103
new 0 231 103
assign 1 231 103
createInstance 2 231 103
assign 1 232 103
def 1 232 103
assign 1 234 103
sourceFileNameGet 0 234 103
return 1 234 103
return 1 237 103
assign 1 242 103
new 0 242 103
assign 1 242 103
split 1 242 103
assign 1 244 103
new 0 244 103
assign 1 244 103
get 1 244 103
assign 1 244 103
extractKlass 1 244 103
return 1 244 103
assign 1 249 104
extractKlassInner 1 249 104
return 1 249 104
return 1 253 104
assign 1 257 103
undef 1 257 103
assign 1 0 103
assign 1 257 103
new 0 257 103
assign 1 257 103
begins 1 257 103
assign 1 257 103
not 0 257 103
assign 1 0 103
assign 1 0 103
return 1 258 103
assign 1 260 103
new 0 260 103
assign 1 260 103
substring 1 260 103
assign 1 260 103
new 0 260 103
assign 1 260 103
split 1 260 103
assign 1 261 103
sizeGet 0 261 103
assign 1 261 103
new 0 261 103
assign 1 261 103
subtract 1 261 103
assign 1 262 103
get 1 262 103
assign 1 263 103
new 0 263 103
assign 1 264 103
new 0 264 103
assign 1 265 103
new 0 265 103
assign 1 265 103
lesser 1 265 103
assign 1 266 103
get 1 266 103
assign 1 266 103
new 1 266 103
assign 1 268 103
add 1 268 103
assign 1 268 103
substring 2 268 103
addValue 1 268 103
assign 1 269 103
new 0 269 103
assign 1 269 103
add 1 269 103
assign 1 269 103
lesser 1 269 103
assign 1 269 103
new 0 269 103
addValue 1 269 103
addValue 1 270 103
incrementValue 0 265 103
return 1 273 103
assign 1 277 103
undef 1 277 103
assign 1 0 103
assign 1 277 103
new 0 277 103
assign 1 277 103
begins 1 277 103
assign 1 277 103
not 0 277 103
assign 1 0 103
assign 1 0 103
return 1 278 103
assign 1 280 103
new 0 280 103
assign 1 280 103
substring 1 280 103
assign 1 280 103
new 0 280 103
assign 1 280 103
split 1 280 103
assign 1 281 103
sizeGet 0 281 103
assign 1 281 103
new 0 281 103
assign 1 281 103
subtract 1 281 103
assign 1 282 103
new 0 282 103
assign 1 283 103
new 0 283 103
assign 1 283 103
lesser 1 283 103
assign 1 284 103
get 1 284 103
addValue 1 284 103
assign 1 285 103
new 0 285 103
assign 1 285 103
add 1 285 103
assign 1 285 103
lesser 1 285 103
assign 1 285 103
new 0 285 103
addValue 1 285 103
incrementValue 0 283 103
return 1 288 103
return 1 294 103
translateEmittedException 0 298 103
assign 1 299 103
new 0 299 103
assign 1 300 103
framesGet 0 300 103
assign 1 301 103
def 1 301 103
assign 1 302 103
new 0 302 103
assign 1 302 103
add 1 302 103
assign 1 303 103
linkedListIteratorGet 0 0 103
assign 1 303 103
hasNextGet 0 303 103
assign 1 303 103
nextGet 0 303 103
assign 1 304 103
add 1 304 103
return 1 307 103
return 1 311 103
assign 1 315 103
undef 1 315 103
assign 1 316 103
new 0 316 103
addValue 1 318 103
assign 1 322 103
new 4 322 103
addFrame 1 322 103
return 1 0 103
assign 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
return 1 0 103
assign 1 0 103
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case 1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case 1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case 1184167343: return bem_translatedGet_0();
case 764669899: return bem_getFrameText_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case 1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case 1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 845792839: return bem_iteratorGet_0();
case 1141730732: return bem_framesTextGet_0();
case 314718434: return bem_print_0();
case 220901978: return bem_emitLangGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case 813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1173085090: return bem_translatedSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1130648479: return bem_framesTextSet_1(bevd_0);
case 209819725: return bem_emitLangSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bevs_inst = (BEC_2_6_9_SystemException)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bevs_inst;
}
}
}
