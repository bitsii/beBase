namespace be.BEL_4_Base {

using System;
using System.Diagnostics;
/* File: source/extended/Command.be */
public class BEC_6_7_SystemCommand : BEC_6_6_SystemObject {
public BEC_6_7_SystemCommand() { }
static BEC_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 1));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static byte[] bels_1 = {};
public static new BEC_6_7_SystemCommand bevs_inst;
public BEC_4_6_TextString bevp_command;
public BEC_2_4_6_IOFileReader bevp_outputReader;
public virtual BEC_6_7_SystemCommand bem_new_1(BEC_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_run_1(BEC_4_6_TextString beva__command) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
this.bem_new_1(beva__command);
bevt_0_tmpvar_phold = this.bem_run_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_run_0() {
BEC_4_3_MathInt bevl_res = null;
BEC_4_3_MathInt bevl_sp = null;
BEC_4_6_TextString bevl_cmdRun = null;
BEC_4_6_TextString bevl_cmdArgs = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
 /* Line: 53 */ {
bevt_0_tmpvar_phold = bevo_0;
bevl_sp = bevp_command.bem_find_1(bevt_0_tmpvar_phold);
if (bevl_sp == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_phold = bevo_1;
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_tmpvar_phold, bevl_sp);
bevt_4_tmpvar_phold = bevo_2;
bevt_3_tmpvar_phold = bevl_sp.bem_add_1(bevt_4_tmpvar_phold);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_tmpvar_phold);
} /* Line: 57 */
 else  /* Line: 58 */ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_4_6_TextString) (new BEC_4_6_TextString(0, bels_1));
} /* Line: 60 */

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 64 */
return bevl_res;
} /*method end*/
public virtual BEC_6_7_SystemCommand bem_open_0() {
this.bem_run_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileReader bem_outputGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 96 */ {
return bevp_outputReader;
} /* Line: 97 */
bevp_outputReader = (BEC_2_4_6_IOFileReader) (new BEC_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_closeOutput_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_outputReader == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 117 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_close_0() {
this.bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_commandSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_command = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_outputReaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_outputReader = (BEC_2_4_6_IOFileReader) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {41, 46, 47, 47, 54, 54, 55, 55, 56, 56, 57, 57, 57, 59, 60, 85, 89, 96, 96, 97, 99, 110, 111, 115, 115, 116, 117, 122, 0, 0, 0, 0};
//int[] bevs_nlecs = {22, 27, 28, 29, 42, 43, 44, 49, 50, 51, 52, 53, 54, 57, 58, 72, 75, 80, 85, 86, 88, 91, 92, 96, 101, 102, 103, 108, 114, 117, 121, 124};
/* BEGIN LINEINFO 
assign 1 41 22
new 1 46 27
assign 1 47 28
run 0 47 28
return 1 47 29
assign 1 54 42
new 0 54 42
assign 1 54 43
find 1 54 43
assign 1 55 44
def 1 55 49
assign 1 56 50
new 0 56 50
assign 1 56 51
substring 2 56 51
assign 1 57 52
new 0 57 52
assign 1 57 53
add 1 57 53
assign 1 57 54
substring 1 57 54
assign 1 59 57
assign 1 60 58
new 0 60 58
return 1 85 72
run 0 89 75
assign 1 96 80
def 1 96 85
return 1 97 86
assign 1 99 88
new 0 99 88
extOpen 0 110 91
return 1 111 92
assign 1 115 96
def 1 115 101
close 0 116 102
assign 1 117 103
closeOutput 0 122 108
return 1 0 114
assign 1 0 117
return 1 0 121
assign 1 0 124
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 108875644: return bem_run_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 866536361: return bem_close_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 847016698: return bem_outputGet_0();
case 1933649148: return bem_commandGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1849988413: return bem_outputReaderGet_0();
case 1010579589: return bem_open_0();
case 1322103434: return bem_closeOutput_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 108875645: return bem_run_1((BEC_4_6_TextString) bevd_0);
case 1944731401: return bem_commandSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1838906160: return bem_outputReaderSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_7_SystemCommand.bevs_inst = (BEC_6_7_SystemCommand)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_7_SystemCommand.bevs_inst;
}
}
}
