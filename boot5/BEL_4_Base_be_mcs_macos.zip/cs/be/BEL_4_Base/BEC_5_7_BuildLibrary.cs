namespace be.BEL_4_Base {
/* File: source/build/Library.be */
public class BEC_5_7_BuildLibrary : BEC_6_6_SystemObject {
public BEC_5_7_BuildLibrary() { }
static BEC_5_7_BuildLibrary() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x2E,0x62,0x65};
public static new BEC_5_7_BuildLibrary bevs_inst;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_5_9_BuildClassInfo bevp_libnameInfo;
public BEC_5_5_BuildBuild bevp_build;
public BEC_2_4_4_IOFilePath bevp_basePath;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public virtual BEC_5_7_BuildLibrary bem_new_2(BEC_4_6_TextString beva_spath, BEC_5_5_BuildBuild beva__build) {
BEC_2_4_4_IOFilePath bevl_libPath = null;
BEC_6_6_SystemObject bevl_libnameNp = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevp_build = beva__build;
if (bevp_libName == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 20 */ {
bevl_libPath = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_basePath = (BEC_2_4_4_IOFilePath) bevl_libPath.bem_parentGet_0();
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_1_tmpvar_phold = bevl_libPath.bem_stepsGet_0();
bevp_libName = (BEC_4_6_TextString) bevt_1_tmpvar_phold.bem_lastGet_0();
} /* Line: 24 */
 else  /* Line: 25 */ {
bevp_basePath = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_new_1(beva_spath);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
} /* Line: 27 */
if (bevp_libName == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevl_libnameNp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevl_libnameNp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, bevp_libName);
if (bevp_exeName == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevp_exeName = bevp_libName;
} /* Line: 32 */
bevt_4_tmpvar_phold = bevp_build.bem_emitterGet_0();
bevp_libnameInfo = (BEC_5_9_BuildClassInfo) (new BEC_5_9_BuildClassInfo()).bem_new_5((BEC_5_8_BuildNamePath) bevl_libnameNp, bevt_4_tmpvar_phold, bevp_emitPath, bevp_libName, bevp_exeName);
} /* Line: 33 */
return this;
} /*method end*/
public virtual BEC_5_7_BuildLibrary bem_new_4(BEC_4_6_TextString beva_spath, BEC_5_5_BuildBuild beva__build, BEC_4_6_TextString beva__libName, BEC_4_6_TextString beva__exeName) {
bevp_libName = beva__libName;
bevp_exeName = beva__exeName;
this.bem_new_2(beva_spath, beva__build);
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_9_BuildClassInfo bem_libnameInfoGet_0() {
return bevp_libnameInfo;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_libnameInfoSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_libnameInfo = (BEC_5_9_BuildClassInfo) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_basePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_basePath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {16, 20, 20, 21, 22, 23, 24, 24, 26, 27, 29, 29, 30, 31, 32, 32, 32, 33, 33, 38, 39, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {23, 24, 29, 30, 31, 32, 33, 34, 37, 38, 40, 45, 46, 47, 48, 53, 54, 56, 57, 62, 63, 64, 68, 71, 75, 78, 82, 85, 89, 92, 96, 99, 103, 106};
/* BEGIN LINEINFO 
assign 1 16 23
assign 1 20 24
undef 1 20 29
assign 1 21 30
new 1 21 30
assign 1 22 31
parentGet 0 22 31
assign 1 23 32
copy 0 23 32
assign 1 24 33
stepsGet 0 24 33
assign 1 24 34
lastGet 0 24 34
assign 1 26 37
new 1 26 37
assign 1 27 38
copy 0 27 38
assign 1 29 40
def 1 29 45
assign 1 30 46
new 0 30 46
fromString 1 31 47
assign 1 32 48
undef 1 32 53
assign 1 32 54
assign 1 33 56
emitterGet 0 33 56
assign 1 33 57
new 5 33 57
assign 1 38 62
assign 1 39 63
new 2 40 64
return 1 0 68
assign 1 0 71
return 1 0 75
assign 1 0 78
return 1 0 82
assign 1 0 85
return 1 0 89
assign 1 0 92
return 1 0 96
assign 1 0 99
return 1 0 103
assign 1 0 106
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1743271113: return bem_libnameInfoGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 2097068593: return bem_emitPathGet_0();
case 186098742: return bem_exeNameGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1803479881: return bem_libNameGet_0();
case 1820417453: return bem_create_0();
case 607794031: return bem_basePathGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1754353366: return bem_libnameInfoSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 596711778: return bem_basePathSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 104713555: return bem_new_2((BEC_4_6_TextString) bevd_0, (BEC_5_5_BuildBuild) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 104713557: return bem_new_4((BEC_4_6_TextString) bevd_0, (BEC_5_5_BuildBuild) bevd_1, (BEC_4_6_TextString) bevd_2, (BEC_4_6_TextString) bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_7_BuildLibrary();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_7_BuildLibrary.bevs_inst = (BEC_5_7_BuildLibrary)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_7_BuildLibrary.bevs_inst;
}
}
}
