namespace be.BEL_4_Base {
/* File: source/build/Pass9.be */
public class BEC_5_5_5_BuildVisitPass9 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass9() { }
static BEC_5_5_5_BuildVisitPass9() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_4_6_TextString bevo_0 = (BEC_4_6_TextString) (new BEC_4_6_TextString(bels_0, 44));
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x53,0x45,0x54};
private static byte[] bels_3 = {0x47,0x45,0x54};
private static byte[] bels_4 = {0x53,0x45,0x54};
private static byte[] bels_5 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_6 = {0x70,0x75,0x74};
private static byte[] bels_7 = {0x67,0x65,0x74};
private static byte[] bels_8 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bels_9 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bels_10 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_11 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_12 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bels_13 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_14 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bels_15 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bels_16 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_5_5_5_BuildVisitPass9 bevs_inst;
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_lnode = null;
BEC_6_6_SystemObject bevl_lbrnode = null;
BEC_6_6_SystemObject bevl_loopif = null;
BEC_6_6_SystemObject bevl_enode = null;
BEC_6_6_SystemObject bevl_brnode = null;
BEC_6_6_SystemObject bevl_bnode = null;
BEC_6_6_SystemObject bevl_pnode = null;
BEC_6_6_SystemObject bevl_init = null;
BEC_6_6_SystemObject bevl_cond = null;
BEC_6_6_SystemObject bevl_atStep = null;
BEC_6_6_SystemObject bevl_estr = null;
BEC_6_6_SystemObject bevl_ac = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_6_6_SystemObject bevl_ntarg = null;
BEC_6_6_SystemObject bevl_isPut = null;
BEC_5_4_BuildNode bevl_narg2 = null;
BEC_5_4_BuildNode bevl_narg3 = null;
BEC_6_6_SystemObject bevl_lin = null;
BEC_6_6_SystemObject bevl_lvar = null;
BEC_6_6_SystemObject bevl_toit = null;
BEC_6_6_SystemObject bevl_tmpn = null;
BEC_6_6_SystemObject bevl_tmpv = null;
BEC_6_6_SystemObject bevl_gin = null;
BEC_6_6_SystemObject bevl_gic = null;
BEC_6_6_SystemObject bevl_asn = null;
BEC_6_6_SystemObject bevl_asc = null;
BEC_6_6_SystemObject bevl_tmpnt = null;
BEC_6_6_SystemObject bevl_tcn = null;
BEC_6_6_SystemObject bevl_tcc = null;
BEC_6_6_SystemObject bevl_tmpng = null;
BEC_6_6_SystemObject bevl_iagn = null;
BEC_6_6_SystemObject bevl_iagc = null;
BEC_6_6_SystemObject bevl_iasn = null;
BEC_6_6_SystemObject bevl_iasc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_22_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_44_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_50_tmpvar_phold = null;
BEC_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_67_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_68_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_74_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_78_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_4_3_MathInt bevt_82_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_83_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_100_tmpvar_phold = null;
BEC_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_4_3_MathInt bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_4_3_MathInt bevt_117_tmpvar_phold = null;
BEC_4_3_MathInt bevt_118_tmpvar_phold = null;
BEC_4_3_MathInt bevt_119_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_120_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_125_tmpvar_phold = null;
BEC_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_4_3_MathInt bevt_131_tmpvar_phold = null;
BEC_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_140_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_initContained_0();
bevt_8_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_8_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 41 */ {
bevt_9_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 41 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_11_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 44 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1696089045, BEL_4_Base.bevn_firstNodeGet_0);
if (bevt_14_tmpvar_phold == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_17_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_i.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevt_16_tmpvar_phold);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 47 */
 else  /* Line: 48 */ {
bevt_18_tmpvar_phold = bevo_0;
bevt_21_tmpvar_phold = bevl_i.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_estr = bevt_18_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 50 */
} /* Line: 45 */
} /* Line: 44 */
 else  /* Line: 41 */ {
break;
} /* Line: 41 */
} /* Line: 41 */
bevt_23_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_23_tmpvar_phold;
} /* Line: 54 */
 else  /* Line: 36 */ {
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_equals_1(bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_27_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_c.bemd_1(671626972, BEL_4_Base.bevn_wasAccessorSet_1, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_typenameGet_0();
bevt_31_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_equals_1(bevt_31_tmpvar_phold);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_35_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_heldGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_1));
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_36_tmpvar_phold);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 62 */ {
bevt_37_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 62 */ {
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_2));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_38_tmpvar_phold);
} /* Line: 63 */
 else  /* Line: 64 */ {
bevt_39_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_3));
bevl_c.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_39_tmpvar_phold);
} /* Line: 65 */
bevt_40_tmpvar_phold = bevl_ac.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpvar_phold);
bevl_c.bemd_0(173192194, BEL_4_Base.bevn_toAccessorName_0);
bevt_42_tmpvar_phold = bevl_c.bemd_0(783669222, BEL_4_Base.bevn_accessorTypeGet_0);
bevt_43_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_4));
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 69 */ {
bevt_44_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_44_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_45_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_45_tmpvar_phold.bem_firstGet_0();
bevt_46_tmpvar_phold = bevl_ntarg.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_46_tmpvar_phold);
bevt_47_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_47_tmpvar_phold);
bevt_48_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_48_tmpvar_phold);
bevt_50_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_nextDescendGet_0();
return bevt_49_tmpvar_phold;
} /* Line: 76 */
 else  /* Line: 77 */ {
bevt_51_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_51_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 79 */
bevt_52_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_52_tmpvar_phold;
} /* Line: 81 */
 else  /* Line: 36 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_equals_1(bevt_55_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_typenameGet_0();
bevt_59_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_63_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_heldGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_64_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_5));
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_64_tmpvar_phold);
if (bevt_60_tmpvar_phold != null && bevt_60_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_60_tmpvar_phold).bevi_bool) /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 86 */ {
bevt_65_tmpvar_phold = beva_node.bem_isFirstGet_0();
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 86 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 88 */
 else  /* Line: 89 */ {
bevl_isPut = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 91 */
if (bevl_isPut != null && bevl_isPut is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_isPut).bevi_bool) /* Line: 93 */ {
bevt_66_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_6));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_67_tmpvar_phold.bem_heldSet_1(bevl_c);
bevt_68_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_68_tmpvar_phold.bem_firstGet_0();
bevl_narg2 = (BEC_5_4_BuildNode) bevl_ntarg.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_69_tmpvar_phold = bevl_ntarg.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
beva_node.bem_typenameSet_1(bevt_69_tmpvar_phold);
bevt_70_tmpvar_phold = bevl_ntarg.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_70_tmpvar_phold);
bevt_71_tmpvar_phold = bevl_ntarg.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
beva_node.bem_containedSet_1(bevt_71_tmpvar_phold);
bevt_72_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_72_tmpvar_phold.bem_addValue_1(bevl_narg2);
bevt_73_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_73_tmpvar_phold.bem_addValue_1(bevl_narg3);
bevt_75_tmpvar_phold = beva_node.bem_containerGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bem_nextDescendGet_0();
return bevt_74_tmpvar_phold;
} /* Line: 111 */
 else  /* Line: 112 */ {
bevt_76_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(3, bels_7));
bevl_c.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_77_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 119 */
bevt_78_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_78_tmpvar_phold;
} /* Line: 121 */
} /* Line: 36 */
} /* Line: 36 */
bevt_80_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_81_tmpvar_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_equals_1(bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_82_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_82_tmpvar_phold);
bevt_83_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_83_tmpvar_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_84_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lin = bevt_84_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_85_tmpvar_phold = bevl_lin.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_lvar = bevt_85_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_toit = bevl_lin.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_pnode.bemd_1(443337441, BEL_4_Base.bevn_containedSet_1, null);
bevl_tmpn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_86_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(4, bels_8));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_87_tmpvar_phold, bevp_build);
bevl_tmpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_gin = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_88_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_88_tmpvar_phold);
bevl_gic = (new BEC_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gic);
bevt_89_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_9));
bevl_gic.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_89_tmpvar_phold);
bevl_gin.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_toit);
bevl_asn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpvar_phold);
bevl_asc = (new BEC_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asc);
bevt_91_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_10));
bevl_asc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_91_tmpvar_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpn);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_5_4_BuildNode) bevl_asn);
bevl_tmpn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_tmpnt = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_92_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_92_tmpvar_phold);
bevl_tmpnt.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_tcn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpvar_phold);
bevl_tcc = (new BEC_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tcc);
bevt_94_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_11));
bevl_tcc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_94_tmpvar_phold);
bevl_tcn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpnt);
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tcn);
bevl_tmpng = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_95_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_95_tmpvar_phold);
bevl_tmpng.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_tmpv);
bevl_iagn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_96_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_96_tmpvar_phold);
bevl_iagc = (new BEC_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iagc);
bevt_97_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_12));
bevl_iagc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_97_tmpvar_phold);
bevl_iagn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_tmpng);
bevl_iasn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_98_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_98_tmpvar_phold);
bevl_iasc = (new BEC_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_iasc);
bevt_99_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_13));
bevl_iasc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_99_tmpvar_phold);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lvar);
bevl_iasn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_iagn);
bevl_brnode.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_iasn);
return (BEC_5_4_BuildNode) bevl_toit;
} /* Line: 212 */
bevt_101_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_102_tmpvar_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_equals_1(bevt_102_tmpvar_phold);
if (bevt_100_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevl_lnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_103_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_5_4_BuildNode) bevl_lnode);
bevl_lbrnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_104_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_104_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_105_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_105_tmpvar_phold);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevt_107_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_107_tmpvar_phold == null) {
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_106_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_106_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_109_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_110_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(5, bels_14));
bevt_108_tmpvar_phold = bevt_109_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_110_tmpvar_phold);
if (bevt_108_tmpvar_phold != null && bevt_108_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_108_tmpvar_phold).bevi_bool) /* Line: 226 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 226 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 226 */
 else  /* Line: 226 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 226 */ {
bevt_111_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(6, bels_15));
bevl_loopif.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_111_tmpvar_phold);
} /* Line: 227 */
bevl_enode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_112_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_112_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_113_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_113_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_114_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_114_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_115_tmpvar_phold = bevl_lnode.bemd_0(1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_5_4_BuildNode) bevt_115_tmpvar_phold;
} /* Line: 241 */
 else  /* Line: 214 */ {
bevt_117_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_118_tmpvar_phold = bevp_ntypes.bem_FORGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bem_equals_1(bevt_118_tmpvar_phold);
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevl_lnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_119_tmpvar_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_119_tmpvar_phold);
beva_node.bem_replaceWith_1((BEC_5_4_BuildNode) bevl_lnode);
bevt_120_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_120_tmpvar_phold.bem_firstGet_0();
bevl_pnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_123_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_124_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_124_tmpvar_phold);
if (bevt_121_tmpvar_phold != null && bevt_121_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_121_tmpvar_phold).bevi_bool) /* Line: 249 */ {
bevt_126_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(55, bels_16));
bevt_125_tmpvar_phold = (BEC_5_10_BuildVisitError) (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_126_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_125_tmpvar_phold);
} /* Line: 250 */
bevt_127_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_init = bevt_127_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_cond = bevl_pnode.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_atStep = null;
bevt_130_tmpvar_phold = bevl_pnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_129_tmpvar_phold = bevt_130_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_131_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_131_tmpvar_phold);
if (bevt_128_tmpvar_phold != null && bevt_128_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_128_tmpvar_phold).bevi_bool) /* Line: 255 */ {
bevl_atStep = bevl_pnode.bemd_0(978128800, BEL_4_Base.bevn_thirdGet_0);
bevl_atStep.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 257 */
bevl_init.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_node.bem_replaceWith_1((BEC_5_4_BuildNode) bevl_lnode);
bevl_lnode.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_init);
bevl_lbrnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_132_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_132_tmpvar_phold);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lbrnode);
bevl_loopif = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_133_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_133_tmpvar_phold);
bevl_loopif.bemd_1(875977779, BEL_4_Base.bevn_takeContents_1, beva_node);
if (bevl_atStep == null) {
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_134_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_136_tmpvar_phold = bevl_loopif.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_135_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_atStep);
} /* Line: 273 */
bevl_loopif.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_pnode);
bevl_lbrnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_loopif);
bevl_enode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_137_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_137_tmpvar_phold);
bevl_loopif.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_brnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_138_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_138_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevl_bnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_139_tmpvar_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_139_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
return (BEC_5_4_BuildNode) bevl_init;
} /* Line: 290 */
} /* Line: 214 */
bevt_140_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_140_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 36, 36, 40, 41, 41, 41, 43, 44, 44, 44, 45, 45, 45, 45, 46, 46, 46, 47, 49, 49, 49, 49, 49, 50, 50, 54, 54, 55, 55, 55, 59, 60, 61, 61, 62, 62, 62, 62, 62, 62, 62, 62, 62, 0, 0, 0, 62, 0, 0, 0, 63, 63, 65, 65, 67, 67, 68, 69, 69, 69, 70, 70, 71, 71, 73, 73, 74, 74, 75, 75, 76, 76, 76, 78, 78, 79, 81, 81, 82, 82, 82, 84, 85, 86, 86, 86, 86, 86, 86, 86, 86, 86, 0, 0, 0, 86, 0, 0, 0, 88, 91, 94, 94, 95, 95, 96, 96, 99, 100, 102, 103, 105, 105, 106, 106, 107, 107, 109, 109, 110, 110, 111, 111, 111, 117, 117, 118, 118, 119, 121, 121, 123, 123, 123, 124, 124, 125, 125, 126, 127, 127, 128, 128, 129, 130, 149, 150, 151, 151, 152, 152, 153, 155, 156, 156, 157, 158, 159, 159, 160, 162, 163, 164, 164, 165, 166, 167, 167, 168, 169, 171, 172, 174, 175, 176, 176, 177, 179, 180, 181, 181, 182, 183, 184, 184, 185, 187, 189, 190, 191, 191, 192, 194, 195, 196, 196, 197, 198, 199, 199, 200, 202, 203, 204, 204, 205, 206, 207, 207, 208, 209, 211, 212, 214, 214, 214, 215, 216, 217, 217, 218, 219, 220, 221, 221, 222, 223, 224, 224, 225, 226, 226, 226, 226, 226, 226, 0, 0, 0, 227, 227, 229, 230, 231, 231, 232, 233, 234, 235, 235, 236, 237, 238, 239, 239, 240, 241, 241, 242, 242, 242, 243, 244, 245, 245, 246, 247, 247, 248, 249, 249, 249, 249, 250, 250, 250, 252, 252, 253, 254, 255, 255, 255, 255, 256, 257, 259, 261, 262, 264, 265, 266, 266, 267, 268, 269, 270, 270, 271, 272, 272, 273, 273, 273, 275, 276, 277, 278, 279, 279, 280, 281, 282, 283, 283, 284, 285, 286, 287, 287, 288, 290, 292, 292};
public static new int[] bevs_smnlec
 = new int[] {206, 207, 208, 210, 211, 212, 215, 217, 218, 219, 220, 222, 223, 224, 229, 230, 231, 232, 233, 236, 237, 238, 239, 240, 241, 242, 250, 251, 254, 255, 256, 258, 259, 260, 261, 262, 263, 264, 265, 267, 268, 269, 270, 271, 273, 276, 280, 283, 285, 288, 292, 295, 296, 299, 300, 302, 303, 304, 305, 306, 307, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 324, 325, 326, 328, 329, 332, 333, 334, 336, 337, 338, 339, 340, 341, 343, 344, 345, 346, 347, 349, 352, 356, 359, 361, 364, 368, 371, 374, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 402, 403, 404, 405, 406, 408, 409, 413, 414, 415, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 497, 498, 499, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 521, 522, 523, 524, 526, 529, 533, 536, 537, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 558, 559, 560, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 575, 576, 577, 579, 580, 581, 582, 583, 584, 585, 586, 588, 589, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 609, 610, 611, 612, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 634, 635};
/* BEGIN LINEINFO 
assign 1 36 206
typenameGet 0 36 206
assign 1 36 207
CALLGet 0 36 207
assign 1 36 208
equals 1 36 208
initContained 0 40 210
assign 1 41 211
containedGet 0 41 211
assign 1 41 212
iteratorGet 0 41 212
assign 1 41 215
hasNextGet 0 41 215
assign 1 43 217
nextGet 0 43 217
assign 1 44 218
typenameGet 0 44 218
assign 1 44 219
PARENSGet 0 44 219
assign 1 44 220
equals 1 44 220
assign 1 45 222
containedGet 0 45 222
assign 1 45 223
firstNodeGet 0 45 223
assign 1 45 224
def 1 45 229
assign 1 46 230
containedGet 0 46 230
assign 1 46 231
firstGet 0 46 231
beforeInsert 1 46 232
delete 0 47 233
assign 1 49 236
new 0 49 236
assign 1 49 237
containedGet 0 49 237
assign 1 49 238
lengthGet 0 49 238
assign 1 49 239
toString 0 49 239
assign 1 49 240
add 1 49 240
assign 1 50 241
new 2 50 241
throw 1 50 242
assign 1 54 250
nextDescendGet 0 54 250
return 1 54 251
assign 1 55 254
typenameGet 0 55 254
assign 1 55 255
ACCESSORGet 0 55 255
assign 1 55 256
equals 1 55 256
assign 1 59 258
heldGet 0 59 258
assign 1 60 259
new 0 60 259
assign 1 61 260
new 0 61 260
wasAccessorSet 1 61 261
assign 1 62 262
containerGet 0 62 262
assign 1 62 263
typenameGet 0 62 263
assign 1 62 264
CALLGet 0 62 264
assign 1 62 265
equals 1 62 265
assign 1 62 267
containerGet 0 62 267
assign 1 62 268
heldGet 0 62 268
assign 1 62 269
nameGet 0 62 269
assign 1 62 270
new 0 62 270
assign 1 62 271
equals 1 62 271
assign 1 0 273
assign 1 0 276
assign 1 0 280
assign 1 62 283
isFirstGet 0 62 283
assign 1 0 285
assign 1 0 288
assign 1 0 292
assign 1 63 295
new 0 63 295
accessorTypeSet 1 63 296
assign 1 65 299
new 0 65 299
accessorTypeSet 1 65 300
assign 1 67 302
nameGet 0 67 302
nameSet 1 67 303
toAccessorName 0 68 304
assign 1 69 305
accessorTypeGet 0 69 305
assign 1 69 306
new 0 69 306
assign 1 69 307
equals 1 69 307
assign 1 70 309
containerGet 0 70 309
heldSet 1 70 310
assign 1 71 311
containedGet 0 71 311
assign 1 71 312
firstGet 0 71 312
assign 1 73 313
typenameGet 0 73 313
typenameSet 1 73 314
assign 1 74 315
heldGet 0 74 315
heldSet 1 74 316
assign 1 75 317
containedGet 0 75 317
containedSet 1 75 318
assign 1 76 319
containerGet 0 76 319
assign 1 76 320
nextDescendGet 0 76 320
return 1 76 321
assign 1 78 324
CALLGet 0 78 324
typenameSet 1 78 325
heldSet 1 79 326
assign 1 81 328
nextDescendGet 0 81 328
return 1 81 329
assign 1 82 332
typenameGet 0 82 332
assign 1 82 333
IDXACCGet 0 82 333
assign 1 82 334
equals 1 82 334
assign 1 84 336
heldGet 0 84 336
assign 1 85 337
new 0 85 337
assign 1 86 338
containerGet 0 86 338
assign 1 86 339
typenameGet 0 86 339
assign 1 86 340
CALLGet 0 86 340
assign 1 86 341
equals 1 86 341
assign 1 86 343
containerGet 0 86 343
assign 1 86 344
heldGet 0 86 344
assign 1 86 345
nameGet 0 86 345
assign 1 86 346
new 0 86 346
assign 1 86 347
equals 1 86 347
assign 1 0 349
assign 1 0 352
assign 1 0 356
assign 1 86 359
isFirstGet 0 86 359
assign 1 0 361
assign 1 0 364
assign 1 0 368
assign 1 88 371
new 0 88 371
assign 1 91 374
new 0 91 374
assign 1 94 377
new 0 94 377
nameSet 1 94 378
assign 1 95 379
containerGet 0 95 379
heldSet 1 95 380
assign 1 96 381
containedGet 0 96 381
assign 1 96 382
firstGet 0 96 382
assign 1 99 383
nextPeerGet 0 99 383
assign 1 100 384
nextPeerGet 0 100 384
delete 0 102 385
delete 0 103 386
assign 1 105 387
typenameGet 0 105 387
typenameSet 1 105 388
assign 1 106 389
heldGet 0 106 389
heldSet 1 106 390
assign 1 107 391
containedGet 0 107 391
containedSet 1 107 392
assign 1 109 393
containerGet 0 109 393
addValue 1 109 394
assign 1 110 395
containerGet 0 110 395
addValue 1 110 396
assign 1 111 397
containerGet 0 111 397
assign 1 111 398
nextDescendGet 0 111 398
return 1 111 399
assign 1 117 402
new 0 117 402
nameSet 1 117 403
assign 1 118 404
CALLGet 0 118 404
typenameSet 1 118 405
heldSet 1 119 406
assign 1 121 408
nextDescendGet 0 121 408
return 1 121 409
assign 1 123 413
typenameGet 0 123 413
assign 1 123 414
FOREACHGet 0 123 414
assign 1 123 415
equals 1 123 415
assign 1 124 417
WHILEGet 0 124 417
typenameSet 1 124 418
assign 1 125 419
containedGet 0 125 419
assign 1 125 420
firstGet 0 125 420
assign 1 126 421
secondGet 0 126 421
assign 1 127 422
containedGet 0 127 422
assign 1 127 423
firstGet 0 127 423
assign 1 128 424
containedGet 0 128 424
assign 1 128 425
firstGet 0 128 425
assign 1 129 426
secondGet 0 129 426
containedSet 1 130 427
assign 1 149 428
new 1 149 428
copyLoc 1 150 429
assign 1 151 430
VARGet 0 151 430
typenameSet 1 151 431
assign 1 152 432
new 0 152 432
assign 1 152 433
tmpVar 2 152 433
heldSet 1 153 434
assign 1 155 435
new 1 155 435
assign 1 156 436
CALLGet 0 156 436
typenameSet 1 156 437
assign 1 157 438
new 0 157 438
heldSet 1 158 439
assign 1 159 440
new 0 159 440
nameSet 1 159 441
addValue 1 160 442
assign 1 162 443
new 1 162 443
copyLoc 1 163 444
assign 1 164 445
CALLGet 0 164 445
typenameSet 1 164 446
assign 1 165 447
new 0 165 447
heldSet 1 166 448
assign 1 167 449
new 0 167 449
nameSet 1 167 450
addValue 1 168 451
addValue 1 169 452
beforeInsert 1 171 453
addVariable 0 172 454
assign 1 174 455
new 1 174 455
copyLoc 1 175 456
assign 1 176 457
VARGet 0 176 457
typenameSet 1 176 458
heldSet 1 177 459
assign 1 179 460
new 1 179 460
copyLoc 1 180 461
assign 1 181 462
CALLGet 0 181 462
typenameSet 1 181 463
assign 1 182 464
new 0 182 464
heldSet 1 183 465
assign 1 184 466
new 0 184 466
nameSet 1 184 467
addValue 1 185 468
addValue 1 187 469
assign 1 189 470
new 1 189 470
copyLoc 1 190 471
assign 1 191 472
VARGet 0 191 472
typenameSet 1 191 473
heldSet 1 192 474
assign 1 194 475
new 1 194 475
copyLoc 1 195 476
assign 1 196 477
CALLGet 0 196 477
typenameSet 1 196 478
assign 1 197 479
new 0 197 479
heldSet 1 198 480
assign 1 199 481
new 0 199 481
nameSet 1 199 482
addValue 1 200 483
assign 1 202 484
new 1 202 484
copyLoc 1 203 485
assign 1 204 486
CALLGet 0 204 486
typenameSet 1 204 487
assign 1 205 488
new 0 205 488
heldSet 1 206 489
assign 1 207 490
new 0 207 490
nameSet 1 207 491
addValue 1 208 492
addValue 1 209 493
prepend 1 211 494
return 1 212 495
assign 1 214 497
typenameGet 0 214 497
assign 1 214 498
WHILEGet 0 214 498
assign 1 214 499
equals 1 214 499
assign 1 215 501
new 1 215 501
copyLoc 1 216 502
assign 1 217 503
LOOPGet 0 217 503
typenameSet 1 217 504
replaceWith 1 218 505
assign 1 219 506
new 1 219 506
copyLoc 1 220 507
assign 1 221 508
BRACESGet 0 221 508
typenameSet 1 221 509
addValue 1 222 510
assign 1 223 511
assign 1 224 512
IFGet 0 224 512
typenameSet 1 224 513
addValue 1 225 514
assign 1 226 515
heldGet 0 226 515
assign 1 226 516
def 1 226 521
assign 1 226 522
heldGet 0 226 522
assign 1 226 523
new 0 226 523
assign 1 226 524
equals 1 226 524
assign 1 0 526
assign 1 0 529
assign 1 0 533
assign 1 227 536
new 0 227 536
heldSet 1 227 537
assign 1 229 539
new 1 229 539
copyLoc 1 230 540
assign 1 231 541
ELSEGet 0 231 541
typenameSet 1 231 542
addValue 1 232 543
assign 1 233 544
new 1 233 544
copyLoc 1 234 545
assign 1 235 546
BRACESGet 0 235 546
typenameSet 1 235 547
addValue 1 236 548
assign 1 237 549
new 1 237 549
copyLoc 1 238 550
assign 1 239 551
BREAKGet 0 239 551
typenameSet 1 239 552
addValue 1 240 553
assign 1 241 554
nextDescendGet 0 241 554
return 1 241 555
assign 1 242 558
typenameGet 0 242 558
assign 1 242 559
FORGet 0 242 559
assign 1 242 560
equals 1 242 560
assign 1 243 562
new 1 243 562
copyLoc 1 244 563
assign 1 245 564
LOOPGet 0 245 564
typenameSet 1 245 565
replaceWith 1 246 566
assign 1 247 567
containedGet 0 247 567
assign 1 247 568
firstGet 0 247 568
delete 0 248 569
assign 1 249 570
containedGet 0 249 570
assign 1 249 571
lengthGet 0 249 571
assign 1 249 572
new 0 249 572
assign 1 249 573
lesser 1 249 573
assign 1 250 575
new 0 250 575
assign 1 250 576
new 2 250 576
throw 1 250 577
assign 1 252 579
containedGet 0 252 579
assign 1 252 580
firstGet 0 252 580
assign 1 253 581
secondGet 0 253 581
assign 1 254 582
assign 1 255 583
containedGet 0 255 583
assign 1 255 584
lengthGet 0 255 584
assign 1 255 585
new 0 255 585
assign 1 255 586
greater 1 255 586
assign 1 256 588
thirdGet 0 256 588
delete 0 257 589
delete 0 259 591
replaceWith 1 261 592
beforeInsert 1 262 593
assign 1 264 594
new 1 264 594
copyLoc 1 265 595
assign 1 266 596
BRACESGet 0 266 596
typenameSet 1 266 597
addValue 1 267 598
assign 1 268 599
new 1 268 599
copyLoc 1 269 600
assign 1 270 601
IFGet 0 270 601
typenameSet 1 270 602
takeContents 1 271 603
assign 1 272 604
def 1 272 609
assign 1 273 610
containedGet 0 273 610
assign 1 273 611
firstGet 0 273 611
addValue 1 273 612
prepend 1 275 614
addValue 1 276 615
assign 1 277 616
new 1 277 616
copyLoc 1 278 617
assign 1 279 618
ELSEGet 0 279 618
typenameSet 1 279 619
addValue 1 280 620
assign 1 281 621
new 1 281 621
copyLoc 1 282 622
assign 1 283 623
BRACESGet 0 283 623
typenameSet 1 283 624
addValue 1 284 625
assign 1 285 626
new 1 285 626
copyLoc 1 286 627
assign 1 287 628
BREAKGet 0 287 628
typenameSet 1 287 629
addValue 1 288 630
return 1 290 631
assign 1 292 634
nextDescendGet 0 292 634
return 1 292 635
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass9.bevs_inst = (BEC_5_5_5_BuildVisitPass9)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass9.bevs_inst;
}
}
}
