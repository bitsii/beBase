namespace be.BEL_4_Base {

using System;
using System.Reflection;
    /* File: source/base/EcProcess.be */
public class BEC_6_7_SystemProcess : BEC_6_6_SystemObject {
public BEC_6_7_SystemProcess() { }
static BEC_6_7_SystemProcess() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static new BEC_6_7_SystemProcess bevs_inst;
public BEC_9_5_ContainerArray bevp_args;
public BEC_4_3_MathInt bevp_numArgs;
public BEC_6_6_SystemObject bevp_execName;
public BEC_6_6_SystemObject bevp_target;
public BEC_6_6_SystemObject bevp_result;
public BEC_6_6_SystemObject bevp_except;
public BEC_6_15_SystemCurrentPlatform bevp_platform;
public BEC_6_6_SystemObject bevp_fullExecName;
public override BEC_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_6_7_SystemProcess bem_default_0() {
bevp_platform = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
this.bem_prepArgs_0();
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_execNameGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 42 */ {
bevt_1_tmpvar_phold = this.bem_fullExecNameGet_0();
return bevt_1_tmpvar_phold;
} /* Line: 42 */
if (bevp_execName == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 43 */ {

            bevp_execName = new BEC_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            //bevp_execName = new BEC_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Assembly.GetEntryAssembly().Location));
            } /* Line: 44 */
return bevp_execName;
} /*method end*/
public virtual BEC_2_4_4_IOFilePath bem_execPathGet_0() {
BEC_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_execNameGet_0();
bevt_0_tmpvar_phold = (BEC_2_4_4_IOFilePath) (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullExecNameGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_fullExecName == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 62 */ {

            //bevp_execName = new BEC_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(Environment.GetCommandLineArgs()[0]));
            bevp_fullExecName = new BEC_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(System.Reflection.Assembly.GetEntryAssembly().Location));
            } /* Line: 63 */
return bevp_fullExecName;
} /*method end*/
public virtual BEC_6_7_SystemProcess bem_prepArgs_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
 /* Line: 75 */ {
if (bevp_args == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevp_args = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_0();

            for (int i = 0;i < be.BELS_Base.BECS_Runtime.args.Length;i++) {
                bevp_args.bem_addValue_1(new BEC_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BELS_Base.BECS_Runtime.args[i])));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 101 */
} /* Line: 76 */
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exit_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_exit_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exit_1(BEC_4_3_MathInt beva_code) {

     Environment.Exit(beva_code.bevi_int);
     return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_start_1(BEC_6_6_SystemObject beva__target) {
BEC_6_6_SystemObject bevl_e = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevp_target = beva__target;
try  /* Line: 126 */ {
bevp_result = bevp_target.bemd_0(1081571542, BEL_4_Base.bevn_main_0);
} /* Line: 127 */
 catch (System.Exception beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
return bevt_0_tmpvar_phold;
} /* Line: 131 */
return bevp_result;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_startByName_1(BEC_6_6_SystemObject beva__name) {
BEC_6_6_SystemObject bevl_t = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_createInstance_1((BEC_4_6_TextString) beva__name);
bevl_t = bevt_0_tmpvar_phold.bemd_0(104713553, BEL_4_Base.bevn_new_0);
bevt_1_tmpvar_phold = this.bem_start_1(bevl_t);
return bevt_1_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_numArgsGet_0() {
return bevp_numArgs;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_numArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_numArgs = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_execNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_execName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_targetSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_target = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_resultGet_0() {
return bevp_result;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_resultSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_result = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_exceptSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_except = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_15_SystemCurrentPlatform bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_platform = (BEC_6_15_SystemCurrentPlatform) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_fullExecNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_fullExecName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
//int[] bevs_nlcs = {35, 38, 42, 42, 42, 43, 43, 51, 55, 55, 55, 62, 62, 70, 76, 76, 77, 101, 108, 108, 125, 127, 129, 130, 131, 131, 133, 137, 137, 138, 138, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//int[] bevs_nlecs = {24, 25, 32, 34, 35, 37, 42, 47, 52, 53, 54, 58, 63, 68, 73, 78, 79, 84, 91, 92, 103, 105, 109, 110, 111, 112, 114, 120, 121, 122, 123, 126, 129, 133, 136, 140, 144, 147, 151, 154, 158, 161, 165, 168, 172};
/* BEGIN LINEINFO 
assign 1 35 24
new 0 35 24
prepArgs 0 38 25
assign 1 42 32
new 0 42 32
assign 1 42 34
fullExecNameGet 0 42 34
return 1 42 35
assign 1 43 37
undef 1 43 42
return 1 51 47
assign 1 55 52
execNameGet 0 55 52
assign 1 55 53
apNew 1 55 53
return 1 55 54
assign 1 62 58
undef 1 62 63
return 1 70 68
assign 1 76 73
undef 1 76 78
assign 1 77 79
new 0 77 79
assign 1 101 84
sizeGet 0 101 84
assign 1 108 91
new 0 108 91
exit 1 108 92
assign 1 125 103
assign 1 127 105
main 0 127 105
assign 1 129 109
print 0 130 110
assign 1 131 111
new 0 131 111
return 1 131 112
return 1 133 114
assign 1 137 120
createInstance 1 137 120
assign 1 137 121
new 0 137 121
assign 1 138 122
start 1 138 122
return 1 138 123
return 1 0 126
assign 1 0 129
return 1 0 133
assign 1 0 136
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
return 1 0 165
assign 1 0 168
assign 1 0 172
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1502128718: return bem_default_0();
case 104713553: return bem_new_0();
case 1261441745: return bem_execPathGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 1455253956: return bem_numArgsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1289358001: return bem_exit_0();
case 1422062549: return bem_execNameGet_0();
case 2127864150: return bem_argsGet_0();
case 559681686: return bem_resultGet_0();
case 2089652699: return bem_prepArgs_0();
case 1213659612: return bem_fullExecNameGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 2107175306: return bem_targetGet_0();
case 1820417453: return bem_create_0();
case 2118553618: return bem_exceptGet_0();
case 786424307: return bem_tagGet_0();
case 515445972: return bem_platformGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1466336209: return bem_numArgsSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1897185388: return bem_start_1(bevd_0);
case 548599433: return bem_resultSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1289358000: return bem_exit_1((BEC_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1410980296: return bem_execNameSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2096093053: return bem_targetSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1224741865: return bem_fullExecNameSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2107471365: return bem_exceptSet_1(bevd_0);
case 1463603510: return bem_startByName_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_6_7_SystemProcess();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_6_7_SystemProcess.bevs_inst = (BEC_6_7_SystemProcess)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_6_7_SystemProcess.bevs_inst;
}
}
}
