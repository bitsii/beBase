namespace be.BEL_4_Base {

using System;
    /* File: source/base/Array.be */
public class BEC_9_5_ContainerArray : BEC_6_6_SystemObject {
public BEC_9_5_ContainerArray() { }
static BEC_9_5_ContainerArray() { }

   
    public BEC_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_9_5_ContainerArray(BEC_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_capacity = new BEC_4_3_MathInt(bevi_array.Length);
        this.bevp_multiplier = new BEC_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_4_3_MathInt bevo_0 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_4_3_MathInt bevo_4 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_5 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_7 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_8 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_9 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_10 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_11 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_12 = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
public static new BEC_9_5_ContainerArray bevs_inst;
public BEC_6_6_SystemObject bevp_varray;
public BEC_4_3_MathInt bevp_length;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_multiplier;
public override BEC_6_6_SystemObject bem_new_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(16));
this.bem_new_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_1(BEC_4_3_MathInt beva_leni) {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_new_2(BEC_4_3_MathInt beva_leni, BEC_4_3_MathInt beva_capi) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 159 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 159 */ {
bevt_4_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 160 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_6_tmpvar_phold = bevp_length.bem_equals_1(beva_leni);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 165 */ {
return this;
} /* Line: 166 */
} /* Line: 165 */

      bevi_array = new BEC_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni;
bevp_capacity = beva_capi;
bevp_multiplier = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(2));
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_isEmptyGet_0() {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_length.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 204 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varrayGet_0() {
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_0() {
return this;
} /*method end*/
public override BEC_4_6_TextString bem_serializeToString_0() {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_firstGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lastGet_0() {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_2;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_posi, BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_posi.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_3_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (BEC_6_9_SystemException) (new BEC_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 243 */
bevt_4_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevp_length);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_6_tmpvar_phold = bevo_4;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 246 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_posi) {
BEC_6_6_SystemObject bevl_val = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_3_tmpvar_phold = beva_posi.bem_lesser_1(bevp_length);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 276 */
return bevl_val;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_delete_1(BEC_4_3_MathInt beva_pos) {
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_pos.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_1_tmpvar_phold = bevo_6;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 288 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevt_5_tmpvar_phold = bevo_7;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 288 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_8;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 293 */
bevt_9_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_iteratorGet_0() {
BEC_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_8_ContainerArrayIterator) (new BEC_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_clear_0() {
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 303 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 303 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 303 */
 else  /* Line: 303 */ {
break;
} /* Line: 303 */
} /* Line: 303 */
return this;
} /*method end*/
public override BEC_6_6_SystemObject bem_copy_0() {
BEC_9_5_ContainerArray bevl_n = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_9_5_ContainerArray) this.bem_create_0();
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 310 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 310 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 310 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
return bevl_n;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_create_1(BEC_4_3_MathInt beva_len) {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public override BEC_6_6_SystemObject bem_create_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) (new BEC_9_5_ContainerArray()).bem_new_1(bevp_length);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_add_1(BEC_9_5_ContainerArray beva_xi) {
BEC_9_5_ContainerArray bevl_yi = null;
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_2_tmpvar_phold = bevp_length.bem_add_1(bevt_3_tmpvar_phold);
bevl_yi = (BEC_9_5_ContainerArray) this.bem_create_1(bevt_2_tmpvar_phold);
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_4_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 323 */ {
bevl_c = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_put_2(bevl_i, bevl_c);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 325 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
bevt_1_tmpvar_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_5_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevl_c = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_put_2(bevl_i, bevl_c);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return (BEC_9_5_ContainerArray) bevl_yi;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_0();
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortInPlace_0() {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
this.bem_sortInPlace_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_sortInPlace_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_6_6_SystemObject bevl_hold = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 343 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 343 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 345 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 346 */ {
bevl_c = bevl_j;
} /* Line: 347 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 345 */
 else  /* Line: 345 */ {
break;
} /* Line: 345 */
} /* Line: 345 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 343 */
 else  /* Line: 343 */ {
break;
} /* Line: 343 */
} /* Line: 343 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeIn_2(BEC_9_5_ContainerArray beva_first, BEC_9_5_ContainerArray beva_second) {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_fi = null;
BEC_4_3_MathInt bevl_si = null;
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_6_6_SystemObject bevl_fo = null;
BEC_6_6_SystemObject bevl_so = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fi = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_si = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 362 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 362 */ {
bevt_2_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_3_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 363 */
 else  /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 363 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 366 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 368 */
 else  /* Line: 369 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 371 */
} /* Line: 366 */
 else  /* Line: 363 */ {
bevt_5_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 373 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 376 */
 else  /* Line: 363 */ {
bevt_6_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 380 */
} /* Line: 363 */
} /* Line: 363 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 382 */
 else  /* Line: 362 */ {
break;
} /* Line: 362 */
} /* Line: 362 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_0() {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_mergeSort_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) {
BEC_4_3_MathInt bevl_mlen = null;
BEC_9_5_ContainerArray bevl_ra = null;
BEC_4_3_MathInt bevl_shalf = null;
BEC_4_3_MathInt bevl_fhalf = null;
BEC_4_3_MathInt bevl_fend = null;
BEC_9_5_ContainerArray bevl_fa = null;
BEC_9_5_ContainerArray bevl_sa = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_9;
bevt_0_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_3_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 393 */
 else  /* Line: 392 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevt_6_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(1));
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 397 */
 else  /* Line: 398 */ {
bevt_9_tmpvar_phold = bevo_11;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_9_5_ContainerArray) this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 406 */
} /* Line: 392 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_lengthSet_1(BEC_4_3_MathInt beva_newlen) {
BEC_4_3_MathInt bevl_newcap = null;
BEC_4_3_MathInt bevl_oldcap = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_newlen.bem_greaterEquals_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);
bevl_oldcap = bevp_capacity;

         //BEC_6_6_SystemObject[] bevls_array = bevi_array;
         Array.Resize(ref bevi_array, bevl_newcap.bevi_int);
         //this.bevi_array = bevls_array;
         bevp_capacity = bevl_newcap;
} /* Line: 460 */
bevl_i = bevp_length;
bevp_length = beva_newlen;
while (true)
 /* Line: 465 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_newlen);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 465 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 467 */
 else  /* Line: 465 */ {
break;
} /* Line: 465 */
} /* Line: 465 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 472 */ {
while (true)
 /* Line: 473 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 473 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValue_1(bevt_2_tmpvar_phold);
} /* Line: 474 */
 else  /* Line: 473 */ {
break;
} /* Line: 473 */
} /* Line: 473 */
} /* Line: 473 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addAll_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 481 */
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addWhole_1(BEC_6_6_SystemObject beva_val) {
this.bem_put_2(bevp_length, beva_val);
return this;
} /*method end*/
public virtual BEC_9_5_ContainerArray bem_addValue_1(BEC_6_6_SystemObject beva_val) {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 490 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 490 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 490 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 490 */
 else  /* Line: 490 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 490 */ {
this.bem_addAll_1(beva_val);
} /* Line: 491 */
 else  /* Line: 492 */ {
this.bem_put_2(bevp_length, beva_val);
} /* Line: 493 */
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_find_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 499 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 499 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 501 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 501 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 501 */
 else  /* Line: 501 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 501 */ {
return bevl_i;
} /* Line: 502 */
bevl_i.bem_incrementValue_0();
} /* Line: 499 */
 else  /* Line: 499 */ {
break;
} /* Line: 499 */
} /* Line: 499 */
return null;
} /*method end*/
public virtual BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_value) {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 509 */ {
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 510 */
bevt_3_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_1(BEC_6_6_SystemObject beva_value) {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public virtual BEC_4_3_MathInt bem_sortedFind_2(BEC_6_6_SystemObject beva_value, BEC_5_4_LogicBool beva_returnNoMatch) {
BEC_4_3_MathInt bevl_high = null;
BEC_4_3_MathInt bevl_low = null;
BEC_4_3_MathInt bevl_lastMid = null;
BEC_4_3_MathInt bevl_mid = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 529 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_12;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 532 */ {
return bevl_mid;
} /* Line: 533 */
 else  /* Line: 532 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 534 */ {
bevl_low = bevl_mid;
} /* Line: 536 */
 else  /* Line: 532 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevl_high = bevl_mid;
} /* Line: 539 */
} /* Line: 532 */
} /* Line: 532 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 542 */ {
bevt_9_tmpvar_phold = bevl_lastMid.bem_equals_1(bevl_mid);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 542 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 542 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 542 */
 else  /* Line: 542 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 542 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 543 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 543 */ {
return bevl_low;
} /* Line: 544 */
return null;
} /* Line: 546 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 549 */ {
return null;
} /* Line: 550 */
} /* Line: 549 */
} /*method end*/
public virtual BEC_6_6_SystemObject bem_varraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public virtual BEC_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_capacitySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_capacity = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public virtual BEC_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_multiplierSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) {
bevp_multiplier = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {145, 145, 145, 149, 159, 159, 0, 159, 159, 0, 0, 160, 160, 160, 162, 162, 165, 166, 192, 193, 194, 199, 203, 203, 204, 204, 206, 206, 216, 216, 220, 220, 224, 224, 228, 228, 228, 232, 232, 232, 232, 242, 242, 243, 243, 243, 245, 246, 246, 246, 269, 269, 269, 0, 0, 0, 282, 286, 287, 287, 288, 288, 289, 289, 289, 289, 288, 291, 292, 292, 292, 293, 293, 295, 295, 299, 299, 303, 303, 304, 303, 309, 310, 310, 311, 311, 310, 313, 316, 316, 318, 318, 321, 321, 321, 322, 323, 0, 323, 323, 324, 325, 327, 0, 327, 327, 328, 329, 331, 335, 335, 339, 339, 343, 343, 344, 345, 345, 346, 346, 346, 347, 345, 350, 351, 351, 352, 343, 357, 358, 359, 360, 361, 362, 363, 363, 0, 0, 0, 364, 365, 366, 367, 368, 370, 371, 373, 374, 375, 376, 377, 378, 379, 380, 382, 387, 387, 387, 391, 392, 392, 393, 393, 393, 394, 394, 395, 395, 396, 396, 396, 397, 399, 399, 400, 401, 402, 403, 404, 405, 406, 430, 431, 432, 460, 463, 464, 465, 466, 467, 472, 472, 473, 474, 474, 480, 480, 481, 481, 486, 490, 490, 490, 0, 0, 0, 491, 493, 499, 499, 500, 501, 501, 501, 0, 0, 0, 502, 499, 505, 509, 509, 509, 510, 510, 512, 512, 518, 518, 518, 525, 526, 530, 530, 530, 530, 531, 532, 533, 534, 536, 537, 539, 542, 542, 542, 0, 0, 0, 543, 543, 0, 0, 0, 544, 546, 548, 549, 550, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 48, 52, 63, 68, 69, 72, 77, 78, 81, 85, 86, 87, 89, 94, 95, 97, 102, 103, 104, 108, 115, 116, 118, 119, 121, 122, 132, 133, 137, 138, 143, 144, 149, 150, 151, 157, 158, 159, 160, 170, 171, 173, 174, 175, 177, 179, 180, 181, 193, 194, 196, 198, 201, 205, 211, 226, 228, 229, 230, 233, 235, 236, 237, 238, 239, 245, 246, 247, 248, 249, 250, 252, 253, 257, 258, 263, 266, 268, 269, 282, 283, 286, 288, 289, 290, 296, 300, 301, 305, 306, 318, 319, 320, 321, 322, 322, 325, 327, 328, 329, 335, 335, 338, 340, 341, 342, 348, 352, 353, 357, 358, 372, 375, 377, 378, 381, 383, 384, 385, 387, 389, 395, 396, 397, 398, 399, 422, 423, 424, 425, 426, 429, 431, 433, 435, 438, 442, 445, 446, 447, 449, 450, 453, 454, 458, 460, 461, 462, 465, 467, 468, 469, 473, 484, 485, 486, 506, 507, 508, 510, 511, 512, 515, 516, 518, 519, 520, 521, 522, 523, 526, 527, 528, 529, 530, 531, 532, 533, 534, 544, 546, 547, 552, 554, 555, 558, 560, 561, 573, 578, 581, 583, 584, 596, 601, 602, 603, 608, 615, 620, 621, 623, 626, 630, 633, 636, 647, 650, 652, 653, 658, 659, 661, 664, 668, 671, 673, 679, 686, 687, 692, 693, 694, 696, 697, 702, 703, 704, 725, 726, 729, 730, 731, 732, 733, 734, 736, 739, 741, 744, 746, 750, 755, 756, 758, 761, 765, 769, 770, 772, 775, 779, 782, 784, 786, 787, 789, 794, 798, 801, 804, 808, 811};
/* BEGIN LINEINFO 
assign 1 145 46
new 0 145 46
assign 1 145 47
new 0 145 47
new 2 145 48
new 2 149 52
assign 1 159 63
undef 1 159 68
assign 1 0 69
assign 1 159 72
undef 1 159 77
assign 1 0 78
assign 1 0 81
assign 1 160 85
new 0 160 85
assign 1 160 86
new 1 160 86
throw 1 160 87
assign 1 162 89
def 1 162 94
assign 1 165 95
equals 1 165 95
return 1 166 97
assign 1 192 102
assign 1 193 103
assign 1 194 104
new 0 194 104
return 1 199 108
assign 1 203 115
new 0 203 115
assign 1 203 116
equals 1 203 116
assign 1 204 118
new 0 204 118
return 1 204 119
assign 1 206 121
new 0 206 121
return 1 206 122
assign 1 216 132
toString 0 216 132
return 1 216 133
assign 1 220 137
new 1 220 137
new 1 220 138
assign 1 224 143
iteratorGet 0 224 143
return 1 224 144
assign 1 228 149
new 0 228 149
assign 1 228 150
get 1 228 150
return 1 228 151
assign 1 232 157
new 0 232 157
assign 1 232 158
subtract 1 232 158
assign 1 232 159
get 1 232 159
return 1 232 160
assign 1 242 170
new 0 242 170
assign 1 242 171
lesser 1 242 171
assign 1 243 173
new 0 243 173
assign 1 243 174
new 1 243 174
throw 1 243 175
assign 1 245 177
greaterEquals 1 245 177
assign 1 246 179
new 0 246 179
assign 1 246 180
add 1 246 180
lengthSet 1 246 181
assign 1 269 193
new 0 269 193
assign 1 269 194
greaterEquals 1 269 194
assign 1 269 196
lesser 1 269 196
assign 1 0 198
assign 1 0 201
assign 1 0 205
return 1 282 211
assign 1 286 226
lesser 1 286 226
assign 1 287 228
new 0 287 228
assign 1 287 229
subtract 1 287 229
assign 1 288 230
assign 1 288 233
lesser 1 288 233
assign 1 289 235
new 0 289 235
assign 1 289 236
add 1 289 236
assign 1 289 237
get 1 289 237
put 2 289 238
assign 1 288 239
increment 0 288 239
put 2 291 245
assign 1 292 246
new 0 292 246
assign 1 292 247
subtract 1 292 247
lengthSet 1 292 248
assign 1 293 249
new 0 293 249
return 1 293 250
assign 1 295 252
new 0 295 252
return 1 295 253
assign 1 299 257
new 1 299 257
return 1 299 258
assign 1 303 263
new 0 303 263
assign 1 303 266
lesser 1 303 266
put 2 304 268
assign 1 303 269
increment 0 303 269
assign 1 309 282
create 0 309 282
assign 1 310 283
new 0 310 283
assign 1 310 286
lesser 1 310 286
assign 1 311 288
get 1 311 288
put 2 311 289
assign 1 310 290
increment 0 310 290
return 1 313 296
assign 1 316 300
new 1 316 300
return 1 316 301
assign 1 318 305
new 1 318 305
return 1 318 306
assign 1 321 318
lengthGet 0 321 318
assign 1 321 319
add 1 321 319
assign 1 321 320
create 1 321 320
assign 1 322 321
new 0 322 321
assign 1 323 322
iteratorGet 0 0 322
assign 1 323 325
hasNextGet 0 323 325
assign 1 323 327
nextGet 0 323 327
put 2 324 328
assign 1 325 329
increment 0 325 329
assign 1 327 335
iteratorGet 0 0 335
assign 1 327 338
hasNextGet 0 327 338
assign 1 327 340
nextGet 0 327 340
put 2 328 341
assign 1 329 342
increment 0 329 342
return 1 331 348
assign 1 335 352
mergeSort 0 335 352
return 1 335 353
assign 1 339 357
new 0 339 357
sortInPlace 2 339 358
assign 1 343 372
assign 1 343 375
lesser 1 343 375
assign 1 344 377
assign 1 345 378
assign 1 345 381
lesser 1 345 381
assign 1 346 383
get 1 346 383
assign 1 346 384
get 1 346 384
assign 1 346 385
lesser 1 346 385
assign 1 347 387
assign 1 345 389
increment 0 345 389
assign 1 350 395
get 1 350 395
assign 1 351 396
get 1 351 396
put 2 351 397
put 2 352 398
assign 1 343 399
increment 0 343 399
assign 1 357 422
new 0 357 422
assign 1 358 423
new 0 358 423
assign 1 359 424
new 0 359 424
assign 1 360 425
lengthGet 0 360 425
assign 1 361 426
lengthGet 0 361 426
assign 1 362 429
lesser 1 362 429
assign 1 363 431
lesser 1 363 431
assign 1 363 433
lesser 1 363 433
assign 1 0 435
assign 1 0 438
assign 1 0 442
assign 1 364 445
get 1 364 445
assign 1 365 446
get 1 365 446
assign 1 366 447
lesser 1 366 447
assign 1 367 449
increment 0 367 449
put 2 368 450
assign 1 370 453
increment 0 370 453
put 2 371 454
assign 1 373 458
lesser 1 373 458
assign 1 374 460
get 1 374 460
assign 1 375 461
increment 0 375 461
put 2 376 462
assign 1 377 465
lesser 1 377 465
assign 1 378 467
get 1 378 467
assign 1 379 468
increment 0 379 468
put 2 380 469
assign 1 382 473
increment 0 382 473
assign 1 387 484
new 0 387 484
assign 1 387 485
mergeSort 2 387 485
return 1 387 486
assign 1 391 506
subtract 1 391 506
assign 1 392 507
new 0 392 507
assign 1 392 508
equals 1 392 508
assign 1 393 510
new 0 393 510
assign 1 393 511
create 1 393 511
return 1 393 512
assign 1 394 515
new 0 394 515
assign 1 394 516
equals 1 394 516
assign 1 395 518
new 0 395 518
assign 1 395 519
create 1 395 519
assign 1 396 520
new 0 396 520
assign 1 396 521
get 1 396 521
put 2 396 522
return 1 397 523
assign 1 399 526
new 0 399 526
assign 1 399 527
divide 1 399 527
assign 1 400 528
subtract 1 400 528
assign 1 401 529
add 1 401 529
assign 1 402 530
mergeSort 2 402 530
assign 1 403 531
mergeSort 2 403 531
assign 1 404 532
create 1 404 532
mergeIn 2 405 533
return 1 406 534
assign 1 430 544
greaterEquals 1 430 544
assign 1 431 546
multiply 1 431 546
assign 1 432 547
assign 1 460 552
assign 1 463 554
assign 1 464 555
assign 1 465 558
lesser 1 465 558
put 2 466 560
assign 1 467 561
increment 0 467 561
assign 1 472 573
def 1 472 578
assign 1 473 581
hasNextGet 0 473 581
assign 1 474 583
nextGet 0 474 583
addValue 1 474 584
assign 1 480 596
def 1 480 601
assign 1 481 602
iteratorGet 0 481 602
iterateAdd 1 481 603
put 2 486 608
assign 1 490 615
def 1 490 620
assign 1 490 621
sameType 1 490 621
assign 1 0 623
assign 1 0 626
assign 1 0 630
addAll 1 491 633
put 2 493 636
assign 1 499 647
new 0 499 647
assign 1 499 650
lesser 1 499 650
assign 1 500 652
get 1 500 652
assign 1 501 653
def 1 501 658
assign 1 501 659
equals 1 501 659
assign 1 0 661
assign 1 0 664
assign 1 0 668
return 1 502 671
incrementValue 0 499 673
return 1 505 679
assign 1 509 686
find 1 509 686
assign 1 509 687
def 1 509 692
assign 1 510 693
new 0 510 693
return 1 510 694
assign 1 512 696
new 0 512 696
return 1 512 697
assign 1 518 702
new 0 518 702
assign 1 518 703
sortedFind 2 518 703
return 1 518 704
assign 1 525 725
assign 1 526 726
new 0 526 726
assign 1 530 729
subtract 1 530 729
assign 1 530 730
new 0 530 730
assign 1 530 731
divide 1 530 731
assign 1 530 732
add 1 530 732
assign 1 531 733
get 1 531 733
assign 1 532 734
equals 1 532 734
return 1 533 736
assign 1 534 739
greater 1 534 739
assign 1 536 741
assign 1 537 744
lesser 1 537 744
assign 1 539 746
assign 1 542 750
def 1 542 755
assign 1 542 756
equals 1 542 756
assign 1 0 758
assign 1 0 761
assign 1 0 765
assign 1 543 769
get 1 543 769
assign 1 543 770
lesser 1 543 770
assign 1 0 772
assign 1 0 775
assign 1 0 779
return 1 544 782
return 1 546 784
assign 1 548 786
assign 1 549 787
new 0 549 787
return 1 550 789
assign 1 0 794
return 1 0 798
return 1 0 801
assign 1 0 804
return 1 0 808
assign 1 0 811
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 1473032100: return bem_varrayGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1479417926: return bem_multiplierGet_0();
case 188061735: return bem_mergeSort_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1484114352: return bem_varraySet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1442201067: return bem_sortInPlace_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 786424307: return bem_tagGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_5_ContainerArray) bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1740761350: return bem_capacitySet_1(bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1820417454: return bem_create_1((BEC_4_3_MathInt) bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1064717368: return bem_addWhole_1(bevd_0);
case 819712669: return bem_delete_1((BEC_4_3_MathInt) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_4_3_MathInt) bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1442201065: return bem_sortInPlace_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_9_5_ContainerArray();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_9_5_ContainerArray.bevs_inst = (BEC_9_5_ContainerArray)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_9_5_ContainerArray.bevs_inst;
}
}
}
