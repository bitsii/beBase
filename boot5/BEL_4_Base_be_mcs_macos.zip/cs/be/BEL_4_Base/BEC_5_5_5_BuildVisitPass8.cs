namespace be.BEL_4_Base {
/* File: source/build/Pass8.be */
public class BEC_5_5_5_BuildVisitPass8 : BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass8() { }
static BEC_5_5_5_BuildVisitPass8() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bels_28 = {0x3D,0x40};
private static byte[] bels_29 = {0x3D,0x23};
public static new BEC_5_5_5_BuildVisitPass8 bevs_inst;
public virtual BEC_6_6_SystemObject bem_acceptClass_1(BEC_6_6_SystemObject beva_node) {
BEC_5_8_BuildEmitData bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpvar_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_prepOps_0() {
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(10));
bevl_ops = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 25 */ {
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(10));
bevt_1_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 25 */ {
bevt_3_tmpvar_phold = (BEC_9_10_ContainerLinkedList) (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 25 */
 else  /* Line: 25 */ {
break;
} /* Line: 25 */
} /* Line: 25 */
return bevl_ops;
} /*method end*/
public override BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_6_6_SystemObject bevl_prec = null;
BEC_6_6_SystemObject bevl_cont = null;
BEC_6_6_SystemObject bevl_ops = null;
BEC_6_6_SystemObject bevl_onode = null;
BEC_6_6_SystemObject bevl_mo = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_mt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
bevt_3_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 35 */ {
this.bem_acceptClass_1(beva_node);
bevt_5_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpvar_phold;
} /* Line: 37 */
bevt_6_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_7_tmpvar_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpvar_phold.bem_get_1(bevt_7_tmpvar_phold);
if (bevl_prec == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = this.bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 50 */ {
if (bevl_onode == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 50 */ {
if (bevl_prec == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_12_tmpvar_phold = bevl_onode.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_cont);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 50 */ {
bevt_13_tmpvar_phold = bevl_ops.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_prec);
bevt_13_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_onode);
bevl_inode = bevl_onode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_17_tmpvar_phold = bevl_inode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_18_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 56 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_inode == null) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevl_inode = bevl_inode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 59 */
} /* Line: 58 */
} /* Line: 56 */
} /* Line: 55 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 65 */ {
bevt_21_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_22_tmpvar_phold = bevl_onode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevl_prec = bevt_21_tmpvar_phold.bem_get_1(bevt_22_tmpvar_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_prec = null;
} /* Line: 68 */
} /* Line: 65 */
 else  /* Line: 50 */ {
break;
} /* Line: 50 */
} /* Line: 50 */
bevl_prec = (new BEC_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 72 */ {
bevt_23_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 72 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_i.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 74 */ {
bevl_mt = bevl_i.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 75 */ {
bevt_27_tmpvar_phold = bevl_mt.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevl_mo = bevl_mt.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_28_tmpvar_phold = bevl_mo.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
bevt_29_tmpvar_phold = bevl_mo.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_mo = this.bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpvar_phold, bevt_29_tmpvar_phold);
beva_node = (BEC_5_4_BuildNode) bevl_mo;
} /* Line: 78 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
} /* Line: 75 */
bevl_prec = bevl_prec.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 81 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
} /* Line: 72 */
bevt_30_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public virtual BEC_6_6_SystemObject bem_callFromOper_4(BEC_6_6_SystemObject beva_op, BEC_6_6_SystemObject beva_prec, BEC_6_6_SystemObject beva_pr, BEC_6_6_SystemObject beva_nx) {
BEC_6_6_SystemObject bevl_gc = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
bevl_gc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1795527427, BEL_4_Base.bevn_wasOperSet_1, bevt_2_tmpvar_phold);
bevt_5_tmpvar_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_get_1(bevt_6_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(357005938, BEL_4_Base.bevn_lower_0);
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_3_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_0));
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 93 */ {
bevt_10_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_1));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_10_tmpvar_phold);
} /* Line: 94 */
bevt_12_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_2));
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_13_tmpvar_phold);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 96 */ {
bevt_14_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_3));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_14_tmpvar_phold);
} /* Line: 97 */
bevt_16_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_4));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_5));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_6));
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold != null && bevt_19_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_19_tmpvar_phold).bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_7));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_9));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_10));
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_11));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_30_tmpvar_phold);
} /* Line: 109 */
bevt_32_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(15, bels_12));
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 111 */ {
bevt_34_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_13));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_34_tmpvar_phold);
} /* Line: 112 */
bevt_36_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(14, bels_14));
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpvar_phold);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 114 */ {
bevt_38_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_15));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_38_tmpvar_phold);
} /* Line: 115 */
bevt_40_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_16));
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_41_tmpvar_phold);
if (bevt_39_tmpvar_phold != null && bevt_39_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_39_tmpvar_phold).bevi_bool) /* Line: 117 */ {
bevt_42_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_17));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_42_tmpvar_phold);
} /* Line: 118 */
bevt_44_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_45_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(13, bels_18));
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_45_tmpvar_phold);
if (bevt_43_tmpvar_phold != null && bevt_43_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_43_tmpvar_phold).bevi_bool) /* Line: 120 */ {
bevt_46_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(12, bels_19));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_46_tmpvar_phold);
} /* Line: 121 */
bevt_48_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_49_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(11, bels_20));
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_49_tmpvar_phold);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 123 */ {
bevt_50_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_21));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpvar_phold);
} /* Line: 124 */
bevt_52_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(10, bels_22));
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpvar_phold);
if (bevt_51_tmpvar_phold != null && bevt_51_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_51_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_54_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_23));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_54_tmpvar_phold);
} /* Line: 127 */
bevt_56_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_57_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(9, bels_24));
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_57_tmpvar_phold);
if (bevt_55_tmpvar_phold != null && bevt_55_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_55_tmpvar_phold).bevi_bool) /* Line: 129 */ {
bevt_58_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_25));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_58_tmpvar_phold);
} /* Line: 130 */
bevt_60_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(8, bels_26));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_61_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 132 */ {
bevt_62_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(7, bels_27));
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_62_tmpvar_phold);
} /* Line: 133 */
bevt_63_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_63_tmpvar_phold);
bevt_65_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_66_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_66_tmpvar_phold);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_68_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_69_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_28));
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 137 */ {
bevt_70_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_70_tmpvar_phold);
} /* Line: 139 */
bevt_72_tmpvar_phold = beva_op.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_73_tmpvar_phold);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_75_tmpvar_phold = beva_op.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpvar_phold = (BEC_4_6_TextString) (new BEC_4_6_TextString(2, bels_29));
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
 else  /* Line: 141 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_77_tmpvar_phold = (BEC_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_77_tmpvar_phold);
} /* Line: 143 */
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
beva_op.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_pr.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_pr);
bevt_80_tmpvar_phold = (BEC_4_3_MathInt) (new BEC_4_3_MathInt(0));
bevt_79_tmpvar_phold = beva_prec.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_80_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold is BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 149 */ {
beva_nx.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
beva_op.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_nx);
} /* Line: 151 */
return beva_op;
} /*method end*/
//int[] bevs_nlcs = {20, 20, 24, 24, 25, 25, 25, 26, 26, 25, 28, 35, 35, 35, 36, 37, 37, 39, 39, 39, 40, 40, 45, 46, 47, 49, 50, 50, 50, 50, 0, 0, 0, 50, 50, 0, 0, 0, 51, 51, 52, 53, 53, 54, 55, 55, 56, 56, 56, 57, 58, 58, 59, 64, 65, 65, 66, 66, 66, 68, 71, 72, 72, 73, 74, 74, 74, 75, 75, 76, 77, 77, 77, 78, 81, 86, 86, 90, 91, 91, 92, 92, 92, 92, 92, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 124, 124, 126, 126, 126, 127, 127, 129, 129, 129, 130, 130, 132, 132, 132, 133, 133, 136, 136, 137, 137, 137, 137, 137, 137, 0, 0, 0, 139, 139, 141, 141, 141, 141, 141, 141, 0, 0, 0, 143, 143, 145, 145, 146, 147, 148, 149, 149, 150, 151, 153};
//int[] bevs_nlecs = {41, 42, 52, 53, 54, 57, 58, 60, 61, 62, 68, 111, 112, 113, 115, 116, 117, 119, 120, 121, 122, 127, 128, 129, 130, 131, 134, 139, 140, 145, 146, 149, 153, 156, 157, 159, 162, 166, 169, 170, 171, 172, 177, 178, 179, 184, 185, 186, 187, 189, 190, 195, 196, 201, 202, 207, 208, 209, 210, 213, 220, 221, 224, 226, 227, 228, 229, 231, 234, 236, 237, 238, 239, 240, 247, 254, 255, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 352, 353, 355, 356, 357, 359, 360, 362, 363, 364, 366, 367, 369, 370, 371, 373, 374, 376, 377, 378, 380, 381, 383, 384, 385, 387, 388, 390, 391, 392, 394, 395, 397, 398, 399, 401, 402, 404, 405, 406, 408, 409, 411, 412, 413, 415, 416, 418, 419, 420, 422, 423, 425, 426, 427, 429, 430, 432, 433, 434, 436, 437, 439, 440, 441, 443, 444, 446, 447, 448, 449, 450, 452, 453, 454, 456, 459, 463, 466, 467, 469, 470, 471, 473, 474, 475, 477, 480, 484, 487, 488, 490, 491, 492, 493, 494, 495, 496, 498, 499, 501};
/* BEGIN LINEINFO 
assign 1 20 41
emitDataGet 0 20 41
addParsedClass 1 20 42
assign 1 24 52
new 0 24 52
assign 1 24 53
new 1 24 53
assign 1 25 54
new 0 25 54
assign 1 25 57
new 0 25 57
assign 1 25 58
lesser 1 25 58
assign 1 26 60
new 0 26 60
put 2 26 61
assign 1 25 62
increment 0 25 62
return 1 28 68
assign 1 35 111
typenameGet 0 35 111
assign 1 35 112
CLASSGet 0 35 112
assign 1 35 113
equals 1 35 113
acceptClass 1 36 115
assign 1 37 116
nextDescendGet 0 37 116
return 1 37 117
assign 1 39 119
operGet 0 39 119
assign 1 39 120
typenameGet 0 39 120
assign 1 39 121
get 1 39 121
assign 1 40 122
def 1 40 127
assign 1 45 128
containerGet 0 45 128
assign 1 46 129
prepOps 0 46 129
assign 1 47 130
assign 1 49 131
assign 1 50 134
def 1 50 139
assign 1 50 140
def 1 50 145
assign 1 0 146
assign 1 0 149
assign 1 0 153
assign 1 50 156
containerGet 0 50 156
assign 1 50 157
equals 1 50 157
assign 1 0 159
assign 1 0 162
assign 1 0 166
assign 1 51 169
get 1 51 169
addValue 1 51 170
assign 1 52 171
nextPeerGet 0 52 171
assign 1 53 172
def 1 53 177
assign 1 54 178
nextPeerGet 0 54 178
assign 1 55 179
def 1 55 184
assign 1 56 185
typenameGet 0 56 185
assign 1 56 186
COMMAGet 0 56 186
assign 1 56 187
equals 1 56 187
assign 1 57 189
nextPeerGet 0 57 189
assign 1 58 190
def 1 58 195
assign 1 59 196
nextPeerGet 0 59 196
assign 1 64 201
assign 1 65 202
def 1 65 207
assign 1 66 208
operGet 0 66 208
assign 1 66 209
typenameGet 0 66 209
assign 1 66 210
get 1 66 210
assign 1 68 213
assign 1 71 220
new 0 71 220
assign 1 72 221
iteratorGet 0 72 221
assign 1 72 224
hasNextGet 0 72 224
assign 1 73 226
nextGet 0 73 226
assign 1 74 227
lengthGet 0 74 227
assign 1 74 228
new 0 74 228
assign 1 74 229
greater 1 74 229
assign 1 75 231
iteratorGet 0 75 231
assign 1 75 234
hasNextGet 0 75 234
assign 1 76 236
nextGet 0 76 236
assign 1 77 237
priorPeerGet 0 77 237
assign 1 77 238
nextPeerGet 0 77 238
assign 1 77 239
callFromOper 4 77 239
assign 1 78 240
assign 1 81 247
increment 0 81 247
assign 1 86 254
nextDescendGet 0 86 254
return 1 86 255
assign 1 90 340
new 0 90 340
assign 1 91 341
new 0 91 341
wasOperSet 1 91 342
assign 1 92 343
operNamesGet 0 92 343
assign 1 92 344
typenameGet 0 92 344
assign 1 92 345
get 1 92 345
assign 1 92 346
lower 0 92 346
nameSet 1 92 347
assign 1 93 348
nameGet 0 93 348
assign 1 93 349
new 0 93 349
assign 1 93 350
equals 1 93 350
assign 1 94 352
new 0 94 352
nameSet 1 94 353
assign 1 96 355
nameGet 0 96 355
assign 1 96 356
new 0 96 356
assign 1 96 357
equals 1 96 357
assign 1 97 359
new 0 97 359
nameSet 1 97 360
assign 1 99 362
nameGet 0 99 362
assign 1 99 363
new 0 99 363
assign 1 99 364
equals 1 99 364
assign 1 100 366
new 0 100 366
nameSet 1 100 367
assign 1 102 369
nameGet 0 102 369
assign 1 102 370
new 0 102 370
assign 1 102 371
equals 1 102 371
assign 1 103 373
new 0 103 373
nameSet 1 103 374
assign 1 105 376
nameGet 0 105 376
assign 1 105 377
new 0 105 377
assign 1 105 378
equals 1 105 378
assign 1 106 380
new 0 106 380
nameSet 1 106 381
assign 1 108 383
nameGet 0 108 383
assign 1 108 384
new 0 108 384
assign 1 108 385
equals 1 108 385
assign 1 109 387
new 0 109 387
nameSet 1 109 388
assign 1 111 390
nameGet 0 111 390
assign 1 111 391
new 0 111 391
assign 1 111 392
equals 1 111 392
assign 1 112 394
new 0 112 394
nameSet 1 112 395
assign 1 114 397
nameGet 0 114 397
assign 1 114 398
new 0 114 398
assign 1 114 399
equals 1 114 399
assign 1 115 401
new 0 115 401
nameSet 1 115 402
assign 1 117 404
nameGet 0 117 404
assign 1 117 405
new 0 117 405
assign 1 117 406
equals 1 117 406
assign 1 118 408
new 0 118 408
nameSet 1 118 409
assign 1 120 411
nameGet 0 120 411
assign 1 120 412
new 0 120 412
assign 1 120 413
equals 1 120 413
assign 1 121 415
new 0 121 415
nameSet 1 121 416
assign 1 123 418
nameGet 0 123 418
assign 1 123 419
new 0 123 419
assign 1 123 420
equals 1 123 420
assign 1 124 422
new 0 124 422
nameSet 1 124 423
assign 1 126 425
nameGet 0 126 425
assign 1 126 426
new 0 126 426
assign 1 126 427
equals 1 126 427
assign 1 127 429
new 0 127 429
nameSet 1 127 430
assign 1 129 432
nameGet 0 129 432
assign 1 129 433
new 0 129 433
assign 1 129 434
equals 1 129 434
assign 1 130 436
new 0 130 436
nameSet 1 130 437
assign 1 132 439
nameGet 0 132 439
assign 1 132 440
new 0 132 440
assign 1 132 441
equals 1 132 441
assign 1 133 443
new 0 133 443
nameSet 1 133 444
assign 1 136 446
new 0 136 446
wasBoundSet 1 136 447
assign 1 137 448
typenameGet 0 137 448
assign 1 137 449
ASSIGNGet 0 137 449
assign 1 137 450
equals 1 137 450
assign 1 137 452
heldGet 0 137 452
assign 1 137 453
new 0 137 453
assign 1 137 454
equals 1 137 454
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 139 466
new 0 139 466
isOnceSet 1 139 467
assign 1 141 469
typenameGet 0 141 469
assign 1 141 470
ASSIGNGet 0 141 470
assign 1 141 471
equals 1 141 471
assign 1 141 473
heldGet 0 141 473
assign 1 141 474
new 0 141 474
assign 1 141 475
equals 1 141 475
assign 1 0 477
assign 1 0 480
assign 1 0 484
assign 1 143 487
new 0 143 487
isManySet 1 143 488
assign 1 145 490
CALLGet 0 145 490
typenameSet 1 145 491
heldSet 1 146 492
delete 0 147 493
addValue 1 148 494
assign 1 149 495
new 0 149 495
assign 1 149 496
greater 1 149 496
delete 0 150 498
addValue 1 151 499
return 1 153 501
END LINEINFO */
public override BEC_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 1028089930: return bem_prepOps_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 724180734: return bem_acceptClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) {
switch (callHash) {
case 1204261941: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_6_6_SystemObject bemc_create() {
return new BEC_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_6_6_SystemObject becc_inst) {
BEC_5_5_5_BuildVisitPass8.bevs_inst = (BEC_5_5_5_BuildVisitPass8)becc_inst;
}
public override BEC_6_6_SystemObject bemc_getInitial() {
return BEC_5_5_5_BuildVisitPass8.bevs_inst;
}
}
}
