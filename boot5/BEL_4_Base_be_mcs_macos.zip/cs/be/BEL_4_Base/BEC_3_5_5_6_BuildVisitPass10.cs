namespace be.BEL_4_Base {
/* IO:File: source/build/Pass10.be */
public class BEC_3_5_5_6_BuildVisitPass10 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass10() { }
static BEC_3_5_5_6_BuildVisitPass10() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x30};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x30,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_1 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_2 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bels_3 = {0x61,0x6E,0x63,0x68,0x6F,0x72};
private static byte[] bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_5 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bels_6 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
public static new BEC_3_5_5_6_BuildVisitPass10 bevs_inst;
public virtual BEC_2_6_6_SystemObject bem_condCall_2(BEC_2_6_6_SystemObject beva_condvar, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_acc = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_5_4_BuildCall bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevl_cnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpvar_phold = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_cnode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_cnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_1_tmpvar_phold);
bevl_acc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_acc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpvar_phold);
bevl_acc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_condvar);
bevl_cnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_acc);
bevt_3_tmpvar_phold = bevl_cnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_0));
bevt_3_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_4_tmpvar_phold);
bevl_nnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, beva_value);
bevl_cnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
return bevl_cnode;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_anchor = null;
BEC_2_6_6_SystemObject bevl_condvar = null;
BEC_2_6_6_SystemObject bevl_cvnp = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_rinode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpvar_phold = null;
bevt_4_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_5_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_4_tmpvar_phold.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevt_8_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_lengthGet_0();
bevt_9_tmpvar_phold = bevo_0;
if (bevt_7_tmpvar_phold.bevi_int == bevt_9_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 35 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 35 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 35 */
 else  /* Line: 35 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 35 */ {
bevt_13_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_firstGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_14_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 35 */
 else  /* Line: 35 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 35 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
beva_node.bem_takeContents_1((BEC_2_5_4_BuildNode) bevt_15_tmpvar_phold);
return beva_node;
} /* Line: 37 */
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_18_tmpvar_phold.bevi_int == bevt_19_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 40 */ {
bevt_20_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_20_tmpvar_phold);
beva_node.bem_syncVariable_1(this);
} /* Line: 42 */
bevt_22_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_22_tmpvar_phold.bevi_int == bevt_23_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_26_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_27_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_1));
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpvar_phold);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_2));
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_31_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 45 */ {
bevl_anchor = beva_node.bem_anchorGet_0();
bevl_condvar = bevl_anchor.bemd_0(516830146, BEL_4_Base.bevn_condvarGet_0);
if (bevl_condvar == null) {
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_33_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bels_3));
bevl_condvar = bevl_anchor.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_33_tmpvar_phold, bevp_build);
bevt_34_tmpvar_phold = (BEC_2_5_4_LogicBool) be.BELS_Base.BECS_Runtime.boolTrue;
bevl_condvar.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_34_tmpvar_phold);
bevl_cvnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_35_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bels_4));
bevl_cvnp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, bevt_35_tmpvar_phold);
bevl_condvar.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_cvnp);
bevl_anchor.bemd_1(527912399, BEL_4_Base.bevn_condvarSet_1, bevl_condvar);
} /* Line: 56 */
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_36_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_36_tmpvar_phold);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_rinode = bevl_inode;
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_37_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_37_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_39_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_firstGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_38_tmpvar_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_40_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_40_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_43_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_5));
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_44_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 77 */ {
bevt_46_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_45_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_46_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_45_tmpvar_phold);
} /* Line: 78 */
 else  /* Line: 80 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_47_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_47_tmpvar_phold);
bevl_inode.bemd_1(527912399, BEL_4_Base.bevn_condvarSet_1, bevl_condvar);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_48_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_48_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_49_tmpvar_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_49_tmpvar_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_50_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_50_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_52_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_51_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_52_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_51_tmpvar_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_53_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_53_tmpvar_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_54_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_54_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_55_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_56_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_55_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
} /* Line: 107 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_57_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_57_tmpvar_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_58_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_58_tmpvar_phold);
bevl_rinode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_61_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bels_6));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_62_tmpvar_phold);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 119 */ {
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_63_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_63_tmpvar_phold);
bevl_inode.bemd_1(527912399, BEL_4_Base.bevn_condvarSet_1, bevl_condvar);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_pnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_pnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_64_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_pnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_64_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_pnode);
bevt_65_tmpvar_phold = beva_node.bem_secondGet_0();
bevl_pnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_65_tmpvar_phold);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_66_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_66_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
bevt_68_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_67_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_68_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_67_tmpvar_phold);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_69_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_69_tmpvar_phold);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_70_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_bnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_70_tmpvar_phold);
bevt_72_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_71_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_72_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_71_tmpvar_phold);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_bnode);
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_74_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_73_tmpvar_phold = this.bem_condCall_2(bevl_condvar, bevt_74_tmpvar_phold);
bevl_bnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_73_tmpvar_phold);
} /* Line: 147 */
bevl_anchor.bemd_1(1671186230, BEL_4_Base.bevn_beforeInsert_1, bevl_rinode);
beva_node.bem_containedSet_1(null);
bevt_75_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_75_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_condvar);
beva_node.bem_syncAddVariable_0();
bevt_76_tmpvar_phold = bevl_rinode.bemd_0(1779180144, BEL_4_Base.bevn_nextDescendGet_0);
return (BEC_2_5_4_BuildNode) bevt_76_tmpvar_phold;
} /* Line: 156 */
bevt_77_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_77_tmpvar_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 21, 21, 22, 22, 23, 24, 24, 25, 26, 27, 27, 27, 28, 29, 30, 31, 35, 35, 35, 35, 35, 35, 35, 35, 35, 0, 0, 0, 35, 35, 35, 35, 35, 0, 0, 0, 36, 36, 36, 37, 40, 40, 40, 40, 41, 41, 42, 45, 45, 45, 45, 45, 45, 45, 45, 0, 45, 45, 45, 45, 0, 0, 0, 0, 0, 47, 48, 50, 50, 51, 51, 52, 52, 53, 54, 54, 55, 56, 59, 60, 60, 61, 63, 65, 66, 67, 67, 68, 70, 70, 70, 72, 73, 74, 74, 75, 77, 77, 77, 77, 78, 78, 78, 82, 83, 84, 84, 85, 86, 88, 89, 90, 90, 91, 92, 92, 93, 94, 95, 95, 96, 97, 97, 97, 99, 100, 101, 101, 102, 103, 104, 104, 105, 105, 105, 106, 107, 110, 111, 112, 112, 113, 114, 115, 115, 116, 117, 119, 119, 119, 119, 120, 121, 122, 122, 123, 124, 126, 127, 128, 128, 129, 130, 130, 131, 132, 133, 133, 134, 135, 135, 135, 137, 138, 139, 139, 140, 141, 142, 143, 143, 144, 144, 144, 145, 147, 147, 147, 151, 152, 153, 153, 154, 155, 156, 156, 159, 159};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 131, 132, 133, 138, 139, 140, 141, 142, 147, 148, 151, 155, 158, 159, 160, 161, 162, 164, 167, 171, 174, 175, 176, 177, 179, 180, 181, 186, 187, 188, 189, 191, 192, 193, 198, 199, 200, 201, 202, 204, 207, 208, 209, 210, 212, 215, 219, 222, 226, 229, 230, 231, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 270, 271, 272, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 361, 362, 363, 365, 366, 367, 368, 369, 370, 371, 372, 374, 375};
/* BEGIN LINEINFO 
assign 1 20 26
new 1 20 26
assign 1 21 27
new 0 21 27
heldSet 1 21 28
assign 1 22 29
CALLGet 0 22 29
typenameSet 1 22 30
assign 1 23 31
new 1 23 31
assign 1 24 32
VARGet 0 24 32
typenameSet 1 24 33
heldSet 1 25 34
addValue 1 26 35
assign 1 27 36
heldGet 0 27 36
assign 1 27 37
new 0 27 37
nameSet 1 27 38
assign 1 28 39
new 1 28 39
typenameSet 1 29 40
addValue 1 30 41
return 1 31 42
assign 1 35 131
typenameGet 0 35 131
assign 1 35 132
PARENSGet 0 35 132
assign 1 35 133
equals 1 35 138
assign 1 35 139
containedGet 0 35 139
assign 1 35 140
lengthGet 0 35 140
assign 1 35 141
new 0 35 141
assign 1 35 142
equals 1 35 147
assign 1 0 148
assign 1 0 151
assign 1 0 155
assign 1 35 158
containedGet 0 35 158
assign 1 35 159
firstGet 0 35 159
assign 1 35 160
typenameGet 0 35 160
assign 1 35 161
PARENSGet 0 35 161
assign 1 35 162
equals 1 35 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 36 174
containedGet 0 36 174
assign 1 36 175
firstGet 0 36 175
takeContents 1 36 176
return 1 37 177
assign 1 40 179
typenameGet 0 40 179
assign 1 40 180
IDGet 0 40 180
assign 1 40 181
equals 1 40 186
assign 1 41 187
VARGet 0 41 187
typenameSet 1 41 188
syncVariable 1 42 189
assign 1 45 191
typenameGet 0 45 191
assign 1 45 192
CALLGet 0 45 192
assign 1 45 193
equals 1 45 198
assign 1 45 199
heldGet 0 45 199
assign 1 45 200
nameGet 0 45 200
assign 1 45 201
new 0 45 201
assign 1 45 202
equals 1 45 202
assign 1 0 204
assign 1 45 207
heldGet 0 45 207
assign 1 45 208
nameGet 0 45 208
assign 1 45 209
new 0 45 209
assign 1 45 210
equals 1 45 210
assign 1 0 212
assign 1 0 215
assign 1 0 219
assign 1 0 222
assign 1 0 226
assign 1 47 229
anchorGet 0 47 229
assign 1 48 230
condvarGet 0 48 230
assign 1 50 231
undef 1 50 236
assign 1 51 237
new 0 51 237
assign 1 51 238
tmpVar 2 51 238
assign 1 52 239
new 0 52 239
isTypedSet 1 52 240
assign 1 53 241
new 0 53 241
assign 1 54 242
new 0 54 242
fromString 1 54 243
namepathSet 1 55 244
condvarSet 1 56 245
assign 1 59 247
new 1 59 247
assign 1 60 248
IFGet 0 60 248
typenameSet 1 60 249
copyLoc 1 61 250
assign 1 63 251
assign 1 65 252
new 1 65 252
copyLoc 1 66 253
assign 1 67 254
PARENSGet 0 67 254
typenameSet 1 67 255
addValue 1 68 256
assign 1 70 257
containedGet 0 70 257
assign 1 70 258
firstGet 0 70 258
addValue 1 70 259
assign 1 72 260
new 1 72 260
copyLoc 1 73 261
assign 1 74 262
BRACESGet 0 74 262
typenameSet 1 74 263
addValue 1 75 264
assign 1 77 265
heldGet 0 77 265
assign 1 77 266
nameGet 0 77 266
assign 1 77 267
new 0 77 267
assign 1 77 268
equals 1 77 268
assign 1 78 270
TRUEGet 0 78 270
assign 1 78 271
condCall 2 78 271
addValue 1 78 272
assign 1 82 275
new 1 82 275
copyLoc 1 83 276
assign 1 84 277
IFGet 0 84 277
typenameSet 1 84 278
condvarSet 1 85 279
addValue 1 86 280
assign 1 88 281
new 1 88 281
copyLoc 1 89 282
assign 1 90 283
PARENSGet 0 90 283
typenameSet 1 90 284
addValue 1 91 285
assign 1 92 286
secondGet 0 92 286
addValue 1 92 287
assign 1 93 288
new 1 93 288
copyLoc 1 94 289
assign 1 95 290
BRACESGet 0 95 290
typenameSet 1 95 291
addValue 1 96 292
assign 1 97 293
TRUEGet 0 97 293
assign 1 97 294
condCall 2 97 294
addValue 1 97 295
assign 1 99 296
new 1 99 296
copyLoc 1 100 297
assign 1 101 298
ELSEGet 0 101 298
typenameSet 1 101 299
assign 1 102 300
new 1 102 300
copyLoc 1 103 301
assign 1 104 302
BRACESGet 0 104 302
typenameSet 1 104 303
assign 1 105 304
FALSEGet 0 105 304
assign 1 105 305
condCall 2 105 305
addValue 1 105 306
addValue 1 106 307
addValue 1 107 308
assign 1 110 310
new 1 110 310
copyLoc 1 111 311
assign 1 112 312
ELSEGet 0 112 312
typenameSet 1 112 313
assign 1 113 314
new 1 113 314
copyLoc 1 114 315
assign 1 115 316
BRACESGet 0 115 316
typenameSet 1 115 317
addValue 1 116 318
addValue 1 117 319
assign 1 119 320
heldGet 0 119 320
assign 1 119 321
nameGet 0 119 321
assign 1 119 322
new 0 119 322
assign 1 119 323
equals 1 119 323
assign 1 120 325
new 1 120 325
copyLoc 1 121 326
assign 1 122 327
IFGet 0 122 327
typenameSet 1 122 328
condvarSet 1 123 329
addValue 1 124 330
assign 1 126 331
new 1 126 331
copyLoc 1 127 332
assign 1 128 333
PARENSGet 0 128 333
typenameSet 1 128 334
addValue 1 129 335
assign 1 130 336
secondGet 0 130 336
addValue 1 130 337
assign 1 131 338
new 1 131 338
copyLoc 1 132 339
assign 1 133 340
BRACESGet 0 133 340
typenameSet 1 133 341
addValue 1 134 342
assign 1 135 343
TRUEGet 0 135 343
assign 1 135 344
condCall 2 135 344
addValue 1 135 345
assign 1 137 346
new 1 137 346
copyLoc 1 138 347
assign 1 139 348
ELSEGet 0 139 348
typenameSet 1 139 349
addValue 1 140 350
assign 1 141 351
new 1 141 351
copyLoc 1 142 352
assign 1 143 353
BRACESGet 0 143 353
typenameSet 1 143 354
assign 1 144 355
FALSEGet 0 144 355
assign 1 144 356
condCall 2 144 356
addValue 1 144 357
addValue 1 145 358
assign 1 147 361
FALSEGet 0 147 361
assign 1 147 362
condCall 2 147 362
addValue 1 147 363
beforeInsert 1 151 365
containedSet 1 152 366
assign 1 153 367
VARGet 0 153 367
typenameSet 1 153 368
heldSet 1 154 369
syncAddVariable 0 155 370
assign 1 156 371
nextDescendGet 0 156 371
return 1 156 372
assign 1 159 374
nextDescendGet 0 159 374
return 1 159 375
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 2036228013: return bem_condCall_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass10();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass10.bevs_inst = (BEC_3_5_5_6_BuildVisitPass10)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass10.bevs_inst;
}
}
}
