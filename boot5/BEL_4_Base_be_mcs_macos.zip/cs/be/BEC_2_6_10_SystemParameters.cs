namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x0D,0x0A};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_6 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_1 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_1, 2));
private static BEC_2_4_3_MathInt bevo_10 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x2D};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 1));
private static BEC_2_4_3_MathInt bevo_12 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_3 = {0x3D};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 1));
private static BEC_2_4_3_MathInt bevo_14 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_4 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 3));
private static BEC_2_4_3_MathInt bevo_17 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
private static byte[] bels_5 = {0x23};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 1));
public static new BEC_2_6_10_SystemParameters bevs_inst;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
this.bem_new_0();
this.bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 124 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_9_tmpany_phold);
beva__args.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 124 */
 else  /* Line: 124 */ {
break;
} /* Line: 124 */
} /* Line: 124 */
} /* Line: 124 */
if (bevp_args == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevp_args = (BEC_2_9_4_ContainerList) beva__args;
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
} /* Line: 131 */
 else  /* Line: 132 */ {
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args);
} /* Line: 133 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 137 */ {
bevt_11_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_13_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_14_tmpany_phold = bevo_0;
if (bevt_13_tmpany_phold.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_15_tmpany_phold = bevo_1;
bevt_16_tmpany_phold = bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_19_tmpany_phold = bevo_3;
if (bevt_18_tmpany_phold.bevi_int > bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_20_tmpany_phold = bevo_4;
bevt_21_tmpany_phold = bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_24_tmpany_phold = bevo_6;
if (bevt_23_tmpany_phold.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 145 */ {
bevt_25_tmpany_phold = bevo_7;
bevt_26_tmpany_phold = bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 143 */
if (bevl_pname == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 151 */ {
this.bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 152 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 155 */
 else  /* Line: 150 */ {
if (bevl_fb == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_31_tmpany_phold = bevo_9;
bevt_30_tmpany_phold = bevl_fb.bem_equals_1(bevt_31_tmpany_phold);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 156 */
 else  /* Line: 156 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 156 */ {
bevt_32_tmpany_phold = bevo_10;
bevt_33_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
} /* Line: 157 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_36_tmpany_phold = bevo_11;
bevt_35_tmpany_phold = bevl_fa.bem_equals_1(bevt_36_tmpany_phold);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 158 */ {
bevt_37_tmpany_phold = bevo_12;
bevt_38_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_37_tmpany_phold, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_39_tmpany_phold);
if (bevl_pos == null) {
bevt_40_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevt_41_tmpany_phold = bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_41_tmpany_phold, bevl_pos);
bevt_43_tmpany_phold = bevo_15;
bevt_42_tmpany_phold = bevl_pos.bem_add_1(bevt_43_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_42_tmpany_phold);
this.bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 164 */
} /* Line: 161 */
 else  /* Line: 150 */ {
if (bevl_fc == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_46_tmpany_phold = bevo_16;
bevt_45_tmpany_phold = bevl_fc.bem_equals_1(bevt_46_tmpany_phold);
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
 else  /* Line: 166 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_47_tmpany_phold = bevo_17;
bevt_48_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 168 */
 else  /* Line: 150 */ {
if (bevl_fa == null) {
bevt_49_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_51_tmpany_phold = bevo_18;
bevt_50_tmpany_phold = bevl_fa.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 170 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
} /* Line: 150 */
 else  /* Line: 137 */ {
break;
} /* Line: 137 */
} /* Line: 137 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 177 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 178 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 178 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 178 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 183 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 183 */
 else  /* Line: 183 */ {
break;
} /* Line: 183 */
} /* Line: 183 */
} /* Line: 183 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 189 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 189 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 193 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 193 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 194 */
 else  /* Line: 193 */ {
break;
} /* Line: 193 */
} /* Line: 193 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-1094759839, BEL_4_Base.bevn_process_1, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 197 */
 else  /* Line: 189 */ {
break;
} /* Line: 189 */
} /* Line: 189 */
bevp_params = bevl__params;
} /* Line: 199 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = this.bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 205 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 207 */
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = this.bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 227 */ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 229 */
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
return beva_default;
} /* Line: 241 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 251 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(-1987444950, BEL_4_Base.bevn_toList_0);
this.bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {111, 111, 118, 119, 123, 123, 124, 124, 124, 125, 125, 125, 124, 128, 128, 129, 130, 131, 133, 135, 136, 137, 0, 137, 137, 138, 139, 140, 141, 141, 141, 141, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 145, 146, 146, 146, 150, 150, 151, 151, 152, 154, 155, 156, 156, 156, 156, 0, 0, 0, 157, 157, 157, 158, 158, 158, 158, 0, 0, 0, 159, 159, 159, 160, 160, 161, 161, 162, 162, 163, 163, 163, 164, 166, 166, 166, 166, 0, 0, 0, 167, 167, 167, 168, 169, 169, 169, 169, 0, 0, 0, 169, 169, 170, 176, 177, 177, 178, 178, 178, 178, 179, 179, 179, 178, 182, 182, 183, 183, 183, 183, 184, 184, 184, 183, 187, 187, 188, 189, 189, 190, 191, 192, 193, 0, 193, 193, 194, 194, 196, 197, 199, 204, 205, 205, 207, 210, 214, 214, 214, 218, 218, 222, 222, 226, 227, 227, 228, 229, 231, 235, 235, 239, 240, 240, 241, 243, 243, 248, 249, 249, 250, 251, 253, 257, 257, 257, 258, 258, 259, 259, 260, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {41, 42, 46, 47, 115, 120, 121, 124, 125, 127, 128, 129, 130, 137, 142, 143, 144, 145, 148, 150, 151, 152, 152, 155, 157, 158, 159, 160, 161, 162, 163, 168, 169, 170, 171, 172, 173, 174, 179, 180, 181, 182, 183, 184, 185, 190, 191, 192, 193, 197, 202, 203, 208, 209, 211, 212, 215, 220, 221, 222, 224, 227, 231, 234, 235, 236, 239, 244, 245, 246, 248, 251, 255, 258, 259, 260, 261, 262, 263, 268, 269, 270, 271, 272, 273, 274, 278, 283, 284, 285, 287, 290, 294, 297, 298, 299, 300, 303, 308, 309, 310, 312, 315, 319, 321, 326, 327, 363, 364, 369, 370, 373, 374, 379, 380, 381, 382, 383, 390, 395, 396, 399, 400, 405, 406, 407, 408, 409, 416, 421, 422, 423, 426, 428, 429, 430, 431, 431, 434, 436, 437, 438, 444, 445, 451, 458, 459, 464, 465, 467, 472, 473, 474, 478, 479, 483, 484, 489, 490, 495, 496, 497, 499, 503, 504, 510, 511, 516, 517, 519, 520, 525, 526, 531, 532, 533, 535, 545, 546, 547, 548, 549, 550, 551, 552, 556, 559, 563, 566, 570, 573, 577, 580, 584};
/* BEGIN LINEINFO 
assign 1 111 41
new 0 111 41
assign 1 111 42
new 1 111 42
new 0 118 46
addArgs 1 119 47
assign 1 123 115
def 1 123 120
assign 1 124 121
new 0 124 121
assign 1 124 124
lengthGet 0 124 124
assign 1 124 125
lesser 1 124 125
assign 1 125 127
get 1 125 127
assign 1 125 128
process 1 125 128
put 2 125 129
assign 1 124 130
increment 0 124 130
assign 1 128 137
undef 1 128 142
assign 1 129 143
assign 1 130 144
new 0 130 144
assign 1 131 145
new 0 131 145
assign 1 133 148
add 1 133 148
assign 1 135 150
assign 1 136 151
new 0 136 151
assign 1 137 152
iteratorGet 0 0 152
assign 1 137 155
hasNextGet 0 137 155
assign 1 137 157
nextGet 0 137 157
assign 1 138 158
assign 1 139 159
assign 1 140 160
assign 1 141 161
sizeGet 0 141 161
assign 1 141 162
new 0 141 162
assign 1 141 163
greater 1 141 168
assign 1 142 169
new 0 142 169
assign 1 142 170
new 0 142 170
assign 1 142 171
substring 2 142 171
assign 1 143 172
sizeGet 0 143 172
assign 1 143 173
new 0 143 173
assign 1 143 174
greater 1 143 179
assign 1 144 180
new 0 144 180
assign 1 144 181
new 0 144 181
assign 1 144 182
substring 2 144 182
assign 1 145 183
sizeGet 0 145 183
assign 1 145 184
new 0 145 184
assign 1 145 185
greater 1 145 190
assign 1 146 191
new 0 146 191
assign 1 146 192
new 0 146 192
assign 1 146 193
substring 2 146 193
assign 1 150 197
def 1 150 202
assign 1 151 203
not 0 151 208
addParameter 2 152 209
assign 1 154 211
assign 1 155 212
new 0 155 212
assign 1 156 215
def 1 156 220
assign 1 156 221
new 0 156 221
assign 1 156 222
equals 1 156 222
assign 1 0 224
assign 1 0 227
assign 1 0 231
assign 1 157 234
new 0 157 234
assign 1 157 235
sizeGet 0 157 235
assign 1 157 236
substring 2 157 236
assign 1 158 239
def 1 158 244
assign 1 158 245
new 0 158 245
assign 1 158 246
equals 1 158 246
assign 1 0 248
assign 1 0 251
assign 1 0 255
assign 1 159 258
new 0 159 258
assign 1 159 259
sizeGet 0 159 259
assign 1 159 260
substring 2 159 260
assign 1 160 261
new 0 160 261
assign 1 160 262
find 1 160 262
assign 1 161 263
def 1 161 268
assign 1 162 269
new 0 162 269
assign 1 162 270
substring 2 162 270
assign 1 163 271
new 0 163 271
assign 1 163 272
add 1 163 272
assign 1 163 273
substring 1 163 273
addParameter 2 164 274
assign 1 166 278
def 1 166 283
assign 1 166 284
new 0 166 284
assign 1 166 285
equals 1 166 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 167 297
new 0 167 297
assign 1 167 298
sizeGet 0 167 298
assign 1 167 299
substring 2 167 299
assign 1 168 300
new 0 168 300
assign 1 169 303
def 1 169 308
assign 1 169 309
new 0 169 309
assign 1 169 310
equals 1 169 310
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 169 321
not 0 169 326
addValue 1 170 327
assign 1 176 363
assign 1 177 364
def 1 177 369
assign 1 178 370
new 0 178 370
assign 1 178 373
lengthGet 0 178 373
assign 1 178 374
lesser 1 178 379
assign 1 179 380
get 1 179 380
assign 1 179 381
process 1 179 381
put 2 179 382
assign 1 178 383
increment 0 178 383
assign 1 182 390
def 1 182 395
assign 1 183 396
new 0 183 396
assign 1 183 399
lengthGet 0 183 399
assign 1 183 400
lesser 1 183 405
assign 1 184 406
get 1 184 406
assign 1 184 407
process 1 184 407
put 2 184 408
assign 1 183 409
increment 0 183 409
assign 1 187 416
def 1 187 421
assign 1 188 422
new 0 188 422
assign 1 189 423
keyIteratorGet 0 189 423
assign 1 189 426
hasNextGet 0 189 426
assign 1 190 428
nextGet 0 190 428
assign 1 191 429
get 1 191 429
assign 1 192 430
new 0 192 430
assign 1 193 431
linkedListIteratorGet 0 0 431
assign 1 193 434
hasNextGet 0 193 434
assign 1 193 436
nextGet 0 193 436
assign 1 194 437
process 1 194 437
addValue 1 194 438
assign 1 196 444
process 1 196 444
put 2 197 445
assign 1 199 451
assign 1 204 458
getFirst 1 204 458
assign 1 205 459
def 1 205 464
assign 1 207 465
new 1 207 465
return 1 210 467
assign 1 214 472
new 0 214 472
assign 1 214 473
isTrue 2 214 473
return 1 214 474
assign 1 218 478
has 1 218 478
return 1 218 479
assign 1 222 483
get 1 222 483
return 1 222 484
assign 1 226 489
get 1 226 489
assign 1 227 490
undef 1 227 495
assign 1 228 496
new 0 228 496
addValue 1 229 497
return 1 231 499
assign 1 235 503
getFirst 2 235 503
return 1 235 504
assign 1 239 510
get 1 239 510
assign 1 240 511
undef 1 240 516
return 1 241 517
assign 1 243 519
firstGet 0 243 519
return 1 243 520
assign 1 248 525
get 1 248 525
assign 1 249 526
undef 1 249 531
assign 1 250 532
new 0 250 532
put 2 251 533
addValue 1 253 535
assign 1 257 545
readerGet 0 257 545
assign 1 257 546
open 0 257 546
assign 1 257 547
readString 0 257 547
assign 1 258 548
readerGet 0 258 548
close 0 258 549
assign 1 259 550
tokenize 1 259 550
assign 1 259 551
toList 0 259 551
addArgs 1 260 552
return 1 0 556
assign 1 0 559
return 1 0 563
assign 1 0 566
return 1 0 570
assign 1 0 573
return 1 0 577
assign 1 0 580
return 1 0 584
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 1695168417: return bem_paramsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1600549146: return bem_orderedGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1895160755: return bem_fileTokGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case -2127864150: return bem_argsGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 1128894872: return bem_preProcessorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case 187837996: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1139977125: return bem_preProcessorSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1611631399: return bem_orderedSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1906243008: return bem_fileTokSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -516636336: return bem_addArgs_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -381666769: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -191084662: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 98246025: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1957079483: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -191084661: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 187837997: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bevs_inst = (BEC_2_6_10_SystemParameters)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bevs_inst;
}
}
}
