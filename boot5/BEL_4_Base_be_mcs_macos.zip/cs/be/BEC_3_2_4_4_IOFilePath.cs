namespace be {
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath : BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
static BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
private static byte[] bels_0 = {0x3A};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 1));
private static BEC_2_4_3_MathInt bevo_3 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_5 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
public static new BEC_3_2_4_4_IOFilePath bevs_inst;
public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevp_separator = bevt_0_tmpany_phold.bem_separatorGet_0();
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = beva_spath.bem_sizeGet_0();
bevt_3_tmpany_phold = bevo_0;
if (bevt_2_tmpany_phold.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevt_6_tmpany_phold = bevo_1;
bevt_5_tmpany_phold = beva_spath.bem_getPoint_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_2;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 28 */
 else  /* Line: 28 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 28 */ {
bevt_8_tmpany_phold = bevo_3;
bevt_9_tmpany_phold = bevo_4;
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevo_5;
bevt_11_tmpany_phold = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
} /* Line: 30 */
bevt_12_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl_p = bevt_12_tmpany_phold.bem_platformGet_0();
bevt_13_tmpany_phold = bevl_p.bem_otherSeparatorGet_0();
bevt_14_tmpany_phold = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_tmpany_phold, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_3_2_4_4_IOFilePath) this.bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = base.bem_isAbsoluteGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
this.bem_apNew_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_fileGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_file == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 59 */ {
bevp_file = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 61 */
return bevp_file;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_other.bem_fileSet_1(null);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_driveLetter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 75 */ {
bevt_1_tmpany_phold = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_tmpany_phold;
} /* Line: 76 */
return bevp_path;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = base.bem_parentGet_0();
return (BEC_2_6_8_SystemBasePath) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevp_driveLetter = null;
base.bem_makeNonAbsolute_0();
} /* Line: 88 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_4_TextGlob bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_4_TextGlob) (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_match_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = base.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(975920932, BEL_4_Base.bevn_driveLetterSet_1, bevp_driveLetter);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_lastStepGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_driveLetterGet_0() {
return bevp_driveLetter;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {22, 22, 23, 28, 28, 28, 28, 28, 28, 28, 28, 0, 0, 0, 29, 29, 29, 30, 30, 30, 32, 32, 33, 33, 33, 34, 34, 41, 41, 45, 45, 49, 53, 53, 59, 59, 60, 61, 63, 67, 68, 69, 69, 70, 71, 75, 75, 76, 76, 78, 82, 82, 86, 87, 88, 93, 93, 93, 93, 97, 98, 99, 103, 103, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 43, 44, 45, 50, 51, 52, 53, 54, 56, 59, 63, 66, 67, 68, 69, 70, 71, 73, 74, 75, 76, 77, 78, 79, 83, 84, 88, 89, 92, 97, 98, 102, 107, 108, 109, 111, 116, 117, 118, 119, 120, 121, 126, 131, 132, 133, 135, 139, 140, 144, 146, 147, 155, 156, 157, 158, 162, 163, 164, 168, 169, 172, 176, 179};
/* BEGIN LINEINFO 
assign 1 22 20
new 0 22 20
assign 1 22 21
separatorGet 0 22 21
fromString 1 23 22
assign 1 28 43
sizeGet 0 28 43
assign 1 28 44
new 0 28 44
assign 1 28 45
greater 1 28 50
assign 1 28 51
new 0 28 51
assign 1 28 52
getPoint 1 28 52
assign 1 28 53
new 0 28 53
assign 1 28 54
equals 1 28 54
assign 1 0 56
assign 1 0 59
assign 1 0 63
assign 1 29 66
new 0 29 66
assign 1 29 67
new 0 29 67
assign 1 29 68
substring 2 29 68
assign 1 30 69
new 0 30 69
assign 1 30 70
sizeGet 0 30 70
assign 1 30 71
substring 2 30 71
assign 1 32 73
new 0 32 73
assign 1 32 74
platformGet 0 32 74
assign 1 33 75
otherSeparatorGet 0 33 75
assign 1 33 76
separatorGet 0 33 76
assign 1 33 77
swap 2 33 77
assign 1 34 78
new 1 34 78
return 1 34 79
assign 1 41 83
isAbsoluteGet 0 41 83
return 1 41 84
assign 1 45 88
toString 0 45 88
return 1 45 89
apNew 1 49 92
assign 1 53 97
new 0 53 97
return 1 53 98
assign 1 59 102
undef 1 59 107
assign 1 60 108
new 0 60 108
pathSet 1 61 109
return 1 63 111
assign 1 67 116
create 0 67 116
copyTo 1 68 117
assign 1 69 118
copy 0 69 118
pathSet 1 69 119
fileSet 1 70 120
return 1 71 121
assign 1 75 126
def 1 75 131
assign 1 76 132
add 1 76 132
return 1 76 133
return 1 78 135
assign 1 82 139
parentGet 0 82 139
return 1 82 140
assign 1 86 144
isAbsoluteGet 0 86 144
assign 1 87 146
makeNonAbsolute 0 88 147
assign 1 93 155
new 1 93 155
assign 1 93 156
toString 0 93 156
assign 1 93 157
match 1 93 157
return 1 93 158
assign 1 97 162
subPath 2 97 162
driveLetterSet 1 98 163
return 1 99 164
assign 1 103 168
lastStepGet 0 103 168
return 1 103 169
assign 1 0 172
return 1 0 176
assign 1 0 179
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case -1081412016: return bem_many_0();
case -1338882709: return bem_fileGet_0();
case 964838679: return bem_driveLetterGet_0();
case 1359432006: return bem_isAbsoluteGet_0();
case -1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case 1211273660: return bem_nameGet_0();
case -471950299: return bem_lastStepGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -935459934: return bem_deleteFirstStep_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case -729571811: return bem_serializeToString_0();
case -1719674549: return bem_firstStepGet_0();
case -723109216: return bem_stepsGet_0();
case -1354714650: return bem_copy_0();
case -400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case -1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 14682424: return bem_addSteps_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -824830365: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -630006451: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1787791811: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 975920932: return bem_driveLetterSet_1(bevd_0);
case -494959043: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -488966921: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case -2006569863: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1327800456: return bem_fileSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -389107089: return bem_pathSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 92659731: return bem_add_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case -488966920: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_4_IOFilePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_4_IOFilePath.bevs_inst = (BEC_3_2_4_4_IOFilePath)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_4_IOFilePath.bevs_inst;
}
}
}
