namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_8_BuildClassSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
static BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_14 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_15, 90));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_15 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_16, 84));
private static byte[] bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_16 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_17, 80));
private static byte[] bels_18 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_17 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_18, 9));
private static byte[] bels_19 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_18 = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(bels_19, 26));
public static new BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 96 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 99 */
} /* Line: 98 */
 else  /* Line: 96 */ {
break;
} /* Line: 96 */
} /* Line: 96 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 107 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 109 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(-1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpany_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 132 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpany_phold);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 135 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
 else  /* Line: 135 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 135 */ {
bevt_24_tmpany_phold = bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 136 */
} /* Line: 135 */
 else  /* Line: 132 */ {
break;
} /* Line: 132 */
} /* Line: 132 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 141 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpany_phold != null && bevt_33_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpany_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpany_phold);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevt_39_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 148 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpany_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 151 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_54_tmpany_phold = bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 154 */
} /* Line: 153 */
} /* Line: 152 */
} /* Line: 151 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 168 */ {
return this;
} /* Line: 168 */
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 178 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 178 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 179 */
 else  /* Line: 178 */ {
break;
} /* Line: 178 */
} /* Line: 178 */
return this;
} /* Line: 181 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 188 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_19_tmpany_phold = bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 190 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_26_tmpany_phold = bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 193 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 195 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 195 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 195 */
 else  /* Line: 195 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 195 */ {
bevt_33_tmpany_phold = bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 196 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 198 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 198 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 200 */ {
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 203 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 206 */
} /* Line: 205 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 210 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpany_phold).bevi_bool) /* Line: 210 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevt_52_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 217 */
} /* Line: 214 */
 else  /* Line: 219 */ {
bevt_54_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 223 */
} /* Line: 213 */
 else  /* Line: 210 */ {
break;
} /* Line: 210 */
} /* Line: 210 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 230 */ {
return this;
} /* Line: 230 */
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 232 */ {
return this;
} /* Line: 232 */
bevl_psyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_4_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 234 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 234 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_7_tmpany_phold = bevl_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_9_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_7_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_8_tmpany_phold);
if (bevl_pv == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_12_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevt_17_tmpany_phold = bevo_9;
bevt_19_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_20_tmpany_phold = bevo_10;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_13_tmpany_phold);
} /* Line: 239 */
 else  /* Line: 240 */ {
bevt_24_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_24_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_28_tmpany_phold);
} /* Line: 242 */
} /* Line: 238 */
} /* Line: 237 */
 else  /* Line: 234 */ {
break;
} /* Line: 234 */
} /* Line: 234 */
bevt_31_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_30_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 246 */ {
bevt_32_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 246 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_33_tmpany_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_35_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_33_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_34_tmpany_phold);
if (bevl_pm == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_37_tmpany_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_37_tmpany_phold != null && bevt_37_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpany_phold).bevi_bool) /* Line: 250 */ {
bevt_42_tmpany_phold = bevo_11;
bevt_44_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_45_tmpany_phold = bevo_12;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_tmpany_phold);
} /* Line: 251 */
bevt_50_tmpany_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_49_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 254 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_51_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_52_tmpany_phold);
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_51_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevt_54_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_54_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_55_tmpany_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_55_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_56_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_56_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
if (bevl_omr == null) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 262 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 262 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 262 */ {
if (bevl_pmr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
if (bevl_omr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 263 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 263 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 263 */ {
bevt_65_tmpany_phold = bevo_13;
bevt_68_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_add_1(bevt_66_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_tmpany_phold);
} /* Line: 268 */
} /* Line: 263 */
 else  /* Line: 270 */ {
bevt_69_tmpany_phold = bevl_pmr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
if (bevt_69_tmpany_phold != null && bevt_69_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_69_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_71_tmpany_phold = bevl_pmr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
bevt_72_tmpany_phold = bevl_omr.bemd_0(595432319, BEL_4_Base.bevn_isThisGet_0);
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_72_tmpany_phold);
if (bevt_70_tmpany_phold != null && bevt_70_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_70_tmpany_phold).bevi_bool) /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 272 */ {
bevt_75_tmpany_phold = bevo_14;
bevt_78_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_76_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 273 */
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 275 */
} /* Line: 262 */
} /* Line: 249 */
 else  /* Line: 246 */ {
break;
} /* Line: 246 */
} /* Line: 246 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpany_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = bevo_15;
bevt_9_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 283 */
 else  /* Line: 282 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 287 */ {
return this;
} /* Line: 288 */
bevt_13_tmpany_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(-986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpany_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 291 */ {
bevt_20_tmpany_phold = bevo_16;
bevt_23_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 292 */
} /* Line: 291 */
} /* Line: 282 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
this.bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 299 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 299 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 301 */ {
bevt_10_tmpany_phold = bevo_17;
bevt_12_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevo_18;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 302 */
} /* Line: 301 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 317 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 317 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 319 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
bevt_11_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 321 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 321 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
bevt_14_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 326 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 326 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 329 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 339 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 343 */
} /* Line: 341 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 349 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 356 */
} /* Line: 351 */
 else  /* Line: 349 */ {
break;
} /* Line: 349 */
} /* Line: 349 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 363 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 363 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 369 */
} /* Line: 368 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 375 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 375 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 389 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(-885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpany_phold);
bevl_oma.bemd_1(-1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 395 */
} /* Line: 377 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 400 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 400 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {72, 74, 76, 78, 79, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 95, 96, 96, 97, 98, 98, 98, 99, 102, 106, 106, 107, 107, 109, 109, 111, 111, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 132, 132, 132, 132, 133, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 0, 0, 0, 135, 135, 135, 0, 0, 0, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 136, 141, 141, 141, 142, 143, 143, 144, 144, 144, 144, 148, 148, 148, 148, 149, 150, 150, 150, 150, 151, 151, 152, 152, 152, 153, 153, 153, 153, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 154, 159, 160, 160, 160, 164, 164, 168, 169, 170, 171, 172, 173, 173, 174, 175, 176, 177, 178, 0, 178, 178, 179, 179, 179, 179, 181, 183, 184, 185, 187, 187, 187, 187, 188, 188, 188, 189, 190, 190, 190, 190, 190, 192, 192, 192, 0, 0, 0, 193, 193, 193, 193, 193, 195, 195, 195, 0, 0, 0, 195, 195, 0, 0, 0, 196, 196, 196, 196, 196, 198, 0, 198, 198, 199, 200, 200, 200, 200, 200, 200, 200, 200, 0, 0, 0, 202, 203, 205, 205, 205, 205, 205, 206, 210, 210, 211, 212, 212, 212, 213, 213, 214, 215, 215, 216, 216, 217, 220, 220, 221, 222, 223, 223, 223, 223, 230, 231, 232, 232, 232, 233, 234, 234, 234, 234, 235, 236, 236, 236, 236, 237, 237, 238, 238, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 239, 241, 241, 241, 241, 242, 242, 242, 242, 246, 246, 246, 246, 247, 248, 248, 248, 248, 249, 249, 250, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 251, 253, 253, 253, 254, 254, 254, 254, 255, 255, 256, 256, 258, 254, 260, 261, 261, 262, 262, 0, 262, 262, 0, 0, 263, 263, 263, 0, 263, 263, 263, 0, 0, 268, 268, 268, 268, 268, 268, 268, 272, 272, 272, 272, 0, 0, 0, 273, 273, 273, 273, 273, 273, 273, 275, 282, 282, 282, 283, 283, 283, 283, 283, 283, 283, 284, 287, 287, 0, 0, 0, 288, 290, 290, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 292, 298, 299, 299, 299, 299, 300, 301, 301, 301, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 302, 305, 306, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 317, 317, 317, 317, 318, 319, 319, 321, 321, 321, 321, 322, 323, 324, 326, 326, 326, 326, 327, 328, 329, 331, 335, 336, 339, 339, 340, 341, 341, 341, 341, 343, 343, 347, 348, 349, 349, 350, 351, 351, 351, 351, 352, 352, 353, 354, 354, 355, 356, 356, 356, 359, 361, 363, 363, 364, 366, 366, 368, 368, 368, 368, 369, 369, 373, 374, 375, 375, 376, 377, 377, 377, 377, 378, 378, 387, 387, 388, 388, 388, 389, 389, 391, 391, 392, 393, 394, 395, 395, 395, 398, 400, 0, 400, 400, 401, 402, 405, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 100, 101, 104, 106, 107, 108, 113, 114, 121, 129, 130, 131, 136, 137, 138, 140, 141, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 238, 240, 241, 242, 243, 244, 245, 246, 247, 248, 250, 255, 256, 259, 263, 266, 267, 268, 270, 273, 277, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 298, 299, 302, 304, 305, 306, 308, 309, 310, 311, 318, 319, 320, 323, 325, 326, 327, 328, 329, 330, 335, 336, 337, 342, 343, 344, 345, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 370, 371, 372, 373, 378, 379, 447, 449, 450, 451, 452, 453, 458, 459, 460, 461, 462, 463, 463, 466, 468, 469, 470, 471, 472, 478, 480, 481, 482, 483, 484, 485, 486, 487, 488, 490, 492, 494, 495, 496, 497, 498, 500, 502, 503, 505, 508, 512, 515, 516, 517, 518, 519, 521, 523, 528, 529, 532, 536, 539, 544, 545, 548, 552, 555, 556, 557, 558, 559, 561, 561, 564, 566, 567, 568, 569, 570, 571, 576, 577, 578, 579, 581, 584, 588, 591, 592, 594, 595, 596, 597, 602, 603, 610, 613, 615, 616, 617, 618, 619, 624, 625, 627, 628, 629, 630, 631, 635, 636, 637, 638, 639, 640, 641, 642, 743, 745, 746, 751, 752, 754, 755, 756, 757, 760, 762, 763, 764, 765, 766, 767, 772, 773, 774, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 790, 791, 792, 793, 794, 795, 796, 797, 805, 806, 807, 810, 812, 813, 814, 815, 816, 817, 822, 823, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 838, 839, 840, 841, 844, 845, 846, 848, 849, 850, 851, 852, 853, 859, 860, 861, 862, 867, 868, 871, 876, 877, 880, 884, 889, 894, 895, 898, 903, 908, 909, 912, 916, 917, 918, 919, 920, 921, 922, 926, 928, 929, 930, 932, 935, 939, 942, 943, 944, 945, 946, 947, 948, 950, 986, 987, 988, 990, 991, 992, 993, 994, 995, 996, 999, 1001, 1003, 1005, 1008, 1012, 1015, 1017, 1018, 1019, 1020, 1021, 1022, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1056, 1057, 1058, 1059, 1062, 1064, 1065, 1066, 1067, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1087, 1088, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1133, 1135, 1136, 1137, 1143, 1144, 1145, 1148, 1150, 1151, 1152, 1158, 1159, 1160, 1163, 1165, 1166, 1167, 1173, 1224, 1225, 1226, 1229, 1231, 1232, 1233, 1234, 1239, 1240, 1241, 1248, 1249, 1250, 1253, 1255, 1256, 1257, 1258, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1279, 1280, 1281, 1284, 1286, 1287, 1288, 1289, 1290, 1291, 1296, 1297, 1298, 1305, 1306, 1307, 1310, 1312, 1313, 1314, 1315, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1331, 1332, 1333, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1349, 1350, 1350, 1353, 1355, 1356, 1357, 1363, 1367, 1370, 1374, 1377, 1381, 1384, 1388, 1391, 1395, 1398, 1402, 1405, 1409, 1412, 1416, 1419, 1423, 1426, 1430, 1433, 1437, 1440, 1444, 1447, 1451, 1454, 1458, 1461, 1465, 1468, 1472, 1475, 1479, 1482, 1486, 1489, 1493, 1496, 1500, 1503, 1507, 1510, 1514, 1517, 1521, 1524, 1528, 1531, 1535, 1538, 1542, 1545, 1549, 1552};
/* BEGIN LINEINFO 
assign 1 72 76
new 0 72 76
assign 1 74 77
new 0 74 77
assign 1 76 78
new 0 76 78
assign 1 78 79
new 0 78 79
assign 1 79 80
new 0 79 80
assign 1 80 81
new 0 80 81
assign 1 81 82
new 0 81 82
assign 1 82 83
new 0 82 83
assign 1 83 84
new 0 83 84
assign 1 84 85
new 0 84 85
assign 1 85 86
new 0 85 86
assign 1 87 87
new 0 87 87
assign 1 88 88
new 0 88 88
assign 1 89 89
new 0 89 89
assign 1 90 90
new 0 90 90
assign 1 95 100
new 0 95 100
assign 1 96 101
valueIteratorGet 0 96 101
assign 1 96 104
hasNextGet 0 96 104
assign 1 97 106
nextGet 0 97 106
assign 1 98 107
mtdxGet 0 98 107
assign 1 98 108
greater 1 98 113
assign 1 99 114
mtdxGet 0 99 114
return 1 102 121
assign 1 106 129
new 0 106 129
assign 1 106 130
get 1 106 130
assign 1 107 131
def 1 107 136
assign 1 109 137
new 0 109 137
return 1 109 138
assign 1 111 140
new 0 111 140
return 1 111 141
assign 1 115 214
new 0 115 214
assign 1 116 215
new 0 116 215
assign 1 117 216
new 0 117 216
assign 1 118 217
new 0 118 217
assign 1 119 218
new 0 119 218
assign 1 120 219
new 0 120 219
assign 1 121 220
new 0 121 220
assign 1 122 221
new 0 122 221
assign 1 123 222
new 0 123 222
assign 1 124 223
new 0 124 223
assign 1 125 224
new 0 125 224
assign 1 126 225
superListGet 0 126 225
assign 1 126 226
copy 0 126 226
assign 1 127 227
namepathGet 0 127 227
addValue 1 127 228
assign 1 128 229
mtdListGet 0 128 229
assign 1 128 230
copy 0 128 230
assign 1 129 231
ptyListGet 0 129 231
assign 1 129 232
copy 0 129 232
assign 1 132 233
heldGet 0 132 233
assign 1 132 234
orderedVarsGet 0 132 234
assign 1 132 235
iteratorGet 0 132 235
assign 1 132 238
hasNextGet 0 132 238
assign 1 133 240
nextGet 0 133 240
assign 1 134 241
ptyMapGet 0 134 241
assign 1 134 242
heldGet 0 134 242
assign 1 134 243
nameGet 0 134 243
assign 1 134 244
get 1 134 244
assign 1 135 245
heldGet 0 135 245
assign 1 135 246
nameGet 0 135 246
assign 1 135 247
new 0 135 247
assign 1 135 248
notEquals 1 135 248
assign 1 135 250
undef 1 135 255
assign 1 0 256
assign 1 0 259
assign 1 0 263
assign 1 135 266
heldGet 0 135 266
assign 1 135 267
isDeclaredGet 0 135 267
assign 1 135 268
not 0 135 268
assign 1 0 270
assign 1 0 273
assign 1 0 277
assign 1 136 280
new 0 136 280
assign 1 136 281
heldGet 0 136 281
assign 1 136 282
nameGet 0 136 282
assign 1 136 283
add 1 136 283
assign 1 136 284
new 0 136 284
assign 1 136 285
add 1 136 285
assign 1 136 286
heldGet 0 136 286
assign 1 136 287
namepathGet 0 136 287
assign 1 136 288
toString 0 136 288
assign 1 136 289
add 1 136 289
assign 1 136 290
new 2 136 290
throw 1 136 291
assign 1 141 298
ptyListGet 0 141 298
assign 1 141 299
iteratorGet 0 141 299
assign 1 141 302
hasNextGet 0 141 302
assign 1 142 304
nextGet 0 142 304
assign 1 143 305
memSynGet 0 143 305
assign 1 143 306
isTypedGet 0 143 306
assign 1 144 308
heldGet 0 144 308
assign 1 144 309
memSynGet 0 144 309
assign 1 144 310
namepathGet 0 144 310
addUsed 1 144 311
assign 1 148 318
heldGet 0 148 318
assign 1 148 319
orderedMethodsGet 0 148 319
assign 1 148 320
iteratorGet 0 148 320
assign 1 148 323
hasNextGet 0 148 323
assign 1 149 325
nextGet 0 149 325
assign 1 150 326
mtdMapGet 0 150 326
assign 1 150 327
heldGet 0 150 327
assign 1 150 328
nameGet 0 150 328
assign 1 150 329
get 1 150 329
assign 1 151 330
def 1 151 335
assign 1 152 336
rsynGet 0 152 336
assign 1 152 337
def 1 152 342
assign 1 153 343
heldGet 0 153 343
assign 1 153 344
rtypeGet 0 153 344
assign 1 153 345
undef 1 153 350
assign 1 154 351
new 0 154 351
assign 1 154 352
heldGet 0 154 352
assign 1 154 353
nameGet 0 154 353
assign 1 154 354
add 1 154 354
assign 1 154 355
new 0 154 355
assign 1 154 356
add 1 154 356
assign 1 154 357
heldGet 0 154 357
assign 1 154 358
nameGet 0 154 358
assign 1 154 359
add 1 154 359
assign 1 154 360
new 2 154 360
throw 1 154 361
loadClass 1 159 370
assign 1 160 371
depthGet 0 160 371
assign 1 160 372
new 0 160 372
assign 1 160 373
add 1 160 373
assign 1 164 378
has 1 164 378
return 1 164 379
return 1 168 447
assign 1 169 449
new 0 169 449
assign 1 170 450
new 0 170 450
assign 1 171 451
new 0 171 451
assign 1 172 452
new 0 172 452
assign 1 173 453
undef 1 173 458
assign 1 174 459
new 0 174 459
assign 1 175 460
sizeGet 0 175 460
assign 1 176 461
sizeGet 0 176 461
assign 1 177 462
assign 1 178 463
iteratorGet 0 0 463
assign 1 178 466
hasNextGet 0 178 466
assign 1 178 468
nextGet 0 178 468
assign 1 179 469
emitDataGet 0 179 469
assign 1 179 470
methodIndexesGet 0 179 470
assign 1 179 471
new 2 179 471
put 1 179 472
return 1 181 478
assign 1 183 480
getSynNp 1 183 480
assign 1 184 481
new 0 184 481
assign 1 185 482
new 0 185 482
assign 1 187 483
sizeGet 0 187 483
assign 1 187 484
ptyListGet 0 187 484
assign 1 187 485
sizeGet 0 187 485
assign 1 187 486
subtract 1 187 486
assign 1 188 487
libNameGet 0 188 487
assign 1 188 488
equals 1 188 488
integrate 1 188 490
assign 1 189 492
isFinalGet 0 189 492
assign 1 190 494
new 0 190 494
assign 1 190 495
toString 0 190 495
assign 1 190 496
add 1 190 496
assign 1 190 497
new 1 190 497
throw 1 190 498
assign 1 192 500
isLocalGet 0 192 500
assign 1 192 502
libNameGet 0 192 502
assign 1 192 503
notEquals 1 192 503
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 193 515
new 0 193 515
assign 1 193 516
toString 0 193 516
assign 1 193 517
add 1 193 517
assign 1 193 518
new 1 193 518
throw 1 193 519
assign 1 195 521
isLocalGet 0 195 521
assign 1 195 523
not 0 195 528
assign 1 0 529
assign 1 0 532
assign 1 0 536
assign 1 195 539
not 0 195 544
assign 1 0 545
assign 1 0 548
assign 1 0 552
assign 1 196 555
new 0 196 555
assign 1 196 556
toString 0 196 556
assign 1 196 557
add 1 196 557
assign 1 196 558
new 1 196 558
throw 1 196 559
assign 1 198 561
linkedListIteratorGet 0 0 561
assign 1 198 564
hasNextGet 0 198 564
assign 1 198 566
nextGet 0 198 566
assign 1 199 567
getSynNp 1 199 567
assign 1 200 568
closeLibrariesGet 0 200 568
assign 1 200 569
libNameGet 0 200 569
assign 1 200 570
has 1 200 570
assign 1 200 571
not 0 200 576
assign 1 200 577
toString 0 200 577
assign 1 200 578
new 0 200 578
assign 1 200 579
notEquals 1 200 579
assign 1 0 581
assign 1 0 584
assign 1 0 588
assign 1 202 591
new 0 202 591
assign 1 203 592
new 0 203 592
assign 1 205 594
closeLibrariesGet 0 205 594
assign 1 205 595
libNameGet 0 205 595
assign 1 205 596
has 1 205 596
assign 1 205 597
not 0 205 602
assign 1 206 603
new 0 206 603
assign 1 210 610
valueIteratorGet 0 210 610
assign 1 210 613
hasNextGet 0 210 613
assign 1 211 615
nextGet 0 211 615
assign 1 212 616
mtdMapGet 0 212 616
assign 1 212 617
nameGet 0 212 617
assign 1 212 618
get 1 212 618
assign 1 213 619
def 1 213 624
assign 1 214 625
notEquals 1 214 625
assign 1 215 627
new 0 215 627
lastDefSet 1 215 628
assign 1 216 629
new 0 216 629
isOverrideSet 1 216 630
assign 1 217 631
increment 0 217 631
assign 1 220 635
new 0 220 635
isOverrideSet 1 220 636
assign 1 221 637
increment 0 221 637
assign 1 222 638
increment 0 222 638
assign 1 223 639
emitDataGet 0 223 639
assign 1 223 640
methodIndexesGet 0 223 640
assign 1 223 641
new 2 223 641
put 1 223 642
return 1 230 743
assign 1 231 745
new 0 231 745
assign 1 232 746
undef 1 232 751
return 1 232 752
assign 1 233 754
getSynNp 1 233 754
assign 1 234 755
heldGet 0 234 755
assign 1 234 756
orderedVarsGet 0 234 756
assign 1 234 757
iteratorGet 0 234 757
assign 1 234 760
hasNextGet 0 234 760
assign 1 235 762
nextGet 0 235 762
assign 1 236 763
ptyMapGet 0 236 763
assign 1 236 764
heldGet 0 236 764
assign 1 236 765
nameGet 0 236 765
assign 1 236 766
get 1 236 766
assign 1 237 767
def 1 237 772
assign 1 238 773
heldGet 0 238 773
assign 1 238 774
isDeclaredGet 0 238 774
assign 1 239 776
new 0 239 776
assign 1 239 777
heldGet 0 239 777
assign 1 239 778
nameGet 0 239 778
assign 1 239 779
add 1 239 779
assign 1 239 780
new 0 239 780
assign 1 239 781
add 1 239 781
assign 1 239 782
heldGet 0 239 782
assign 1 239 783
namepathGet 0 239 783
assign 1 239 784
toString 0 239 784
assign 1 239 785
add 1 239 785
assign 1 239 786
new 1 239 786
throw 1 239 787
assign 1 241 790
heldGet 0 241 790
assign 1 241 791
memSynGet 0 241 791
assign 1 241 792
isTypedGet 0 241 792
isTypedSet 1 241 793
assign 1 242 794
heldGet 0 242 794
assign 1 242 795
memSynGet 0 242 795
assign 1 242 796
namepathGet 0 242 796
namepathSet 1 242 797
assign 1 246 805
heldGet 0 246 805
assign 1 246 806
orderedMethodsGet 0 246 806
assign 1 246 807
iteratorGet 0 246 807
assign 1 246 810
hasNextGet 0 246 810
assign 1 247 812
nextGet 0 247 812
assign 1 248 813
mtdMapGet 0 248 813
assign 1 248 814
heldGet 0 248 814
assign 1 248 815
nameGet 0 248 815
assign 1 248 816
get 1 248 816
assign 1 249 817
def 1 249 822
assign 1 250 823
isFinalGet 0 250 823
assign 1 251 825
new 0 251 825
assign 1 251 826
heldGet 0 251 826
assign 1 251 827
nameGet 0 251 827
assign 1 251 828
add 1 251 828
assign 1 251 829
new 0 251 829
assign 1 251 830
add 1 251 830
assign 1 251 831
heldGet 0 251 831
assign 1 251 832
namepathGet 0 251 832
assign 1 251 833
toString 0 251 833
assign 1 251 834
add 1 251 834
assign 1 251 835
new 2 251 835
throw 1 251 836
assign 1 253 838
containedGet 0 253 838
assign 1 253 839
firstGet 0 253 839
assign 1 253 840
containedGet 0 253 840
assign 1 254 841
new 0 254 841
assign 1 254 844
argSynsGet 0 254 844
assign 1 254 845
lengthGet 0 254 845
assign 1 254 846
lesser 1 254 846
assign 1 255 848
argSynsGet 0 255 848
assign 1 255 849
get 1 255 849
assign 1 256 850
get 1 256 850
assign 1 256 851
heldGet 0 256 851
checkTypes 5 258 852
assign 1 254 853
increment 0 254 853
assign 1 260 859
rsynGet 0 260 859
assign 1 261 860
heldGet 0 261 860
assign 1 261 861
rtypeGet 0 261 861
assign 1 262 862
undef 1 262 867
assign 1 0 868
assign 1 262 871
undef 1 262 876
assign 1 0 877
assign 1 0 880
assign 1 263 884
undef 1 263 889
assign 1 263 889
not 0 263 894
assign 1 0 895
assign 1 263 898
undef 1 263 903
assign 1 263 903
not 0 263 908
assign 1 0 909
assign 1 0 912
assign 1 268 916
new 0 268 916
assign 1 268 917
heldGet 0 268 917
assign 1 268 918
namepathGet 0 268 918
assign 1 268 919
toString 0 268 919
assign 1 268 920
add 1 268 920
assign 1 268 921
new 2 268 921
throw 1 268 922
assign 1 272 926
isThisGet 0 272 926
assign 1 272 928
isThisGet 0 272 928
assign 1 272 929
isThisGet 0 272 929
assign 1 272 930
notEquals 1 272 930
assign 1 0 932
assign 1 0 935
assign 1 0 939
assign 1 273 942
new 0 273 942
assign 1 273 943
heldGet 0 273 943
assign 1 273 944
namepathGet 0 273 944
assign 1 273 945
toString 0 273 945
assign 1 273 946
add 1 273 946
assign 1 273 947
new 2 273 947
throw 1 273 948
checkTypes 5 275 950
assign 1 282 986
isTypedGet 0 282 986
assign 1 282 987
isTypedGet 0 282 987
assign 1 282 988
notEquals 1 282 988
assign 1 283 990
new 0 283 990
assign 1 283 991
heldGet 0 283 991
assign 1 283 992
namepathGet 0 283 992
assign 1 283 993
toString 0 283 993
assign 1 283 994
add 1 283 994
assign 1 283 995
new 2 283 995
throw 1 283 996
assign 1 284 999
isTypedGet 0 284 999
assign 1 287 1001
isSelfGet 0 287 1001
assign 1 287 1003
isSelfGet 0 287 1003
assign 1 0 1005
assign 1 0 1008
assign 1 0 1012
return 1 288 1015
assign 1 290 1017
namepathGet 0 290 1017
assign 1 290 1018
getSynNp 1 290 1018
assign 1 291 1019
allTypesGet 0 291 1019
assign 1 291 1020
namepathGet 0 291 1020
assign 1 291 1021
has 1 291 1021
assign 1 291 1022
not 0 291 1022
assign 1 292 1024
new 0 292 1024
assign 1 292 1025
heldGet 0 292 1025
assign 1 292 1026
namepathGet 0 292 1026
assign 1 292 1027
toString 0 292 1027
assign 1 292 1028
add 1 292 1028
assign 1 292 1029
new 2 292 1029
throw 1 292 1030
new 0 298 1056
assign 1 299 1057
heldGet 0 299 1057
assign 1 299 1058
orderedVarsGet 0 299 1058
assign 1 299 1059
iteratorGet 0 299 1059
assign 1 299 1062
hasNextGet 0 299 1062
assign 1 300 1064
nextGet 0 300 1064
assign 1 301 1065
heldGet 0 301 1065
assign 1 301 1066
isDeclaredGet 0 301 1066
assign 1 301 1067
not 0 301 1067
assign 1 302 1069
new 0 302 1069
assign 1 302 1070
heldGet 0 302 1070
assign 1 302 1071
nameGet 0 302 1071
assign 1 302 1072
add 1 302 1072
assign 1 302 1073
new 0 302 1073
assign 1 302 1074
add 1 302 1074
assign 1 302 1075
heldGet 0 302 1075
assign 1 302 1076
namepathGet 0 302 1076
assign 1 302 1077
toString 0 302 1077
assign 1 302 1078
add 1 302 1078
assign 1 302 1079
new 2 302 1079
throw 1 302 1080
loadClass 1 305 1087
assign 1 306 1088
new 0 306 1088
assign 1 311 1116
heldGet 0 311 1116
assign 1 311 1117
fromFileGet 0 311 1117
assign 1 312 1118
heldGet 0 312 1118
assign 1 312 1119
namepathGet 0 312 1119
assign 1 313 1120
heldGet 0 313 1120
assign 1 313 1121
libNameGet 0 313 1121
assign 1 314 1122
heldGet 0 314 1122
assign 1 314 1123
isFinalGet 0 314 1123
assign 1 315 1124
heldGet 0 315 1124
assign 1 315 1125
isLocalGet 0 315 1125
assign 1 316 1126
heldGet 0 316 1126
assign 1 316 1127
isNotNullGet 0 316 1127
assign 1 317 1128
heldGet 0 317 1128
assign 1 317 1129
usedGet 0 317 1129
assign 1 317 1130
iteratorGet 0 317 1130
assign 1 317 1133
hasNextGet 0 317 1133
assign 1 318 1135
nextGet 0 318 1135
assign 1 319 1136
toString 0 319 1136
put 1 319 1137
assign 1 321 1143
heldGet 0 321 1143
assign 1 321 1144
orderedVarsGet 0 321 1144
assign 1 321 1145
iteratorGet 0 321 1145
assign 1 321 1148
hasNextGet 0 321 1148
assign 1 322 1150
nextGet 0 322 1150
assign 1 323 1151
new 2 323 1151
addValue 1 324 1152
assign 1 326 1158
heldGet 0 326 1158
assign 1 326 1159
orderedMethodsGet 0 326 1159
assign 1 326 1160
iteratorGet 0 326 1160
assign 1 326 1163
hasNextGet 0 326 1163
assign 1 327 1165
nextGet 0 327 1165
assign 1 328 1166
new 2 328 1166
addValue 1 329 1167
postLoad 0 331 1173
assign 1 335 1224
new 0 335 1224
assign 1 336 1225
new 0 336 1225
assign 1 339 1226
iteratorGet 0 339 1226
assign 1 339 1229
hasNextGet 0 339 1229
assign 1 340 1231
nextGet 0 340 1231
assign 1 341 1232
nameGet 0 341 1232
assign 1 341 1233
has 1 341 1233
assign 1 341 1234
not 0 341 1239
assign 1 343 1240
nameGet 0 343 1240
put 2 343 1241
assign 1 347 1248
new 0 347 1248
assign 1 348 1249
new 0 348 1249
assign 1 349 1250
iteratorGet 0 349 1250
assign 1 349 1253
hasNextGet 0 349 1253
assign 1 350 1255
nextGet 0 350 1255
assign 1 351 1256
nameGet 0 351 1256
assign 1 351 1257
has 1 351 1257
assign 1 351 1258
not 0 351 1263
assign 1 352 1264
nameGet 0 352 1264
assign 1 352 1265
get 1 352 1265
mposSet 1 353 1266
assign 1 354 1267
new 0 354 1267
assign 1 354 1268
add 1 354 1268
addValue 1 355 1269
assign 1 356 1270
nameGet 0 356 1270
assign 1 356 1271
nameGet 0 356 1271
put 2 356 1272
assign 1 359 1279
assign 1 361 1280
new 0 361 1280
assign 1 363 1281
iteratorGet 0 363 1281
assign 1 363 1284
hasNextGet 0 363 1284
assign 1 364 1286
nextGet 0 364 1286
assign 1 366 1287
nameGet 0 366 1287
put 2 366 1288
assign 1 368 1289
nameGet 0 368 1289
assign 1 368 1290
has 1 368 1290
assign 1 368 1291
not 0 368 1296
assign 1 369 1297
nameGet 0 369 1297
put 2 369 1298
assign 1 373 1305
new 0 373 1305
assign 1 374 1306
new 0 374 1306
assign 1 375 1307
iteratorGet 0 375 1307
assign 1 375 1310
hasNextGet 0 375 1310
assign 1 376 1312
nextGet 0 376 1312
assign 1 377 1313
nameGet 0 377 1313
assign 1 377 1314
has 1 377 1314
assign 1 377 1315
not 0 377 1320
assign 1 378 1321
nameGet 0 378 1321
assign 1 378 1322
get 1 378 1322
assign 1 387 1323
nameGet 0 387 1323
assign 1 387 1324
get 1 387 1324
assign 1 388 1325
declarationGet 0 388 1325
assign 1 388 1326
undef 1 388 1331
assign 1 389 1332
originGet 0 389 1332
declarationSet 1 389 1333
assign 1 391 1335
declarationGet 0 391 1335
declarationSet 1 391 1336
mtdxSet 1 392 1337
assign 1 393 1338
increment 0 393 1338
addValue 1 394 1339
assign 1 395 1340
nameGet 0 395 1340
assign 1 395 1341
nameGet 0 395 1341
put 2 395 1342
assign 1 398 1349
assign 1 400 1350
linkedListIteratorGet 0 0 1350
assign 1 400 1353
hasNextGet 0 400 1353
assign 1 400 1355
nextGet 0 400 1355
put 2 401 1356
assign 1 402 1357
put 2 405 1363
return 1 0 1367
assign 1 0 1370
return 1 0 1374
assign 1 0 1377
return 1 0 1381
assign 1 0 1384
return 1 0 1388
assign 1 0 1391
return 1 0 1395
assign 1 0 1398
return 1 0 1402
assign 1 0 1405
return 1 0 1409
assign 1 0 1412
return 1 0 1416
assign 1 0 1419
return 1 0 1423
assign 1 0 1426
return 1 0 1430
assign 1 0 1433
return 1 0 1437
assign 1 0 1440
return 1 0 1444
assign 1 0 1447
return 1 0 1451
assign 1 0 1454
return 1 0 1458
assign 1 0 1461
return 1 0 1465
assign 1 0 1468
return 1 0 1472
assign 1 0 1475
return 1 0 1479
assign 1 0 1482
return 1 0 1486
assign 1 0 1489
return 1 0 1493
assign 1 0 1496
return 1 0 1500
assign 1 0 1503
return 1 0 1507
assign 1 0 1510
return 1 0 1514
assign 1 0 1517
return 1 0 1521
assign 1 0 1524
return 1 0 1528
assign 1 0 1531
return 1 0 1535
assign 1 0 1538
return 1 0 1542
assign 1 0 1545
return 1 0 1549
assign 1 0 1552
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) {
switch (callHash) {
case 481879936: return bem_hasDefaultGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case -492006165: return bem_directPropertiesGet_0();
case 795036897: return bem_fromFileGet_0();
case 363636983: return bem_isNotNullGet_0();
case -1081412016: return bem_many_0();
case 287367803: return bem_isFinalGet_0();
case -1974592946: return bem_superListGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 2033393684: return bem_ptyListGet_0();
case 244359240: return bem_mtdMapGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1774940957: return bem_toString_0();
case -1012494862: return bem_once_0();
case -2097069068: return bem_integratedGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case -986531569: return bem_allTypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -1760712968: return bem_signatureCheckedGet_0();
case -1354714650: return bem_copy_0();
case 1477961836: return bem_mtdListGet_0();
case -311680096: return bem_allNamesGet_0();
case 1314364113: return bem_newMbrsGet_0();
case -1182494494: return bem_toAny_0();
case -153365600: return bem_ptyMapGet_0();
case -2058095605: return bem_signatureChangedGet_0();
case -314718434: return bem_print_0();
case -1214937871: return bem_newMtdsGet_0();
case 354142775: return bem_namepathGet_0();
case 71634217: return bem_iCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 202810500: return bem_depthGet_0();
case 287040793: return bem_hashGet_0();
case -1308786538: return bem_echo_0();
case 68632810: return bem_superNpGet_0();
case 1413594071: return bem_postLoad_0();
case -1803479881: return bem_libNameGet_0();
case 345555227: return bem_usesGet_0();
case 834964524: return bem_defMtdsGet_0();
case -729571811: return bem_serializeToString_0();
case -842582618: return bem_isLocalGet_0();
case 1820417453: return bem_create_0();
case -1631955979: return bem_foreignClassesGet_0();
case -1443447938: return bem_directMethodsGet_0();
case 104713553: return bem_new_0();
case 2055025483: return bem_serializeContents_0();
}
return base.bemd_0(callHash, callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case -1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case -975449316: return bem_allTypesSet_1(bevd_0);
case -142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case -1749630715: return bem_signatureCheckedSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2085986815: return bem_integratedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case -300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case -831500365: return bem_isLocalSet_1(bevd_0);
case -480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1963510693: return bem_superListSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case -1620873726: return bem_foreignClassesSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return base.bemd_1(callHash, callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 104713555: return bem_new_2(bevd_0, bevd_1);
}
return base.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callHash) {
case -913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override byte[] bemc_clname() {
return becc_clname;
}
public override byte[] bemc_clfile() {
return becc_clfile;
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
}
