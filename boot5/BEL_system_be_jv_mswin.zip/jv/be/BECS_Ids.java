// Copyright 2015 Craig Welch
//
// Licensed under the MIT license. See LICENSE.txt file in the project root 
// for full license information.

package be;

import be.BEC_2_6_6_SystemObject;

import java.util.*;

public class BECS_Ids {
    
    public static Map<String, Integer> callIds;
    public static Map<Integer, String> idCalls;
    
    public static int callIdCounter;
    
}

